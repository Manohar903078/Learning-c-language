# programs 601-700
P = {}
def add(i, code, stdin=""): P[i] = (stdin, code.strip("\n"))

add(601, r'''
#include <stdio.h>

int main(void)
{
    int m[3][3] = {{4, 7, 1}, {9, 2, 6}, {3, 8, 5}};
    int i, j;
    printf("The matrix is:\n");
    for (i = 0; i < 3; i++) {
        for (j = 0; j < 3; j++) {
            printf("%4d", m[i][j]);
        }
        printf("\n");
    }
    return 0;
}
''')
add(602, r'''
#include <stdio.h>

int main(void)
{
    int a[2][3] = {{1, 2, 3}, {4, 5, 6}};
    int b[2][3] = {{9, 8, 7}, {6, 5, 4}};
    int s[2][3];
    int i, j;
    for (i = 0; i < 2; i++) {
        for (j = 0; j < 3; j++) {
            s[i][j] = a[i][j] + b[i][j];
        }
    }
    printf("A + B =\n");
    for (i = 0; i < 2; i++) {
        for (j = 0; j < 3; j++) {
            printf("%4d", s[i][j]);
        }
        printf("\n");
    }
    return 0;
}
''')
add(603, r'''
#include <stdio.h>

int main(void)
{
    int a[3][2] = {{10, 20}, {30, 40}, {50, 60}};
    int b[3][2] = {{1, 5}, {9, 13}, {17, 21}};
    int i, j;
    printf("A - B =\n");
    for (i = 0; i < 3; i++) {
        for (j = 0; j < 2; j++) {
            printf("%4d", a[i][j] - b[i][j]);
        }
        printf("\n");
    }
    return 0;
}
''')
add(604, r'''
#include <stdio.h>

int main(void)
{
    int a[2][3] = {{1, 2, 3}, {4, 5, 6}};
    int b[3][2] = {{7, 8}, {9, 10}, {11, 12}};
    int c[2][2] = {{0}};
    int i, j, k;
    for (i = 0; i < 2; i++) {
        for (j = 0; j < 2; j++) {
            for (k = 0; k < 3; k++) {
                c[i][j] += a[i][k] * b[k][j];
            }
        }
    }
    printf("A x B =\n");
    for (i = 0; i < 2; i++) {
        for (j = 0; j < 2; j++) {
            printf("%5d", c[i][j]);
        }
        printf("\n");
    }
    return 0;
}
''')
add(605, r'''
#include <stdio.h>

int main(void)
{
    int a[2][4] = {{1, 2, 3, 4}, {5, 6, 7, 8}};
    int t[4][2];
    int i, j;
    for (i = 0; i < 2; i++) {
        for (j = 0; j < 4; j++) {
            t[j][i] = a[i][j];
        }
    }
    printf("Transpose (4 x 2):\n");
    for (i = 0; i < 4; i++) {
        printf("%3d %3d\n", t[i][0], t[i][1]);
    }
    return 0;
}
''')
add(606, r'''
#include <stdio.h>

int main(void)
{
    int m[3][4] = {{3, 1, 4, 1}, {5, 9, 2, 6}, {5, 3, 5, 8}};
    int i, j, sum;
    for (i = 0; i < 3; i++) {
        sum = 0;
        for (j = 0; j < 4; j++) {
            sum += m[i][j];
        }
        printf("Sum of row %d = %d\n", i + 1, sum);
    }
    return 0;
}
''')
add(607, r'''
#include <stdio.h>

int main(void)
{
    int m[3][4] = {{2, 7, 1, 8}, {2, 8, 1, 8}, {2, 8, 4, 5}};
    int i, j, sum;
    for (j = 0; j < 4; j++) {
        sum = 0;
        for (i = 0; i < 3; i++) {
            sum += m[i][j];
        }
        printf("Sum of column %d = %d\n", j + 1, sum);
    }
    return 0;
}
''')
add(608, r'''
#include <stdio.h>

int main(void)
{
    int m[4][4] = {{1, 2, 3, 4}, {5, 6, 7, 8}, {9, 10, 11, 12}, {13, 14, 15, 16}};
    int i, sum = 0;
    for (i = 0; i < 4; i++) {
        sum += m[i][i];
    }
    printf("Main diagonal sum = %d\n", sum);
    return 0;
}
''')
add(609, r'''
#include <stdio.h>

int main(void)
{
    int m[4][4] = {{1, 2, 3, 4}, {5, 6, 7, 8}, {9, 10, 11, 12}, {13, 14, 15, 16}};
    int i, sum = 0;
    for (i = 0; i < 4; i++) {
        sum += m[i][3 - i];
    }
    printf("Secondary diagonal sum = %d\n", sum);
    return 0;
}
''')
add(610, r'''
#include <stdio.h>

int main(void)
{
    int rows, cols;
    printf("Enter rows and columns: ");
    scanf("%d %d", &rows, &cols);
    if (rows == cols) {
        printf("%d x %d is a square matrix.\n", rows, cols);
    } else {
        printf("%d x %d is not a square matrix.\n", rows, cols);
    }
    return 0;
}
''', "3 4")
add(611, r'''
#include <stdio.h>

int main(void)
{
    int m[3][3], i, j, identity = 1;
    printf("Enter 3x3 matrix (9 values): ");
    for (i = 0; i < 3; i++) {
        for (j = 0; j < 3; j++) {
            scanf("%d", &m[i][j]);
            if (i == j && m[i][j] != 1) {
                identity = 0;
            }
            if (i != j && m[i][j] != 0) {
                identity = 0;
            }
        }
    }
    printf(identity ? "It is an identity matrix.\n" : "It is not an identity matrix.\n");
    return 0;
}
''', "1 0 0 0 1 0 0 0 1")
add(612, r'''
#include <stdio.h>

int main(void)
{
    int m[3][3], i, j, diagonal = 1;
    printf("Enter 3x3 matrix (9 values): ");
    for (i = 0; i < 3; i++) {
        for (j = 0; j < 3; j++) {
            scanf("%d", &m[i][j]);
            if (i != j && m[i][j] != 0) {
                diagonal = 0;   /* any non-zero off-diagonal entry breaks it */
            }
        }
    }
    printf(diagonal ? "Diagonal matrix.\n" : "Not a diagonal matrix.\n");
    return 0;
}
''', "5 0 0 0 -3 0 0 0 8")
add(613, r'''
#include <stdio.h>

int main(void)
{
    int m[3][3], i, j, upper = 1;
    printf("Enter 3x3 matrix (9 values): ");
    for (i = 0; i < 3; i++) {
        for (j = 0; j < 3; j++) {
            scanf("%d", &m[i][j]);
            if (i > j && m[i][j] != 0) {
                upper = 0;   /* below the diagonal must be zero */
            }
        }
    }
    printf(upper ? "Upper triangular.\n" : "Not upper triangular.\n");
    return 0;
}
''', "1 2 3 0 4 5 7 0 6")
add(614, r'''
#include <stdio.h>

int main(void)
{
    int m[3][3], i, j, lower = 1;
    printf("Enter 3x3 matrix (9 values): ");
    for (i = 0; i < 3; i++) {
        for (j = 0; j < 3; j++) {
            scanf("%d", &m[i][j]);
            if (i < j && m[i][j] != 0) {
                lower = 0;   /* above the diagonal must be zero */
            }
        }
    }
    printf(lower ? "Lower triangular.\n" : "Not lower triangular.\n");
    return 0;
}
''', "2 0 0 3 5 0 1 4 9")
add(615, r'''
#include <stdio.h>

int main(void)
{
    int m[3][3], i, j, symmetric = 1;
    printf("Enter 3x3 matrix (9 values): ");
    for (i = 0; i < 3; i++) {
        for (j = 0; j < 3; j++) {
            scanf("%d", &m[i][j]);
        }
    }
    for (i = 0; i < 3; i++) {
        for (j = 0; j < i; j++) {
            if (m[i][j] != m[j][i]) {
                symmetric = 0;
            }
        }
    }
    printf(symmetric ? "Symmetric matrix.\n" : "Not symmetric.\n");
    return 0;
}
''', "1 7 3 7 4 -5 3 -5 6")
add(616, r'''
#include <stdio.h>

int main(void)
{
    int m[4][4] = {{0, 0, 3, 0}, {0, 0, 0, 0}, {5, 0, 0, 0}, {0, 0, 0, 1}};
    int i, j, zeros = 0, total = 16;
    for (i = 0; i < 4; i++) {
        for (j = 0; j < 4; j++) {
            if (m[i][j] == 0) {
                zeros++;
            }
        }
    }
    printf("Zeros = %d out of %d\n", zeros, total);
    if (zeros > total / 2) {
        printf("The matrix is sparse.\n");
    } else {
        printf("The matrix is not sparse.\n");
    }
    return 0;
}
''')
add(617, r'''
#include <stdio.h>

int main(void)
{
    int m[3][3] = {{14, -2, 33}, {8, 90, 5}, {-17, 41, 6}};
    int i, j, max = m[0][0], min = m[0][0];
    for (i = 0; i < 3; i++) {
        for (j = 0; j < 3; j++) {
            if (m[i][j] > max) {
                max = m[i][j];
            }
            if (m[i][j] < min) {
                min = m[i][j];
            }
        }
    }
    printf("Largest  = %d\nSmallest = %d\n", max, min);
    return 0;
}
''')
add(618, r'''
#include <stdio.h>

int main(void)
{
    int m[3][4] = {{11, 22, 33, 44}, {55, 66, 77, 88}, {99, 12, 13, 14}};
    int key, i, j, found = 0;
    printf("Enter value to search: ");
    scanf("%d", &key);
    for (i = 0; i < 3 && !found; i++) {
        for (j = 0; j < 4; j++) {
            if (m[i][j] == key) {
                printf("%d found at row %d, column %d\n", key, i + 1, j + 1);
                found = 1;
                break;
            }
        }
    }
    if (!found) {
        printf("%d not found.\n", key);
    }
    return 0;
}
''', "77")
add(619, r'''
#include <stdio.h>

int main(void)
{
    int m[3][3] = {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}};
    int i, j;
    printf("Row-major order: ");
    for (i = 0; i < 3; i++) {
        for (j = 0; j < 3; j++) {
            printf("%d ", m[i][j]);
        }
    }
    printf("\n");
    return 0;
}
''')
add(620, r'''
#include <stdio.h>

int main(void)
{
    int m[3][3] = {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}};
    int i, j;
    printf("Column-major order: ");
    for (j = 0; j < 3; j++) {
        for (i = 0; i < 3; i++) {
            printf("%d ", m[i][j]);
        }
    }
    printf("\n");
    return 0;
}
''')
add(621, r'''
#include <stdio.h>

int main(void)
{
    int m[3][4] = {{1, 2, 3, 4}, {5, 6, 7, 8}, {9, 10, 11, 12}};
    int top = 0, bottom = 2, left = 0, right = 3, i;
    printf("Spiral order: ");
    while (top <= bottom && left <= right) {
        for (i = left; i <= right; i++) {
            printf("%d ", m[top][i]);
        }
        top++;
        for (i = top; i <= bottom; i++) {
            printf("%d ", m[i][right]);
        }
        right--;
        if (top <= bottom) {
            for (i = right; i >= left; i--) {
                printf("%d ", m[bottom][i]);
            }
            bottom--;
        }
        if (left <= right) {
            for (i = bottom; i >= top; i--) {
                printf("%d ", m[i][left]);
            }
            left++;
        }
    }
    printf("\n");
    return 0;
}
''')
add(622, r'''
#include <stdio.h>

int main(void)
{
    int m[3][3] = {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}};
    int r[3][3], i, j;
    for (i = 0; i < 3; i++) {
        for (j = 0; j < 3; j++) {
            r[j][2 - i] = m[i][j];   /* element (i,j) moves to (j, n-1-i) */
        }
    }
    printf("Rotated 90 degrees clockwise:\n");
    for (i = 0; i < 3; i++) {
        printf("%d %d %d\n", r[i][0], r[i][1], r[i][2]);
    }
    return 0;
}
''')
add(623, r'''
#include <stdio.h>

int main(void)
{
    int m[3][3] = {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}};
    int r[3][3], i, j;
    for (i = 0; i < 3; i++) {
        for (j = 0; j < 3; j++) {
            r[2 - j][i] = m[i][j];   /* element (i,j) moves to (n-1-j, i) */
        }
    }
    printf("Rotated 90 degrees anticlockwise:\n");
    for (i = 0; i < 3; i++) {
        printf("%d %d %d\n", r[i][0], r[i][1], r[i][2]);
    }
    return 0;
}
''')
add(624, r'''
#include <stdio.h>

int main(void)
{
    int m[3][4] = {{1, 2, 3, 4}, {5, 6, 7, 8}, {9, 10, 11, 12}};
    int i, j, tmp;
    for (i = 0; i < 3; i++) {
        for (j = 0; j < 2; j++) {
            tmp = m[i][j];
            m[i][j] = m[i][3 - j];
            m[i][3 - j] = tmp;
        }
    }
    printf("Each row reversed:\n");
    for (i = 0; i < 3; i++) {
        for (j = 0; j < 4; j++) {
            printf("%3d", m[i][j]);
        }
        printf("\n");
    }
    return 0;
}
''')
add(625, r'''
#include <stdio.h>

int main(void)
{
    int m[3][4] = {{9, 3, 7, 1}, {8, 2, 6, 4}, {5, 12, 0, 10}};
    int i, j, k, tmp;
    for (i = 0; i < 3; i++) {
        for (j = 0; j < 3; j++) {
            for (k = 0; k < 3 - j; k++) {
                if (m[i][k] > m[i][k + 1]) {
                    tmp = m[i][k];
                    m[i][k] = m[i][k + 1];
                    m[i][k + 1] = tmp;
                }
            }
        }
    }
    printf("Rows sorted ascending:\n");
    for (i = 0; i < 3; i++) {
        for (j = 0; j < 4; j++) {
            printf("%3d", m[i][j]);
        }
        printf("\n");
    }
    return 0;
}
''')
