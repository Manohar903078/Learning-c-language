# programs 701-800
P = {}
def add(i, code, stdin=""): P[i] = (stdin, code.strip("\n"))

add(701, r'''
#include <stdio.h>

int add(int a, int b)
{
    return a + b;
}

int main(void)
{
    printf("add(7, 5) = %d\n", add(7, 5));
    printf("add(-3, 10) = %d\n", add(-3, 10));
    return 0;
}
''')
add(702, r'''
#include <stdio.h>

int maxOfTwo(int a, int b)
{
    return (a > b) ? a : b;
}

int main(void)
{
    printf("Max of 14 and 9 is %d\n", maxOfTwo(14, 9));
    printf("Max of -4 and -8 is %d\n", maxOfTwo(-4, -8));
    return 0;
}
''')
add(703, r'''
#include <stdio.h>

int maxOfThree(int a, int b, int c)
{
    int m = a;
    if (b > m) {
        m = b;
    }
    if (c > m) {
        m = c;
    }
    return m;
}

int main(void)
{
    printf("Max of 3, 17, 8 is %d\n", maxOfThree(3, 17, 8));
    printf("Max of 40, 2, 40 is %d\n", maxOfThree(40, 2, 40));
    return 0;
}
''')
add(704, r'''
#include <stdio.h>

unsigned long long factorial(int n)
{
    unsigned long long result = 1;
    for (int i = 2; i <= n; i++) {
        result *= i;
    }
    return result;
}

int main(void)
{
    for (int n = 0; n <= 10; n += 2) {
        printf("%2d! = %llu\n", n, factorial(n));
    }
    return 0;
}
''')
add(705, r'''
#include <stdio.h>

int isPrime(int n)
{
    if (n < 2) {
        return 0;
    }
    for (int i = 2; i * i <= n; i++) {
        if (n % i == 0) {
            return 0;
        }
    }
    return 1;
}

int main(void)
{
    int tests[] = {1, 2, 15, 17, 29, 91};
    for (int i = 0; i < 6; i++) {
        printf("%d is %s\n", tests[i], isPrime(tests[i]) ? "prime" : "not prime");
    }
    return 0;
}
''')
add(706, r'''
#include <stdio.h>

int gcd(int a, int b)
{
    while (b != 0) {
        int t = a % b;
        a = b;
        b = t;
    }
    return a;
}

int main(void)
{
    printf("gcd(48, 18) = %d\n", gcd(48, 18));
    printf("gcd(100, 75) = %d\n", gcd(100, 75));
    printf("gcd(17, 5) = %d\n", gcd(17, 5));
    return 0;
}
''')
add(707, r'''
#include <stdio.h>

int gcd(int a, int b)
{
    return (b == 0) ? a : gcd(b, a % b);
}

long long lcm(int a, int b)
{
    return (long long)a / gcd(a, b) * b;
}

int main(void)
{
    printf("lcm(4, 6) = %lld\n", lcm(4, 6));
    printf("lcm(21, 6) = %lld\n", lcm(21, 6));
    printf("lcm(8, 9) = %lld\n", lcm(8, 9));
    return 0;
}
''')
add(708, r'''
#include <stdio.h>

int reverseInt(int n)
{
    int rev = 0;
    while (n != 0) {
        rev = rev * 10 + n % 10;
        n /= 10;
    }
    return rev;
}

int main(void)
{
    printf("Reverse of 12345 = %d\n", reverseInt(12345));
    printf("Reverse of 9870 = %d\n", reverseInt(9870));
    printf("Reverse of -402 = %d\n", reverseInt(-402));
    return 0;
}
''')
add(709, r'''
#include <stdio.h>

int sumDigits(int n)
{
    int sum = 0;
    if (n < 0) {
        n = -n;
    }
    while (n > 0) {
        sum += n % 10;
        n /= 10;
    }
    return sum;
}

int main(void)
{
    printf("Sum of digits of 2024 = %d\n", sumDigits(2024));
    printf("Sum of digits of 999 = %d\n", sumDigits(999));
    printf("Sum of digits of 0 = %d\n", sumDigits(0));
    return 0;
}
''')
add(710, r'''
#include <stdio.h>

int isPalindrome(int n)
{
    int original = n, rev = 0;
    if (n < 0) {
        return 0;
    }
    while (n > 0) {
        rev = rev * 10 + n % 10;
        n /= 10;
    }
    return rev == original;
}

int main(void)
{
    int tests[] = {121, 1331, 123, 7, 1220};
    for (int i = 0; i < 5; i++) {
        printf("%d -> %s\n", tests[i], isPalindrome(tests[i]) ? "palindrome" : "not a palindrome");
    }
    return 0;
}
''')
add(711, r'''
#include <stdio.h>

int isArmstrong(int n)
{
    int digits = 0, temp = n, sum = 0;
    while (temp > 0) {
        digits++;
        temp /= 10;
    }
    temp = n;
    while (temp > 0) {
        int d = temp % 10;
        int p = 1;
        for (int i = 0; i < digits; i++) {
            p *= d;
        }
        sum += p;
        temp /= 10;
    }
    return n > 0 && sum == n;
}

int main(void)
{
    int tests[] = {153, 370, 371, 100, 9474, 123};
    for (int i = 0; i < 6; i++) {
        printf("%d: %s\n", tests[i], isArmstrong(tests[i]) ? "Armstrong" : "not Armstrong");
    }
    return 0;
}
''')
add(712, r'''
#include <stdio.h>

long long power(int base, int exp)
{
    long long result = 1;
    for (int i = 0; i < exp; i++) {
        result *= base;
    }
    return result;
}

int main(void)
{
    printf("2^10 = %lld\n", power(2, 10));
    printf("3^5 = %lld\n", power(3, 5));
    printf("7^0 = %lld\n", power(7, 0));
    printf("(-2)^7 = %lld\n", power(-2, 7));
    return 0;
}
''')
add(713, r'''
#include <stdio.h>

void swap(int *a, int *b)
{
    int temp = *a;
    *a = *b;
    *b = temp;
}

int main(void)
{
    int x = 10, y = 25;
    printf("Before: x = %d, y = %d\n", x, y);
    swap(&x, &y);
    printf("After:  x = %d, y = %d\n", x, y);
    return 0;
}
''')
add(714, r'''
#include <stdio.h>

void tryToChange(int n)
{
    n = n * 100;                       /* changes only the local copy */
    printf("Inside function: n = %d\n", n);
}

int main(void)
{
    int value = 6;
    printf("Before call: value = %d\n", value);
    tryToChange(value);
    printf("After call:  value = %d (unchanged)\n", value);
    return 0;
}
''')
add(715, r'''
#include <stdio.h>

void rectangleInfo(int w, int h, int *area, int *perimeter)
{
    *area = w * h;
    *perimeter = 2 * (w + h);
}

void incrementBoth(int *a, int *b)
{
    (*a)++;
    (*b)++;
}

int main(void)
{
    int area, perimeter, p = 3, q = 8;
    rectangleInfo(7, 4, &area, &perimeter);
    printf("Area = %d, Perimeter = %d\n", area, perimeter);
    incrementBoth(&p, &q);
    printf("p = %d, q = %d\n", p, q);
    return 0;
}
''')
add(716, r'''
#include <stdio.h>

int largest(const int arr[], int n)
{
    int max = arr[0];
    for (int i = 1; i < n; i++) {
        if (arr[i] > max) {
            max = arr[i];
        }
    }
    return max;
}

int main(void)
{
    int data[] = {12, 45, -7, 88, 31, 60};
    printf("Largest element = %d\n", largest(data, 6));
    return 0;
}
''')
add(717, r'''
#include <stdio.h>

double average(const int arr[], int n)
{
    int sum = 0;
    for (int i = 0; i < n; i++) {
        sum += arr[i];
    }
    return (double)sum / n;
}

int main(void)
{
    int marks[] = {78, 85, 92, 66, 70};
    printf("Average = %.2f\n", average(marks, 5));
    return 0;
}
''')
add(718, r'''
#include <stdio.h>
#include <ctype.h>

int countVowels(const char *s)
{
    int count = 0;
    for (int i = 0; s[i] != '\0'; i++) {
        char c = (char)tolower((unsigned char)s[i]);
        if (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u') {
            count++;
        }
    }
    return count;
}

int main(void)
{
    printf("\"Programming\" has %d vowels\n", countVowels("Programming"));
    printf("\"Rhythm\" has %d vowels\n", countVowels("Rhythm"));
    printf("\"EDUCATION\" has %d vowels\n", countVowels("EDUCATION"));
    return 0;
}
''')
add(719, r'''
#include <stdio.h>
#include <string.h>

void reverseString(char *s)
{
    int i = 0, j = (int)strlen(s) - 1;
    while (i < j) {
        char t = s[i];
        s[i] = s[j];
        s[j] = t;
        i++;
        j--;
    }
}

int main(void)
{
    char text[] = "hello world";
    printf("Original: %s\n", text);
    reverseString(text);
    printf("Reversed: %s\n", text);
    return 0;
}
''')
add(720, r'''
#include <stdio.h>

void sortArray(int arr[], int n)
{
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - 1 - i; j++) {
            if (arr[j] > arr[j + 1]) {
                int t = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = t;
            }
        }
    }
}

int main(void)
{
    int a[] = {29, 4, 51, 12, 8, 37};
    sortArray(a, 6);
    printf("Sorted:");
    for (int i = 0; i < 6; i++) {
        printf(" %d", a[i]);
    }
    printf("\n");
    return 0;
}
''')
add(721, r'''
#include <stdio.h>

int contains(const int arr[], int n, int key)
{
    for (int i = 0; i < n; i++) {
        if (arr[i] == key) {
            return 1;
        }
    }
    return 0;
}

int main(void)
{
    int a[] = {5, 18, 23, 41, 56};
    int keys[] = {23, 40};
    for (int i = 0; i < 2; i++) {
        printf("%d %s in the array\n", keys[i], contains(a, 5, keys[i]) ? "is found" : "is not found");
    }
    return 0;
}
''')
add(722, r'''
#include <stdio.h>

void addMatrices(int a[2][3], int b[2][3], int c[2][3])
{
    for (int i = 0; i < 2; i++) {
        for (int j = 0; j < 3; j++) {
            c[i][j] = a[i][j] + b[i][j];
        }
    }
}

int main(void)
{
    int a[2][3] = {{1, 2, 3}, {4, 5, 6}};
    int b[2][3] = {{7, 8, 9}, {1, 1, 1}};
    int c[2][3];
    addMatrices(a, b, c);
    printf("Sum matrix:\n");
    for (int i = 0; i < 2; i++) {
        for (int j = 0; j < 3; j++) {
            printf("%4d", c[i][j]);
        }
        printf("\n");
    }
    return 0;
}
''')
