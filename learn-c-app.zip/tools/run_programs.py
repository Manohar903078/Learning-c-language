import json, subprocess, tempfile, os, sys, importlib
sys.path.insert(0, os.path.dirname(__file__))
progs = {}
for mod in ["prog_a", "prog_b"]:
    progs.update(importlib.import_module(mod).P)
q = {x["id"]: x for x in json.load(open("../data/practice_q.json"))["items"]}
out, bad = [], []
for i in sorted(progs):
    stdin, code = progs[i]
    with tempfile.TemporaryDirectory() as d:
        src = os.path.join(d, "a.c"); exe = os.path.join(d, "a.out")
        open(src, "w").write(code + "\n")
        c = subprocess.run(["gcc", "-std=gnu99", "-Wall", "-Wextra", "-o", exe, src, "-lm"], capture_output=True, text=True)
        if c.returncode != 0 or c.stderr.strip():
            bad.append((i, c.stderr[:300]))
        if c.returncode != 0: continue
        r = subprocess.run([exe], input=stdin, capture_output=True, text=True, timeout=5)
        out.append({"id": i, "q": q[i]["q"], "topic": q[i]["topic"], "code": code, "stdin": stdin, "output": r.stdout})
print("compiled", len(out), "of", len(progs), "| warnings/errors:", len(bad))
for i, e in bad: print(i, e)
json.dump(out, open("../data/programs.json", "w"), ensure_ascii=False)
