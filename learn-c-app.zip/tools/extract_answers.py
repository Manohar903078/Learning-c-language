import re, json, sys
src = sys.argv[1]; out = "data/interview_a.json"
qs = {x["id"]: x["q"] for x in json.load(open("data/interview_q.json"))["items"]}
lines = []
for ln in open(src, encoding="utf-8").read().split("\n"):
    if re.match(r"^\s*C Programming . Simple English Answer Book", ln): continue
    lines.append(ln.rstrip())
items = {}; cur = None; mode = None
for ln in lines:
    s = ln.strip()
    m = re.match(r"^Q(\d{1,4})\.\s+(.*)$", s)
    if m:
        cur = int(m.group(1)); items[cur] = {"q": m.group(2), "a": ""}; mode = "q"; continue
    if cur is None: continue
    m = re.match(r"^Answer:\s*(.*)$", s)
    if m: items[cur]["a"] = m.group(1); mode = "a"; continue
    if not s: mode = None if mode == "a" else mode; continue
    if re.match(r"^\d{1,2}\.\s+[A-Z]", s) and mode is None: continue          # section heading
    if mode == "q": items[cur]["q"] += " " + s
    elif mode == "a": items[cur]["a"] += " " + s
    # lines in other states are headings -> ignored
ids = sorted(items)
print("parsed", len(ids), "first", ids[:3], "last", ids[-3:])
missing = [i for i in range(1, 2001) if i not in items]; print("missing ids:", missing[:20], len(missing))
norm = lambda t: re.sub(r"\W+", "", t).lower()
bad = [i for i in ids if i in qs and norm(items[i]["q"]) != norm(qs[i])]
print("question text differs from our list:", len(bad), bad[:10])
empty = [i for i in ids if not items[i]["a"].strip()]; print("empty answers:", empty[:10], len(empty))
ans = {str(i): re.sub(r"\s+", " ", items[i]["a"]).strip() for i in ids}
json.dump(ans, open(out, "w"), ensure_ascii=False)
import collections; c = collections.Counter(ans.values()); print("distinct answers:", len(c), "of", len(ans)); print(c.most_common(2))
