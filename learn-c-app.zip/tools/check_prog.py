#!/usr/bin/env python3
"""Compile + run every program of a module (tools/prog_X.py defines P = {id: (stdin, code)}).
Usage: python3 tools/check_prog.py prog_c [first_id last_id]
Fails (non-zero exit) when a program has a warning, error, non-zero exit, timeout, empty or non-deterministic output."""
import json, subprocess, tempfile, os, sys, importlib, concurrent.futures as cf
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
mod = sys.argv[1]; P = importlib.import_module(mod).P
lo = int(sys.argv[2]) if len(sys.argv) > 2 else 0; hi = int(sys.argv[3]) if len(sys.argv) > 3 else 10**9
q = {x["id"]: x["q"] for x in json.load(open(os.path.join(HERE, "../data/practice_q.json")))["items"]}
def one(i):
    stdin, code = P[i]; issues = []
    with tempfile.TemporaryDirectory() as d:
        src, exe = os.path.join(d, "a.c"), os.path.join(d, "a.out"); open(src, "w").write(code + "\n")
        c = subprocess.run(["gcc", "-std=gnu99", "-Wall", "-Wextra", "-o", exe, src, "-lm"], capture_output=True, text=True)
        if c.returncode != 0: return {"id": i, "issues": ["COMPILE ERROR: " + c.stderr[:300]]}
        if c.stderr.strip(): issues.append("WARNING: " + c.stderr[:300])
        outs = []
        for _ in range(2):
            try: r = subprocess.run([exe], input=stdin, capture_output=True, text=True, timeout=5, cwd=d)
            except subprocess.TimeoutExpired: return {"id": i, "issues": issues + ["TIMEOUT (waiting for more input or infinite loop?)"]}
            if r.returncode != 0: issues.append(f"EXIT CODE {r.returncode}")
            outs.append(r.stdout)
        if outs[0] != outs[1]: issues.append("NON-DETERMINISTIC OUTPUT")
        if not outs[0].strip(): issues.append("EMPTY OUTPUT")
        if len(outs[0]) > 4000: issues.append("OUTPUT TOO LONG (>4000 chars)")
        return {"id": i, "q": q.get(i, ""), "code": code, "stdin": stdin, "output": outs[0], "issues": issues}
ids = sorted(k for k in P if lo <= k <= hi)
with cf.ThreadPoolExecutor(8) as ex: res = list(ex.map(one, ids))
json.dump(res, open(os.path.join(HERE, "out", mod + ".json"), "w"), ensure_ascii=False)
bad = [r for r in res if r["issues"]]
print(f"{mod}: {len(res)} programs, {len(res) - len(bad)} clean, {len(bad)} with problems")
for r in bad: print(" ", r["id"], "|", "; ".join(r["issues"])[:260].replace("\n", " "))
sys.exit(1 if bad else 0)
