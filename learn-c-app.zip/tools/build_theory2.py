import re, json, html, sys
sys.path.insert(0, "/home/claude/app/tools")
from diagrams import D as DG

SRC = "/mnt/user-data/uploads/new_c_2016-1_docx.txt"
L = open(SRC, encoding="utf-8").read().split("\n")
OLD = {t["id"]: t for t in json.load(open("/home/claude/app/data/theory.json"))}   # keeps titles, icons, quizzes

RANGES = {1: (7, 114), 2: (115, 171), 3: (172, 297), 4: (298, 397), 5: (398, 545), 6: (546, 658), 7: (659, 724), 8: (725, 754), 9: (755, 987),
          10: (988, 1121), 11: (1122, 1239), 12: (1240, 1325), 13: (1326, 1529), 14: (1530, 1615), 15: (1616, 1653), 16: (1654, 1923),
          17: (1924, 2212), 18: (2213, 2391), 19: (2392, 2507), 20: (2508, len(L))}

SUBS = [(r"SSS-BDPS Computer Education, JPT", "LearnC Academy"), (r"BDPS-SRI SAI SADGURU COMPUTER EDUCATION, JPT", "LEARNC ACADEMY, CITY"),
        (r"sri sai sadguru computer education point", "learnc academy c programming course here"), (r"BDPS Computers, JPT", "LearnC Computers, CITY"),
        (r"BDPS Computer Education, Jaggaiahpet", "LearnC Computer Education, City"), (r"BDPS \\n COMPUTER \\n EDUCATION", "LEARNC \\n COMPUTER \\n EDUCATION"),
        (r"BPDS", "LEARNC"), (r"Bdps", "Learnc"), (r"BDPS", "LEARNC"), (r"bdps", "learnc"), (r"Jaggaiahpet", "City"), (r"jaggaiahpet", "city"),
        (r"\bJPT\b", "CITY"), (r"\bjpt\b", "city"), (r"\bA\.P\b", "IN")]
def rebrand(t):
    for a, b in SUBS: t = re.sub(a, b, t)
    return t
def esc(s): return html.escape(s, quote=False)
def inl(s):
    s = esc(s)
    s = re.sub(r"\*\*\s*(.+?)\s*\*\*(?=[A-Za-z])", r"<b>\1</b> ", s)
    s = re.sub(r"\*\*\s*(.+?)\s*\*\*", r"<b>\1</b>", s)
    return s.replace("**", "")

def prep(lines):
    out = []
    for ln in lines:
        ln = ln.rstrip().replace(" ", " ")
        if re.search(r"Page \*{0,2}\d+\*{0,2} of \*{0,2}\d+", ln): continue
        ln = re.sub(r"\[([^\]]+)\]\(http[^)]*\)", r"\1", ln)
        if not re.search(r"\b(int|char|float|double|long)\s+\*{3,}\w", ln): ln = ln.replace("****", "")
        ln = re.sub(r"[ \t]{40,}", "  ", ln)
        mh = re.match(r"^\s*#{1,6}\s+(?!include|define)(.+)$", ln)
        if mh: ln = "**" + mh.group(1).strip().strip("*").strip() + "**"
        ln = rebrand(ln).replace("t = &t;", "t = &d;")
        out.append(ln)
    return out

CODE = re.compile(r"""^\s*(\#\s*(include|define)|(void|int|float|char|double|long|short|unsigned|signed|struct|union|enum|typedef|static|auto|register|extern|const|datatype|size_t)\b[^:]*[;{)\]]\s*(//.*)?$|printf\s*\(|scanf\s*\(|puts\s*\(|gets\s*\(|clrscr|getch\s*\(|for\s*\(|while\s*\(|do\s*$|if\s*\(|else\b|switch\s*\(|case\b.*:|default\s*:|return\b.*;|break;|continue;|goto\b|\{\s*$|\}.*$|//|/\*|<[a-z_ ]+>\s+\*?[a-z_<>]|[A-Za-z_][\w\.\[\]\*>\-()]*\s*(=|\+=|-=|\+\+|--)[^;]*;|[A-Za-z_]\w*\s*\(.*\)\s*;?\s*(//.*)?$|\(\*\w+\)\.\w+\s*;|[A-Za-z_]+(\s[a-z]+)?\s*=\s*\(.*\)\s*\w+\(.*\)\s*;\s*$|[a-z]\w*(\.\w+)+\s*[,;]|-\s-\s-|(int|char|float|double)\s+\*+\w+\s*(;\s*)?->|(struct|union|enum)\s+\*{0,2}\w+\*{0,2}\s*$|[A-Za-z_][\w\.\[\]>\-]*\s*;\s*$|<[\w_ ]+>[^.]*[;)]\s*$|(…+|\.{3,}|\u2026+)\s*$)""", re.X)
LABEL = re.compile(r"^\s*(Eg|e\.g\.?|ex|Example|Syntax|Sy|Program\s*\d?|Instance\s*\d|Initialization|Declaration|Form\s*\d|Basic Syntax)(?:\s*:-?\s*|\s*-\s*|\s*$)(.*)$", re.I)
OUT = re.compile(r"^\s*(output)\s*(:|->)\s*-?>?\s*(.*)$", re.I)
UPPER = re.compile(r"^[A-Z][A-Z0-9 \(\)/&\-,.:']{3,}$")

def isbold_line(s):
    m = re.match(r"^\*\*\s*(.+?)\s*\*\*\s*[:\-]*\s*$", s)
    return m if m and "**" not in m.group(1) else None

def expand(num, text):
    parts = re.split(r"\s+(?=\d+\.\s*[A-Za-z])", text.strip())
    if len(parts) == 1: return [(num, text)]
    out = [(num, parts[0])]
    for p_ in parts[1:]:
        m = re.match(r"^(\d+)\.\s*(.*)$", p_); out.append((m.group(1), m.group(2)) if m else ("", p_))
    return out
def table(rows, head=None, cls="nt"):
    if head and len(head) >= 4: cls += " wide"
    h = "<div class=\"tw\"><table class=\"%s\">" % cls
    if head: h += "<thead><tr>" + "".join(f"<th>{inl(c)}</th>" for c in head) + "</tr></thead>"
    h += "<tbody>" + "".join("<tr>" + "".join(f"<td>{inl(c)}</td>" for c in r) + "</tr>" for r in rows) + "</tbody></table></div>"
    return h

def reindent(ls):
    if not any("{" in x or "}" in x for x in ls): return None
    out = []; depth = 0; pend = 0; incase = False
    for raw in ls:
        st = raw.strip()
        if not st: continue
        bare = re.sub(r'"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'', "", re.sub(r"//.*$", "", st))
        d = depth
        if st.startswith("}"): d -= 1; incase = False
        is_case = bool(re.match(r"^(case\b.*:|default\s*:)", st))
        lvl = max(d, 0) + (1 if incase and not is_case and not st.startswith("}") else 0) + (pend if not st.startswith("{") else 0)
        out.append("    " * lvl + st)
        depth += bare.count("{") - bare.count("}")
        if is_case: incase = True
        pend = 1 if (re.match(r"^(if|else if|for|while)\s*\(.*\)\s*$", bare) or bare == "else" or bare == "do") else 0
    return "\n".join(out)
def _dedent(ls):
    r = reindent([x for x in ls if x.strip()]) if ls else None
    if r is not None: return r
    ind = min((len(x) - len(x.lstrip()) for x in ls if x.strip()), default=0)
    return "\n".join(x[ind:].rstrip() for x in ls).strip("\n")
def _comment_gaps(line):
    # code followed by a wide gap and prose -> turn the prose into a trailing comment
    m0 = re.match(r"^(\s*\S.*?[;\w\)])\s+->\s+(\S.*)$", line)
    if m0 and "//" not in line: return f"{m0.group(1)}    // {m0.group(2).strip()}"
    m = re.match(r"^(\s*\S.*?\S)\s{6,}(\S.*)$", line)
    if m and "//" not in line and not CODE.match(m.group(2)) and not re.match(r"^\s*\{", m.group(2)): return f"{m.group(1)}    // {m.group(2).strip()}"
    return line
def code_html(lines):
    lines = [re.sub(r"\*\*([A-Za-z_][A-Za-z_ ]*?)\s*\*\*", r"\1", x) for x in lines]
    colre = re.compile(r"^(\s*\S.*?)\t{2,}\s*(\S.*)$")
    nonempty = [x for x in lines if x.strip()]
    split = [colre.match(x) for x in nonempty]
    if nonempty and sum(1 for m in split if m) >= max(2, 0.35 * len(nonempty)):
        first_right = next(m.group(2) for m in split if m)
        A, B = [], []
        if CODE.match(first_right):                       # two side-by-side examples
            for x in lines:
                m = colre.match(x)
                if not x.strip(): continue
                if m:
                    A.append(m.group(1).expandtabs(4))
                    r = m.group(2).expandtabs(4)
                    if CODE.match(r) or not B: B.append(r)
                    else: B[-1] += "    // " + r.strip()
                else: A.append(x.expandtabs(4))
            A = [_comment_gaps(x) for x in A]; B = [_comment_gaps(x) for x in B]
            return f'<div class="two"><pre class="code" data-hl>{esc(_dedent(A))}</pre><pre class="code" data-hl>{esc(_dedent(B))}</pre></div>'
        out = []
        for x in lines:
            m = colre.match(x)
            out.append(f"{m.group(1).expandtabs(4)}    // {m.group(2).strip()}" if m else x.expandtabs(4))
        return f'<pre class="code" data-hl>{esc(_dedent([_comment_gaps(x) for x in out if x.strip()]))}</pre>'
    out = [_comment_gaps(x.expandtabs(4)) for x in lines]
    if not any("{" in x or "}" in x for x in out): out = [x.strip() for x in out]
    txt = re.sub(r"\n{2,}", "\n", "\n".join(out))
    return f'<pre class="code" data-hl>{esc(_dedent(txt.split(chr(10))))}</pre>'

def parse(tid, lines):
    out = []; i = 0; n = len(lines)
    def nxt(j):
        while j < n and not lines[j].strip(): j += 1
        return j
    def add(h): out.append(h)
    anchors = ANCH.get(tid, [])
    for k in range(n):
        plain = re.sub(r"\*\*\s*([A-Za-z_][\w ]*\)?)\s*\*\*", r"\1", lines[k])
        if plain != lines[k] and CODE.match(plain) and not isbold_line(lines[k].strip()): lines[k] = plain
    while i < n:
        ln = lines[i]; s = ln.strip()
        if not s: i += 1; continue
        plain = re.sub(r"\*\*\s*([A-Za-z_][A-Za-z_ ]*?)\s*\*\*", r"\1", ln)
        if plain != ln and CODE.match(plain) and not OUT.match(plain): lines[i] = ln = plain; s = ln.strip()
        # ---------- anchored diagrams / special regions ----------
        if tid == 1 and re.match(r"^Starting or Stopping", s):
            add(DG["flow_symbols"]); i += 1
            while i < n and re.match(r"^\s*(Input / Output spec|Logical or Arith|Indicates|Indicate|$)", lines[i]): i += 1
            continue
        if tid == 3 and re.match(r"^Documentation Section$", s) and i + 2 < n and "Header files declarations" in lines[nxt(i + 1)]:
            add(DG["structure"])
            while i < n and not re.match(r"^Documentation Section$", lines[i].strip()) or (i < n and i == 0): i += 1
            # skip the raw structure lines up to the "(user-defined function)" line
            while i < n and "(user-defined function)" not in lines[i]: i += 1
            i += 1; continue
        if tid == 4 and re.match(r"^\s*Character\s+Escape sequence", ln.expandtabs(4)):
            rows = []; i += 1
            while i < n:
                m = re.match(r"^\s*([A-Za-z][A-Za-z \(\)]*?)\s{2,}(\\\S+)\s+(\d{3})\s*$", lines[i].expandtabs(4))
                if m: rows.append([m.group(1).strip(), f"<code>{esc(m.group(2))}</code>".replace("&lt;", "<"), m.group(3)])
                elif lines[i].strip(): break
                i += 1
            h = '<div class="tw"><table class="nt"><thead><tr><th>Character</th><th>Escape sequence</th><th>ASCII value</th></tr></thead><tbody>' + "".join(f"<tr><td>{a}</td><td>{b}</td><td>{c}</td></tr>" for a, b, c in rows) + "</tbody></table></div>"
            add(h); continue
        if tid == 5 and re.match(r"^\s*Constants\s+values", ln.expandtabs(4)):
            rows = []; i += 1
            while i < n:
                m = re.match(r"^\s*(.+?)\s{2,}(\d+(?:\s*-\s*\d+)?)\s*$", lines[i].expandtabs(4))
                if m: rows.append([m.group(1).strip(), m.group(2).strip()])
                elif lines[i].strip(): break
                i += 1
            add(table(rows, ["Constants", "Values"])); continue
        if tid == 6 and re.match(r"^Data types , Format specifiers", s):
            add(f'<p>{inl(s)}</p>')
            rows = [["unsigned char", "%c", "1 byte", "0 to 255"], ["char", "%c", "1 byte", "-128 to +127"], ["int", "%d", "2 bytes", "-32,768 to 32,767"],
                    ["unsigned int", "%u", "2 bytes", "0 to 65,535"], ["long int", "%ld", "4 bytes", "-214,74,83,648 to 214,74,83,647"],
                    ["unsigned long int", "%lu", "4 bytes", "0 to 429,49,67,295"], ["float", "%f", "4 bytes", "3.4 × 10<sup>-38</sup> to 3.4 × 10<sup>38</sup>"],
                    ["double", "%lf", "8 bytes", "1.7 × 10<sup>-308</sup> to 1.7 × 10<sup>308</sup>"], ["long double", "%Lf", "10 bytes", "3.4 × 10<sup>-4932</sup> to 1.1 × 10<sup>4932</sup>"],
                    ["char [ ] (string)", "%s", "—", "—"]]
            h = '<div class="tw"><table class="nt wide"><thead><tr><th>Data type</th><th>Format specifier</th><th>Memory size</th><th>Accessibility range</th></tr></thead><tbody>'
            h += "".join("<tr>" + "".join(f"<td>{c if '<sup>' in c else esc(c)}</td>" for c in r) + "</tr>" for r in rows) + "</tbody></table></div>"
            add(h); break
        if tid == 9 and re.match(r"^Truth table for bitwise", s, re.I):
            name = re.search(r"bitwise\s+(\w+)", s, re.I).group(1).title()
            i += 1; rows = []
            while i < n:
                m = re.match(r"^\s*([01])\s+([01])\s+([01])\s*$", lines[i].expandtabs(4))
                if m: rows.append(list(m.groups()))
                elif re.match(r"^\s*(High|Input|$)", lines[i].expandtabs(4)): pass
                else: break
                i += 1
            add(f'<p class="lbl">Truth table for bitwise {name}</p>' + table(rows, ["Input 1", "Input 2", "Output"], "nt tt")); continue
        if tid == 17 and re.match(r"^\s*Function Name\s+Description", ln):
            rows = []; i += 1
            while i < n:
                l2 = lines[i]
                if not l2.strip(): i += 1; continue
                m = re.match(r"^\s*([\w\(\),]+)\s*-\s*(.*)$", l2.replace("\t", " "))
                if l2[:1] in ("\t", " ") and m: rows.append([m.group(1), re.sub(r"\s+", " ", m.group(2)).strip()])
                elif l2[:1] in ("\t", " ") and rows: rows[-1][1] += " " + re.sub(r"\s+", " ", l2).strip()
                else: break
                i += 1
            add('<div class="tw"><table class="nt"><thead><tr><th>Function name</th><th>Description</th></tr></thead><tbody>' + "".join(f"<tr><td><code>{esc(a)}</code></td><td>{inl(b)}</td></tr>" for a, b in rows) + "</tbody></table></div>"); continue
        # ---------- markdown tables ----------
        if s.startswith("|"):
            rows = []
            while i < n and lines[i].strip().startswith("|"):
                cells = [c.strip() for c in lines[i].strip().strip("|").split("|")]
                if all(re.fullmatch(r"-{3,}|:?-+:?", c) for c in cells if c): i += 1; continue
                if any(cells): rows.append(cells)
                i += 1
            add(md_table(rows)); continue
        # ---------- output boxes ----------
        m = OUT.match(ln)
        if m and not re.match(r"^\s*output\s*:-", ln, re.I):
            first = m.group(3).strip(); body = [first] if first else []; i += 1
            lim = 0
            while i < n and lim < 8:
                l2 = lines[i]
                if not l2.strip(): i += 1; continue
                if isbold_line(l2.strip()) or re.match(r"^\s*(Program|Syntax|Eg|Note|WAP|Features|Advantages)\b", l2): break
                if l2[:1] in (" ", "\t") or "value :" in l2 or re.match(r"^\S+.*", l2) and (first == "" and lim < 4 and not CODE.match(l2) and len(l2) < 70 and "Output" not in l2 and not re.match(r"^[A-Z][a-z]+ [a-z]+ [a-z]+", l2)):
                    if CODE.match(l2) and l2[:1] not in (" ", "\t"): break
                    body.append(l2.expandtabs(4).strip()); i += 1; lim += 1
                else: break
            if body: add('<div class="outbox"><span>Output</span><pre>' + esc("\n".join(body)) + "</pre></div>")
            continue
        if s in SUBHEAD.get(tid, ()):
            add(f'<h4 class="nh2">{esc(s)}</h4>'); i += 1; continue
        # ---------- keyboard keys table ----------
        if tid == 3 and s.startswith("Common  keys") or tid == 3 and s.startswith("Common keys"):
            add(f"<p>{inl(s)}</p>"); i += 1; rows = []
            while i < n:
                l2 = lines[i]
                if not l2.strip(): i += 1; continue
                m2 = re.match(r"^\s*((?:Alt|F\d)[^\t>→]*?)\s*(?:->|→|\t)\s*(.*)$", l2) or re.match(r"^\s*((?:Alt|F\d)\S*)\s{2,}(.*)$", l2)
                if not m2: break
                key = re.sub(r"\s+", " ", m2.group(1)).strip(); rest = re.split(r"\t+|\s{3,}", m2.group(2).strip(), maxsplit=1)
                rows.append([key, rest[0].strip(), rest[1].strip() if len(rest) > 1 else ""]); i += 1
            add(table(rows, ["Keys", "Action", "Description"]).replace('class="nt"', 'class="nt keys"')); continue
        # ---------- headings ----------
        mb = isbold_line(s)
        if mb and len(mb.group(1)) < 80 and not CODE.match(mb.group(1)):
            add(f'<h3 class="nh">{inl(mb.group(1)).rstrip(":- ")}</h3>'); i += 1; anchor_after(out, tid, s, anchors); continue
        if UPPER.match(s) and len(s) < 70 and not CODE.match(s) and not s.startswith(("NOTE", "NULL")):
            add(f'<h3 class="nh">{esc(s.rstrip(":- "))}</h3>'); i += 1; anchor_after(out, tid, s, anchors); continue
        if re.match(r"^(Features|Advantages|Disadvantages|Types of .+|Limitations of .+|Note|NOTE)\s*:-?\s*$", s):
            add(f'<h4 class="nh2">{esc(s.rstrip(":- "))}</h4>'); i += 1; continue
        # ---------- NOTE ----------
        mn = re.match(r"^NOTE\s*:-?\s*(.+)$", s) or re.match(r"^Note\s*:\s*(.+)$", s)
        if mn:
            add(f'<div class="note"><b>Note</b> {inl(mn.group(1))}</div>'); i += 1; continue
        # ---------- list items ----------
        mnum = re.match(r"^(\d+)[\.\)]\s*(?=[A-Za-z])(.+)$", s)
        mb2 = re.match(r"^[-•]\s+(?!-)(.+)$", s)
        mbh = re.match(r"^[-•]\s+\*\*\s*(.+?)\s*\*\*\s*$", s)
        if mbh:
            add(f'<h3 class="nh">{esc(mbh.group(1).rstrip(":- "))}</h3>'); i += 1; anchor_after(out, tid, mbh.group(1), anchors); continue
        mbc = re.match(r"^[-•]\s+([A-Za-z][^:]{2,55}?)\s*:\s*-?\s*$", s)
        if mbc:
            add(f'<h4 class="nh2">{esc(mbc.group(1))}</h4>'); i += 1; anchor_after(out, tid, mbc.group(1), anchors); continue
        if mb2 and re.search(r"\S\s{2,}\d+\.\s+[A-Za-z]", mb2.group(1)):
            its = [("1", re.split(r"\s{2,}\d+\.", mb2.group(1))[0])] + [("2", re.sub(r"^\d+\.\s*", "", re.split(r"\s{2,}", mb2.group(1), 1)[1]))]
            add("<div class=\"ol\">" + "".join(f'<div class="li"><span class="num">{a}</span><span>{inl(b)}</span></div>' for a, b in its) + "</div>"); i += 1; continue
        if mb2 and not CODE.match(s):
            items = []
            while i < n:
                j = nxt(i); sj = lines[j].strip() if j < n else ""
                mm = re.match(r"^[-•]\s+(?!-)(.+)$", sj)
                if not mm: break
                if items and re.match(r"^[-•]\s+([A-Za-z][^:]{2,55}?)\s*:\s*-?\s*$", sj): break
                items.append(mm.group(1)); i = j + 1
            add("<ul class=\"ul\">" + "".join(f"<li>{inl(x)}</li>" for x in items) + "</ul>"); continue
        if mnum and not CODE.match(s) and len(s) < 160 and "=" not in s[:12]:
            items = []
            while i < n:
                j = nxt(i); sj = lines[j].strip() if j < n else ""
                mm = re.match(r"^(\d+)[\.\)]\s*(?=[A-Za-z])(.+)$", sj)
                if not mm or CODE.match(sj) or len(sj) > 160: break
                items.extend(expand(mm.group(1), mm.group(2))); i = j + 1
            add("<div class=\"ol\">" + "".join(f'<div class="li"><span class="num">{a}</span><span>{inl(b)}</span></div>' for a, b in items) + "</div>")
            if tid == 1 and items[-1][1].startswith("Documentation"): add(DG["steps"])
            continue
        # ---------- label (+code) ----------
        ml = LABEL.match(ln)
        if ml and (not ml.group(2).strip() or CODE.match(ml.group(2))):
            lab = ml.group(1).strip().rstrip(":-")
            add(f'<p class="lbl">{esc(lab[:1].upper() + lab[1:])}</p>'); rest = ml.group(2).strip()
            if rest: lines[i] = rest
            else: i += 1
            continue
        mt0 = re.match(r"^\s*([A-Za-z_]\w*\(\s*\))\s*:\s?-\s*(.*)$", ln)
        if mt0:
            add(f'<p class="def"><b>{esc(mt0.group(1))}:</b> {inl(mt0.group(2))}</p>'); i += 1; continue
        # ---------- code ----------
        if CODE.match(ln) and not re.match(r"^[A-Z][a-z]+ ", s) or CODE.match(ln) and re.match(r"^\s*(void|int|float|char|double|struct)\b", ln):
            blk = []
            while i < n:
                l2 = lines[i]
                if not l2.strip():
                    j = nxt(i)
                    if j < n and (CODE.match(lines[j]) or lines[j][:1] in (" ", "\t")) and not isbold_line(lines[j].strip()) and not OUT.match(lines[j]) and not LABEL.match(lines[j]) : blk.append(""); i += 1; continue
                    break
                if OUT.match(l2) and blk: break
                if not CODE.match(l2) and re.match(r"^\s*[A-Z][a-z]*\s+[a-z]+", l2) and blk: break
                if not CODE.match(l2) and re.match(r"^\s*[A-Z][a-z]+(\s+\w+)*\s*:-?\s*$", l2) and blk: break
                if CODE.match(l2) or l2[:1] in (" ", "\t") and not re.match(r"^\s*(Output|NOTE)", l2) and not (len(l2.strip()) > 60 and " " in l2.strip() and not CODE.match(l2)):
                    blk.append(l2); i += 1
                else: break
            add(code_html([b for b in blk])); continue
        # ---------- term definition ----------
        mt = re.match(r"^\*{0,2}([A-Za-z][\w \.\(\)&/’'\-\*]{0,40}?)\*{0,2}\s*:\s?-\s*(.*)$", s)
        if mt:
            add(f'<p class="def"><b>{esc(mt.group(1).strip() if not s.startswith("**") else mt.group(1).strip().rstrip("*"))}:</b> {inl(mt.group(2))}</p>'); i += 1; anchor_after(out, tid, s, anchors); continue
        add(f"<p>{inl(s)}</p>"); i += 1; anchor_after(out, tid, s, anchors)
    return "\n".join(out)

def md_table(rows):
    if not rows: return ""
    if re.match(r"^Int$", rows[0][0], re.I):     # keywords grid
        return '<div class="tw"><table class="nt kw"><tbody>' + "".join("<tr>" + "".join(f"<td><code>{esc(c)}</code></td>" for c in r) + "</tr>" for r in rows) + "</tbody></table></div>"
    if rows[0][0] == "Associativity":
        body = []; cur = None
        for r in rows[1:]:
            if len(r) < 3: continue
            if r[0].strip(): cur = r[0].strip(); body.append([cur, r[1], r[2]])
            elif r[1].strip(): body.append(["", r[1], r[2]])
        # merge into rowspans
        h = '<div class="tw"><table class="nt prec"><thead><tr><th>Associativity</th><th>Operator</th><th>Description</th></tr></thead><tbody>'
        i = 0
        while i < len(body):
            j = i + 1
            while j < len(body) and body[j][0] == "": j += 1
            span = j - i
            for k in range(i, j):
                h += "<tr" + (' class="g"' if k == i else "") + ">"
                if k == i: h += f'<td rowspan="{span}" class="as">{esc(body[k][0])}</td>'
                h += f"<td><code>{esc(body[k][1])}</code></td><td>{inl(body[k][2])}</td></tr>"
            i = j
        return h + "</tbody></table></div>"
    return table(rows[1:], rows[0])

SUBHEAD = {3: ("Documentation Section", "Link section")}
ANCH = {}
def A(tid, rx, key): ANCH.setdefault(tid, []).append((re.compile(rx), key))
A(2, r"^Middle level language|^# Programming languages are classified|Programming languages are classified", "lang_levels")
A(2, r"^Compiler:\s*A compiler|^\*\*Compiler:", "translators")
A(3, r"^Compiling the program", "pipeline")
A(5, r"^C has the following tokens", "tokens")
A(6, r"^C has 3 types of data types", "types")
A(7, r"^Declaration of a variable", "variable")
A(9, r"^\s*Bitwise Xor", "bitwise")
A(9, r"^Right shift operator|^Left shift operator", None)
A(10, r"^Syntax of the if-else statement|Syntax of the if-else", "if")
A(10, r"^The last choice of the switch|When the switch statement is executed", "switch")
A(11, r"^\*{0,2}\s*TYPES OF LOOPING|^Exit controlled loop:", "loops")
A(12, r"^Array is a collection of homogenous", "array")
A(13, r"^Initialization of a string", "string")
A(14, r"^Value at address operator", "pointer")
A(14, r"^Double and triple pointers|^A point variable declared", "multi_pointer")
A(15, r"^Definition:-", "malloc")
A(16, r"^ACEESSING STRUCTURE|^ACCESSING STRUCTURE", "struct")
A(16, r"^STRUCTURES AND POINTERS", "struct_ptr")
A(18, r"^C program does not execute the functions", "func_call")
A(19, r"^WAP to calculate", "recursion")
A(20, r"^Types of Storage Classes", "memory")
_used = set()
def anchor_after(out, tid, s, anchors):
    for rx, key in anchors:
        if key and key not in _used and rx.search(s):
            _used.add(key); out.append(DG[key])

theory = []
for tid, (a, b) in RANGES.items():
    _used.clear()
    lines = prep(L[a - 1:b])
    html_body = parse(tid, lines)
    # bitwise AND/OR diagram + shift diagram (placed after their text, not tied to a fragile anchor)
    if tid == 9:
        html_body = html_body.replace('<h3 class="nh">Bitwise shift operators', DG["bitwise"] + '<h3 class="nh">Bitwise shift operators', 1)
        html_body = html_body.replace("<p>1’s compliment", DG["shifts"] + "<p>1’s compliment", 1)
    if tid == 20:
        html_body += '<h3 class="nh">Storage classes at a glance</h3>' + DG["memory"] + table([
            ["auto", "Main memory", "Garbage Value", "Control remains in a block where it is defined.", "Local to the block in which variable is declared."],
            ["register", "CPU Register", "Garbage", "Local to the block in which variable is declared.", "Local to the block."],
            ["static", "Main memory", "Zero and can be initialize once only.", "depends on function calls and the whole application or program.", "Local to the block."],
            ["extern", "Main memory", "Zero", "Until the program ends.", "Global to the program."]],
            ["Keyword", "Storage location", "Initial value", "Life", "Scope"])
    o = OLD[tid]; theory.append({"id": tid, "title": o["title"], "icon": o["icon"], "html": html_body, "quiz": o["quiz"]})
json.dump(theory, open("/home/claude/app/data/theory.json", "w"), ensure_ascii=False)
open("/tmp/theory_dump.html", "w").write("\n<hr>\n".join(f"<h1>{t['id']} {t['title']}</h1>{t['html']}" for t in theory))
for t in theory: print(t["id"], t["title"], len(t["html"]), "chars", "svg:", t["html"].count("<svg"), "tables:", t["html"].count("<table"))
joined = "".join(t["html"] for t in theory)
for bad in ["BDPS", "bdps", "SADGURU", "Jaggaiah", "jaggaiah", "JPT", "SRI SAI", "sri sai"]: assert bad not in joined, bad
