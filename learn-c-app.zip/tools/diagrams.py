from dg import *
D = {}

# ---------- Topic 1 ----------
def flow_symbols():
    rows = [
        (oval(10, 8, 90, 34, "Start / Stop"), "Starting or Stopping of process."),
        (para(6, 6, 98, 38, "Input /\nOutput"), "Input / Output specifications."),
        (box(10, 8, 90, 34, "Process", "b", "", 3), "Logical or Arithmetic data transfer"),
        (diamond(55, 25, 90, 42, "Decision"), "Indicates conditional operation"),
        ('<circle cx="55" cy="25" r="17" class="b"/>' + t(55, 29, "A"), "Indicates joints the different parts of flow chart."),
        (arr(20, 25, 92, 25), "Indicate connector that shows relationships between the reprehensive shapes."),
    ]
    out = '<div class="symgrid">'
    for sh, d in rows:
        out += f'<div class="sym"><svg class="dg s" viewBox="0 0 110 50">{"<defs><marker id=\"ar\" viewBox=\"0 0 10 10\" refX=\"8\" refY=\"5\" markerWidth=\"7\" markerHeight=\"7\" orient=\"auto-start-reverse\"><path d=\"M0 0L10 5L0 10z\"/></marker></defs>"}{sh}</svg><span>{e(d)}</span></div>'
    return out + "</div>"
D["flow_symbols"] = flow_symbols()

def steps():
    names = ["Problem\ndefinition", "Problem analysis\n& design", "Algorithm", "Flowchart", "Coding &\nimplementation", "Debugging\n& testing", "Documentation"]
    out = ""; y = 8
    for i, n in enumerate(names):
        x = 20 if i % 2 == 0 else 190
        out += box(x, y, 130, 42, n, "b", "", 10) + t(x + 14, y + 12, str(i+1), "m", "middle") if False else box(x, y, 130, 42, n, "b", "", 10)
        out += f'<circle cx="{x}" cy="{y}" r="11" class="bf"/>' + t(x, y + 4, str(i+1), "w")
        if i < len(names) - 1:
            if i % 2 == 0: out += arr(150, y + 21, 190, y + 21 + 26 + 0) if False else poly(f"150,{y+21} 170,{y+21} 170,{y+68-21+21} 190,{y+68+21}")
            else: out += poly(f"255,{y+42} 255,{y+54} 85,{y+54} 85,{y+68}")
        y += 68
    return svg(340, y, out, "Steps of program development")
D["steps"] = steps()

# ---------- Topic 2 ----------
def lang_levels():
    out = box(60, 6, 220, 42, "High level language\n(English words & symbols)", "bf", "w", 8) \
        + box(30, 54, 280, 42, "Middle level language\n(C)", "b", "", 8) \
        + box(0, 102, 340, 42, "Low level language\n(Assembly / Machine / Binary)", "b", "", 8)
    return svg(340, 150, out, "Levels of programming languages")
D["lang_levels"] = lang_levels()

def translators():
    out = box(4, 6, 92, 38, "Assembly\nlanguage") + arr(96, 25, 130, 25) + box(130, 8, 80, 34, "Assembler", "bf", "w") + arr(210, 25, 244, 25) + box(244, 6, 92, 38, "Machine\nlanguage")
    out += box(4, 62, 92, 38, "High level\nlanguage") + arr(96, 81, 130, 81) + box(130, 64, 80, 34, "Compiler", "bf", "w") + arr(210, 81, 244, 81) + box(244, 62, 92, 38, "Machine\nlanguage")
    return svg(340, 106, out, "Translators")
D["translators"] = translators()

# ---------- Topic 3 ----------
def c_pipeline():
    out = box(4, 14, 66, 40, "Source\nprogram\n(.c)", "b", "", 8)
    out += arr(70, 34, 92, 34) + box(92, 14, 66, 40, "Compiler", "bf", "w", 8)
    out += arr(158, 34, 180, 34) + box(180, 14, 66, 40, "Object\ncode\n(.obj)", "b", "", 8)
    out += arr(246, 34, 266, 34) + box(266, 14, 70, 40, "Linker", "bf", "w", 8)
    out += box(180, 82, 66, 30, "Libraries", "b", "", 8) + arr(213, 82, 290, 54)
    out += arr(301, 54, 301, 128) if False else ""
    out += poly("301,54 301,150") if False else ""
    out += box(266, 128, 70, 40, "Executable\n(.exe)", "b", "", 8) + arr(301, 54, 301, 128) if False else ""
    return ""
def c_pipeline2():
    out = box(4, 10, 70, 40, "Source\nprogram (.c)") + arr(74, 30, 96, 30) + box(96, 10, 70, 40, "Compiler", "bf", "w")
    out += arr(166, 30, 188, 30) + box(188, 10, 70, 40, "Object code\n(.obj)") + arr(258, 30, 280, 30)
    out += box(280, 10, 56, 40, "Linker", "bf", "w")
    out += box(250, 76, 86, 30, "Libraries") + arr(300, 76, 308, 52)
    out += arr(308, 50, 308, 126) if False else ""
    out += poly("336,30 336,30") if False else ""
    out += box(4, 132, 100, 40, "Executable\nfile (.exe)", "b", "", 8) + arr(280, 36, 280, 36) if False else ""
    out += poly("308,50 308,60 54,60 54,132") if False else ""
    return out
def c_pipeline3():
    out = box(4, 8, 70, 38, "Source\nprogram (.c)") + arr(74, 27, 96, 27) + box(96, 8, 70, 38, "Compiler", "bf", "w")
    out += arr(166, 27, 188, 27) + box(188, 8, 70, 38, "Object code\n(.obj)") + arr(258, 27, 280, 27) + box(280, 8, 56, 38, "Linker", "bf", "w")
    out += box(252, 70, 84, 28, "Libraries") + arr(308, 70, 308, 48)
    out += poly("308,98 308,118 60,118 60,134") if False else ""
    out += arr(262, 46, 262, 46) if False else ""
    out += poly("280,27 280,27") if False else ""
    out += box(4, 134, 332, 34, "Execution: the .exe file is run from the DOS command prompt (or any other software)", "b", "", 8) if False else ""
    out += box(4, 134, 120, 34, "Executable file (.exe)", "bf", "w") + arr(124, 151, 150, 151) + box(150, 134, 120, 34, "Run the program") + poly("308,98 308,116 64,116 64,134") if False else ""
    return out
def pipeline():
    out = box(4, 8, 70, 38, "Source\nprogram (.c)") + arr(74, 27, 96, 27) + box(96, 8, 70, 38, "Compiler", "bf", "w")
    out += arr(166, 27, 188, 27) + box(188, 8, 70, 38, "Object code\n(.obj)") + arr(258, 27, 280, 27) + box(280, 8, 56, 38, "Linker", "bf", "w")
    out += box(250, 62, 86, 26, "Libraries") + arr(308, 62, 308, 48)
    out += poly("308,88 308,104 54,104 54,118")
    out += box(4, 118, 100, 38, "Executable\nfile (.exe)", "bf", "w") + arr(104, 137, 134, 137) + box(134, 118, 100, 38, "Run the\nprogram")
    return svg(340, 162, out, "Compile, link and run")
D["pipeline"] = pipeline()

STRUCT = [("Documentation Section", "b"), ("Header files declarations or Link Section", "b"), ("Declarations of symbolic constants / preprocessor statements", "b"),
          ("Declaration of global variables / functions / structures", "b"), ("Definition section", "b")]
def program_structure():
    out = '<div class="struct">'
    for s, _ in STRUCT: out += f'<div class="sb">{e(s)}</div>'
    out += '<div class="sb main"><b>void main( )</b><div class="in">{</div><div class="in2">Local Declaration part;</div><div class="in2">Statements;</div><div class="in">}</div></div>'
    out += '<div class="sb">[sub programming section]<br><small>(user-defined function)</small></div></div>'
    return out
D["structure"] = program_structure()

# ---------- Topic 5 / 6 ----------
def tree(root, kids, w=340):
    n = len(kids); cw = (w - 8) / n; out = box(w/2 - 70, 4, 140, 30, root, "bf", "w")
    mh = max(k.count("\n") + 1 for k in kids) * 14 + 14
    for i, k in enumerate(kids):
        cx = 4 + cw * i + cw / 2
        out += poly(f"{w/2},34 {w/2},46 {cx},46 {cx},58") + box(cx - cw/2 + 3, 58, cw - 6, mh, k, "b", "", 6)
    return svg(w, 66 + mh, out, root)
D["tokens"] = tree("C Tokens", ["Identi-\nfiers", "Key-\nwords", "Con-\nstants", "Opera-\ntors", "Special\ncharacters"])
D["types"] = tree("Data types", ["Primary\n(int, char,\nfloat, double)", "User defined\n(enum,\ntypedef)", "Derived\n(array, pointer,\nstructure)"])

def variable_box():
    out = box(20, 20, 110, 56, "", "b") + t(75, 14, "k", "m") + t(75, 54, "100") + cap(75, 90, "value") + t(150, 54, "←", "m")
    out += cap(184, 48, "int k = 100;", "start") + cap(184, 64, "name = k, type = int", "start")
    return svg(340, 100, out, "A variable")
D["variable"] = variable_box()

# ---------- Topic 9 ----------
def bits(label, bitstr, y, hi=None):
    out = t(4, y + 19, label, "m", "start")
    for i, b in enumerate(bitstr):
        out += box(70 + i*34, y, 32, 28, b, "bf" if b == "1" else "b", "w" if b == "1" else "", 4)
    return out
def bitwise():
    out = bits("a = 23", "10111", 6) + bits("b = 28", "11100", 40)
    out += f'<line x1="4" y1="76" x2="336" y2="76" class="rule"/>' + bits("a & b = 20", "10100", 84) 
    out += bits("a | b = 31", "11111", 122) + cap(4, 164, "AND: output is 1 only if both bits are 1.   OR: output is 1 if any bit is 1.", "start")
    return svg(340, 174, out, "Bitwise AND and OR")
D["bitwise"] = bitwise()
def shifts():
    a = "0000000000011100"; b = "0000000001110000"
    out = t(4, 14, "a = 28   (16-bit)", "m", "start")
    for i, ch in enumerate(a): out += box(4 + i*20.5, 22, 19, 24, ch, "bf" if ch == "1" else "b", "w" if ch == "1" else "", 3)
    out += t(4, 70, "a << 2  →  a = 112   (bits move 2 places left, zeros fill the right)", "m", "start")
    for i, ch in enumerate(b): out += box(4 + i*20.5, 78, 19, 24, ch, "bf" if ch == "1" else "b", "w" if ch == "1" else "", 3)
    out += t(4, 126, "a >> 2  →  a = 7     (bits move 2 places right, zeros fill the left)", "m", "start")
    c = "0000000000000111"
    for i, ch in enumerate(c): out += box(4 + i*20.5, 134, 19, 24, ch, "bf" if ch == "1" else "b", "w" if ch == "1" else "", 3)
    return svg(340, 166, out, "Shift operators")
D["shifts"] = shifts()

# ---------- Topic 10 / 11 flowcharts ----------
def if_flow():
    out = oval(115, 2, 70, 24, "Start") + arr(150, 26, 150, 38) + diamond(150, 62, 130, 48, "condition?") 
    out += arr(215, 62, 262, 62) + cap(238, 56, "True") + box(262, 46, 72, 32, "true part\nstatements")
    out += arr(150, 86, 150, 118) + cap(165, 104, "False", "start") + box(110, 118, 80, 32, "else part\nstatements")
    out += poly("298,78 298,134 190,134") + arr(150, 150, 150, 164) + oval(115, 164, 70, 24, "End")
    return svg(340, 194, out, "if-else flow")
D["if"] = if_flow()
def switch_flow():
    out = box(100, 2, 140, 30, "switch(expression)", "bf", "w") 
    xs = [10, 124, 238]
    for i, (x, l) in enumerate(zip(xs, ["case value1", "case value2", "default"])):
        out += poly(f"170,32 170,46 {x+46},46 {x+46},60") + box(x, 60, 92, 30, l) + arr(x + 46, 90, x + 46, 108) + box(x, 108, 92, 30, "statements;\nbreak;" if i < 2 else "statements;")
    out += poly("56,138 56,152 284,152") + arr(170, 152, 170, 164) + oval(135, 164, 70, 24, "End")
    return svg(340, 194, out, "switch flow")
D["switch"] = switch_flow()
def loop_flow():
    out = t(85, 12, "Entry controlled (while, for)", "m") + t(255, 12, "Exit controlled (do-while)", "m")
    out += diamond(85, 56, 120, 44, "condition?") + arr(85, 78, 85, 100) + cap(100, 92, "True", "start") + box(40, 100, 90, 30, "body")
    out += poly("40,115 14,115 14,56 25,56") + arr(25, 56, 25, 56) if False else poly("40,115 12,115 12,56 25,56")
    out += poly("145,56 160,56 160,150") + cap(166, 100, "False", "start") if False else ""
    out += poly("145,56 156,56 156,160") + cap(122, 48, "False", "start") if False else ""
    out += cap(160, 50, "False", "start") + poly("145,56 158,56 158,150 120,150") if False else ""
    out += poly("145,56 156,56 156,150 140,150") + t(150, 164, "exit", "m") if False else ""
    out += box(215, 30, 80, 30, "body") + arr(255, 60, 255, 82) + diamond(255, 106, 120, 44, "condition?") + cap(262, 150, "False → exit", "start") + arr(255, 128, 255, 146)
    out += poly("195,106 180,106 180,45 215,45") + cap(172, 98, "True", "end")
    out += poly("85,134 85,150") + cap(92, 148, "", "start") if False else ""
    out += cap(85, 150, "False → exit") + arr(85, 78, 85, 78) if False else ""
    return svg(340, 170, out, "Loop flow")
D["loops"] = loop_flow()

# ---------- Topic 12 / 13 ----------
def arrays():
    out = t(4, 12, "int a[5];", "m", "start") + cells(4, 22, ["10", "20", "30", "40", "50"], 44, 32, labels=["a[0]", "a[1]", "a[2]", "a[3]", "a[4]"])
    out += cap(4, 92, "Array elements are counted from 0 to n-1.", "start")
    out += t(4, 118, "int a[3][3];", "m", "start")
    for r in range(3):
        for c in range(3): out += box(34 + c*66, 126 + r*30, 64, 28, f"a[{r}][{c}]", "b", "", 4)
    return svg(340, 222, out, "Array in memory")
D["array"] = arrays()
def string_mem():
    chars = list("LEARNC") + ["\\0"]
    out = t(4, 12, 'char name[7] = "LEARNC";', "m", "start") + cells(4, 22, [f"'{c}'" if c != "\\0" else "'\\0'" for c in chars], 46, 34, labels=[f"name[{i}]" for i in range(7)])
    out += cap(4, 84, "Every string ends with the NULL character '\\0'.", "start")
    return svg(340, 94, out, "String in memory")
D["string"] = string_mem()

# ---------- Topic 14 / 15 ----------
def pointer():
    out = box(10, 24, 90, 44, "100") + cap(55, 16, "n") + cap(55, 84, "address 1000") + box(190, 24, 90, 44, "1000") + cap(235, 16, "p") + cap(235, 84, "address 2000")
    out += arr(190, 46, 102, 46) + cap(145, 38, "points to")
    out += cap(4, 108, "int n, *p;   n = 100;   p = &n;", "start") + cap(4, 124, "*p gives the value at the address in p, that is 100.", "start")
    return svg(340, 132, out, "Pointer")
D["pointer"] = pointer()
def multi_pointer():
    names = [("t", "d"), ("d", "p"), ("p", "k")]
    out = ""; xs = [4, 92, 180, 268]; labs = ["t", "d", "p", "k"]; vals = ["addr of d", "addr of p", "addr of k", "50"]; ty = ["***t", "**d", "*p", "k"]
    for i, x in enumerate(xs):
        out += cap(x + 36, 14, ty[i]) + box(x, 20, 72, 40, vals[i], "bf" if i == 3 else "b", "w" if i == 3 else "", 6)
        if i < 3: out += arr(x + 72, 40, xs[i+1], 40)
    out += cap(4, 84, "int k, *p, **d, ***t;   k = 50;   p = &k;   d = &p;   t = &d;", "start")
    return svg(340, 92, out, "Double and triple pointers")
D["multi_pointer"] = multi_pointer()
def malloc_diag():
    out = box(10, 24, 80, 36, "p") + cap(50, 16, "pointer (stack)") + arr(90, 42, 140, 42)
    out += cap(240, 16, "heap memory (run time)") + cells(140, 24, ["", "", "", "", ""], 40, 36) + cap(240, 78, "n × sizeof(int) bytes", "middle")
    out += cap(4, 104, "p = (int *)malloc(n * sizeof(int));", "start")
    return svg(340, 112, out, "malloc")
D["malloc"] = malloc_diag()

# ---------- Topic 16 ----------
def struct_mem():
    out = cap(4, 14, "struct emp_info { ... } emp;", "start")
    rows = [("emp_id[10]", "char"), ("nm[100]", "char"), ("sal", "float")]
    for i, (n, ty) in enumerate(rows):
        out += box(10, 24 + i*34, 130, 32, n, "bf" if i == 0 else "b", "w" if i == 0 else "", 4) + cap(150, 44 + i*34, ty, "start")
    out += cap(200, 60, "emp.emp_id", "start") + cap(200, 78, "emp.nm", "start") + cap(200, 96, "emp.sal", "start")
    out += cap(4, 140, "Members are accessed with the dot operator ( . )", "start")
    return svg(340, 150, out, "Structure members")
D["struct"] = struct_mem()
def struct_ptr():
    out = box(10, 20, 70, 34, "p") + cap(45, 14, "struct student *p") + arr(80, 37, 150, 37) + cap(115, 30, "p = &s")
    out += box(150, 8, 180, 100, "", "b") + cap(240, 26, "struct student s")
    for i, n in enumerate(["sno", "sname[80]", "m1, m2, m3"]): out += box(162, 34 + i*22, 156, 20, n, "b", "", 3)
    out += cap(4, 130, "(*p).sno   is the same as   p->sno", "start")
    return svg(340, 140, out, "Structure pointer")
D["struct_ptr"] = struct_ptr()

# ---------- Topic 18 / 19 / 20 ----------
def func_call():
    out = box(10, 10, 120, 74, "", "b") + cap(70, 26, "main()") + cap(70, 50, "f = fact(n);") + cap(70, 70, "…")
    out += box(210, 10, 120, 74, "", "bf") + t(270, 26, "function body", "w") + t(270, 50, "statements;", "w") + t(270, 70, "return value;", "w")
    out += arr(132, 36, 208, 36) + cap(170, 28, "call + arguments") + arr(208, 62, 132, 62) + cap(170, 78, "return value")
    return svg(340, 96, out, "Function call and return")
D["func_call"] = func_call()
def recursion():
    out = cap(4, 12, "fact(3) — calls go down, results come back up", "start")
    rows = [("fact(3)", "3 × fact(2)", "= 6"), ("fact(2)", "2 × fact(1)", "= 2"), ("fact(1)", "returns 1", "= 1")]
    for i, (a, b, c) in enumerate(rows):
        y = 22 + i * 40
        out += box(10 + i*18, y, 190 - i*18, 32, f"{a}   {b}", "b" if i < 2 else "bf", "" if i < 2 else "w", 6) + cap(250, y + 20, c, "start")
        if i < 2: out += arr(60 + i*18, y + 32, 60 + i*18, y + 40)
    out += cap(250, 14, "result", "start")
    return svg(340, 148, out, "Recursion")
D["recursion"] = recursion()
def memory_regions():
    out = box(10, 8, 150, 60, "Main memory\n(auto, static, extern)", "b") + box(180, 8, 150, 60, "CPU register\n(register)", "bf", "w")
    return svg(340, 76, out, "Where storage classes keep variables")
D["memory"] = memory_regions()

# ---- clean versions (replace the first drafts above) ----
def steps_clean():
    names = ["Problem\ndefinition", "Problem analysis\n& design", "Algorithm", "Flowchart", "Coding &\nimplementation", "Debugging\n& testing", "Documentation"]
    out = ""; y = 12
    for i, n in enumerate(names):
        x = 18 if i % 2 == 0 else 192
        out += box(x, y, 130, 42, n, "b", "", 10) + f'<circle cx="{x}" cy="{y}" r="11" class="bf"/>' + t(x, y + 4, str(i + 1), "w")
        if i < len(names) - 1:
            if i % 2 == 0: out += poly(f"{x+130},{y+21} 170,{y+21} 170,{y+68+21} 192,{y+68+21}")
            else: out += poly(f"{x+65},{y+42} {x+65},{y+55} {18+65},{y+55} {18+65},{y+68}")
        y += 68
    return svg(340, y - 14, out, "Steps of program development")
D["steps"] = steps_clean()

def loops_clean():
    out = t(85, 12, "Entry controlled", "m") + t(85, 26, "(while, for)", "m") + t(269, 12, "Exit controlled", "m") + t(269, 26, "(do-while)", "m")
    out += diamond(85, 66, 128, 46, "condition?") + arr(85, 89, 85, 110) + cap(95, 103, "True", "start") + box(40, 110, 90, 30, "body")
    out += poly("40,125 14,125 14,66 21,66")
    out += poly("149,66 160,66 160,160 130,160") + cap(156, 130, "False", "end") + oval(40, 150, 90, 24, "exit", "b", "")
    out += box(224, 40, 90, 30, "body") + arr(269, 70, 269, 90) + diamond(269, 112, 128, 46, "condition?") + arr(269, 135, 269, 150) + cap(279, 146, "False", "start") + oval(224, 150, 90, 24, "exit", "b", "")
    out += poly("205,112 192,112 192,55 224,55") + cap(188, 104, "True", "end")
    return svg(340, 184, out, "Entry and exit controlled loops")
D["loops"] = loops_clean()
