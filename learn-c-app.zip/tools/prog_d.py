# programs 201-300
P = {}
def add(i, code, stdin=""): P[i] = (stdin, code.strip("\n"))

add(201, r'''
#include <stdio.h>

int main(void)
{
    double a, b;
    char op;
    printf("Enter expression (number operator number): ");
    if (scanf("%lf %c %lf", &a, &op, &b) != 3) {
        printf("Error: bad input\n");
        return 0;
    }
    switch (op) {
    case '+':
        printf("%.2f + %.2f = %.2f\n", a, b, a + b);
        break;
    case '-':
        printf("%.2f - %.2f = %.2f\n", a, b, a - b);
        break;
    case '*':
        printf("%.2f * %.2f = %.2f\n", a, b, a * b);
        break;
    case '/':
        if (b == 0) {
            printf("Error: division by zero\n");
        } else {
            printf("%.2f / %.2f = %.2f\n", a, b, a / b);
        }
        break;
    default:
        printf("Error: unknown operator '%c'\n", op);
    }
    return 0;
}
''', "12.5 * 4")
add(202, r'''
#include <stdio.h>

int main(void)
{
    int d;
    printf("Enter a number from 1 to 7: ");
    if (scanf("%d", &d) != 1) {
        return 0;
    }
    switch (d) {
    case 1: printf("Monday\n"); break;
    case 2: printf("Tuesday\n"); break;
    case 3: printf("Wednesday\n"); break;
    case 4: printf("Thursday\n"); break;
    case 5: printf("Friday\n"); break;
    case 6: printf("Saturday\n"); break;
    case 7: printf("Sunday\n"); break;
    default: printf("Invalid day number\n");
    }
    return 0;
}
''', "5")
add(203, r'''
#include <stdio.h>

int main(void)
{
    int m;
    printf("Enter month number (1-12): ");
    if (scanf("%d", &m) != 1) {
        return 0;
    }
    switch (m) {
    case 1: printf("January\n"); break;
    case 2: printf("February\n"); break;
    case 3: printf("March\n"); break;
    case 4: printf("April\n"); break;
    case 5: printf("May\n"); break;
    case 6: printf("June\n"); break;
    case 7: printf("July\n"); break;
    case 8: printf("August\n"); break;
    case 9: printf("September\n"); break;
    case 10: printf("October\n"); break;
    case 11: printf("November\n"); break;
    case 12: printf("December\n"); break;
    default: printf("Invalid month\n");
    }
    return 0;
}
''', "10")
add(204, r'''
#include <stdio.h>

int main(void)
{
    int digit;
    printf("Enter a digit (0-9): ");
    if (scanf("%d", &digit) != 1) {
        return 0;
    }
    switch (digit) {
    case 0: printf("Zero\n"); break;
    case 1: printf("One\n"); break;
    case 2: printf("Two\n"); break;
    case 3: printf("Three\n"); break;
    case 4: printf("Four\n"); break;
    case 5: printf("Five\n"); break;
    case 6: printf("Six\n"); break;
    case 7: printf("Seven\n"); break;
    case 8: printf("Eight\n"); break;
    case 9: printf("Nine\n"); break;
    default: printf("Not a single digit\n");
    }
    return 0;
}
''', "7")
add(205, r'''
#include <stdio.h>

int main(void)
{
    int choice;
    double a, b;
    const double PI = 3.14159265;
    printf("1. Circle\n2. Rectangle\n3. Triangle\nChoose: ");
    if (scanf("%d", &choice) != 1) {
        return 0;
    }
    switch (choice) {
    case 1:
        printf("Enter radius: ");
        scanf("%lf", &a);
        printf("Area of circle = %.2f\n", PI * a * a);
        break;
    case 2:
        printf("Enter length and width: ");
        scanf("%lf %lf", &a, &b);
        printf("Area of rectangle = %.2f\n", a * b);
        break;
    case 3:
        printf("Enter base and height: ");
        scanf("%lf %lf", &a, &b);
        printf("Area of triangle = %.2f\n", 0.5 * a * b);
        break;
    default:
        printf("Invalid choice\n");
    }
    return 0;
}
''', "2\n7.5 4")
add(206, r'''
#include <stdio.h>

int main(void)
{
    int choice;
    double t;
    printf("1. Celsius to Fahrenheit\n2. Fahrenheit to Celsius\nChoose: ");
    if (scanf("%d", &choice) != 1) {
        return 0;
    }
    if (choice == 1) {
        printf("Enter Celsius: ");
        scanf("%lf", &t);
        printf("%.1f C = %.1f F\n", t, t * 9.0 / 5.0 + 32.0);
    } else if (choice == 2) {
        printf("Enter Fahrenheit: ");
        scanf("%lf", &t);
        printf("%.1f F = %.1f C\n", t, (t - 32.0) * 5.0 / 9.0);
    } else {
        printf("Invalid choice\n");
    }
    return 0;
}
''', "1\n36.6")
add(207, r'''
#include <stdio.h>

int main(void)
{
    int choice;
    int a, b;
    printf("1.Add 2.Subtract 3.Multiply 4.Divide 5.Modulus\nChoose: ");
    if (scanf("%d", &choice) != 1) {
        return 0;
    }
    printf("Enter two integers: ");
    if (scanf("%d %d", &a, &b) != 2) {
        return 0;
    }
    switch (choice) {
    case 1: printf("%d + %d = %d\n", a, b, a + b); break;
    case 2: printf("%d - %d = %d\n", a, b, a - b); break;
    case 3: printf("%d * %d = %d\n", a, b, a * b); break;
    case 4:
        if (b == 0) {
            printf("Cannot divide by zero\n");
        } else {
            printf("%d / %d = %.3f\n", a, b, (double)a / b);
        }
        break;
    case 5:
        if (b == 0) {
            printf("Cannot divide by zero\n");
        } else {
            printf("%d %% %d = %d\n", a, b, a % b);
        }
        break;
    default: printf("Invalid choice\n");
    }
    return 0;
}
''', "5\n47 6")
add(208, r'''
#include <stdio.h>

int main(void)
{
    int choice;
    double v;
    do {
        printf("\n1. km to m\n2. m to cm\n3. km to cm\n4. cm to m\n0. Exit\nChoose: ");
        if (scanf("%d", &choice) != 1) {
            break;
        }
        if (choice == 0) {
            printf("Goodbye!\n");
            break;
        }
        if (choice < 1 || choice > 4) {
            printf("Invalid choice\n");
            continue;
        }
        printf("Enter value: ");
        scanf("%lf", &v);
        switch (choice) {
        case 1: printf("%.2f km = %.2f m\n", v, v * 1000); break;
        case 2: printf("%.2f m = %.2f cm\n", v, v * 100); break;
        case 3: printf("%.2f km = %.2f cm\n", v, v * 100000); break;
        case 4: printf("%.2f cm = %.2f m\n", v, v / 100); break;
        }
    } while (choice != 0);
    return 0;
}
''', "1\n2.5\n4\n250\n9\n0")
add(209, r'''
#include <stdio.h>

int main(void)
{
    int month, year, days;
    printf("Enter month (1-12) and year: ");
    if (scanf("%d %d", &month, &year) != 2) {
        return 0;
    }
    switch (month) {
    case 1: case 3: case 5: case 7: case 8: case 10: case 12:
        days = 31;
        break;
    case 4: case 6: case 9: case 11:
        days = 30;
        break;
    case 2:
        if ((year % 4 == 0 && year % 100 != 0) || year % 400 == 0) {
            days = 29;
        } else {
            days = 28;
        }
        break;
    default:
        printf("Invalid month\n");
        return 0;
    }
    printf("Month %d of year %d has %d days\n", month, year, days);
    return 0;
}
''', "2 2024")
add(210, r'''
#include <stdio.h>
#include <math.h>

int main(void)
{
    int choice;
    double p, r, t;
    printf("1. Simple interest\n2. Compound interest (yearly)\nChoose: ");
    if (scanf("%d", &choice) != 1) {
        return 0;
    }
    printf("Enter principal, rate (%%), time (years): ");
    if (scanf("%lf %lf %lf", &p, &r, &t) != 3) {
        return 0;
    }
    switch (choice) {
    case 1:
        printf("Simple interest = %.2f\n", p * r * t / 100.0);
        break;
    case 2:
        printf("Compound interest = %.2f\n", p * pow(1.0 + r / 100.0, t) - p);
        break;
    default:
        printf("Invalid choice\n");
    }
    return 0;
}
''', "2\n10000 8 3")
add(211, r'''
#include <stdio.h>

int main(void)
{
    char ch;
    printf("Enter a character: ");
    if (scanf(" %c", &ch) != 1) {
        return 0;
    }
    switch (ch) {
    case 'a': case 'e': case 'i': case 'o': case 'u':
    case 'A': case 'E': case 'I': case 'O': case 'U':
        printf("'%c' is a vowel\n", ch);
        break;
    default:
        if ((ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z')) {
            printf("'%c' is a consonant\n", ch);
        } else {
            printf("'%c' is not a letter\n", ch);
        }
    }
    return 0;
}
''', "E")
add(212, r'''
#include <stdio.h>
#include <math.h>

int main(void)
{
    int choice;
    double x;
    printf("1. Square\n2. Cube\n3. Square root\nChoose: ");
    if (scanf("%d", &choice) != 1) {
        return 0;
    }
    printf("Enter a number: ");
    if (scanf("%lf", &x) != 1) {
        return 0;
    }
    switch (choice) {
    case 1: printf("Square of %.2f = %.2f\n", x, x * x); break;
    case 2: printf("Cube of %.2f = %.2f\n", x, x * x * x); break;
    case 3:
        if (x < 0) {
            printf("Square root of a negative number is not real\n");
        } else {
            printf("Square root of %.2f = %.4f\n", x, sqrt(x));
        }
        break;
    default: printf("Invalid choice\n");
    }
    return 0;
}
''', "3\n20")
add(213, r'''
#include <stdio.h>

int main(void)
{
    int choice, n;
    do {
        printf("\n1. Decimal to binary\n2. Decimal to octal\n3. Decimal to hex\n4. Exit\nChoose: ");
        if (scanf("%d", &choice) != 1) {
            break;
        }
        if (choice == 4) {
            printf("Bye\n");
            break;
        }
        if (choice < 1 || choice > 3) {
            printf("Invalid choice\n");
            continue;
        }
        printf("Enter a non-negative decimal number: ");
        scanf("%d", &n);
        if (n < 0) {
            printf("Negative numbers not handled here\n");
            continue;
        }
        if (choice == 1) {
            int bits[32], k = 0, v = n;
            do {
                bits[k++] = v % 2;
                v /= 2;
            } while (v > 0);
            printf("%d in binary = ", n);
            while (k > 0) {
                printf("%d", bits[--k]);
            }
            printf("\n");
        } else if (choice == 2) {
            printf("%d in octal = %o\n", n, n);
        } else {
            printf("%d in hex = %X\n", n, n);
        }
    } while (choice != 4);
    return 0;
}
''', "1\n45\n3\n255\n2\n64\n4")
add(214, r'''
#include <stdio.h>

int main(void)
{
    int choice;
    double a, b, c;
    printf("1. Square\n2. Rectangle\n3. Triangle\n4. Circle\nChoose: ");
    if (scanf("%d", &choice) != 1) {
        return 0;
    }
    switch (choice) {
    case 1:
        printf("Enter side: ");
        scanf("%lf", &a);
        printf("Perimeter = %.2f\n", 4 * a);
        break;
    case 2:
        printf("Enter length and width: ");
        scanf("%lf %lf", &a, &b);
        printf("Perimeter = %.2f\n", 2 * (a + b));
        break;
    case 3:
        printf("Enter three sides: ");
        scanf("%lf %lf %lf", &a, &b, &c);
        printf("Perimeter = %.2f\n", a + b + c);
        break;
    case 4:
        printf("Enter radius: ");
        scanf("%lf", &a);
        printf("Circumference = %.2f\n", 2 * 3.14159265 * a);
        break;
    default:
        printf("Invalid choice\n");
    }
    return 0;
}
''', "3\n3 4 5")
add(215, r'''
#include <stdio.h>

int main(void)
{
    int choice, marks = -1;
    do {
        printf("\n1. Enter marks\n2. Show grade\n3. Exit\nChoose: ");
        if (scanf("%d", &choice) != 1) {
            break;
        }
        switch (choice) {
        case 1:
            printf("Enter marks (0-100): ");
            scanf("%d", &marks);
            break;
        case 2:
            if (marks < 0 || marks > 100) {
                printf("No valid marks entered yet\n");
            } else {
                char grade = marks >= 90 ? 'A' : marks >= 75 ? 'B' : marks >= 60 ? 'C' : marks >= 40 ? 'D' : 'F';
                printf("Marks = %d, Grade = %c\n", marks, grade);
            }
            break;
        case 3:
            printf("Exiting\n");
            break;
        default:
            printf("Invalid choice\n");
        }
    } while (choice != 3);
    return 0;
}
''', "2\n1\n82\n2\n7\n3")
add(216, r'''
#include <stdio.h>

int main(void)
{
    char light;
    printf("Enter light colour (R, Y or G): ");
    if (scanf(" %c", &light) != 1) {
        return 0;
    }
    switch (light) {
    case 'R': case 'r':
        printf("RED: Stop\n");
        break;
    case 'Y': case 'y':
        printf("YELLOW: Get ready / slow down\n");
        break;
    case 'G': case 'g':
        printf("GREEN: Go\n");
        break;
    default:
        printf("Unknown signal '%c'\n", light);
    }
    return 0;
}
''', "g")
add(217, r'''
#include <stdio.h>

int main(void)
{
    char op;
    printf("Enter a symbol: ");
    if (scanf(" %c", &op) != 1) {
        return 0;
    }
    switch (op) {
    case '+': printf("Addition operator\n"); break;
    case '-': printf("Subtraction operator\n"); break;
    case '*': printf("Multiplication operator\n"); break;
    case '/': printf("Division operator\n"); break;
    case '%': printf("Modulus operator\n"); break;
    default: printf("'%c' is not a basic arithmetic operator\n", op);
    }
    return 0;
}
''', "*")
add(218, r'''
#include <stdio.h>

int is_prime(int n)
{
    int i;
    if (n < 2) {
        return 0;
    }
    for (i = 2; i * i <= n; i++) {
        if (n % i == 0) {
            return 0;
        }
    }
    return 1;
}

int main(void)
{
    int choice, n;
    printf("Enter an integer: ");
    if (scanf("%d", &n) != 1) {
        return 0;
    }
    do {
        printf("\n1. Even/Odd\n2. Positive/Negative\n3. Prime\n4. Exit\nChoose: ");
        if (scanf("%d", &choice) != 1) {
            break;
        }
        switch (choice) {
        case 1: printf("%d is %s\n", n, n % 2 == 0 ? "even" : "odd"); break;
        case 2: printf("%d is %s\n", n, n > 0 ? "positive" : n < 0 ? "negative" : "zero"); break;
        case 3: printf("%d is %sprime\n", n, is_prime(n) ? "" : "not "); break;
        case 4: printf("Done\n"); break;
        default: printf("Invalid choice\n");
        }
    } while (choice != 4);
    return 0;
}
''', "29\n1\n2\n3\n4")
add(219, r'''
#include <stdio.h>

int main(void)
{
    int choice;
    double t;
    do {
        printf("\n1. C to F\n2. F to C\n3. C to K\n4. K to C\n0. Exit\nChoose: ");
        if (scanf("%d", &choice) != 1 || choice == 0) {
            break;
        }
        if (choice < 1 || choice > 4) {
            printf("Invalid choice\n");
            continue;
        }
        printf("Enter temperature: ");
        scanf("%lf", &t);
        switch (choice) {
        case 1: printf("%.2f F\n", t * 1.8 + 32); break;
        case 2: printf("%.2f C\n", (t - 32) / 1.8); break;
        case 3: printf("%.2f K\n", t + 273.15); break;
        case 4: printf("%.2f C\n", t - 273.15); break;
        }
    } while (1);
    printf("Program ended\n");
    return 0;
}
''', "1\n100\n4\n300\n0")
add(220, r'''
#include <stdio.h>

int main(void)
{
    int choice;
    int tries;
    for (tries = 0; tries < 3; tries++) {
        printf("Menu: 1=Hello 2=Goodbye. Choice: ");
        if (scanf("%d", &choice) != 1) {
            printf("Error: please enter a number\n");
            return 0;
        }
        switch (choice) {
        case 1:
            printf("Hello there!\n");
            break;
        case 2:
            printf("Goodbye!\n");
            break;
        default:
            printf("Error: %d is not a valid choice, use 1 or 2\n", choice);
        }
    }
    return 0;
}
''', "5\n-1\n2")
add(221, r'''
#include <stdio.h>

int main(void)
{
    char shape;
    double a, b;
    printf("Select shape: C=circle, S=square, R=rectangle, T=triangle: ");
    if (scanf(" %c", &shape) != 1) {
        return 0;
    }
    switch (shape) {
    case 'C':
        printf("Radius: ");
        scanf("%lf", &a);
        printf("Area = %.2f\n", 3.14159265 * a * a);
        break;
    case 'S':
        printf("Side: ");
        scanf("%lf", &a);
        printf("Area = %.2f\n", a * a);
        break;
    case 'R':
        printf("Length and width: ");
        scanf("%lf %lf", &a, &b);
        printf("Area = %.2f\n", a * b);
        break;
    case 'T':
        printf("Base and height: ");
        scanf("%lf %lf", &a, &b);
        printf("Area = %.2f\n", a * b / 2);
        break;
    default:
        printf("Unknown shape\n");
    }
    return 0;
}
''', "C\n3.5")
add(222, r'''
#include <stdio.h>

#define MAX 5

int main(void)
{
    int stack[MAX], top = -1, choice, v;
    do {
        printf("\n1. Push 2. Pop 3. Peek 4. Display 5. Exit\nChoose: ");
        if (scanf("%d", &choice) != 1) {
            break;
        }
        switch (choice) {
        case 1:
            printf("Value: ");
            scanf("%d", &v);
            if (top == MAX - 1) {
                printf("Stack overflow\n");
            } else {
                stack[++top] = v;
                printf("Pushed %d\n", v);
            }
            break;
        case 2:
            if (top == -1) {
                printf("Stack underflow\n");
            } else {
                printf("Popped %d\n", stack[top--]);
            }
            break;
        case 3:
            if (top == -1) {
                printf("Stack is empty\n");
            } else {
                printf("Top = %d\n", stack[top]);
            }
            break;
        case 4: {
            int i;
            printf("Stack (top first):");
            for (i = top; i >= 0; i--) {
                printf(" %d", stack[i]);
            }
            printf("\n");
            break;
        }
        case 5: printf("Exit\n"); break;
        default: printf("Invalid choice\n");
        }
    } while (choice != 5);
    return 0;
}
''', "2\n1\n10\n1\n20\n1\n30\n3\n4\n2\n4\n5")
add(223, r'''
#include <stdio.h>

int main(void)
{
    int a[6] = {14, 3, 9, 27, 8, 21};
    int n = 6, choice, i, key, big, small, sum;
    do {
        printf("\n1. Display 2. Sum 3. Largest/Smallest 4. Search 5. Reverse 6. Exit\nChoose: ");
        if (scanf("%d", &choice) != 1) {
            break;
        }
        switch (choice) {
        case 1:
            for (i = 0; i < n; i++) {
                printf("%d ", a[i]);
            }
            printf("\n");
            break;
        case 2:
            sum = 0;
            for (i = 0; i < n; i++) {
                sum += a[i];
            }
            printf("Sum = %d\n", sum);
            break;
        case 3:
            big = small = a[0];
            for (i = 1; i < n; i++) {
                if (a[i] > big) { big = a[i]; }
                if (a[i] < small) { small = a[i]; }
            }
            printf("Largest = %d, Smallest = %d\n", big, small);
            break;
        case 4:
            printf("Search for: ");
            scanf("%d", &key);
            for (i = 0; i < n && a[i] != key; i++) {
            }
            if (i < n) {
                printf("%d found at index %d\n", key, i);
            } else {
                printf("%d not found\n", key);
            }
            break;
        case 5:
            for (i = n - 1; i >= 0; i--) {
                printf("%d ", a[i]);
            }
            printf("\n");
            break;
        case 6: printf("Bye\n"); break;
        default: printf("Invalid choice\n");
        }
    } while (choice != 6);
    return 0;
}
''', "1\n2\n3\n4\n27\n4\n5\n5\n6")
add(224, r'''
#include <stdio.h>
#include <string.h>
#include <ctype.h>

int main(void)
{
    char s[50], t[50];
    int choice, i;
    printf("Enter a word: ");
    if (scanf("%49s", s) != 1) {
        return 0;
    }
    do {
        printf("\n1. Length 2. Reverse 3. Uppercase 4. Palindrome? 5. Count vowels 6. Exit\nChoose: ");
        if (scanf("%d", &choice) != 1) {
            break;
        }
        switch (choice) {
        case 1: printf("Length = %zu\n", strlen(s)); break;
        case 2: {
            size_t n = strlen(s);
            for (i = 0; i < (int)n; i++) {
                t[i] = s[n - 1 - i];
            }
            t[n] = '\0';
            printf("Reversed = %s\n", t);
            break;
        }
        case 3:
            for (i = 0; s[i] != '\0'; i++) {
                t[i] = (char)toupper((unsigned char)s[i]);
            }
            t[i] = '\0';
            printf("Uppercase = %s\n", t);
            break;
        case 4: {
            int n = (int)strlen(s), same = 1;
            for (i = 0; i < n / 2; i++) {
                if (s[i] != s[n - 1 - i]) {
                    same = 0;
                }
            }
            printf("%s is %sa palindrome\n", s, same ? "" : "not ");
            break;
        }
        case 5: {
            int count = 0;
            for (i = 0; s[i] != '\0'; i++) {
                if (strchr("aeiouAEIOU", s[i]) != NULL) {
                    count++;
                }
            }
            printf("Vowels = %d\n", count);
            break;
        }
        case 6: printf("Bye\n"); break;
        default: printf("Invalid choice\n");
        }
    } while (choice != 6);
    return 0;
}
''', "Level\n1\n2\n3\n4\n5\n6")
add(225, r'''
#include <stdio.h>

int main(void)
{
    int choice, n;
    do {
        printf("\n1. Decimal -> binary/octal/hex\n2. Binary -> decimal\n3. Hex -> decimal\n4. Exit\nChoose: ");
        if (scanf("%d", &choice) != 1) {
            break;
        }
        if (choice == 1) {
            printf("Enter decimal: ");
            scanf("%d", &n);
            printf("Octal = %o, Hex = %X\n", (unsigned)n, (unsigned)n);
            printf("Binary = ");
            {
                int started = 0, b;
                for (b = 31; b >= 0; b--) {
                    int bit = (int)(((unsigned)n >> b) & 1u);
                    if (bit || started || b == 0) {
                        printf("%d", bit);
                        started = 1;
                    }
                }
            }
            printf("\n");
        } else if (choice == 2) {
            char bin[40];
            int i, value = 0, ok = 1;
            printf("Enter binary: ");
            scanf("%39s", bin);
            for (i = 0; bin[i] != '\0'; i++) {
                if (bin[i] != '0' && bin[i] != '1') {
                    ok = 0;
                }
                value = value * 2 + (bin[i] - '0');
            }
            if (ok && i <= 30) {
                printf("%s = %d\n", bin, value);
            } else {
                printf("Invalid binary number\n");
            }
        } else if (choice == 3) {
            unsigned int h;
            printf("Enter hex: ");
            scanf("%x", &h);
            printf("0x%X = %u\n", h, h);
        } else if (choice != 4) {
            printf("Invalid choice\n");
        }
    } while (choice != 4);
    return 0;
}
''', "1\n202\n2\n101101\n3\n1F\n9\n4")
add(226, r'''
#include <stdio.h>

int main(void)
{
    double x, y;
    char op;
    printf("Enter first number: ");
    if (scanf("%lf", &x) != 1) {
        return 0;
    }
    printf("Enter operator (+ - * /): ");
    if (scanf(" %c", &op) != 1) {
        return 0;
    }
    printf("Enter second number: ");
    if (scanf("%lf", &y) != 1) {
        return 0;
    }
    switch (op) {
    case '+': printf("Result = %.2f\n", x + y); break;
    case '-': printf("Result = %.2f\n", x - y); break;
    case '*': printf("Result = %.2f\n", x * y); break;
    case '/':
        if (y != 0) {
            printf("Result = %.2f\n", x / y);
        } else {
            printf("Error: cannot divide by zero\n");
        }
        break;
    default: printf("Error: invalid operator\n");
    }
    return 0;
}
''', "81 / 4\n".replace(" / 4\n", "\n/\n4"))
add(227, r'''
#include <stdio.h>

const char *day_name(int d)
{
    switch (d) {
    case 1: return "Monday";
    case 2: return "Tuesday";
    case 3: return "Wednesday";
    case 4: return "Thursday";
    case 5: return "Friday";
    case 6: return "Saturday";
    case 7: return "Sunday";
    default: return "Invalid day";
    }
}

int main(void)
{
    int d;
    printf("Enter day number (1-7): ");
    if (scanf("%d", &d) != 1) {
        return 0;
    }
    printf("Day %d is %s\n", d, day_name(d));
    return 0;
}
''', "3")
add(228, r'''
#include <stdio.h>

int main(void)
{
    static const char *names[] = {"January", "February", "March", "April", "May", "June",
        "July", "August", "September", "October", "November", "December"};
    int m;
    printf("Enter month number (1-12): ");
    if (scanf("%d", &m) != 1) {
        printf("Error: input is not a number\n");
        return 0;
    }
    if (m < 1 || m > 12) {
        printf("Error: month must be between 1 and 12, got %d\n", m);
        return 0;
    }
    printf("Month %d is %s\n", m, names[m - 1]);
    return 0;
}
''', "8")
add(229, r'''
#include <stdio.h>

static const char *digit_word(int d)
{
    switch (d) {
    case 0: return "zero";
    case 1: return "one";
    case 2: return "two";
    case 3: return "three";
    case 4: return "four";
    case 5: return "five";
    case 6: return "six";
    case 7: return "seven";
    case 8: return "eight";
    case 9: return "nine";
    default: return "(not a digit)";
    }
}

int main(void)
{
    int i, d;
    for (i = 1; i <= 3; i++) {
        printf("Test %d - enter a digit: ", i);
        if (scanf("%d", &d) != 1) {
            break;
        }
        printf("Test %d: %d -> %s\n", i, d, digit_word(d));
    }
    return 0;
}
''', "0\n6\n12")
add(230, r'''
#include <stdio.h>

int main(void)
{
    int choice;
    double a, b;
    printf("1. Circle  2. Rectangle  3. Triangle\nChoose: ");
    if (scanf("%d", &choice) != 1) {
        return 0;
    }
    switch (choice) {
    case 1:
        printf("Radius: ");
        scanf("%lf", &a);
        /* circle area = pi * r * r */
        printf("Area = %.3f\n", 3.14159265 * a * a);
        break;
    case 2:
        printf("Length and breadth: ");
        scanf("%lf %lf", &a, &b);
        /* rectangle area = length * breadth */
        printf("Area = %.3f\n", a * b);
        break;
    case 3:
        printf("Base and height: ");
        scanf("%lf %lf", &a, &b);
        /* triangle area = half of base * height */
        printf("Area = %.3f\n", 0.5 * a * b);
        break;
    default:
        /* any other number is rejected */
        printf("Invalid choice\n");
    }
    return 0;
}
''', "1\n6.2")
add(231, r'''
#include <stdio.h>

int main(void)
{
    int choice, i;
    double t, vals[4] = {-40.0, 0.0, 100.0, -273.15};
    printf("1. C to F  2. F to C\nChoose: ");
    if (scanf("%d", &choice) != 1 || (choice != 1 && choice != 2)) {
        printf("Invalid choice\n");
        return 0;
    }
    printf("Boundary values: freezing point, boiling point, -40 and absolute zero\n");
    for (i = 0; i < 4; i++) {
        t = vals[i];
        if (choice == 1) {
            printf("%8.2f C = %8.2f F\n", t, t * 9.0 / 5.0 + 32.0);
        } else {
            printf("%8.2f F = %8.2f C\n", t, (t - 32.0) * 5.0 / 9.0);
        }
    }
    printf("Enter your own value: ");
    if (scanf("%lf", &t) == 1) {
        if (choice == 1) {
            printf("%.2f C = %.2f F\n", t, t * 9.0 / 5.0 + 32.0);
        } else {
            printf("%.2f F = %.2f C\n", t, (t - 32.0) * 5.0 / 9.0);
        }
    }
    return 0;
}
''', "1\n-40")
add(232, r'''
#include <stdio.h>

int main(void)
{
    int choice;
    long long a, b;
    do {
        printf("\n1.Add 2.Subtract 3.Multiply 4.Divide 5.Exit\nChoose: ");
        if (scanf("%d", &choice) != 1) {
            break;
        }
        if (choice == 5) {
            printf("Goodbye\n");
            break;
        }
        if (choice < 1 || choice > 4) {
            printf("Invalid choice\n");
            continue;
        }
        printf("Enter two integers: ");
        if (scanf("%lld %lld", &a, &b) != 2) {
            break;
        }
        switch (choice) {
        case 1: printf("Sum = %lld\n", a + b); break;
        case 2: printf("Difference = %lld\n", a - b); break;
        case 3: printf("Product = %lld\n", a * b); break;
        case 4:
            if (b == 0) {
                printf("Cannot divide by zero\n");
            } else {
                printf("Quotient = %lld, remainder = %lld\n", a / b, a % b);
            }
            break;
        }
    } while (choice != 5);
    return 0;
}
''', "1\n120 35\n4\n100 7\n4\n5 0\n8\n5")
add(233, r'''
#include <stdio.h>

int main(void)
{
    int choice;
    double v;
    do {
        printf("\n1. km -> m -> cm\n2. m -> cm\n3. cm -> m\n4. Exit\nChoose: ");
        if (scanf("%d", &choice) != 1) {
            break;
        }
        if (choice >= 1 && choice <= 3) {
            printf("Enter value: ");
            scanf("%lf", &v);
        }
        switch (choice) {
        case 1:
            printf("Step 1: %.3f km x 1000 = %.3f m\n", v, v * 1000);
            printf("Step 2: %.3f m x 100 = %.3f cm\n", v * 1000, v * 100000);
            break;
        case 2:
            printf("Step: %.3f m x 100 = %.3f cm\n", v, v * 100);
            break;
        case 3:
            printf("Step: %.3f cm / 100 = %.3f m\n", v, v / 100);
            break;
        case 4: printf("Done\n"); break;
        default: printf("Invalid choice\n");
        }
    } while (choice != 4);
    return 0;
}
''', "1\n1.25\n3\n450\n4")
add(234, r'''
#include <stdio.h>

int days_in(int month, int year)
{
    switch (month) {
    case 2: return ((year % 4 == 0 && year % 100 != 0) || year % 400 == 0) ? 29 : 28;
    case 4: case 6: case 9: case 11: return 30;
    default: return 31;
    }
}

int main(void)
{
    int year, m, total = 0;
    printf("Enter a year: ");
    if (scanf("%d", &year) != 1) {
        return 0;
    }
    /* one loop replaces twelve separate switch/print statements */
    for (m = 1; m <= 12; m++) {
        int d = days_in(m, year);
        printf("Month %2d: %d days\n", m, d);
        total += d;
    }
    printf("Total days in %d = %d\n", year, total);
    return 0;
}
''', "1900")
add(235, r'''
#include <stdio.h>
#include <math.h>

void simple(double p, double r, double t, double *si)
{
    *si = p * r * t / 100.0;
}

void compound(double p, double r, double t, double *ci)
{
    *ci = p * pow(1.0 + r / 100.0, t) - p;
}

int main(void)
{
    int choice;
    double p, r, t, result;
    do {
        printf("\n1. Simple interest\n2. Compound interest\n3. Exit\nChoose: ");
        if (scanf("%d", &choice) != 1) {
            break;
        }
        if (choice == 1 || choice == 2) {
            printf("Enter principal, rate, years: ");
            scanf("%lf %lf %lf", &p, &r, &t);
            if (choice == 1) {
                simple(p, r, t, &result);
            } else {
                compound(p, r, t, &result);
            }
            printf("Interest = %.2f\n", result);
        } else if (choice != 3) {
            printf("Invalid choice\n");
        }
    } while (choice != 3);
    return 0;
}
''', "1\n5000 6 2\n2\n5000 6 2\n3")
add(236, r'''
#include <stdio.h>

int main(void)
{
    const char vowels[] = "aeiouAEIOU";
    char text[40];
    int i, j, found, v = 0, o = 0;
    printf("Enter a word: ");
    if (scanf("%39s", text) != 1) {
        return 0;
    }
    for (i = 0; text[i] != '\0'; i++) {
        found = 0;
        for (j = 0; vowels[j] != '\0'; j++) {
            if (text[i] == vowels[j]) {
                found = 1;
            }
        }
        switch (found) {
        case 1: v++; break;
        default: o++;   /* consonants, digits, symbols */
        }
    }
    printf("Word: %s\nVowels: %d\nOther characters: %d\n", text, v, o);
    return 0;
}
''', "Education2024")
add(237, r'''
#include <stdio.h>
#include <math.h>

struct Request {
    int choice;
    double value;
};

int main(void)
{
    struct Request r;
    printf("1. Square  2. Cube  3. Square root\nChoose: ");
    if (scanf("%d", &r.choice) != 1) {
        return 0;
    }
    printf("Enter number: ");
    if (scanf("%lf", &r.value) != 1) {
        return 0;
    }
    switch (r.choice) {
    case 1: printf("Square = %.3f\n", r.value * r.value); break;
    case 2: printf("Cube = %.3f\n", r.value * r.value * r.value); break;
    case 3:
        if (r.value < 0) {
            printf("No real square root\n");
        } else {
            printf("Square root = %.3f\n", sqrt(r.value));
        }
        break;
    default: printf("Invalid choice\n");
    }
    return 0;
}
''', "2\n-4.5")
add(238, r'''
#include <stdio.h>

int main(void)
{
    int choice, count, i, n;
    do {
        printf("\n1. To binary  2. To octal  3. To hex  4. Exit\nChoose: ");
        if (scanf("%d", &choice) != 1) {
            break;
        }
        if (choice < 1 || choice > 3) {
            if (choice != 4) {
                printf("Invalid choice\n");
            }
            continue;
        }
        printf("How many numbers? ");
        scanf("%d", &count);
        for (i = 0; i < count; i++) {
            printf("Number %d: ", i + 1);
            scanf("%d", &n);
            if (choice == 1) {
                char buf[33];
                int k = 0, v = n;
                if (n < 0) {
                    printf("  negative skipped\n");
                    continue;
                }
                do {
                    buf[k++] = (char)('0' + v % 2);
                    v /= 2;
                } while (v > 0);
                printf("  %d = ", n);
                while (k > 0) {
                    putchar(buf[--k]);
                }
                printf(" (binary)\n");
            } else if (choice == 2) {
                printf("  %d = %o (octal)\n", n, (unsigned)n);
            } else {
                printf("  %d = %X (hex)\n", n, (unsigned)n);
            }
        }
    } while (choice != 4);
    return 0;
}
''', "1\n3\n5 18 100\n3\n2\n255 4096\n4")
add(239, r'''
#include <stdio.h>

int main(void)
{
    int choice;
    double a, b, c, p;
    const char *name;
    printf("1. Square 2. Rectangle 3. Triangle 4. Circle\nChoose: ");
    if (scanf("%d", &choice) != 1) {
        return 0;
    }
    switch (choice) {
    case 1:
        printf("Side: ");
        scanf("%lf", &a);
        p = 4 * a;
        name = "Square";
        printf("\n%-12s: %s\n%-12s: %.2f\n%-12s: %.2f\n", "Shape", name, "Side", a, "Perimeter", p);
        break;
    case 2:
        printf("Length, width: ");
        scanf("%lf %lf", &a, &b);
        p = 2 * (a + b);
        printf("\n%-12s: Rectangle\n%-12s: %.2f\n%-12s: %.2f\n%-12s: %.2f\n", "Shape", "Length", a, "Width", b, "Perimeter", p);
        break;
    case 3:
        printf("Sides a, b, c: ");
        scanf("%lf %lf %lf", &a, &b, &c);
        p = a + b + c;
        printf("\n%-12s: Triangle\n%-12s: %.2f, %.2f, %.2f\n%-12s: %.2f\n", "Shape", "Sides", a, b, c, "Perimeter", p);
        break;
    case 4:
        printf("Radius: ");
        scanf("%lf", &a);
        p = 2 * 3.14159265 * a;
        printf("\n%-12s: Circle\n%-12s: %.2f\n%-12s: %.2f\n", "Shape", "Radius", a, "Circumference", p);
        break;
    default:
        printf("Invalid choice\n");
    }
    return 0;
}
''', "3\n7 8.5 10")
add(240, r'''
#include <stdio.h>

int main(void)
{
    int choice, marks, valid = 0;
    do {
        printf("\n1. Enter marks\n2. Display grade\n3. Exit\nChoose: ");
        if (scanf("%d", &choice) != 1) {
            printf("Error: menu choice must be a number\n");
            break;
        }
        if (choice == 1) {
            printf("Marks (0-100): ");
            if (scanf("%d", &marks) != 1) {
                printf("Error: marks must be a number\n");
                break;
            }
            if (marks < 0 || marks > 100) {
                printf("Error: %d is outside 0-100\n", marks);
                valid = 0;
            } else {
                valid = 1;
                printf("Marks saved\n");
            }
        } else if (choice == 2) {
            if (!valid) {
                printf("Error: no valid marks yet\n");
            } else if (marks >= 80) {
                printf("%d -> Grade A\n", marks);
            } else if (marks >= 60) {
                printf("%d -> Grade B\n", marks);
            } else if (marks >= 40) {
                printf("%d -> Grade C\n", marks);
            } else {
                printf("%d -> Fail\n", marks);
            }
        } else if (choice != 3) {
            printf("Error: invalid choice %d\n", choice);
        }
    } while (choice != 3);
    return 0;
}
''', "1\n150\n2\n1\n67\n2\n3")
add(241, r'''
#include <stdio.h>

void show_instruction(char light)
{
    switch (light) {
    case 'R': printf("Red: stop and wait\n"); break;
    case 'Y': printf("Yellow: slow down, prepare to stop\n"); break;
    case 'G': printf("Green: go when the road is clear\n"); break;
    default: printf("Unknown signal '%c'\n", light);
    }
}

char read_light(void)
{
    char c;
    printf("Enter R, Y or G: ");
    if (scanf(" %c", &c) != 1) {
        return '?';
    }
    return (c >= 'a' && c <= 'z') ? (char)(c - 'a' + 'A') : c;
}

int main(void)
{
    int i;
    for (i = 0; i < 3; i++) {
        show_instruction(read_light());
    }
    return 0;
}
''', "r\ny\nx")
add(242, r'''
#include <stdio.h>

/* Time: O(1) - one switch comparison; Space: O(1) - a single char variable. */
int main(void)
{
    char ch;
    printf("Enter a character: ");
    if (scanf(" %c", &ch) != 1) {
        return 0;
    }
    switch (ch) {
    case '+': case '-': case '*': case '/': case '%':
        printf("'%c' is an arithmetic operator\n", ch);
        break;
    default:
        printf("'%c' is not an arithmetic operator\n", ch);
    }
    return 0;
}
''', "%")
add(243, r'''
#include <stdio.h>
#include <limits.h>

static int is_prime(long long n)
{
    long long i;
    if (n < 2) {
        return 0;
    }
    for (i = 2; i * i <= n; i++) {
        if (n % i == 0) {
            return 0;
        }
    }
    return 1;
}

static void check(const char *label, int n)
{
    printf("%-8s n=%d: %s, %s, %s\n", label, n, n % 2 == 0 ? "even" : "odd",
           n > 0 ? "positive" : n < 0 ? "negative" : "zero", is_prime(n) ? "prime" : "not prime");
}

int main(void)
{
    int choice, n;
    check("Normal", 17);
    check("Minimum", INT_MIN);
    check("Maximum", INT_MAX);
    do {
        printf("\n1. Even/Odd 2. Sign 3. Prime 4. Exit\nChoose: ");
        if (scanf("%d", &choice) != 1 || choice == 4) {
            break;
        }
        if (choice < 1 || choice > 3) {
            printf("Invalid choice\n");
            continue;
        }
        printf("Number: ");
        scanf("%d", &n);
        if (choice == 1) {
            printf("%s\n", n % 2 == 0 ? "even" : "odd");
        } else if (choice == 2) {
            printf("%s\n", n > 0 ? "positive" : n < 0 ? "negative" : "zero");
        } else {
            printf("%s\n", is_prime(n) ? "prime" : "not prime");
        }
    } while (1);
    return 0;
}
''', "3\n97\n1\n-8\n4")
add(244, r'''
#include <stdio.h>

static double c_to_f(double c) { return c * 9.0 / 5.0 + 32.0; }
static double f_to_c(double f) { return (f - 32.0) * 5.0 / 9.0; }

int main(void)
{
    int choice;
    double t;
    /* every variable is local; values travel through parameters */
    do {
        printf("\n1. C to F\n2. F to C\n3. Exit\nChoose: ");
        if (scanf("%d", &choice) != 1) {
            break;
        }
        switch (choice) {
        case 1:
            printf("Celsius: ");
            scanf("%lf", &t);
            printf("%.1f F\n", c_to_f(t));
            break;
        case 2:
            printf("Fahrenheit: ");
            scanf("%lf", &t);
            printf("%.1f C\n", f_to_c(t));
            break;
        case 3: printf("Bye\n"); break;
        default: printf("Invalid choice\n");
        }
    } while (choice != 3);
    return 0;
}
''', "2\n98.6\n1\n-10\n3")
add(245, r'''
#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    char line[40];
    char *end;
    long choice;
    int rounds;
    for (rounds = 0; rounds < 4; rounds++) {
        printf("Enter choice (1=Start, 2=Stop, 3=Status): ");
        if (fgets(line, sizeof line, stdin) == NULL) {
            printf("Error: input ended unexpectedly\n");
            return 0;
        }
        choice = strtol(line, &end, 10);
        if (end == line) {
            printf("Error: '%s' is not a number\n", strtok(line, "\n"));
            continue;
        }
        switch (choice) {
        case 1: printf("Started\n"); break;
        case 2: printf("Stopped\n"); break;
        case 3: printf("Status: OK\n"); break;
        default: printf("Error: choice %ld is not on the menu\n", choice);
        }
    }
    return 0;
}
''', "abc\n9\n3\n1\n")
add(246, r'''
#include <stdio.h>

/* Time: O(1) per operation; the menu loop runs O(k) for k choices.
   Space: O(1) - only a few variables. */
int main(void)
{
    int choice;
    double a, b;
    do {
        printf("\n1.+ 2.- 3.* 4./ 5.Exit\nChoose: ");
        if (scanf("%d", &choice) != 1 || choice == 5) {
            break;
        }
        printf("Two numbers: ");
        scanf("%lf %lf", &a, &b);
        switch (choice) {
        case 1: printf("%.2f\n", a + b); break;
        case 2: printf("%.2f\n", a - b); break;
        case 3: printf("%.2f\n", a * b); break;
        case 4:
            if (b == 0) {
                printf("Division by zero\n");
            } else {
                printf("%.2f\n", a / b);
            }
            break;
        default: printf("Invalid\n");
        }
    } while (1);
    printf("Finished\n");
    return 0;
}
''', "3\n2.5 8\n4\n9 0\n5")
add(247, r'''
#include <stdio.h>

int main(void)
{
    int month, year;
    printf("Enter month number: ");
    if (scanf("%d", &month) != 1) {
        return 0;
    }
    printf("Enter year: ");
    if (scanf("%d", &year) != 1) {
        return 0;
    }
    switch (month) {
    case 4: case 6: case 9: case 11:
        printf("30 days\n");
        break;
    case 2:
        if (year % 400 == 0 || (year % 4 == 0 && year % 100 != 0)) {
            printf("29 days (leap year)\n");
        } else {
            printf("28 days\n");
        }
        break;
    case 1: case 3: case 5: case 7: case 8: case 10: case 12:
        printf("31 days\n");
        break;
    default:
        printf("Invalid month\n");
    }
    return 0;
}
''', "2\n2100")
add(248, r'''
#include <stdio.h>

int main(void)
{
    char ch;
    printf("Enter a character: ");
    if (scanf(" %c", &ch) != 1) {
        return 0;
    }
    /* Several vowel cases share one block (fall-through). */
    switch (ch) {
    case 'a': case 'e': case 'i': case 'o': case 'u':
    case 'A': case 'E': case 'I': case 'O': case 'U':
        printf("%c is a vowel\n", ch);
        break;
    case ' ':
        printf("space\n");
        break;
    default:
        /* letters left over are consonants, anything else is "other" */
        if ((ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z')) {
            printf("%c is a consonant\n", ch);
        } else {
            printf("%c is a digit or symbol\n", ch);
        }
    }
    return 0;
}
''', "#")
add(249, r'''
#include <stdio.h>

int main(void)
{
    int choice, n, bits[32], k, i;
    unsigned int v;
    for (i = 0; i < 3; i++) {
        /* the loop repeats the menu three times instead of copying the code */
        printf("\nRound %d - 1. Binary  2. Octal  3. Hex\nChoose: ", i + 1);
        if (scanf("%d", &choice) != 1) {
            break;
        }
        printf("Number: ");
        scanf("%d", &n);
        v = (unsigned)n;
        switch (choice) {
        case 1:
            k = 0;
            do {
                bits[k++] = (int)(v % 2);
                v /= 2;
            } while (v > 0);
            printf("Binary: ");
            while (k > 0) {
                printf("%d", bits[--k]);
            }
            printf("\n");
            break;
        case 2: printf("Octal: %o\n", v); break;
        case 3: printf("Hex: %X\n", v); break;
        default: printf("Invalid choice\n");
        }
    }
    return 0;
}
''', "1\n37\n2\n37\n3\n37")
add(250, r'''
#include <stdio.h>

#define MAXS 10

int main(void)
{
    int marks[MAXS], n = 0, choice, i;
    do {
        printf("\n1. Add student marks\n2. Show all grades\n3. Exit\nChoose: ");
        if (scanf("%d", &choice) != 1) {
            break;
        }
        if (choice == 1) {
            if (n == MAXS) {
                printf("List is full\n");
            } else {
                printf("Marks: ");
                scanf("%d", &marks[n]);
                if (marks[n] < 0 || marks[n] > 100) {
                    printf("Marks must be 0-100\n");
                } else {
                    n++;
                }
            }
        } else if (choice == 2) {
            printf("%-8s %-6s %s\n", "Student", "Marks", "Grade");
            for (i = 0; i < n; i++) {
                char g = marks[i] >= 85 ? 'A' : marks[i] >= 70 ? 'B' : marks[i] >= 50 ? 'C' : 'F';
                printf("%-8d %-6d %c\n", i + 1, marks[i], g);
            }
        } else if (choice != 3) {
            printf("Invalid choice\n");
        }
    } while (choice != 3);
    return 0;
}
''', "1\n91\n1\n64\n1\n38\n1\n120\n2\n3")
