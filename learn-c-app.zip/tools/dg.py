# tiny SVG helpers for theory diagrams (colours come from CSS variables, so they follow light/dark themes)
import html
def e(s): return html.escape(str(s), quote=False)
def svg(w, h, inner, label="diagram"):
    return (f'<svg class="dg" viewBox="0 0 {w} {h}" role="img" aria-label="{e(label)}"><defs>'
            '<marker id="ar" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0 0L10 5L0 10z"/></marker></defs>'
            + inner + "</svg>")
def t(x, y, s, cls="", anchor="middle"):
    lines = str(s).split("\n"); out = ""
    for i, ln in enumerate(lines):
        out += f'<text x="{x}" y="{y + i*14 - (len(lines)-1)*7}" text-anchor="{anchor}" class="{cls}">{e(ln)}</text>'
    return out
def box(x, y, w, h, s="", cls="b", tcls="", r=8):
    return f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{r}" class="{cls}"/>' + (t(x + w/2, y + h/2 + 4, s, tcls) if s else "")
def oval(x, y, w, h, s, cls="bf", tcls="w"): return box(x, y, w, h, s, cls, tcls, r=h/2)
def diamond(cx, cy, w, h, s, cls="b", tcls=""):
    return f'<polygon points="{cx},{cy-h/2} {cx+w/2},{cy} {cx},{cy+h/2} {cx-w/2},{cy}" class="{cls}"/>' + t(cx, cy + 4, s, tcls)
def para(x, y, w, h, s, cls="b", tcls="", sk=10):
    return f'<polygon points="{x+sk},{y} {x+w},{y} {x+w-sk},{y+h} {x},{y+h}" class="{cls}"/>' + t(x + w/2, y + h/2 + 4, s, tcls)
def arr(x1, y1, x2, y2, dash=False): return f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" class="a{" dash" if dash else ""}"/>'
def poly(pts, dash=False): return f'<polyline points="{pts}" class="a{" dash" if dash else ""}"/>'
def cap(x, y, s, anchor="middle"): return t(x, y, s, "m", anchor)
def cells(x, y, vals, w=34, h=30, cls="b", tcls="", labels=None, lcls="m"):
    out = ""
    for i, v in enumerate(vals):
        out += box(x + i*w, y, w, h, v, cls, tcls, r=4)
        if labels: out += t(x + i*w + w/2, y + h + 13, labels[i], lcls)
    return out
