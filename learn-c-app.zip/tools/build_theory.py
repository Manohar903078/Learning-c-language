import re, json, random
SRC = "/mnt/user-data/uploads/new_c_2016-1_docx.txt"
L = open(SRC, encoding="utf-8").read().split("\n")

TOPICS = [
 (1,  "Basic Terminology & Program Development", 7, 114, "📘"),
 (2,  "Programming Languages", 115, 171, "🗣️"),
 (3,  "Introduction to C", 172, 297, "🚀"),
 (4,  "printf() & Escape Sequences", 298, 397, "🖨️"),
 (5,  "Character Set, Tokens, Keywords & Constants", 398, 545, "🔤"),
 (6,  "Data Types", 546, 658, "🧮"),
 (7,  "Variables & Constants", 659, 724, "📦"),
 (8,  "scanf() & Comments", 725, 754, "⌨️"),
 (9,  "Operators & Expressions", 755, 987, "➕"),
 (10, "Decision Making Statements", 988, 1121, "🔀"),
 (11, "Looping Statements", 1122, 1239, "🔁"),
 (12, "Arrays", 1240, 1325, "🧱"),
 (13, "Strings", 1326, 1529, "🧵"),
 (14, "Pointers", 1530, 1615, "📍"),
 (15, "Dynamic Memory Allocation", 1616, 1653, "🧠"),
 (16, "Structures", 1654, 1923, "🏗️"),
 (17, "Header Files in C", 1924, 2212, "📚"),
 (18, "Functions", 2213, 2391, "⚙️"),
 (19, "Recursion", 2392, 2507, "♻️"),
 (20, "Storage Classes", 2508, len(L), "🗄️"),
]

# ---- rebranding: remove the original institute / place names ----
SUBS = [
 (r"SSS-BDPS Computer Education, JPT", "LearnC Academy"),
 (r"BDPS-SRI SAI SADGURU COMPUTER EDUCATION, JPT", "LEARNC ACADEMY, CITY"),
 (r"sri sai sadguru computer education point", "learnc academy c programming course here"),
 (r"BDPS Computers, JPT", "LearnC Computers, CITY"),
 (r"BDPS Computer Education, Jaggaiahpet", "LearnC Computer Education, City"),
 (r"BDPS \\n COMPUTER \\n EDUCATION", "LEARNC \\n COMPUTER \\n EDUCATION"),
 (r"BPDS", "LEARNC"),
 (r"Bdps", "Learnc"), (r"BDPS", "LEARNC"), (r"bdps", "learnc"),
 (r"Jaggaiahpet", "City"), (r"jaggaiahpet", "city"),
 (r"\bJPT\b", "CITY"), (r"\bjpt\b", "city"),
 (r"\bA\.P\b", "IN"),
]
def rebrand(t):
    t = t.replace("educationjpt", "educationcity")
    for a, b in SUBS: t = re.sub(a, lambda m, b=b: b, t)
    return t

def tidy(block):
    out = []
    for ln in block:
        ln = ln.rstrip()
        if re.search(r"Page \*{0,2}\d+\*{0,2} of \*{0,2}\d+", ln): continue
        ln = re.sub(r"\[([^\]]+)\]\(http[^)]*\)", r"\1", ln)        # strip links, keep text
        ln = ln.replace("****", "").replace(" ", " ")
        ln = re.sub(r"\*\*\s+\*\*", "", ln)
        ln = re.sub(r"^#+\s*", "", ln)
        ln = re.sub(r"[ \t]{40,}", "  ", ln)                          # giant whitespace runs
        ln = ln.replace("\t", "    ")
        out.append(ln)
    text = "\n".join(out)
    text = re.sub(r"\n{3,}", "\n\n", text).strip("\n")
    text = text.replace("    t  = &t;", "    t  = &d;")                # fix typo in the source notes
    text = text.replace("t = &t;", "t = &d;")
    return rebrand(text)

# ---- quizzes (the app only counts a topic as learned after the learner passes its quiz) ----
Q = {
 1: [("Which step comes right after 'Problem analysis and design'?", "Algorithm", ["Coding", "Documentation", "Debugging"]),
     ("The process of correcting errors in a program is called…", "Debugging", ["Compiling", "Documentation", "Flow charting"])],
 2: [("Which language does a computer understand without any translator?", "Machine language", ["Assembly language", "High level language", "Pascal"]),
     ("Which translator converts all statements at a time and shows errors as a list?", "Compiler", ["Interpreter", "Assembler", "Editor"])],
 3: [("Who developed the C language?", "Dennis Ritchie", ["Ken Thompson", "Martin Richards", "Charles Babbage"]),
     ("Execution of every C program starts from…", "main() function", ["the first function written", "printf()", "the header file"]),
     ("Every statement in C ends with…", "; (semicolon)", [". (full stop)", ": (colon)", ", (comma)"])],
 4: [("Which escape sequence moves the cursor to a new line?", "\\n", ["\\t", "\\b", "\\a"]),
     ("printf() belongs to which header file?", "stdio.h", ["conio.h", "math.h", "string.h"])],
 5: [("Which of these is a valid identifier?", "emp_name", ["5n", "a$", "id-no"]),
     ("How many keywords does C have (as per the notes)?", "32", ["16", "64", "48"]),
     ("Which one is a character constant?", "'A'", ["\"A\"", "A", "65.0"])],
 6: [("Which are the four primary data types of C?", "int, char, float, double", ["int, string, bool, long", "array, struct, union, enum", "int, void, pointer, file"]),
     ("Which format specifier is used to print a float?", "%f", ["%d", "%c", "%s"])],
 7: [("Which keyword is used to declare a constant?", "const", ["static", "final", "define"]),
     ("int a=123; printf(\"%d\", a); prints…", "123", ["a", "%d", "0"])],
 8: [("Why is & used in scanf(\"%d\", &a)?", "scanf needs the address of the variable", ["to multiply a", "to print a", "to declare a"]),
     ("Comments in C are written between…", "/* and */", ["<!-- and -->", "## and ##", "{{ and }}"])],
 9: [("After a=10; b=a++;  what are a and b?", "a=11, b=10", ["a=10, b=11", "a=11, b=11", "a=10, b=10"]),
     ("What is the value of 5 % 2 ?", "1", ["2", "2.5", "0"]),
     ("a<<2 is the same as…", "a * 4", ["a / 4", "a + 2", "a * 2"])],
 10: [("Which statement selects one of many groups of statements based on a value?", "switch", ["for", "while", "goto"]),
      ("Which keyword stops execution from falling into the next case?", "break", ["continue", "return 0", "stop"])],
 11: [("Which loop always executes its body at least once?", "do-while", ["while", "for", "none of them"]),
      ("What does break do inside a loop?", "Terminates the loop", ["Skips one iteration", "Restarts the loop", "Does nothing"])],
 12: [("For int a[5]; which is the last valid element?", "a[4]", ["a[5]", "a[6]", "a[0]"]),
      ("An array stores…", "homogeneous data (same type)", ["heterogeneous data", "only characters", "only decimals"])],
 13: [("Every C string ends with…", "'\\0' (NULL character)", ["'\\n'", "a space", "a full stop"]),
      ("Which function returns the length of a string?", "strlen()", ["strcpy()", "strcat()", "strrev()"]),
      ("strcmp(s1, s2) returns 0 when…", "both strings are equal", ["s1 is longer", "s2 is empty", "s1 is smaller"])],
 14: [("Which operator gives the address of a variable?", "&", ["*", "->", "%"]),
      ("int n=100, *p=&n;  What is *p ?", "100", ["the address of n", "0", "the address of p"]),
      ("int **d; is a…", "double pointer variable", ["single pointer", "array of pointers only", "function"])],
 15: [("malloc() allocates memory at…", "run time", ["compile time", "link time", "editing time"]),
      ("calloc() clears the allocated memory to…", "zero", ["garbage values", "one", "spaces"])],
 16: [("Which keyword declares a structure?", "struct", ["structure", "record", "union"]),
      ("The arrow operator (->) is used with…", "a pointer to a structure", ["an array", "an int variable", "a string constant"]),
      ("A structure can store…", "heterogeneous data under one name", ["only integers", "only one value", "only strings"])],
 17: [("Which header file declares sqrt() and pow()?", "math.h", ["stdio.h", "string.h", "time.h"]),
      ("Which header file declares malloc() and atoi()?", "stdlib.h", ["ctype.h", "math.h", "graphics.h"])],
 18: [("A function whose return type is void…", "returns nothing", ["returns int", "returns 0 always", "cannot have arguments"]),
      ("Arguments given in the function call are called…", "actual arguments", ["formal arguments", "receiving parameters", "return values"])],
 19: [("A recursive function is one that…", "calls itself", ["calls main()", "has no arguments", "never returns"]),
      ("What must every recursive function have?", "A condition that stops the recursion", ["A loop", "A global variable", "A pointer"])],
 20: [("Which storage class keeps a local variable's value between function calls?", "static", ["auto", "register", "extern"]),
      ("The initial value of an auto variable is…", "garbage value", ["zero", "one", "NULL"]),
      ("The scope of an extern (global) variable is…", "the whole program", ["only one block", "only one function", "only one loop"])],
}
def mk(topic, items):
    r = random.Random(topic * 7919); out = []
    for q, good, bad in items:
        opts = [good] + bad; r.shuffle(opts)
        out.append({"q": q, "opts": opts, "a": opts.index(good)})
    return out

theory = []
for tid, title, a, b, icon in TOPICS:
    body = tidy(L[a-1:b])
    theory.append({"id": tid, "title": title, "icon": icon, "body": body, "quiz": mk(tid, Q[tid])})
json.dump(theory, open("data/theory.json", "w"), ensure_ascii=False)
for t in theory: print(t["id"], t["title"], len(t["body"]), "chars", len(t["quiz"]), "quiz")
joined = "\n".join(t["body"] for t in theory)
for bad in ["BDPS", "bdps", "SADGURU", "Jaggaiah", "jaggaiah", "JPT", "SRI SAI", "sri sai"]:
    print(bad, joined.count(bad))
print(len("learnc academy c programming course here"))
