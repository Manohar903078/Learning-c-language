import re, json
js = open("public/app.js").read(); css = open("public/style.css").read()
def rep(s, old, new, regex=False):
    if regex:
        out, n = re.subn(old, lambda m: new, s, count=1, flags=re.S); assert n == 1, old; return out
    assert old in s, old[:60]; return s.replace(old, new)

# data embedded instead of fetched
js = rep(js, r"    const \[th, pq, pr, iq\] = await Promise\.all\(.*?\]\);", '''    const g = (id) => JSON.parse(document.getElementById(id).textContent);
    const th = g("d-theory"), pq = g("d-pq"), pr = g("d-prog"), iq = g("d-iq");''', True)
js = rep(js, '    try { D.ia = await jget("/data/interview_a.json"); } catch {}\n', '    try { D.ia = g("d-ia"); } catch {}\n')
js = rep(js, '  if ("serviceWorker" in navigator) navigator.serviceWorker.register("sw.js").catch(() => {});\n', "")
# demo-mode backend
js = rep(js, r"async function post\(u, b\) \{[^\n]*\n", '''async function post(u, b) {
  if (u === "/api/send-otp") {
    if (!/^[^\\s@]+@[^\\s@]+\\.[^\\s@]{2,}$/.test(b.email)) throw new Error("Enter a valid e-mail address.");
    window.__otp = String(100000 + Math.floor(Math.random() * 900000)); return { ok: true, dev: true, devOtp: window.__otp };
  }
  if (u === "/api/verify-otp") { if (b.code !== window.__otp) throw new Error("Wrong code. Try again."); return { ok: true, token: "demo" }; }
  const norm = (s) => String(s).replace(/\\s+/g, " ").trim();
  window.__runs = window.__runs || {};
  if (u === "/api/run/start") {
    const hit = D.prog.find((p) => norm(p.code) === norm(b.code));
    const id = "m" + Date.now();
    window.__runs[id] = hit ? hit.output + (hit.stdin ? "\\n(sample input was: " + hit.stdin.split(String.fromCharCode(10)).join(" ") + ")" : "") + "\\n\\n[Preview mode: this shows the recorded sample run. In the real app the program waits for YOU to type any value.]\\n"
      : "[Preview mode: new code cannot be compiled here.\\nIn the real app (with the server) any C code you write is compiled and run, and it asks for your input live.]\\n";
    return { stage: "run", id };
  }
  if (u === "/api/run/poll") { await new Promise((r) => setTimeout(r, 350)); const o = window.__runs[b.id] || ""; return { out: o.slice(b.pos), pos: o.length, done: true, code: 0, note: "" }; }
  if (u.startsWith("/api/run/")) return { ok: true };
  return { stage: "run", output: "", errors: "Preview mode" };
}
''', True)
# theme handling per page contract
js = rep(js, r"function applyTheme\(\) \{.*?\n\}\n", '''function applyTheme() {
  const [a, b] = THEMES[S.set.theme] || THEMES[0], r = document.documentElement;
  r.style.setProperty("--accent", a); r.style.setProperty("--accent2", b);
  if (S.set.mode === "dark" || S.set.mode === "light") r.dataset.theme = S.set.mode; else delete r.dataset.theme;
}
''', True)
js = rep(js, '{ theme: 0, mode: "dark" }', '{ theme: 0, mode: "auto" }')
js = rep(js, '<div class="btns" style="margin:0"><button class="btn ${S.set.mode === "dark"', '<div class="btns" style="margin:0"><button class="btn ${S.set.mode === "auto" ? "" : "sec"}" onclick="S.set.mode=\'auto\';LS.set(\'set\',S.set);render()">Auto</button><button class="btn ${S.set.mode === "dark"')
js = rep(js, "confirm('Reset all progress?')", "true").replace("confirm('Reset to the Hello World template?')", "true")
js = rep(js, "location.href='mailto:support@learnc.app?subject=Learn C feedback'", "toast('Feedback: support@learnc.app')")

# stylesheet: dark-first tokens + light blocks
css = re.sub(r":root\[data-mode=light\]\{.*?\}\n", "", css)
LIGHT = "--bg:#fff6fb;--bg2:#ffeaf5;--card:#ffffff;--card2:#ffe3f1;--text:#2a1b3d;--mute:#7b6a96;--code:#2a1b3d;color-scheme:light"
css = css.replace(":root{--bg:", ":root{color-scheme:dark;--bg:", 1)
css += f"""
@media (prefers-color-scheme: light){{:root:not([data-theme="dark"]){{{LIGHT}}}}}
:root[data-theme="light"]{{{LIGHT}}}
body{{padding-left:max(16px,env(safe-area-inset-left,0px));padding-right:max(16px,env(safe-area-inset-right,0px))}}
body::before{{content:"";position:fixed;inset:0 0 auto;height:env(safe-area-inset-top,0px);background:var(--bg);z-index:30}}
#app{{padding-bottom:110px}}
.hero{{margin-top:12px;border-radius:32px;padding:24px 20px 54px}}
.toolbar{{padding:0 12px}}.grid{{padding:20px 0}}.list{{padding:6px 0}}.card{{margin:12px 0}}.btns{{margin:12px 0}}
.top{{padding:14px 0 10px;top:env(safe-area-inset-top,0px)}}.search{{margin:6px 0 12px;width:100%}}.pager{{margin:14px 0}}
.tabs{{padding:4px 0 10px}}.login{{padding:0 0 40px}}.login .hero{{margin:12px 0 22px}}
.nav{{padding-left:max(16px,env(safe-area-inset-left,0px));padding-right:max(16px,env(safe-area-inset-right,0px));padding-bottom:calc(10px + env(safe-area-inset-bottom,0px))}}
"""
def emb(id, path):
    return f'<script type="application/json" id="{id}">' + open(path).read().replace("</", "<\\/") + "</script>"
html = f"""<title>Learn C Language</title>
<meta name="claude:viewport-fit-sides" content="cover">
<style>
{css}
</style>
<div id="app"></div>
<div id="toast"></div>
{emb("d-theory","data/theory.json")}
{emb("d-pq","data/practice_q.json")}
{emb("d-prog","data/programs.json")}
{emb("d-ia","data/interview_a.json")}
{emb("d-iq","data/interview_q.json")}
<script>
{js}
</script>
"""
open("preview/index.html", "w").write(html); print(len(html)//1024, "KB")
