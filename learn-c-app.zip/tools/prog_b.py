# programs 51-100
P = {}
def add(i, code, stdin=""): P[i] = (stdin, code.strip("\n"))

add(51, r'''
#include <stdio.h>

int main(void)
{
    int n;
    scanf("%d", &n);
    printf("You entered: %d\n", n);
    return 0;
}
''', "25")
add(52, r'''
#include <stdio.h>

int main(void)
{
    float x;
    scanf("%f", &x);
    printf("Value = %.2f\n", x);
    return 0;
}
''', "3.14159")
add(53, r'''
#include <stdio.h>

int main(void)
{
    char ch;
    scanf(" %c", &ch);      /* the space skips whitespace */
    printf("Character: %c\n", ch);
    return 0;
}
''', "Q")
add(54, r'''
#include <stdio.h>

int main(void)
{
    char name[30];
    printf("Enter your name: ");
    scanf("%29s", name);
    printf("Good morning, %s! Welcome to C.\n", name);
    return 0;
}
''', "Ravi")
add(55, r'''
#include <stdio.h>

int main(void)
{
    int a, b;
    printf("Enter two integers: ");
    scanf("%d %d", &a, &b);
    printf("First = %d, Second = %d\n", a, b);
    return 0;
}
''', "10 20")
add(56, r'''
#include <stdio.h>

int main(void)
{
    int a, b, c;
    printf("Enter three numbers: ");
    scanf("%d %d %d", &a, &b, &c);
    printf("Reverse order: %d %d %d\n", c, b, a);
    return 0;
}
''', "1 2 3")
add(57, r'''
#include <stdio.h>

int main(void)
{
    int a, b, temp;
    printf("Enter a and b: ");
    scanf("%d %d", &a, &b);
    printf("Before: a=%d b=%d\n", a, b);
    temp = a;
    a = b;
    b = temp;
    printf("After : a=%d b=%d\n", a, b);
    return 0;
}
''', "5 9")
add(58, r'''
#include <stdio.h>

int main(void)
{
    int a, b;
    printf("Enter a and b: ");
    scanf("%d %d", &a, &b);
    printf("Before: a=%d b=%d\n", a, b);
    a = a + b;
    b = a - b;
    a = a - b;
    printf("After : a=%d b=%d\n", a, b);
    return 0;
}
''', "5 9")
add(59, r'''
#include <stdio.h>

int main(void)
{
    char name[30];
    int roll;
    float marks;

    printf("Enter name, roll number and marks: ");
    scanf("%29s %d %f", name, &roll, &marks);

    printf("\n--- Student Details ---\n");
    printf("Name  : %s\n", name);
    printf("Roll  : %d\n", roll);
    printf("Marks : %.1f\n", marks);
    return 0;
}
''', "Anil 101 87.5")
add(60, r'''
#include <stdio.h>

int main(void)
{
    float l, b;
    printf("Enter length and breadth: ");
    scanf("%f %f", &l, &b);
    printf("Area      = %.2f\n", l * b);
    printf("Perimeter = %.2f\n", 2 * (l + b));
    return 0;
}
''', "8 5")
add(61, r'''
#include <stdio.h>

int main(void)
{
    float r;
    printf("Enter radius: ");
    scanf("%f", &r);
    printf("Area of circle = %.2f\n", 3.14159f * r * r);
    return 0;
}
''', "7")
add(62, r'''
#include <stdio.h>

int main(void)
{
    float c, f;
    printf("Enter temperature in Celsius: ");
    scanf("%f", &c);
    f = c * 9 / 5 + 32;
    printf("%.1f C = %.1f F\n", c, f);
    return 0;
}
''', "37")
add(63, r'''
#include <stdio.h>

int main(void)
{
    float f, c;
    printf("Enter temperature in Fahrenheit: ");
    scanf("%f", &f);
    c = (f - 32) * 5 / 9;
    printf("%.1f F = %.1f C\n", f, c);
    return 0;
}
''', "98.6")
add(64, r'''
#include <stdio.h>

int main(void)
{
    float km;
    printf("Enter distance in km: ");
    scanf("%f", &km);
    printf("%.2f km = %.0f metres = %.0f centimetres\n", km, km * 1000, km * 100000);
    return 0;
}
''', "2.5")
add(65, r'''
#include <stdio.h>

int main(void)
{
    int total, h, m, s;
    printf("Enter total seconds: ");
    scanf("%d", &total);
    h = total / 3600;
    m = (total % 3600) / 60;
    s = total % 60;
    printf("%d seconds = %d h %d m %d s\n", total, h, m, s);
    return 0;
}
''', "7384")
add(66, r'''
#include <stdio.h>

int main(void)
{
    int days, years, weeks, rest;
    printf("Enter number of days: ");
    scanf("%d", &days);
    years = days / 365;
    rest  = days % 365;
    weeks = rest / 7;
    rest  = rest % 7;
    printf("%d days = %d year(s), %d week(s), %d day(s)\n", days, years, weeks, rest);
    return 0;
}
''', "1000")
add(67, r'''
#include <stdio.h>

int main(void)
{
    const float GST = 0.18f;          /* cannot be changed later */
    float price = 500.0f;
    float tax = price * GST;
    printf("Price = %.2f, GST = %.2f, Total = %.2f\n", price, tax, price + tax);
    return 0;
}
''')
add(68, r'''
#include <stdio.h>
#define PI 3.14159

int main(void)
{
    float r;
    printf("Enter radius: ");
    scanf("%f", &r);
    printf("Area = %.2f\n", PI * r * r);
    return 0;
}
''', "5")
add(69, r'''
#include <stdio.h>

int main(void)
{
    float p, r, t, si;
    printf("Enter principal, rate and time: ");
    scanf("%f %f %f", &p, &r, &t);
    si = (p * r * t) / 100;
    printf("Simple Interest = %.2f\n", si);
    return 0;
}
''', "10000 7.5 3")
add(70, r'''
#include <stdio.h>

int main(void)
{
    float price; int qty;
    printf("Enter price and quantity: ");
    scanf("%f %d", &price, &qty);
    printf("Bill amount = %.2f\n", price * qty);
    return 0;
}
''', "49.99 3")
add(71, r'''
#include <stdio.h>

int main(void)
{
    float a, b;
    printf("Enter two numbers: ");
    scanf("%f %f", &a, &b);
    printf("Mean = %.2f\n", (a + b) / 2);
    return 0;
}
''', "12.5 7.5")
add(72, r'''
#include <stdio.h>

int main(void)
{
    char ch;
    printf("Enter a character: ");
    scanf(" %c", &ch);
    printf("Integer code of '%c' = %d\n", ch, (int)ch);
    return 0;
}
''', "a")
add(73, r'''
#include <stdio.h>

int main(void)
{
    int h, m, s;
    printf("Enter time as HH MM SS: ");
    scanf("%d %d %d", &h, &m, &s);
    printf("Total seconds = %d\n", h * 3600 + m * 60 + s);
    return 0;
}
''', "2 30 45")
add(74, r'''
#include <stdio.h>

int main(void)
{
    int metres;
    printf("Enter distance in metres: ");
    scanf("%d", &metres);
    printf("%d m = %d km %d m\n", metres, metres / 1000, metres % 1000);
    return 0;
}
''', "3456")
add(75, r'''
#include <stdio.h>

int main(void)
{
    float bill, percent, discount;
    printf("Enter bill amount and discount %%: ");
    scanf("%f %f", &bill, &percent);
    discount = bill * percent / 100;
    printf("Discount = %.2f\n", discount);
    printf("Pay      = %.2f\n", bill - discount);
    return 0;
}
''', "2500 15")
add(76, r'''
#include <stdio.h>

int main(void)
{
    int n;
    printf("Please type an integer: ");
    scanf("%d", &n);
    printf("The integer you typed is %d\n", n);
    return 0;
}
''', "42")
add(77, r'''
#include <stdio.h>

void showTwoDecimals(float x)
{
    printf("Value = %.2f\n", x);
}

int main(void)
{
    float x;
    printf("Enter a float: ");
    scanf("%f", &x);
    showTwoDecimals(x);
    return 0;
}
''', "2.71828")
add(78, r'''
#include <stdio.h>

int main(void)
{
    char ch;
    printf("Enter one character: ");
    if (scanf(" %c", &ch) != 1) {
        printf("Error: no character was read.\n");
        return 1;
    }
    if (ch < 32 || ch > 126) {
        printf("Error: not a printable character.\n");
        return 1;
    }
    printf("You entered: %c\n", ch);
    return 0;
}
''', "k")
add(79, r'''
#include <stdio.h>

int main(void)
{
    char name[30];
    for (int i = 1; i <= 3; i++) {          /* three sample inputs */
        scanf("%29s", name);
        printf("Test %d: Hello, %s!\n", i, name);
    }
    return 0;
}
''', "Asha Bhim Chitra")
add(80, r'''
#include <stdio.h>

int main(void)
{
    int a, b;                    /* variables for two numbers      */
    scanf("%d %d", &a, &b);      /* read both numbers in one line  */
    printf("a = %d and b = %d\n", a, b);   /* display them         */
    return 0;
}
''', "7 8")
add(81, r'''
#include <stdio.h>

int main(void)
{
    int a, b, c;
    scanf("%d %d %d", &a, &b, &c);
    printf("%d %d %d\n", c, b, a);      /* works for negative, zero and large values */
    return 0;
}
''', "-5 0 2147483647")
add(82, r'''
#include <stdio.h>

int main(void)
{
    int choice, a, b, t;
    do {
        printf("\n1. Swap two numbers\n2. Exit\nChoice: ");
        scanf("%d", &choice);
        if (choice == 1) {
            printf("Enter a and b: ");
            scanf("%d %d", &a, &b);
            t = a; a = b; b = t;
            printf("After swap: a=%d b=%d\n", a, b);
        }
    } while (choice != 2);
    return 0;
}
''', "1\n3 4\n2")
add(83, r'''
#include <stdio.h>

int main(void)
{
    int a, b;
    scanf("%d %d", &a, &b);
    printf("Start    : a=%d b=%d\n", a, b);
    a = a + b;  printf("a = a + b: a=%d b=%d\n", a, b);
    b = a - b;  printf("b = a - b: a=%d b=%d\n", a, b);
    a = a - b;  printf("a = a - b: a=%d b=%d\n", a, b);
    return 0;
}
''', "15 27")
add(84, r'''
#include <stdio.h>

int main(void)
{
    char name[30]; int roll; float marks;
    printf("%-10s %-6s %-6s\n", "Name", "Roll", "Marks");
    for (int i = 0; i < 3; i++) {
        scanf("%29s %d %f", name, &roll, &marks);
        printf("%-10s %-6d %-6.1f\n", name, roll, marks);
    }
    return 0;
}
''', "Asha 1 90\nBhanu 2 80\nChitra 3 70")
add(85, r'''
#include <stdio.h>

void rect(float l, float b, float *area, float *perimeter)
{
    *area = l * b;
    *perimeter = 2 * (l + b);
}

int main(void)
{
    float l, b, a, p;
    scanf("%f %f", &l, &b);
    rect(l, b, &a, &p);
    printf("Area = %.2f, Perimeter = %.2f\n", a, p);
    return 0;
}
''', "6 4")
add(86, r'''
#include <stdio.h>

int main(void)
{
    float r[3];
    for (int i = 0; i < 3; i++) scanf("%f", &r[i]);
    for (int i = 0; i < 3; i++)
        printf("Radius %.1f -> Area %.2f\n", r[i], 3.14159f * r[i] * r[i]);
    return 0;
}
''', "1 2 3")
add(87, r'''
#include <stdio.h>

struct Temp { float c, f; };

int main(void)
{
    struct Temp t;
    scanf("%f", &t.c);
    t.f = t.c * 9 / 5 + 32;
    printf("%.1f C = %.1f F\n", t.c, t.f);
    return 0;
}
''', "100")
add(88, r'''
#include <stdio.h>

int main(void)
{
    int n; float f;
    scanf("%d", &n);
    for (int i = 0; i < n; i++) {
        scanf("%f", &f);
        printf("%.1f F = %.1f C\n", f, (f - 32) * 5 / 9);
    }
    return 0;
}
''', "3\n32 212 98.6")
add(89, r'''
#include <stdio.h>

int main(void)
{
    float km;
    scanf("%f", &km);
    printf("+-----------+------------+\n");
    printf("| Unit      | Value      |\n");
    printf("+-----------+------------+\n");
    printf("| km        | %-10.2f |\n", km);
    printf("| metres    | %-10.0f |\n", km * 1000);
    printf("| cm        | %-10.0f |\n", km * 100000);
    printf("+-----------+------------+\n");
    return 0;
}
''', "1.25")
add(90, r'''
#include <stdio.h>

int main(void)
{
    int sec;
    for (int i = 0; i < 2; i++) {
        scanf("%d", &sec);
        if (sec < 0) {
            printf("Invalid: seconds cannot be negative (%d)\n", sec);
            continue;                        /* skip processing */
        }
        printf("%d s = %02d:%02d:%02d\n", sec, sec / 3600, (sec % 3600) / 60, sec % 60);
    }
    return 0;
}
''', "-10 3661")
add(91, r'''
#include <stdio.h>

int years(int d) { return d / 365; }
int weeks(int d) { return (d % 365) / 7; }
int rest(int d)  { return (d % 365) % 7; }

int main(void)
{
    int d;
    scanf("%d", &d);
    printf("%d days = %d year(s) %d week(s) %d day(s)\n", d, years(d), weeks(d), rest(d));
    return 0;
}
''', "800")
add(92, r'''
#include <stdio.h>

int main(void)
{
    /* Time: O(1)  Space: O(1) - a few variables, no loops. */
    const int SIDE = 6;
    int area = SIDE * SIDE;
    printf("Area of square with side %d = %d\n", SIDE, area);
    return 0;
}
''')
add(93, r'''
#include <stdio.h>
#define PI 3.14159

int main(void)
{
    float tests[] = {5.0f, 0.0f, 0.01f, 1000.0f};   /* normal, minimum, tiny, large */
    for (int i = 0; i < 4; i++)
        printf("r = %-8.2f area = %.2f\n", tests[i], PI * tests[i] * tests[i]);
    return 0;
}
''')
add(94, r'''
#include <stdio.h>

float simpleInterest(float p, float r, float t)   /* no global variables */
{
    return p * r * t / 100;
}

int main(void)
{
    float p, r, t;
    scanf("%f %f %f", &p, &r, &t);
    printf("Simple interest = %.2f\n", simpleInterest(p, r, t));
    return 0;
}
''', "5000 8 2")
add(95, r'''
#include <stdio.h>

int main(void)
{
    float price; int qty;
    if (scanf("%f %d", &price, &qty) != 2 || price < 0 || qty <= 0) {
        printf("Error: invalid price or quantity\n");
        return 1;
    }
    printf("Bill = %.2f\n", price * qty);
    return 0;
}
''', "20.5 4")
add(96, r'''
#include <stdio.h>

int main(void)
{
    /* Time: O(1) - three assignments.  Space: O(1) - one extra variable. */
    int a, b, temp;
    scanf("%d %d", &a, &b);
    temp = a; a = b; b = temp;
    printf("a=%d b=%d\n", a, b);
    return 0;
}
''', "11 22")
add(97, r'''
#include <stdio.h>

int main(void)
{
    char name[30]; int roll; float marks;
    printf("Enter name, roll and marks: ");
    scanf("%29s %d %f", name, &roll, &marks);
    printf("Name=%s Roll=%d Marks=%.1f\n", name, roll, marks);
    return 0;
}
''', "Meena 12 91.5")
add(98, r'''
#include <stdio.h>

int main(void)
{
    float r;                       /* radius of the circle      */
    scanf("%f", &r);               /* read the radius           */
    float area = 3.14159f * r * r; /* area = pi * r * r         */
    printf("Area = %.2f\n", area); /* show area with 2 decimals */
    return 0;
}
''', "3.5")
add(99, r'''
#include <stdio.h>

int main(void)
{
    printf("  F      C\n");
    for (int f = 32; f <= 212; f += 20)
        printf("%3d %6.1f\n", f, (f - 32) * 5.0 / 9);
    return 0;
}
''')
add(100, r'''
#include <stdio.h>

int main(void)
{
    int n, sec;
    scanf("%d", &n);
    for (int i = 0; i < n; i++) {
        scanf("%d", &sec);
        printf("%d s = %d h %d m %d s\n", sec, sec / 3600, (sec % 3600) / 60, sec % 60);
    }
    return 0;
}
''', "2\n59 3600")
