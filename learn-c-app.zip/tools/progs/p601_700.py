# programs 601-700
P = {}
def add(i, code, stdin=""): P[i] = (stdin, code.strip("\n"))

add(601, r'''
#include <stdio.h>

int main(void)
{
    int a[10][10], rows, cols, i, j;

    printf("Enter rows and columns (max 10 10): ");
    scanf("%d %d", &rows, &cols);
    printf("Enter %d elements:\n", rows * cols);
    for (i = 0; i < rows; i++)
        for (j = 0; j < cols; j++)
            scanf("%d", &a[i][j]);

    printf("The matrix is:\n");
    for (i = 0; i < rows; i++)
    {
        for (j = 0; j < cols; j++)
            printf("%4d", a[i][j]);
        printf("\n");
    }
    return 0;
}
''', "2 3\n1 2 3\n4 5 6\n")

add(602, r'''
#include <stdio.h>

int main(void)
{
    int a[10][10], b[10][10], sum[10][10], r, c, i, j;

    printf("Enter rows and columns: ");
    scanf("%d %d", &r, &c);
    printf("Enter matrix A (%d elements):\n", r * c);
    for (i = 0; i < r; i++)
        for (j = 0; j < c; j++)
            scanf("%d", &a[i][j]);
    printf("Enter matrix B (%d elements):\n", r * c);
    for (i = 0; i < r; i++)
        for (j = 0; j < c; j++)
            scanf("%d", &b[i][j]);

    for (i = 0; i < r; i++)
        for (j = 0; j < c; j++)
            sum[i][j] = a[i][j] + b[i][j];

    printf("A + B =\n");
    for (i = 0; i < r; i++)
    {
        for (j = 0; j < c; j++)
            printf("%5d", sum[i][j]);
        printf("\n");
    }
    return 0;
}
''', "2 2\n1 2\n3 4\n5 6\n7 8\n")

add(603, r'''
#include <stdio.h>

int main(void)
{
    int a[10][10], b[10][10], r, c, i, j;

    printf("Enter rows and columns: ");
    scanf("%d %d", &r, &c);
    printf("Enter matrix A:\n");
    for (i = 0; i < r; i++)
        for (j = 0; j < c; j++)
            scanf("%d", &a[i][j]);
    printf("Enter matrix B:\n");
    for (i = 0; i < r; i++)
        for (j = 0; j < c; j++)
            scanf("%d", &b[i][j]);

    printf("A - B =\n");
    for (i = 0; i < r; i++)
    {
        for (j = 0; j < c; j++)
            printf("%5d", a[i][j] - b[i][j]);
        printf("\n");
    }
    return 0;
}
''', "2 3\n9 8 7\n6 5 4\n1 2 3\n4 5 6\n")

add(604, r'''
#include <stdio.h>

int main(void)
{
    int a[10][10], b[10][10], p[10][10];
    int r1, c1, r2, c2, i, j, k;

    printf("Enter rows and columns of A: ");
    scanf("%d %d", &r1, &c1);
    printf("Enter rows and columns of B: ");
    scanf("%d %d", &r2, &c2);
    if (c1 != r2)
    {
        printf("Cannot multiply: columns of A must equal rows of B.\n");
        return 0;
    }
    printf("Enter matrix A:\n");
    for (i = 0; i < r1; i++)
        for (j = 0; j < c1; j++)
            scanf("%d", &a[i][j]);
    printf("Enter matrix B:\n");
    for (i = 0; i < r2; i++)
        for (j = 0; j < c2; j++)
            scanf("%d", &b[i][j]);

    for (i = 0; i < r1; i++)
        for (j = 0; j < c2; j++)
        {
            p[i][j] = 0;
            for (k = 0; k < c1; k++)
                p[i][j] += a[i][k] * b[k][j];
        }

    printf("A x B =\n");
    for (i = 0; i < r1; i++)
    {
        for (j = 0; j < c2; j++)
            printf("%5d", p[i][j]);
        printf("\n");
    }
    return 0;
}
''', "2 3\n3 2\n1 2 3\n4 5 6\n7 8\n9 10\n11 12\n")

add(605, r'''
#include <stdio.h>

int main(void)
{
    int a[10][10], r, c, i, j;

    printf("Enter rows and columns: ");
    scanf("%d %d", &r, &c);
    printf("Enter the matrix:\n");
    for (i = 0; i < r; i++)
        for (j = 0; j < c; j++)
            scanf("%d", &a[i][j]);

    printf("Transpose (%d x %d):\n", c, r);
    for (j = 0; j < c; j++)
    {
        for (i = 0; i < r; i++)
            printf("%4d", a[i][j]);
        printf("\n");
    }
    return 0;
}
''', "2 3\n1 2 3\n4 5 6\n")

add(606, r'''
#include <stdio.h>

int main(void)
{
    int a[3][4] = { {1, 2, 3, 4}, {5, 6, 7, 8}, {9, 10, 11, 12} };
    int i, j, sum;

    for (i = 0; i < 3; i++)
    {
        sum = 0;
        for (j = 0; j < 4; j++)
        {
            printf("%4d", a[i][j]);
            sum += a[i][j];
        }
        printf("  | Row %d sum = %d\n", i + 1, sum);
    }
    return 0;
}
''')

add(607, r'''
#include <stdio.h>

int main(void)
{
    int a[3][4] = { {2, 4, 6, 8}, {1, 3, 5, 7}, {10, 20, 30, 40} };
    int colsum[4] = {0};
    int i, j;

    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 4; j++)
        {
            printf("%4d", a[i][j]);
            colsum[j] += a[i][j];
        }
        printf("\n");
    }
    printf("----------------\n");
    for (j = 0; j < 4; j++)
        printf("%4d", colsum[j]);
    printf("   <- column sums\n");
    return 0;
}
''')

add(608, r'''
#include <stdio.h>

int main(void)
{
    int a[10][10], n, i, j, sum = 0;

    printf("Enter order of the square matrix: ");
    scanf("%d", &n);
    printf("Enter the elements:\n");
    for (i = 0; i < n; i++)
        for (j = 0; j < n; j++)
            scanf("%d", &a[i][j]);

    for (i = 0; i < n; i++)
        sum += a[i][i];
    printf("Main diagonal sum = %d\n", sum);
    return 0;
}
''', "3\n1 2 3\n4 5 6\n7 8 9\n")

add(609, r'''
#include <stdio.h>

int main(void)
{
    int a[10][10], n, i, j, sum = 0;

    printf("Enter order of the square matrix: ");
    scanf("%d", &n);
    printf("Enter the elements:\n");
    for (i = 0; i < n; i++)
        for (j = 0; j < n; j++)
            scanf("%d", &a[i][j]);

    for (i = 0; i < n; i++)
        sum += a[i][n - 1 - i];
    printf("Secondary diagonal sum = %d\n", sum);
    return 0;
}
''', "3\n1 2 3\n4 5 6\n7 8 9\n")

add(610, r'''
#include <stdio.h>

int main(void)
{
    int rows, cols;

    printf("Enter number of rows and columns: ");
    scanf("%d %d", &rows, &cols);
    if (rows == cols)
        printf("The %d x %d matrix is a square matrix.\n", rows, cols);
    else
        printf("The %d x %d matrix is NOT a square matrix.\n", rows, cols);
    return 0;
}
''', "3 4\n")

add(611, r'''
#include <stdio.h>

int main(void)
{
    int a[10][10], n, i, j, identity = 1;

    printf("Enter order of the square matrix: ");
    scanf("%d", &n);
    printf("Enter the elements:\n");
    for (i = 0; i < n; i++)
        for (j = 0; j < n; j++)
            scanf("%d", &a[i][j]);

    for (i = 0; i < n; i++)
        for (j = 0; j < n; j++)
        {
            if (i == j && a[i][j] != 1)
                identity = 0;
            if (i != j && a[i][j] != 0)
                identity = 0;
        }

    if (identity)
        printf("It is an identity matrix.\n");
    else
        printf("It is not an identity matrix.\n");
    return 0;
}
''', "3\n1 0 0\n0 1 0\n0 0 1\n")

add(612, r'''
#include <stdio.h>

int main(void)
{
    int a[10][10], n, i, j, diagonal = 1;

    printf("Enter order of the square matrix: ");
    scanf("%d", &n);
    printf("Enter the elements:\n");
    for (i = 0; i < n; i++)
        for (j = 0; j < n; j++)
            scanf("%d", &a[i][j]);

    /* every element off the main diagonal must be zero */
    for (i = 0; i < n; i++)
        for (j = 0; j < n; j++)
            if (i != j && a[i][j] != 0)
                diagonal = 0;

    printf(diagonal ? "It is a diagonal matrix.\n" : "It is not a diagonal matrix.\n");
    return 0;
}
''', "3\n5 0 0\n0 7 0\n0 0 2\n")

add(613, r'''
#include <stdio.h>

int main(void)
{
    int a[10][10], n, i, j, upper = 1;

    printf("Enter order of the square matrix: ");
    scanf("%d", &n);
    printf("Enter the elements:\n");
    for (i = 0; i < n; i++)
        for (j = 0; j < n; j++)
            scanf("%d", &a[i][j]);

    /* elements below the main diagonal (i > j) must be zero */
    for (i = 1; i < n; i++)
        for (j = 0; j < i; j++)
            if (a[i][j] != 0)
                upper = 0;

    if (upper)
        printf("It is an upper triangular matrix.\n");
    else
        printf("It is not an upper triangular matrix.\n");
    return 0;
}
''', "3\n1 2 3\n0 4 5\n0 0 6\n")

add(614, r'''
#include <stdio.h>

int main(void)
{
    int a[10][10], n, i, j, lower = 1;

    printf("Enter order of the square matrix: ");
    scanf("%d", &n);
    printf("Enter the elements:\n");
    for (i = 0; i < n; i++)
        for (j = 0; j < n; j++)
            scanf("%d", &a[i][j]);

    /* elements above the main diagonal (j > i) must be zero */
    for (i = 0; i < n; i++)
        for (j = i + 1; j < n; j++)
            if (a[i][j] != 0)
                lower = 0;

    if (lower)
        printf("It is a lower triangular matrix.\n");
    else
        printf("It is not a lower triangular matrix.\n");
    return 0;
}
''', "3\n1 0 0\n2 3 0\n4 5 6\n")

add(615, r'''
#include <stdio.h>

int main(void)
{
    int a[10][10], n, i, j, symmetric = 1;

    printf("Enter order of the square matrix: ");
    scanf("%d", &n);
    printf("Enter the elements:\n");
    for (i = 0; i < n; i++)
        for (j = 0; j < n; j++)
            scanf("%d", &a[i][j]);

    for (i = 0; i < n; i++)
        for (j = 0; j < n; j++)
            if (a[i][j] != a[j][i])
                symmetric = 0;

    if (symmetric)
        printf("The matrix is symmetric.\n");
    else
        printf("The matrix is not symmetric.\n");
    return 0;
}
''', "3\n1 2 3\n2 4 5\n3 5 6\n")

add(616, r'''
#include <stdio.h>

int main(void)
{
    int a[10][10], r, c, i, j, zeros = 0, total;

    printf("Enter rows and columns: ");
    scanf("%d %d", &r, &c);
    printf("Enter the elements:\n");
    for (i = 0; i < r; i++)
        for (j = 0; j < c; j++)
        {
            scanf("%d", &a[i][j]);
            if (a[i][j] == 0)
                zeros++;
        }

    total = r * c;
    printf("Zeros = %d out of %d elements\n", zeros, total);
    /* a matrix is sparse when more than half of its elements are zero */
    if (zeros > total / 2)
        printf("The matrix is sparse.\n");
    else
        printf("The matrix is not sparse.\n");
    return 0;
}
''', "3 3\n1 0 0\n0 0 2\n0 3 0\n")

add(617, r'''
#include <stdio.h>

int main(void)
{
    int a[10][10], r, c, i, j, max, min;

    printf("Enter rows and columns: ");
    scanf("%d %d", &r, &c);
    printf("Enter the elements:\n");
    for (i = 0; i < r; i++)
        for (j = 0; j < c; j++)
            scanf("%d", &a[i][j]);

    max = min = a[0][0];
    for (i = 0; i < r; i++)
        for (j = 0; j < c; j++)
        {
            if (a[i][j] > max)
                max = a[i][j];
            if (a[i][j] < min)
                min = a[i][j];
        }
    printf("Largest element  = %d\n", max);
    printf("Smallest element = %d\n", min);
    return 0;
}
''', "2 3\n14 -3 27\n8 0 19\n")

add(618, r'''
#include <stdio.h>

int main(void)
{
    int a[10][10], r, c, i, j, key, found = 0;

    printf("Enter rows and columns: ");
    scanf("%d %d", &r, &c);
    printf("Enter the elements:\n");
    for (i = 0; i < r; i++)
        for (j = 0; j < c; j++)
            scanf("%d", &a[i][j]);
    printf("Enter the value to search: ");
    scanf("%d", &key);

    for (i = 0; i < r; i++)
        for (j = 0; j < c; j++)
            if (a[i][j] == key)
            {
                printf("%d found at row %d, column %d\n", key, i + 1, j + 1);
                found = 1;
            }
    if (!found)
        printf("%d is not present in the matrix.\n", key);
    return 0;
}
''', "3 3\n4 8 15\n16 23 42\n7 8 9\n8\n")

add(619, r'''
#include <stdio.h>

int main(void)
{
    int a[3][3] = { {1, 2, 3}, {4, 5, 6}, {7, 8, 9} };
    int i, j;

    /* row-major: finish one row before moving to the next */
    printf("Row-major order: ");
    for (i = 0; i < 3; i++)
        for (j = 0; j < 3; j++)
            printf("%d ", a[i][j]);
    printf("\n");
    return 0;
}
''')

add(620, r'''
#include <stdio.h>

int main(void)
{
    int a[3][4] = { {1, 2, 3, 4}, {5, 6, 7, 8}, {9, 10, 11, 12} };
    int i, j;

    /* column-major: finish one column before moving to the next */
    printf("Column-major order: ");
    for (j = 0; j < 4; j++)
        for (i = 0; i < 3; i++)
            printf("%d ", a[i][j]);
    printf("\n");
    return 0;
}
''')

add(621, r'''
#include <stdio.h>

int main(void)
{
    int a[3][4] = { {1, 2, 3, 4}, {5, 6, 7, 8}, {9, 10, 11, 12} };
    int top = 0, bottom = 2, left = 0, right = 3, i;

    printf("Spiral order: ");
    while (top <= bottom && left <= right)
    {
        for (i = left; i <= right; i++)
            printf("%d ", a[top][i]);
        top++;
        for (i = top; i <= bottom; i++)
            printf("%d ", a[i][right]);
        right--;
        if (top <= bottom)
        {
            for (i = right; i >= left; i--)
                printf("%d ", a[bottom][i]);
            bottom--;
        }
        if (left <= right)
        {
            for (i = bottom; i >= top; i--)
                printf("%d ", a[i][left]);
            left++;
        }
    }
    printf("\n");
    return 0;
}
''')

add(622, r'''
#include <stdio.h>

int main(void)
{
    int a[10][10], r[10][10], n, i, j;

    printf("Enter order of the square matrix: ");
    scanf("%d", &n);
    printf("Enter the elements:\n");
    for (i = 0; i < n; i++)
        for (j = 0; j < n; j++)
            scanf("%d", &a[i][j]);

    /* element (i,j) moves to (j, n-1-i) */
    for (i = 0; i < n; i++)
        for (j = 0; j < n; j++)
            r[j][n - 1 - i] = a[i][j];

    printf("Rotated 90 degrees clockwise:\n");
    for (i = 0; i < n; i++)
    {
        for (j = 0; j < n; j++)
            printf("%4d", r[i][j]);
        printf("\n");
    }
    return 0;
}
''', "3\n1 2 3\n4 5 6\n7 8 9\n")

add(623, r'''
#include <stdio.h>

int main(void)
{
    int a[10][10], r[10][10], n, i, j;

    printf("Enter order of the square matrix: ");
    scanf("%d", &n);
    printf("Enter the elements:\n");
    for (i = 0; i < n; i++)
        for (j = 0; j < n; j++)
            scanf("%d", &a[i][j]);

    /* element (i,j) moves to (n-1-j, i) */
    for (i = 0; i < n; i++)
        for (j = 0; j < n; j++)
            r[n - 1 - j][i] = a[i][j];

    printf("Rotated 90 degrees anticlockwise:\n");
    for (i = 0; i < n; i++)
    {
        for (j = 0; j < n; j++)
            printf("%4d", r[i][j]);
        printf("\n");
    }
    return 0;
}
''', "3\n1 2 3\n4 5 6\n7 8 9\n")

add(624, r'''
#include <stdio.h>

int main(void)
{
    int a[3][4] = { {1, 2, 3, 4}, {5, 6, 7, 8}, {9, 10, 11, 12} };
    int i, j, temp;

    for (i = 0; i < 3; i++)
        for (j = 0; j < 2; j++)
        {
            temp = a[i][j];
            a[i][j] = a[i][3 - j];
            a[i][3 - j] = temp;
        }

    printf("Each row reversed:\n");
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 4; j++)
            printf("%4d", a[i][j]);
        printf("\n");
    }
    return 0;
}
''')

add(625, r'''
#include <stdio.h>

int main(void)
{
    int a[3][4] = { {9, 3, 7, 1}, {4, 8, 2, 6}, {12, 11, 5, 10} };
    int i, j, k, temp;

    for (i = 0; i < 3; i++)             /* bubble sort each row */
        for (j = 0; j < 3; j++)
            for (k = 0; k < 3 - j; k++)
                if (a[i][k] > a[i][k + 1])
                {
                    temp = a[i][k];
                    a[i][k] = a[i][k + 1];
                    a[i][k + 1] = temp;
                }

    printf("Rows sorted in ascending order:\n");
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 4; j++)
            printf("%4d", a[i][j]);
        printf("\n");
    }
    return 0;
}
''')
