# programs 351-400 : id -> (stdin, code)
P = {}
def add(i, code, stdin=""): P[i] = (stdin, code.strip("\n"))

add(351, r'''
#include <stdio.h>

int main(void)
{
    long long n;
    int count = 0;

    printf("Enter an integer: ");
    if (scanf("%lld", &n) != 1) {
        printf("Invalid input.\n");
        return 1;
    }
    if (n < 0) n = -n;               /* ignore the sign */
    if (n == 0) count = 1;           /* zero has one digit */
    while (n > 0) {
        count++;
        n /= 10;                     /* drop the last digit */
    }
    printf("Number of digits = %d\n", count);
    return 0;
}
''', "9047215")

add(352, r'''
#include <stdio.h>

int main(void)
{
    long long n, temp;
    int sum = 0;

    printf("Enter an integer: ");
    if (scanf("%lld", &n) != 1) return 1;
    temp = n < 0 ? -n : n;
    while (temp > 0) {
        sum += temp % 10;            /* add last digit */
        temp /= 10;
    }
    printf("Sum of digits of %lld = %d\n", n, sum);
    return 0;
}
''', "48253")

add(353, r'''
#include <stdio.h>

int main(void)
{
    long long n, temp;
    long long product = 1;

    printf("Enter an integer: ");
    if (scanf("%lld", &n) != 1) return 1;
    temp = n < 0 ? -n : n;
    if (temp == 0) product = 0;
    while (temp > 0) {
        product *= temp % 10;        /* multiply by last digit */
        temp /= 10;
    }
    printf("Product of digits of %lld = %lld\n", n, product);
    return 0;
}
''', "2736")

add(354, r'''
#include <stdio.h>

int main(void)
{
    long long n, temp, rev = 0;

    printf("Enter an integer: ");
    if (scanf("%lld", &n) != 1) return 1;
    temp = n < 0 ? -n : n;
    while (temp > 0) {
        rev = rev * 10 + temp % 10;  /* append last digit to rev */
        temp /= 10;
    }
    if (n < 0) rev = -rev;
    printf("Reverse of %lld = %lld\n", n, rev);
    return 0;
}
''', "-12345")

add(355, r'''
#include <stdio.h>

int main(void)
{
    long long n;

    printf("Enter an integer: ");
    if (scanf("%lld", &n) != 1) return 1;
    if (n < 0) n = -n;
    while (n >= 10)
        n /= 10;                     /* strip digits until one is left */
    printf("First digit = %lld\n", n);
    return 0;
}
''', "82937")

add(356, r'''
#include <stdio.h>

int main(void)
{
    int n, last;

    printf("Enter an integer: ");
    if (scanf("%d", &n) != 1) return 1;
    last = n % 10;
    if (last < 0) last = -last;
    printf("Last digit of %d = %d\n", n, last);
    return 0;
}
''', "-60417")

add(357, r'''
#include <stdio.h>

int main(void)
{
    long long n, first, last;

    printf("Enter an integer: ");
    if (scanf("%lld", &n) != 1) return 1;
    if (n < 0) n = -n;
    last = n % 10;
    first = n;
    while (first >= 10)
        first /= 10;
    printf("First digit = %lld\n", first);
    printf("Last digit  = %lld\n", last);
    printf("Sum         = %lld\n", first + last);
    return 0;
}
''', "75942")

add(358, r'''
#include <stdio.h>

int main(void)
{
    long long n;
    int even = 0, odd = 0;

    printf("Enter an integer: ");
    if (scanf("%lld", &n) != 1) return 1;
    if (n < 0) n = -n;
    do {
        if ((n % 10) % 2 == 0) even++;
        else odd++;
        n /= 10;
    } while (n > 0);
    printf("Even digits = %d\n", even);
    printf("Odd digits  = %d\n", odd);
    return 0;
}
''', "2846193")

add(359, r'''
#include <stdio.h>

int main(void)
{
    long long n;
    int zeros = 0;

    printf("Enter an integer: ");
    if (scanf("%lld", &n) != 1) return 1;
    if (n < 0) n = -n;
    do {
        if (n % 10 == 0) zeros++;
        n /= 10;
    } while (n > 0);                 /* do-while so that 0 is counted */
    printf("Number of zero digits = %d\n", zeros);
    return 0;
}
''', "1002030")

add(360, r'''
#include <stdio.h>

int main(void)
{
    long long n;
    int digit, count = 0;

    printf("Enter an integer: ");
    if (scanf("%lld", &n) != 1) return 1;
    printf("Enter the digit to count (0-9): ");
    if (scanf("%d", &digit) != 1 || digit < 0 || digit > 9) {
        printf("Invalid digit.\n");
        return 1;
    }
    if (n < 0) n = -n;
    do {
        if (n % 10 == digit) count++;
        n /= 10;
    } while (n > 0);
    printf("Digit %d occurs %d time(s)\n", digit, count);
    return 0;
}
''', "7377427 7")

add(361, r'''
#include <stdio.h>

int main(void)
{
    long long n;
    int largest = 0;

    printf("Enter an integer: ");
    if (scanf("%lld", &n) != 1) return 1;
    if (n < 0) n = -n;
    while (n > 0) {
        int d = n % 10;
        if (d > largest) largest = d;
        n /= 10;
    }
    printf("Largest digit = %d\n", largest);
    return 0;
}
''', "483925")

add(362, r'''
#include <stdio.h>

int main(void)
{
    long long n;
    int smallest = 9;

    printf("Enter an integer: ");
    if (scanf("%lld", &n) != 1) return 1;
    if (n < 0) n = -n;
    do {
        int d = n % 10;
        if (d < smallest) smallest = d;
        n /= 10;
    } while (n > 0);
    printf("Smallest digit = %d\n", smallest);
    return 0;
}
''', "483925")

add(363, r'''
#include <stdio.h>

int main(void)
{
    long long n, temp;
    int count[10] = {0};             /* count[d] = times digit d appears */
    int d;

    printf("Enter an integer: ");
    if (scanf("%lld", &n) != 1) return 1;
    temp = n < 0 ? -n : n;
    do {
        count[temp % 10]++;
        temp /= 10;
    } while (temp > 0);

    printf("Digits in ascending order: ");
    for (d = 0; d <= 9; d++) {
        int k;
        for (k = 0; k < count[d]; k++)
            printf("%d", d);
    }
    printf("\n");
    return 0;
}
''', "703951482")

add(364, r'''
#include <stdio.h>

int main(void)
{
    long long n, temp;
    int count[10] = {0};
    int d;

    printf("Enter an integer: ");
    if (scanf("%lld", &n) != 1) return 1;
    temp = n < 0 ? -n : n;
    do {
        count[temp % 10]++;
        temp /= 10;
    } while (temp > 0);

    printf("Digits in descending order: ");
    for (d = 9; d >= 0; d--) {
        int k;
        for (k = 0; k < count[d]; k++)
            printf("%d", d);
    }
    printf("\n");
    return 0;
}
''', "703951482")

add(365, r'''
#include <stdio.h>

int main(void)
{
    long long n, temp, result = 0, place = 1;
    int digit;

    printf("Enter an integer: ");
    if (scanf("%lld", &n) != 1) return 1;
    printf("Enter the digit to remove: ");
    if (scanf("%d", &digit) != 1 || digit < 0 || digit > 9) return 1;
    temp = n < 0 ? -n : n;
    while (temp > 0) {
        int d = temp % 10;
        if (d != digit) {            /* keep every other digit */
            result += d * place;
            place *= 10;
        }
        temp /= 10;
    }
    printf("After removing %d from %lld: %lld\n", digit, n, result);
    return 0;
}
''', "5253025 5")

add(366, r'''
#include <stdio.h>

int main(void)
{
    long long n, temp, result = 0, place = 1;

    printf("Enter an integer: ");
    if (scanf("%lld", &n) != 1) return 1;
    temp = n < 0 ? -n : n;
    if (temp == 0) result = 1;
    while (temp > 0) {
        int d = temp % 10;
        if (d == 0) d = 1;           /* replace zero by one */
        result += d * place;
        place *= 10;
        temp /= 10;
    }
    printf("Original: %lld\nModified: %lld\n", n, result);
    return 0;
}
''', "50307008")

add(367, r'''
#include <stdio.h>

int main(void)
{
    long long n, first;
    int last;

    printf("Enter an integer: ");
    if (scanf("%lld", &n) != 1) return 1;
    if (n < 0) n = -n;
    last = n % 10;
    first = n;
    while (first >= 10)
        first /= 10;
    printf("%lld + %d = %lld\n", first, last, first + last);
    return 0;
}
''', "63218")

add(368, r'''
#include <stdio.h>

int main(void)
{
    long long n, first, power = 1, middle, result;
    int last;

    printf("Enter a positive integer: ");
    if (scanf("%lld", &n) != 1 || n <= 0) {
        printf("Invalid input.\n");
        return 1;
    }
    last = n % 10;
    first = n;
    while (first >= 10) {
        first /= 10;
        power *= 10;                 /* power = 10^(digits-1) */
    }
    if (power == 1) {
        result = n;                  /* single digit: nothing to swap */
    } else {
        middle = (n % power) / 10;   /* digits between first and last */
        result = last * power + middle * 10 + first;
    }
    printf("After swapping: %lld\n", result);
    return 0;
}
''', "48729")

add(369, r'''
#include <stdio.h>

int main(void)
{
    long long n, temp;
    int increasing = 1, prev;

    printf("Enter a positive integer: ");
    if (scanf("%lld", &n) != 1 || n < 0) return 1;
    temp = n;
    prev = temp % 10;                /* start from the last digit */
    temp /= 10;
    while (temp > 0) {
        int cur = temp % 10;
        if (cur >= prev) {           /* left digit must be smaller */
            increasing = 0;
            break;
        }
        prev = cur;
        temp /= 10;
    }
    printf("%lld: digits are %sin increasing order\n", n, increasing ? "" : "not ");
    return 0;
}
''', "13579")

add(370, r'''
#include <stdio.h>

int main(void)
{
    long long n, temp;
    int decreasing = 1, prev;

    printf("Enter a positive integer: ");
    if (scanf("%lld", &n) != 1 || n < 0) return 1;
    temp = n;
    prev = temp % 10;
    temp /= 10;
    while (temp > 0) {
        int cur = temp % 10;
        if (cur <= prev) {           /* left digit must be larger */
            decreasing = 0;
            break;
        }
        prev = cur;
        temp /= 10;
    }
    printf("%lld: digits are %sin decreasing order\n", n, decreasing ? "" : "not ");
    return 0;
}
''', "97531")

add(371, r'''
#include <stdio.h>

int main(void)
{
    unsigned int n, p = 1;

    printf("Enter a non-negative decimal integer: ");
    if (scanf("%u", &n) != 1) return 1;
    printf("Binary of %u = ", n);
    while (p <= n / 2 && n > 0)
        p *= 2;                      /* highest power of 2 not above n */
    if (n == 0) {
        printf("0");
    } else {
        for (; p > 0; p /= 2) {      /* print bits from the top, no array */
            printf("%u", n / p);
            n %= p;
        }
    }
    printf("\n");
    return 0;
}
''', "181")

add(372, r'''
#include <stdio.h>

int main(void)
{
    long long bin, temp;
    int decimal = 0, power = 1;

    printf("Enter a binary number: ");
    if (scanf("%lld", &bin) != 1 || bin < 0) return 1;
    temp = bin;
    while (temp > 0) {
        int bit = temp % 10;
        if (bit > 1) {
            printf("Invalid binary number.\n");
            return 1;
        }
        decimal += bit * power;
        power *= 2;
        temp /= 10;
    }
    printf("Decimal of %lld = %d\n", bin, decimal);
    return 0;
}
''', "1101101")

add(373, r'''
#include <stdio.h>

int main(void)
{
    int n, temp;
    long long octal = 0, place = 1;

    printf("Enter a decimal integer: ");
    if (scanf("%d", &n) != 1 || n < 0) return 1;
    temp = n;
    while (temp > 0) {
        octal += (temp % 8) * place; /* remainder is the next octal digit */
        place *= 10;
        temp /= 8;
    }
    printf("Octal of %d = %lld\n", n, octal);
    return 0;
}
''', "500")

add(374, r'''
#include <stdio.h>

int main(void)
{
    long long oct, temp;
    int decimal = 0, power = 1;

    printf("Enter an octal number: ");
    if (scanf("%lld", &oct) != 1 || oct < 0) return 1;
    temp = oct;
    while (temp > 0) {
        int d = temp % 10;
        if (d > 7) {
            printf("Invalid octal digit %d.\n", d);
            return 1;
        }
        decimal += d * power;
        power *= 8;
        temp /= 10;
    }
    printf("Decimal of octal %lld = %d\n", oct, decimal);
    return 0;
}
''', "7345")

add(375, r'''
#include <stdio.h>

int main(void)
{
    unsigned int n, p = 1, temp;
    const char digits[] = "0123456789ABCDEF";

    printf("Enter a non-negative decimal integer: ");
    if (scanf("%u", &n) != 1) return 1;
    printf("Hexadecimal of %u = ", n);
    temp = n;
    while (temp >= 16) {             /* find highest power of 16 */
        p *= 16;
        temp /= 16;
    }
    for (; p > 0; p /= 16) {
        printf("%c", digits[n / p]);
        n %= p;
    }
    printf("\n");
    return 0;
}
''', "48879")

add(376, r'''
#include <stdio.h>

int main(void)
{
    long long bin, temp, octal = 0, place = 1;

    printf("Enter a binary number: ");
    if (scanf("%lld", &bin) != 1 || bin < 0) return 1;
    temp = bin;
    while (temp > 0) {
        int group = temp % 1000;     /* take 3 bits at a time */
        int value = 0, weight = 1;
        while (group > 0) {
            int bit = group % 10;
            if (bit > 1) {
                printf("Invalid binary number.\n");
                return 1;
            }
            value += bit * weight;
            weight *= 2;
            group /= 10;
        }
        octal += value * place;
        place *= 10;
        temp /= 1000;
    }
    printf("Octal of %lld = %lld\n", bin, octal);
    return 0;
}
''', "11010111")

add(377, r'''
#include <stdio.h>

int main(void)
{
    long long bin, temp;
    char hex[20];
    int len = 0, i;
    const char digits[] = "0123456789ABCDEF";

    printf("Enter a binary number: ");
    if (scanf("%lld", &bin) != 1 || bin <= 0) return 1;
    temp = bin;
    while (temp > 0 && len < 19) {
        int group = temp % 10000;    /* 4 bits at a time */
        int value = 0, weight = 1;
        while (group > 0) {
            int bit = group % 10;
            if (bit > 1) {
                printf("Invalid binary number.\n");
                return 1;
            }
            value += bit * weight;
            weight *= 2;
            group /= 10;
        }
        hex[len++] = digits[value];
        temp /= 10000;
    }
    printf("Hexadecimal of %lld = ", bin);
    for (i = len - 1; i >= 0; i--)
        printf("%c", hex[i]);
    printf("\n");
    return 0;
}
''', "1011111011101111")

add(378, r'''
#include <stdio.h>

int main(void)
{
    long long a, b, sum = 0, place = 1;
    long long x, y;
    int carry = 0;

    printf("Enter two binary numbers: ");
    if (scanf("%lld %lld", &a, &b) != 2 || a < 0 || b < 0) return 1;
    x = a;
    y = b;
    while (x > 0 || y > 0 || carry) {
        int bitA = x % 10, bitB = y % 10;
        int total = bitA + bitB + carry;
        if (bitA > 1 || bitB > 1) {
            printf("Invalid binary number.\n");
            return 1;
        }
        sum += (total % 2) * place;  /* result bit */
        carry = total / 2;           /* carry to next position */
        place *= 10;
        x /= 10;
        y /= 10;
    }
    printf("%lld + %lld = %lld (binary)\n", a, b, sum);
    return 0;
}
''', "101101 11011")

add(379, r'''
#include <stdio.h>
#include <string.h>

int main(void)
{
    char bin[33], ones[33], twos[33];
    int len, i, carry = 1;

    printf("Enter a binary number (up to 32 bits): ");
    if (scanf("%32s", bin) != 1) return 1;
    len = (int)strlen(bin);
    for (i = 0; i < len; i++) {
        if (bin[i] != '0' && bin[i] != '1') {
            printf("Invalid binary number.\n");
            return 1;
        }
        ones[i] = (bin[i] == '0') ? '1' : '0';   /* flip every bit */
    }
    ones[len] = '\0';
    strcpy(twos, ones);
    for (i = len - 1; i >= 0 && carry; i--) {    /* add 1 to the 1's complement */
        if (twos[i] == '0') {
            twos[i] = '1';
            carry = 0;
        } else {
            twos[i] = '0';
        }
    }
    printf("Number        : %s\n", bin);
    printf("1's complement: %s\n", ones);
    printf("2's complement: %s\n", twos);
    return 0;
}
''', "01101100")

add(380, r'''
#include <stdio.h>

int main(void)
{
    unsigned int n, temp;
    int count = 0;

    printf("Enter an unsigned integer: ");
    if (scanf("%u", &n) != 1) return 1;
    temp = n;
    while (temp != 0) {
        temp &= temp - 1;            /* clears the lowest set bit */
        count++;
    }
    printf("Set bits in %u = %d\n", n, count);
    return 0;
}
''', "2863311530")

add(381, r'''
#include <stdio.h>

int main(void)
{
    long long n;
    int pos = 1, oddCount = 0, evenCount = 0;

    printf("Enter an integer: ");
    if (scanf("%lld", &n) != 1) return 1;
    if (n < 0) n = -n;
    do {
        int d = n % 10;
        printf("Position %d (from right): digit %d\n", pos, d);
        if (pos % 2 == 1) oddCount++;
        else evenCount++;
        pos++;
        n /= 10;
    } while (n > 0);
    printf("Digits at odd positions  = %d\n", oddCount);
    printf("Digits at even positions = %d\n", evenCount);
    return 0;
}
''', "836194")

add(382, r'''
#include <stdio.h>

int main(void)
{
    long long n;
    int largest = -1, second = -1;

    printf("Enter an integer: ");
    if (scanf("%lld", &n) != 1) return 1;
    if (n < 0) n = -n;
    do {
        int d = n % 10;
        if (d > largest) {
            second = largest;
            largest = d;
        } else if (d > second && d != largest) {
            second = d;
        }
        n /= 10;
    } while (n > 0);
    if (second == -1)
        printf("There is no second-largest digit (all digits equal).\n");
    else
        printf("Largest = %d, second-largest = %d\n", largest, second);
    return 0;
}
''', "9482969")

add(383, r'''
#include <stdio.h>

int main(void)
{
    int n, temp, sum = 0;

    printf("Enter a positive integer: ");
    if (scanf("%d", &n) != 1 || n <= 0) {
        printf("Invalid input.\n");
        return 1;
    }
    temp = n;
    while (temp > 0) {
        sum += temp % 10;
        temp /= 10;
    }
    printf("Sum of digits = %d\n", sum);
    if (sum % n == 0)
        printf("Sum %d is divisible by the number %d\n", sum, n);
    else
        printf("Sum %d is not divisible by the number %d (remainder %d)\n", sum, n, sum % n);
    return 0;
}
''', "24")

add(384, r'''
#include <stdio.h>

int main(void)
{
    long long n;

    printf("Enter a positive integer: ");
    if (scanf("%lld", &n) != 1 || n <= 0) return 1;
    printf("Removing the last digit repeatedly:\n");
    while (n > 0) {
        printf("%lld\n", n);
        n /= 10;                     /* remove last digit */
    }
    printf("0\n");
    return 0;
}
''', "58213")

add(385, r'''
#include <stdio.h>

int main(void)
{
    unsigned int n, base;
    const char digits[] = "0123456789ABCDEF";

    printf("Enter a positive decimal number: ");
    if (scanf("%u", &n) != 1 || n == 0) return 1;
    for (base = 2; base <= 16; base++) {
        char buf[40];
        int len = 0, i;
        unsigned int temp = n;
        while (temp > 0) {
            buf[len++] = digits[temp % base];
            temp /= base;
        }
        printf("Base %2u: ", base);
        for (i = len - 1; i >= 0; i--)
            putchar(buf[i]);
        putchar('\n');
    }
    return 0;
}
''', "255")

add(386, r'''
#include <stdio.h>
#include <string.h>

int main(void)
{
    char text[40];
    int i, count = 0;

    printf("Enter an integer: ");
    if (scanf("%39s", text) != 1) return 1;
    for (i = 0; text[i] != '\0'; i++) {
        if (text[i] >= '0' && text[i] <= '9')
            count++;                 /* count only digit characters */
    }
    printf("You entered %s\n", text);
    printf("Number of digits = %d\n", count);
    return 0;
}
''', "-1048576")

add(387, r'''
#include <stdio.h>

/* returns the sum of the digits of n */
int digitSum(long long n)
{
    int sum = 0;
    if (n < 0) n = -n;
    while (n > 0) {
        sum += n % 10;
        n /= 10;
    }
    return sum;
}

int main(void)
{
    long long n;

    printf("Enter an integer: ");
    if (scanf("%lld", &n) != 1) return 1;
    printf("Sum of digits of %lld = %d\n", n, digitSum(n));
    return 0;
}
''', "987654")

add(388, r'''
#include <stdio.h>

int main(void)
{
    long long n, product = 1;
    int ch;

    printf("Enter an integer: ");
    if (scanf("%lld", &n) != 1) {
        printf("Error: input is not a valid integer.\n");
        return 1;
    }
    if (n < 0) {
        printf("Error: negative numbers are not allowed.\n");
        return 1;
    }
    ch = n;                          /* ch only used to mark zero case */
    if (ch == 0) product = 0;
    while (n > 0) {
        product *= n % 10;
        n /= 10;
    }
    printf("Product of digits = %lld\n", product);
    return 0;
}
''', "3452")

add(389, r'''
#include <stdio.h>

int main(void)
{
    int tests, t;

    printf("How many numbers? ");
    if (scanf("%d", &tests) != 1) return 1;
    for (t = 1; t <= tests; t++) {
        long long n, rev = 0, temp;
        if (scanf("%lld", &n) != 1) return 1;
        temp = n;
        while (temp > 0) {
            rev = rev * 10 + temp % 10;
            temp /= 10;
        }
        printf("Test %d: %lld reversed is %lld\n", t, n, rev);
    }
    return 0;
}
''', "3 1234 90100 7")

add(390, r'''
#include <stdio.h>

int main(void)
{
    long long n;

    printf("Enter an integer: ");
    if (scanf("%lld", &n) != 1) return 1;

    /* work with the absolute value so the sign does not matter */
    if (n < 0) n = -n;

    /* keep dividing by 10 until only the leading digit remains */
    while (n >= 10)
        n /= 10;

    printf("First digit = %lld\n", n);
    return 0;
}
''', "-6450")

add(391, r'''
#include <stdio.h>

int main(void)
{
    long long values[] = {0, 7, -58, 1000, 123456789012LL};
    int count = (int)(sizeof(values) / sizeof(values[0]));
    int i;

    printf("Boundary cases for the last digit:\n");
    for (i = 0; i < count; i++) {
        long long n = values[i];
        int last = (int)(n % 10);
        if (last < 0) last = -last;  /* negative numbers give negative remainder */
        printf("%15lld -> last digit %d\n", n, last);
    }
    return 0;
}
''')

add(392, r'''
#include <stdio.h>

int main(void)
{
    long long n, first;
    int last, choice;

    printf("Enter an integer: ");
    if (scanf("%lld", &n) != 1) return 1;
    if (n < 0) n = -n;
    last = n % 10;
    first = n;
    while (first >= 10)
        first /= 10;
    do {
        printf("\n1. First digit\n2. Last digit\n3. Sum of first and last\n4. Exit\nChoice: ");
        if (scanf("%d", &choice) != 1) break;
        switch (choice) {
        case 1: printf("First digit = %lld\n", first); break;
        case 2: printf("Last digit = %d\n", last); break;
        case 3: printf("Sum = %lld\n", first + last); break;
        case 4: printf("Goodbye.\n"); break;
        default: printf("Invalid choice.\n");
        }
    } while (choice != 4);
    return 0;
}
''', "4729 1 2 3 7 4")

add(393, r'''
#include <stdio.h>

int main(void)
{
    long long n;
    int even = 0, odd = 0;

    printf("Enter an integer: ");
    if (scanf("%lld", &n) != 1) return 1;
    if (n < 0) n = -n;
    do {
        int d = n % 10;
        printf("Digit %d is %s\n", d, d % 2 == 0 ? "even" : "odd");
        if (d % 2 == 0) even++;
        else odd++;
        n /= 10;
    } while (n > 0);
    printf("Total even = %d, total odd = %d\n", even, odd);
    return 0;
}
''', "50731")

add(394, r'''
#include <stdio.h>

int main(void)
{
    long long n;
    int zeros = 0;

    printf("Enter an integer: ");
    if (scanf("%lld", &n) != 1) return 1;
    if (n < 0) n = -n;
    if (n == 0) zeros = 1;
    while (n > 0) {                  /* one loop handles every digit */
        if (n % 10 == 0)
            zeros++;
        n /= 10;
    }
    printf("Zero digits = %d\n", zeros);
    return 0;
}
''', "305007009")

add(395, r'''
#include <stdio.h>

/* counts how many times digit appears in n; result stored through pointer */
void countDigit(long long n, int digit, int *result)
{
    *result = 0;
    if (n < 0) n = -n;
    do {
        if (n % 10 == digit)
            (*result)++;
        n /= 10;
    } while (n > 0);
}

int main(void)
{
    long long n;
    int digit, count;

    printf("Enter an integer and a digit (0-9): ");
    if (scanf("%lld %d", &n, &digit) != 2 || digit < 0 || digit > 9) return 1;
    countDigit(n, digit, &count);
    printf("Digit %d appears %d time(s) in %lld\n", digit, count, n);
    return 0;
}
''', "1223334444 3")

add(396, r'''
#include <stdio.h>

int main(void)
{
    long long n;
    int digits[20];
    int len = 0, i, largest;

    printf("Enter an integer: ");
    if (scanf("%lld", &n) != 1) return 1;
    if (n < 0) n = -n;
    do {
        digits[len++] = n % 10;      /* store each digit in the array */
        n /= 10;
    } while (n > 0);
    largest = digits[0];
    for (i = 1; i < len; i++)
        if (digits[i] > largest)
            largest = digits[i];
    printf("Digits stored (right to left):");
    for (i = 0; i < len; i++)
        printf(" %d", digits[i]);
    printf("\nLargest digit = %d\n", largest);
    return 0;
}
''', "1730428")

add(397, r'''
#include <stdio.h>

struct DigitInfo {
    long long number;
    int smallest;
    int length;
};

int main(void)
{
    struct DigitInfo info;
    long long temp;

    printf("Enter an integer: ");
    if (scanf("%lld", &info.number) != 1) return 1;
    temp = info.number < 0 ? -info.number : info.number;
    info.smallest = 9;
    info.length = 0;
    do {
        int d = temp % 10;
        if (d < info.smallest) info.smallest = d;
        info.length++;
        temp /= 10;
    } while (temp > 0);
    printf("Number   : %lld\n", info.number);
    printf("Digits   : %d\n", info.length);
    printf("Smallest : %d\n", info.smallest);
    return 0;
}
''', "9285716")

add(398, r'''
#include <stdio.h>

int main(void)
{
    int count, i;

    printf("How many numbers? ");
    if (scanf("%d", &count) != 1 || count <= 0) return 1;
    for (i = 0; i < count; i++) {
        long long n, temp;
        int freq[10] = {0}, d;
        if (scanf("%lld", &n) != 1) return 1;
        temp = n < 0 ? -n : n;
        do {
            freq[temp % 10]++;
            temp /= 10;
        } while (temp > 0);
        printf("%lld -> ", n);
        for (d = 0; d <= 9; d++) {
            int k;
            for (k = 0; k < freq[d]; k++)
                printf("%d", d);
        }
        printf("\n");
    }
    return 0;
}
''', "4 5271 90381 1000 86420")

add(399, r'''
#include <stdio.h>

int main(void)
{
    long long n, temp;
    int freq[10] = {0}, d;

    printf("Enter an integer: ");
    if (scanf("%lld", &n) != 1) return 1;
    temp = n < 0 ? -n : n;
    do {
        freq[temp % 10]++;
        temp /= 10;
    } while (temp > 0);

    printf("\n+------------------------------+\n");
    printf("| Original number : %-10lld |\n", n);
    printf("| Descending order: ");
    for (d = 9; d >= 0; d--) {
        int k;
        for (k = 0; k < freq[d]; k++)
            printf("%d", d);
    }
    printf("\n+------------------------------+\n");
    return 0;
}
''', "40817")

add(400, r'''
#include <stdio.h>

int main(void)
{
    long long n, temp, result = 0, place = 1;
    int digit;

    printf("Enter an integer: ");
    if (scanf("%lld", &n) != 1) {
        printf("Error: the number is not a valid integer.\n");
        return 1;
    }
    printf("Enter the digit to remove (0-9): ");
    if (scanf("%d", &digit) != 1 || digit < 0 || digit > 9) {
        printf("Error: the digit must be between 0 and 9.\n");
        return 1;
    }
    temp = n < 0 ? -n : n;
    while (temp > 0) {
        int d = temp % 10;
        if (d != digit) {
            result += d * place;
            place *= 10;
        }
        temp /= 10;
    }
    if (n < 0) result = -result;
    printf("Result after removing digit %d: %lld\n", digit, result);
    return 0;
}
''', "-2814218 2")
