# programs q576-q650 : id -> (stdin, code)
P = {}
def add(i, code, stdin=""): P[i] = (stdin, code.strip("\n"))

add(576, r'''
#include <stdio.h>

int main(void)
{
    int arr[50], n, key, i, found = -1;

    printf("Enter number of elements (1-50): ");
    if (scanf("%d", &n) != 1 || n < 1 || n > 50) {
        printf("Invalid size.\n");
        return 1;
    }
    printf("Enter %d elements: ", n);
    for (i = 0; i < n; i++)
        scanf("%d", &arr[i]);
    printf("Enter value to search: ");
    scanf("%d", &key);

    /* Linear search: check every element from the start; O(n) */
    for (i = 0; i < n; i++) {
        if (arr[i] == key) {
            found = i;
            break;
        }
    }
    if (found >= 0)
        printf("%d found at index %d (position %d)\n", key, found, found + 1);
    else
        printf("%d not found in the array\n", key);
    return 0;
}
''', "6\n12 45 7 33 90 21\n33")

add(577, r'''
#include <stdio.h>

/* Iterative binary search: returns index or -1 */
int binarySearch(const int a[], int n, int key)
{
    int low = 0, high = n - 1;
    while (low <= high) {
        int mid = low + (high - low) / 2;
        if (a[mid] == key)
            return mid;
        else if (a[mid] < key)
            low = mid + 1;
        else
            high = mid - 1;
    }
    return -1;
}

int main(void)
{
    int a[100], n, key, i, pos;

    printf("Enter number of elements: ");
    scanf("%d", &n);
    printf("Enter %d elements in ascending order: ", n);
    for (i = 0; i < n; i++)
        scanf("%d", &a[i]);
    printf("Enter key: ");
    scanf("%d", &key);

    pos = binarySearch(a, n, key);
    if (pos == -1)
        printf("Key %d not found\n", key);
    else
        printf("Key %d found at index %d\n", key, pos);
    return 0;
}
''', "8\n3 8 15 22 31 47 56 70\n47")

add(578, r'''
#include <stdio.h>

/* Recursive binary search on a[low..high] */
int search(const int a[], int low, int high, int key)
{
    int mid;
    if (low > high)
        return -1;
    mid = low + (high - low) / 2;
    if (a[mid] == key)
        return mid;
    if (key < a[mid])
        return search(a, low, mid - 1, key);
    return search(a, mid + 1, high, key);
}

int main(void)
{
    int a[50], n, key, i, pos;

    printf("Enter number of elements (1-50): ");
    if (scanf("%d", &n) != 1) {
        printf("Error: size must be an integer.\n");
        return 1;
    }
    if (n < 1 || n > 50) {
        printf("Error: size must be between 1 and 50.\n");
        return 1;
    }
    printf("Enter %d sorted integers: ", n);
    for (i = 0; i < n; i++) {
        if (scanf("%d", &a[i]) != 1) {
            printf("Error: element %d is not an integer.\n", i + 1);
            return 1;
        }
        if (i > 0 && a[i] < a[i - 1]) {
            printf("Error: array is not sorted at element %d.\n", i + 1);
            return 1;
        }
    }
    printf("Enter key: ");
    if (scanf("%d", &key) != 1) {
        printf("Error: key must be an integer.\n");
        return 1;
    }
    pos = search(a, 0, n - 1, key);
    if (pos < 0)
        printf("%d is not present\n", key);
    else
        printf("%d found at index %d\n", key, pos);
    return 0;
}
''', "7\n2 4 9 13 18 25 40\n18")

add(579, r'''
#include <stdio.h>

/* First occurrence using binary search: keep searching left after a hit */
int firstOccurrence(const int a[], int n, int key)
{
    int low = 0, high = n - 1, ans = -1;
    while (low <= high) {
        int mid = low + (high - low) / 2;
        if (a[mid] == key) {
            ans = mid;
            high = mid - 1;
        } else if (a[mid] < key)
            low = mid + 1;
        else
            high = mid - 1;
    }
    return ans;
}

int main(void)
{
    int t1[] = {1, 2, 2, 2, 5, 7};
    int t2[] = {4, 4, 4, 4};
    int t3[] = {3, 6, 9, 12, 15};
    int keys[] = {2, 4, 10};
    const int *tests[] = {t1, t2, t3};
    int sizes[] = {6, 4, 5};
    int i;

    for (i = 0; i < 3; i++) {
        int pos = firstOccurrence(tests[i], sizes[i], keys[i]);
        printf("Test %d: key %d -> ", i + 1, keys[i]);
        if (pos < 0)
            printf("not found\n");
        else
            printf("first occurrence at index %d\n", pos);
    }
    return 0;
}
''')

add(580, r'''
#include <stdio.h>

int main(void)
{
    int a[100], n, key, i;
    int low, high, mid, last = -1;

    printf("Enter n: ");
    scanf("%d", &n);
    printf("Enter %d sorted elements: ", n);
    for (i = 0; i < n; i++)
        scanf("%d", &a[i]);
    printf("Enter key: ");
    scanf("%d", &key);

    low = 0;
    high = n - 1;
    while (low <= high) {
        mid = low + (high - low) / 2;
        if (a[mid] == key) {
            last = mid;        /* remember the hit ...            */
            low = mid + 1;     /* ... and look further to the right */
        } else if (a[mid] < key) {
            low = mid + 1;
        } else {
            high = mid - 1;
        }
    }
    if (last == -1)
        printf("%d not found\n", key);
    else
        printf("Last occurrence of %d is at index %d\n", key, last);
    return 0;
}
''', "9\n1 3 5 5 5 5 8 9 12\n5")

add(581, r'''
#include <stdio.h>

/* index of first element >= key */
int lowerBound(const int a[], int n, int key)
{
    int lo = 0, hi = n;
    while (lo < hi) {
        int mid = lo + (hi - lo) / 2;
        if (a[mid] < key) lo = mid + 1;
        else hi = mid;
    }
    return lo;
}

/* index of first element > key */
int upperBound(const int a[], int n, int key)
{
    int lo = 0, hi = n;
    while (lo < hi) {
        int mid = lo + (hi - lo) / 2;
        if (a[mid] <= key) lo = mid + 1;
        else hi = mid;
    }
    return lo;
}

int main(void)
{
    int a[100], n, key, i;

    printf("Enter n (0 for an empty array): ");
    if (scanf("%d", &n) != 1 || n < 0 || n > 100) {
        printf("Invalid n\n");
        return 1;
    }
    printf("Enter %d sorted elements: ", n);
    for (i = 0; i < n; i++)
        scanf("%d", &a[i]);
    printf("Enter key: ");
    scanf("%d", &key);

    /* count = upper bound - lower bound; works for empty array, key smaller
       than all elements or larger than all elements */
    printf("Count of %d = %d\n", key, upperBound(a, n, key) - lowerBound(a, n, key));
    return 0;
}
''', "8\n2 2 4 4 4 4 9 9\n9")

add(582, r'''
#include <stdio.h>

int lowerBound(const int a[], int n, int key)
{
    int lo = 0, hi = n;
    while (lo < hi) {
        int mid = lo + (hi - lo) / 2;
        if (a[mid] < key) lo = mid + 1;
        else hi = mid;
    }
    return lo;
}

int main(void)
{
    int a[100], n = 0, i, choice, key, pos;

    do {
        printf("\n1. Enter sorted array\n2. Find lower bound\n3. Exit\nChoice: ");
        if (scanf("%d", &choice) != 1)
            break;
        if (choice == 1) {
            printf("How many elements? ");
            scanf("%d", &n);
            printf("Enter elements: ");
            for (i = 0; i < n; i++)
                scanf("%d", &a[i]);
        } else if (choice == 2) {
            if (n == 0) {
                printf("Enter the array first.\n");
                continue;
            }
            printf("Target: ");
            scanf("%d", &key);
            pos = lowerBound(a, n, key);
            if (pos == n)
                printf("Lower bound of %d: index %d (all elements are smaller)\n", key, pos);
            else
                printf("Lower bound of %d: index %d (value %d)\n", key, pos, a[pos]);
        } else if (choice != 3) {
            printf("Invalid choice.\n");
        }
    } while (choice != 3);
    printf("Goodbye!\n");
    return 0;
}
''', "1\n7\n1 3 3 5 8 8 10\n2\n8\n2\n4\n2\n11\n9\n3")

add(583, r'''
#include <stdio.h>

int main(void)
{
    int a[100], n, key, i, lo, hi, mid, step = 0;

    printf("Enter n: ");
    scanf("%d", &n);
    printf("Enter %d sorted elements: ", n);
    for (i = 0; i < n; i++)
        scanf("%d", &a[i]);
    printf("Enter target: ");
    scanf("%d", &key);

    /* upper bound = index of the first element greater than key */
    lo = 0;
    hi = n;
    while (lo < hi) {
        mid = lo + (hi - lo) / 2;
        step++;
        printf("Step %d: lo=%d hi=%d mid=%d a[mid]=%d -> ", step, lo, hi, mid, a[mid]);
        if (a[mid] <= key) {
            printf("move right\n");
            lo = mid + 1;
        } else {
            printf("move left\n");
            hi = mid;
        }
    }
    printf("Upper bound of %d is index %d\n", key, lo);
    return 0;
}
''', "8\n1 2 4 4 4 7 9 12\n4")

add(584, r'''
#include <stdio.h>

int main(void)
{
    int a[100], n, q, i, key, pos;

    printf("Enter n: ");
    scanf("%d", &n);
    printf("Enter %d sorted elements: ", n);
    for (i = 0; i < n; i++)
        scanf("%d", &a[i]);
    printf("How many targets? ");
    scanf("%d", &q);

    for (; q > 0; q--) {
        printf("Target: ");
        scanf("%d", &key);
        /* scan with a loop until the first element >= key */
        pos = 0;
        while (pos < n && a[pos] < key)
            pos++;
        printf("Insert %d at index %d\n", key, pos);
    }
    return 0;
}
''', "6\n10 20 30 40 50 60\n4\n35\n5\n60\n99")

add(585, r'''
#include <stdio.h>

/* Search in rotated sorted array using pointers */
int searchRotated(const int *a, int n, int key)
{
    const int *lo = a, *hi = a + n - 1;
    while (lo <= hi) {
        const int *mid = lo + (hi - lo) / 2;
        if (*mid == key)
            return (int)(mid - a);
        if (*lo <= *mid) {                      /* left half sorted */
            if (key >= *lo && key < *mid) hi = mid - 1;
            else lo = mid + 1;
        } else {                                /* right half sorted */
            if (key > *mid && key <= *hi) lo = mid + 1;
            else hi = mid - 1;
        }
    }
    return -1;
}

int main(void)
{
    int a[50], n, key, i;

    printf("Enter n: ");
    scanf("%d", &n);
    printf("Enter rotated sorted array: ");
    for (i = 0; i < n; i++)
        scanf("%d", a + i);
    printf("Enter key: ");
    scanf("%d", &key);
    i = searchRotated(a, n, key);
    if (i < 0)
        printf("%d not found\n", key);
    else
        printf("%d found at index %d\n", key, i);
    return 0;
}
''', "8\n40 50 60 70 5 10 20 30\n10")

add(586, r'''
#include <stdio.h>

int main(void)
{
    int arr[50], n, i, lo, hi, mid;

    printf("Enter n: ");
    scanf("%d", &n);
    printf("Enter rotated sorted array (distinct values): ");
    for (i = 0; i < n; i++)
        scanf("%d", &arr[i]);

    lo = 0;
    hi = n - 1;
    while (lo < hi) {
        mid = (lo + hi) / 2;
        if (arr[mid] > arr[hi])
            lo = mid + 1;      /* minimum is in the right part */
        else
            hi = mid;          /* minimum is at mid or to its left */
    }
    printf("Minimum element = %d at index %d\n", arr[lo], lo);
    return 0;
}
''', "7\n15 18 22 2 5 8 11")

add(587, r'''
#include <stdio.h>

struct Peak {
    int index;
    int value;
};

/* A peak is an element not smaller than its neighbours */
struct Peak findPeak(const int a[], int n)
{
    struct Peak p = {0, a[0]};
    int i;
    for (i = 0; i < n; i++) {
        int leftOk = (i == 0) || (a[i] >= a[i - 1]);
        int rightOk = (i == n - 1) || (a[i] >= a[i + 1]);
        if (leftOk && rightOk) {
            p.index = i;
            p.value = a[i];
            return p;
        }
    }
    return p;
}

int main(void)
{
    int a[50], n, i;
    struct Peak p;

    printf("Enter n: ");
    scanf("%d", &n);
    printf("Enter %d elements: ", n);
    for (i = 0; i < n; i++)
        scanf("%d", &a[i]);
    p = findPeak(a, n);
    printf("Peak element %d found at index %d\n", p.value, p.index);
    return 0;
}
''', "8\n1 3 8 12 4 2 9 5")

add(588, r'''
#include <stdio.h>

int main(void)
{
    int m[10][10], rows, cols, q, key, i, j, r, c, found;

    printf("Enter rows and columns: ");
    scanf("%d %d", &rows, &cols);
    printf("Enter the sorted matrix:\n");
    for (i = 0; i < rows; i++)
        for (j = 0; j < cols; j++)
            scanf("%d", &m[i][j]);
    printf("Number of searches: ");
    scanf("%d", &q);

    while (q-- > 0) {
        scanf("%d", &key);
        /* staircase search from top-right corner: O(rows + cols) */
        r = 0;
        c = cols - 1;
        found = 0;
        while (r < rows && c >= 0) {
            if (m[r][c] == key) { found = 1; break; }
            else if (m[r][c] > key) c--;
            else r++;
        }
        if (found)
            printf("%d found at row %d, column %d\n", key, r, c);
        else
            printf("%d not found\n", key);
    }
    return 0;
}
''', "3 4\n1 3 5 7\n10 11 16 20\n23 30 34 60\n4\n16\n13\n1\n60")

add(589, r'''
#include <stdio.h>
#include <math.h>

int main(void)
{
    int a[100], n, key, i, step, prev, comparisons = 0;

    printf("Enter n: ");
    scanf("%d", &n);
    printf("Enter %d sorted elements: ", n);
    for (i = 0; i < n; i++)
        scanf("%d", &a[i]);
    printf("Enter key: ");
    scanf("%d", &key);

    step = (int)sqrt((double)n);      /* block size */
    prev = 0;
    {
        int cur = step;
        /* jump ahead block by block while the block end is smaller than key */
        while (prev < n && a[(cur < n ? cur : n) - 1] < key) {
            comparisons++;
            prev = cur;
            cur += step;
        }
        comparisons++;
        /* linear scan inside the block */
        for (i = prev; i < n && i < cur; i++) {
            comparisons++;
            if (a[i] == key)
                break;
        }
        printf("\n--- Jump Search Result ---\n");
        printf("Block size  : %d\n", step);
        printf("Key         : %d\n", key);
        if (i < n && i < cur && a[i] == key)
            printf("Found at    : index %d\n", i);
        else
            printf("Found at    : not found\n");
        printf("Comparisons : %d\n", comparisons);
    }
    return 0;
}
''', "10\n2 5 8 12 16 23 38 56 72 91\n23")

add(590, r'''
#include <stdio.h>

int interpolation(const int a[], int n, int key)
{
    int lo = 0, hi = n - 1;
    while (lo <= hi && key >= a[lo] && key <= a[hi]) {
        int pos;
        if (a[hi] == a[lo])
            return (a[lo] == key) ? lo : -1;
        pos = lo + (int)((long)(key - a[lo]) * (hi - lo) / (a[hi] - a[lo]));
        if (a[pos] == key) return pos;
        if (a[pos] < key) lo = pos + 1;
        else hi = pos - 1;
    }
    return -1;
}

int main(void)
{
    int a[100], n, key, i, pos;

    printf("Enter n (1-100): ");
    if (scanf("%d", &n) != 1 || n < 1 || n > 100) {
        printf("Invalid number of elements.\n");
        return 1;
    }
    printf("Enter %d sorted elements: ", n);
    for (i = 0; i < n; i++) {
        if (scanf("%d", &a[i]) != 1) {
            printf("Invalid element.\n");
            return 1;
        }
        if (i > 0 && a[i] < a[i - 1]) {
            printf("Input is not sorted.\n");
            return 1;
        }
    }
    printf("Enter key: ");
    if (scanf("%d", &key) != 1) {
        printf("Invalid key.\n");
        return 1;
    }
    pos = interpolation(a, n, key);
    if (pos < 0) printf("%d not found\n", key);
    else printf("%d found at index %d\n", key, pos);
    return 0;
}
''', "9\n10 20 30 40 50 60 70 80 90\n70")

add(591, r'''
#include <stdio.h>

int binarySearchRange(const int a[], int lo, int hi, int key)
{
    while (lo <= hi) {
        int mid = lo + (hi - lo) / 2;
        if (a[mid] == key) return mid;
        if (a[mid] < key) lo = mid + 1;
        else hi = mid - 1;
    }
    return -1;
}

/* Exponential search: double the range, then binary search inside it */
int exponentialSearch(const int a[], int n, int key)
{
    int bound = 1;
    if (n == 0) return -1;
    if (a[0] == key) return 0;
    while (bound < n && a[bound] < key)
        bound *= 2;
    return binarySearchRange(a, bound / 2, (bound < n ? bound : n - 1), key);
}

void readArray(int a[], int n)
{
    int i;
    for (i = 0; i < n; i++)
        scanf("%d", &a[i]);
}

int main(void)
{
    int a[100], n, key, pos;

    printf("Enter n: ");
    scanf("%d", &n);
    printf("Enter %d sorted elements: ", n);
    readArray(a, n);
    printf("Enter key: ");
    scanf("%d", &key);
    pos = exponentialSearch(a, n, key);
    if (pos >= 0) printf("%d found at index %d\n", key, pos);
    else printf("%d not found\n", key);
    return 0;
}
''', "12\n1 3 6 10 15 21 28 36 45 55 66 78\n45")

add(592, r'''
#include <stdio.h>

/* Ternary search on a sorted array.
   Time : O(log3 n) loop steps, but about 2 comparisons per step, so it is
          not faster than binary search in practice.
   Space: O(1) because it is iterative. */
int ternarySearch(const int a[], int n, int key)
{
    int lo = 0, hi = n - 1;
    while (lo <= hi) {
        int third = (hi - lo) / 3;
        int m1 = lo + third;
        int m2 = hi - third;
        if (a[m1] == key) return m1;
        if (a[m2] == key) return m2;
        if (key < a[m1]) hi = m1 - 1;
        else if (key > a[m2]) lo = m2 + 1;
        else { lo = m1 + 1; hi = m2 - 1; }
    }
    return -1;
}

int main(void)
{
    int a[100], n, key, i, pos;

    printf("Enter n: ");
    scanf("%d", &n);
    printf("Enter %d sorted elements: ", n);
    for (i = 0; i < n; i++)
        scanf("%d", &a[i]);
    printf("Enter key: ");
    scanf("%d", &key);
    pos = ternarySearch(a, n, key);
    if (pos < 0) printf("%d not found\n", key);
    else printf("%d found at index %d\n", key, pos);
    return 0;
}
''', "10\n4 9 13 18 24 31 37 45 52 60\n31")

add(593, r'''
#include <stdio.h>

#define N 16

int linearCount(const int a[], int key)
{
    int i, count = 0;
    for (i = 0; i < N; i++) {
        count++;
        if (a[i] == key) break;
    }
    return count;
}

int binaryCount(const int a[], int key)
{
    int lo = 0, hi = N - 1, count = 0;
    while (lo <= hi) {
        int mid = lo + (hi - lo) / 2;
        count++;
        if (a[mid] == key) break;
        if (a[mid] < key) lo = mid + 1;
        else hi = mid - 1;
    }
    return count;
}

int main(void)
{
    int a[N], i;
    int keys[] = {40, 5, 80, 41};
    const char *label[] = {"normal (middle)", "minimum (first)", "maximum (last)", "absent"};

    for (i = 0; i < N; i++)
        a[i] = 5 * (i + 1);          /* 5, 10, ..., 80 */

    printf("%-18s %6s %8s %8s\n", "Test case", "Key", "Linear", "Binary");
    for (i = 0; i < 4; i++)
        printf("%-18s %6d %8d %8d\n", label[i], keys[i],
               linearCount(a, keys[i]), binaryCount(a, keys[i]));
    return 0;
}
''')

add(594, r'''
#include <stdio.h>

struct Student {
    int id;
    char name[30];
    float marks;
};

/* returns index of student with given id or -1 */
int findStudent(const struct Student s[], int n, int id)
{
    int i;
    for (i = 0; i < n; i++)
        if (s[i].id == id)
            return i;
    return -1;
}

int main(void)
{
    struct Student list[20];
    int n, i, id, pos;

    printf("Enter number of students (1-20): ");
    if (scanf("%d", &n) != 1 || n < 1 || n > 20) {
        printf("Invalid count.\n");
        return 1;
    }
    for (i = 0; i < n; i++) {
        printf("Enter id, name, marks for student %d: ", i + 1);
        scanf("%d %29s %f", &list[i].id, list[i].name, &list[i].marks);
    }
    printf("Enter ID to search: ");
    scanf("%d", &id);
    pos = findStudent(list, n, id);
    if (pos < 0)
        printf("No student with ID %d\n", id);
    else
        printf("Found: ID=%d Name=%s Marks=%.1f\n", list[pos].id, list[pos].name, list[pos].marks);
    return 0;
}
''', "4\n101 Asha 85.5\n102 Ravi 72\n103 Meena 91.25\n104 Kiran 66\n103")

add(595, r'''
#include <stdio.h>
#include <string.h>

int main(void)
{
    char words[20][32];
    char target[32];
    int n, i, found = -1;

    printf("How many words (1-20)? ");
    if (scanf("%d", &n) != 1 || n < 1 || n > 20) {
        printf("Invalid number of words.\n");
        return 1;
    }
    printf("Enter %d words: ", n);
    for (i = 0; i < n; i++) {
        if (scanf("%31s", words[i]) != 1) {
            printf("Could not read word %d.\n", i + 1);
            return 1;
        }
    }
    printf("Word to search: ");
    if (scanf("%31s", target) != 1) {
        printf("No search word given.\n");
        return 1;
    }
    for (i = 0; i < n; i++) {
        if (strcmp(words[i], target) == 0) {
            found = i;
            break;
        }
    }
    if (found >= 0)
        printf("\"%s\" found at position %d\n", target, found + 1);
    else
        printf("\"%s\" is not in the list\n", target);
    return 0;
}
''', "5\napple banana cherry mango grape\nmango")

add(596, r'''
#include <stdio.h>

/* Lower bound = first index whose value is >= target.
   Time : O(log n) - the search range is halved every iteration.
   Space: O(1) - only a few integer variables are used. */
int lowerBound(const int a[], int n, int target)
{
    int lo = 0, hi = n;
    while (lo < hi) {
        int mid = lo + (hi - lo) / 2;
        if (a[mid] < target) lo = mid + 1;
        else hi = mid;
    }
    return lo;
}

int main(void)
{
    int a[8] = {2, 4, 4, 6, 9, 9, 9, 15};
    int targets[] = {4, 5, 9, 1, 20};
    int i;

    printf("Array: 2 4 4 6 9 9 9 15\n");
    for (i = 0; i < 5; i++)
        printf("lower_bound(%2d) = index %d\n", targets[i], lowerBound(a, 8, targets[i]));
    return 0;
}
''')

add(597, r'''
#include <stdio.h>

int main(void)
{
    int a[50], n, target, i, lo, hi, mid;

    printf("Enter number of elements: ");
    scanf("%d", &n);
    printf("Enter %d sorted elements: ", n);
    for (i = 0; i < n; i++)
        scanf("%d", &a[i]);
    printf("Enter target value: ");
    scanf("%d", &target);

    lo = 0;
    hi = n;
    while (lo < hi) {
        mid = (lo + hi) / 2;
        if (a[mid] < target) lo = mid + 1;
        else hi = mid;
    }
    printf("Target %d should be inserted at index %d\n", target, lo);
    if (lo < n && a[lo] == target)
        printf("(the value already exists there)\n");
    return 0;
}
''', "6\n1 4 7 10 13 16\n11")

add(598, r'''
#include <stdio.h>

int main(void)
{
    int a[8] = {38, 42, 51, 7, 12, 19, 24, 30};
    int n = 8, lo = 0, hi = n - 1, mid;

    /* In a rotated sorted array the minimum is the "pivot" where the order
       breaks. If a[mid] > a[hi] the pivot lies to the right of mid,
       otherwise it is at mid or to the left. */
    while (lo < hi) {
        mid = (lo + hi) / 2;
        if (a[mid] > a[hi])
            lo = mid + 1;
        else
            hi = mid;
    }
    printf("Array rotated by %d position(s)\n", lo);
    printf("Minimum element: %d (index %d)\n", a[lo], lo);
    return 0;
}
''')

add(599, r'''
#include <stdio.h>

int main(void)
{
    int m[3][4] = {
        { 1,  4,  7, 11},
        {12, 15, 18, 21},
        {25, 29, 33, 40}
    };
    int rows = 3, cols = 4, key = 29;
    int lo = 0, hi = rows * cols - 1, found = 0;

    /* Treat the matrix as one sorted list; index k -> row k/cols, col k%cols */
    while (lo <= hi) {
        int mid = (lo + hi) / 2;
        int value = m[mid / cols][mid % cols];
        if (value == key) {
            printf("%d found at row %d, column %d\n", key, mid / cols, mid % cols);
            found = 1;
            break;
        }
        if (value < key) lo = mid + 1;
        else hi = mid - 1;
    }
    if (!found)
        printf("%d not found\n", key);
    return 0;
}
''')

add(600, r'''
#include <stdio.h>

typedef struct {
    int id;
    int value;
} Record;

/* interpolation search on records sorted by value */
int searchRecord(const Record r[], int n, int key)
{
    int lo = 0, hi = n - 1;
    while (lo <= hi && key >= r[lo].value && key <= r[hi].value) {
        int pos;
        if (r[hi].value == r[lo].value)
            return r[lo].value == key ? lo : -1;
        pos = lo + (key - r[lo].value) * (hi - lo) / (r[hi].value - r[lo].value);
        if (r[pos].value == key) return pos;
        if (r[pos].value < key) lo = pos + 1;
        else hi = pos - 1;
    }
    return -1;
}

int main(void)
{
    Record rec[50];
    int n, q, i, key, pos;

    printf("Number of records: ");
    scanf("%d", &n);
    printf("Enter id and value (values ascending):\n");
    for (i = 0; i < n; i++)
        scanf("%d %d", &rec[i].id, &rec[i].value);
    printf("Number of queries: ");
    scanf("%d", &q);
    while (q-- > 0) {
        scanf("%d", &key);
        pos = searchRecord(rec, n, key);
        if (pos < 0) printf("Value %d: not found\n", key);
        else printf("Value %d: record id %d at index %d\n", key, rec[pos].id, pos);
    }
    return 0;
}
''', "6\n11 100\n12 200\n13 300\n14 400\n15 500\n16 600\n3\n400\n250\n600")
