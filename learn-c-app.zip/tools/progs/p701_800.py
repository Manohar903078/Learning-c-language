# programs 701-800
P = {}
def add(i, code, stdin=""): P[i] = (stdin, code.strip("\n"))

add(701, r'''
#include <stdio.h>

int add(int a, int b);          /* prototype */

int main(void)
{
    int x = 12, y = 30;
    int sum = add(x, y);        /* function call */
    printf("add(%d, %d) = %d\n", x, y, sum);
    return 0;
}

int add(int a, int b)
{
    return a + b;
}
''')
add(702, r'''
#include <stdio.h>

int maxOfTwo(int a, int b);

int main(void)
{
    printf("Max of 17 and 42 = %d\n", maxOfTwo(17, 42));
    printf("Max of -5 and -9 = %d\n", maxOfTwo(-5, -9));
    printf("Max of 8 and 8   = %d\n", maxOfTwo(8, 8));
    return 0;
}

int maxOfTwo(int a, int b)
{
    return (a > b) ? a : b;
}
''')
add(703, r'''
#include <stdio.h>

int maxOfThree(int a, int b, int c);

int main(void)
{
    printf("Max of 4, 19, 11 = %d\n", maxOfThree(4, 19, 11));
    printf("Max of 30, 2, 7  = %d\n", maxOfThree(30, 2, 7));
    printf("Max of -3, -1, -8 = %d\n", maxOfThree(-3, -1, -8));
    return 0;
}

int maxOfThree(int a, int b, int c)
{
    int max = a;
    if (b > max)
    {
        max = b;
    }
    if (c > max)
    {
        max = c;
    }
    return max;
}
''')
add(704, r'''
#include <stdio.h>

unsigned long long factorial(int n);

int main(void)
{
    int n;
    for (n = 0; n <= 10; n++)
    {
        printf("%2d! = %llu\n", n, factorial(n));
    }
    return 0;
}

unsigned long long factorial(int n)
{
    unsigned long long result = 1;
    int i;
    for (i = 2; i <= n; i++)
    {
        result *= i;
    }
    return result;
}
''')
add(705, r'''
#include <stdio.h>

int isPrime(int n);

int main(void)
{
    int n;
    printf("Prime numbers from 1 to 30:\n");
    for (n = 1; n <= 30; n++)
    {
        if (isPrime(n))
        {
            printf("%d ", n);
        }
    }
    printf("\n");
    printf("Is 97 prime? %s\n", isPrime(97) ? "Yes" : "No");
    printf("Is 91 prime? %s\n", isPrime(91) ? "Yes" : "No");
    return 0;
}

int isPrime(int n)
{
    int i;
    if (n < 2)
    {
        return 0;
    }
    for (i = 2; i * i <= n; i++)
    {
        if (n % i == 0)
        {
            return 0;
        }
    }
    return 1;
}
''')
add(706, r'''
#include <stdio.h>

int gcd(int a, int b);

int main(void)
{
    int pairs[3][2] = {{48, 18}, {100, 75}, {17, 5}};
    int i;
    for (i = 0; i < 3; i++)
    {
        printf("GCD(%d, %d) = %d\n", pairs[i][0], pairs[i][1], gcd(pairs[i][0], pairs[i][1]));
    }
    return 0;
}

/* Euclid's algorithm */
int gcd(int a, int b)
{
    while (b != 0)
    {
        int rem = a % b;
        a = b;
        b = rem;
    }
    return a;
}
''')
add(707, r'''
#include <stdio.h>

int gcd(int a, int b);
int lcm(int a, int b);

int main(void)
{
    int a = 12, b = 18;
    printf("GCD(%d, %d) = %d\n", a, b, gcd(a, b));
    printf("LCM(%d, %d) = %d\n", a, b, lcm(a, b));
    printf("LCM(7, 5) = %d\n", lcm(7, 5));
    return 0;
}

int gcd(int a, int b)
{
    while (b != 0)
    {
        int rem = a % b;
        a = b;
        b = rem;
    }
    return a;
}

/* LCM = a * b / GCD */
int lcm(int a, int b)
{
    return a / gcd(a, b) * b;
}
''')
add(708, r'''
#include <stdio.h>

int reverseNumber(int n);

int main(void)
{
    int n = 12345;
    printf("Original number = %d\n", n);
    printf("Reversed number = %d\n", reverseNumber(n));
    printf("Reverse of 1200 = %d\n", reverseNumber(1200));
    return 0;
}

int reverseNumber(int n)
{
    int rev = 0;
    while (n > 0)
    {
        rev = rev * 10 + n % 10;
        n /= 10;
    }
    return rev;
}
''')
add(709, r'''
#include <stdio.h>

int digitSum(int n);

int main(void)
{
    printf("Sum of digits of 4821 = %d\n", digitSum(4821));
    printf("Sum of digits of 99999 = %d\n", digitSum(99999));
    printf("Sum of digits of 7 = %d\n", digitSum(7));
    return 0;
}

int digitSum(int n)
{
    int sum = 0;
    while (n > 0)
    {
        sum += n % 10;
        n /= 10;
    }
    return sum;
}
''')
add(710, r'''
#include <stdio.h>

int isPalindrome(int n);

int main(void)
{
    int tests[4] = {121, 1331, 123, 4554};
    int i;
    for (i = 0; i < 4; i++)
    {
        printf("%d is %s\n", tests[i], isPalindrome(tests[i]) ? "a palindrome" : "not a palindrome");
    }
    return 0;
}

int isPalindrome(int n)
{
    int original = n, rev = 0;
    while (n > 0)
    {
        rev = rev * 10 + n % 10;
        n /= 10;
    }
    return rev == original;
}
''')
add(711, r'''
#include <stdio.h>

int isArmstrong(int n);

int main(void)
{
    int n;
    printf("Armstrong numbers between 100 and 999:\n");
    for (n = 100; n <= 999; n++)
    {
        if (isArmstrong(n))
        {
            printf("%d ", n);
        }
    }
    printf("\n");
    return 0;
}

/* sum of cubes of the digits equals the number (3-digit case) */
int isArmstrong(int n)
{
    int temp = n, sum = 0, digit;
    while (temp > 0)
    {
        digit = temp % 10;
        sum += digit * digit * digit;
        temp /= 10;
    }
    return sum == n;
}
''')
add(712, r'''
#include <stdio.h>

long long power(int base, int exp);

int main(void)
{
    printf("2^10 = %lld\n", power(2, 10));
    printf("5^3  = %lld\n", power(5, 3));
    printf("7^0  = %lld\n", power(7, 0));
    printf("3^13 = %lld\n", power(3, 13));
    return 0;
}

long long power(int base, int exp)
{
    long long result = 1;
    int i;
    for (i = 0; i < exp; i++)
    {
        result *= base;
    }
    return result;
}
''')
add(713, r'''
#include <stdio.h>

void swap(int *a, int *b);

int main(void)
{
    int x = 10, y = 25;
    printf("Before swap: x = %d, y = %d\n", x, y);
    swap(&x, &y);
    printf("After swap : x = %d, y = %d\n", x, y);
    return 0;
}

void swap(int *a, int *b)
{
    int temp = *a;
    *a = *b;
    *b = temp;
}
''')
add(714, r'''
#include <stdio.h>

void tryToChange(int value);

int main(void)
{
    int number = 50;
    printf("In main before call : number = %d\n", number);
    tryToChange(number);
    printf("In main after call  : number = %d (unchanged)\n", number);
    return 0;
}

/* receives a COPY of the argument */
void tryToChange(int value)
{
    value = value + 100;
    printf("Inside function     : value  = %d (the copy changed)\n", value);
}
''')
add(715, r'''
#include <stdio.h>

void updateValues(int *count, double *price);

int main(void)
{
    int count = 3;
    double price = 12.5;
    printf("Before: count = %d, price = %.2f\n", count, price);
    updateValues(&count, &price);
    printf("After : count = %d, price = %.2f\n", count, price);
    return 0;
}

void updateValues(int *count, double *price)
{
    *count = *count + 2;        /* modifies caller's variable */
    *price = *price * 1.10;     /* 10 percent increase */
}
''')
add(716, r'''
#include <stdio.h>

int largest(const int arr[], int n);

int main(void)
{
    int data[7] = {14, 87, 3, 56, 92, 41, 70};
    printf("Largest element = %d\n", largest(data, 7));
    return 0;
}

int largest(const int arr[], int n)
{
    int max = arr[0], i;
    for (i = 1; i < n; i++)
    {
        if (arr[i] > max)
        {
            max = arr[i];
        }
    }
    return max;
}
''')
add(717, r'''
#include <stdio.h>

double average(const int arr[], int n);

int main(void)
{
    int marks[5] = {72, 85, 90, 64, 79};
    printf("Average of the array = %.2f\n", average(marks, 5));
    return 0;
}

double average(const int arr[], int n)
{
    int sum = 0, i;
    for (i = 0; i < n; i++)
    {
        sum += arr[i];
    }
    return (double)sum / n;
}
''')
add(718, r'''
#include <stdio.h>
#include <ctype.h>

int countVowels(const char *s);

int main(void)
{
    const char *text = "Programming in C is Fun";
    printf("Text   : %s\n", text);
    printf("Vowels = %d\n", countVowels(text));
    return 0;
}

int countVowels(const char *s)
{
    int count = 0, i;
    for (i = 0; s[i] != '\0'; i++)
    {
        char c = (char)tolower((unsigned char)s[i]);
        if (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u')
        {
            count++;
        }
    }
    return count;
}
''')
add(719, r'''
#include <stdio.h>
#include <string.h>

void reverseString(char s[]);

int main(void)
{
    char word[] = "stressed";
    printf("Original: %s\n", word);
    reverseString(word);
    printf("Reversed: %s\n", word);
    return 0;
}

void reverseString(char s[])
{
    int left = 0, right = (int)strlen(s) - 1;
    while (left < right)
    {
        char temp = s[left];
        s[left] = s[right];
        s[right] = temp;
        left++;
        right--;
    }
}
''')
add(720, r'''
#include <stdio.h>

void sortArray(int arr[], int n);
void printArray(const int arr[], int n);

int main(void)
{
    int data[8] = {64, 25, 12, 90, 5, 33, 71, 18};
    printf("Before sorting: ");
    printArray(data, 8);
    sortArray(data, 8);
    printf("After sorting : ");
    printArray(data, 8);
    return 0;
}

/* bubble sort, ascending */
void sortArray(int arr[], int n)
{
    int i, j, temp;
    for (i = 0; i < n - 1; i++)
    {
        for (j = 0; j < n - 1 - i; j++)
        {
            if (arr[j] > arr[j + 1])
            {
                temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
    }
}

void printArray(const int arr[], int n)
{
    int i;
    for (i = 0; i < n; i++)
    {
        printf("%d ", arr[i]);
    }
    printf("\n");
}
''')
add(721, r'''
#include <stdio.h>

int linearSearch(const int arr[], int n, int key);

int main(void)
{
    int data[6] = {11, 22, 33, 44, 55, 66};
    int key = 44;
    int pos = linearSearch(data, 6, key);
    if (pos != -1)
    {
        printf("%d found at position %d (index %d)\n", key, pos + 1, pos);
    }
    else
    {
        printf("%d not found\n", key);
    }
    key = 77;
    pos = linearSearch(data, 6, key);
    printf("%d %s\n", key, pos != -1 ? "found" : "not found");
    return 0;
}

int linearSearch(const int arr[], int n, int key)
{
    int i;
    for (i = 0; i < n; i++)
    {
        if (arr[i] == key)
        {
            return i;
        }
    }
    return -1;
}
''')
add(722, r'''
#include <stdio.h>

#define N 3

void addMatrices(int a[N][N], int b[N][N], int result[N][N]);
void printMatrix(int m[N][N]);

int main(void)
{
    int a[N][N] = {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}};
    int b[N][N] = {{9, 8, 7}, {6, 5, 4}, {3, 2, 1}};
    int sum[N][N];
    addMatrices(a, b, sum);
    printf("Sum of the matrices:\n");
    printMatrix(sum);
    return 0;
}

void addMatrices(int a[N][N], int b[N][N], int result[N][N])
{
    int i, j;
    for (i = 0; i < N; i++)
    {
        for (j = 0; j < N; j++)
        {
            result[i][j] = a[i][j] + b[i][j];
        }
    }
}

void printMatrix(int m[N][N])
{
    int i, j;
    for (i = 0; i < N; i++)
    {
        for (j = 0; j < N; j++)
        {
            printf("%4d", m[i][j]);
        }
        printf("\n");
    }
}
''')
add(723, r'''
#include <stdio.h>

#define PI 3.14159265

double circleArea(double radius);

int main(void)
{
    double radii[3] = {1.0, 2.5, 10.0};
    int i;
    for (i = 0; i < 3; i++)
    {
        printf("Radius %.1f -> Area = %.2f\n", radii[i], circleArea(radii[i]));
    }
    return 0;
}

double circleArea(double radius)
{
    return PI * radius * radius;
}
''')
add(724, r'''
#include <stdio.h>

double celsiusToFahrenheit(double c);

int main(void)
{
    double temps[5] = {-40.0, 0.0, 25.0, 37.0, 100.0};
    int i;
    for (i = 0; i < 5; i++)
    {
        printf("%6.1f C = %6.1f F\n", temps[i], celsiusToFahrenheit(temps[i]));
    }
    return 0;
}

double celsiusToFahrenheit(double c)
{
    return c * 9.0 / 5.0 + 32.0;
}
''')
add(725, r'''
#include <stdio.h>

void printTable(int n);

int main(void)
{
    printTable(7);
    return 0;
}

void printTable(int n)
{
    int i;
    printf("Multiplication table of %d\n", n);
    for (i = 1; i <= 10; i++)
    {
        printf("%d x %2d = %3d\n", n, i, n * i);
    }
}
''')
add(726, r'''
#include <stdio.h>

int isLeapYear(int year);

int main(void)
{
    int years[5] = {1900, 2000, 2024, 2023, 2100};
    int i;
    for (i = 0; i < 5; i++)
    {
        printf("%d is %s\n", years[i], isLeapYear(years[i]) ? "a leap year" : "not a leap year");
    }
    return 0;
}

int isLeapYear(int year)
{
    return (year % 4 == 0 && year % 100 != 0) || (year % 400 == 0);
}
''')
add(727, r'''
#include <stdio.h>

/* function prototypes: declared before main */
int square(int n);
int cube(int n);
void printResult(const char *label, int value);

int main(void)
{
    int n = 6;
    printResult("Square", square(n));
    printResult("Cube", cube(n));
    return 0;
}

int square(int n)
{
    return n * n;
}

int cube(int n)
{
    return n * square(n);
}

void printResult(const char *label, int value)
{
    printf("%s of 6 = %d\n", label, value);
}
''')
add(728, r'''
#include <stdio.h>

int sumOfArray(const int arr[], int n);
int maxOfArray(const int arr[], int n);
int minOfArray(const int arr[], int n);
void showStats(const int arr[], int n);

int main(void)
{
    int values[6] = {23, 7, 45, 12, 38, 19};
    showStats(values, 6);
    return 0;
}

int sumOfArray(const int arr[], int n)
{
    int sum = 0, i;
    for (i = 0; i < n; i++)
    {
        sum += arr[i];
    }
    return sum;
}

int maxOfArray(const int arr[], int n)
{
    int max = arr[0], i;
    for (i = 1; i < n; i++)
    {
        if (arr[i] > max)
        {
            max = arr[i];
        }
    }
    return max;
}

int minOfArray(const int arr[], int n)
{
    int min = arr[0], i;
    for (i = 1; i < n; i++)
    {
        if (arr[i] < min)
        {
            min = arr[i];
        }
    }
    return min;
}

void showStats(const int arr[], int n)
{
    printf("Sum     = %d\n", sumOfArray(arr, n));
    printf("Maximum = %d\n", maxOfArray(arr, n));
    printf("Minimum = %d\n", minOfArray(arr, n));
    printf("Average = %.2f\n", (double)sumOfArray(arr, n) / n);
}
''')
add(729, r'''
#include <stdio.h>

int *findMax(int arr[], int n);

int main(void)
{
    int data[5] = {8, 41, 17, 63, 29};
    int *p = findMax(data, 5);      /* pointer into the caller's array: safe */
    if (p != NULL)
    {
        printf("Largest value = %d at index %d\n", *p, (int)(p - data));
        *p = 0;                     /* change the element through the pointer */
        printf("After setting it to 0, data[3] = %d\n", data[3]);
    }
    return 0;
}

/* Returns a pointer to the largest element.
   It points into the array owned by the caller, never to a local variable. */
int *findMax(int arr[], int n)
{
    int i;
    int *best = NULL;
    if (n <= 0)
    {
        return NULL;
    }
    best = &arr[0];
    for (i = 1; i < n; i++)
    {
        if (arr[i] > *best)
        {
            best = &arr[i];
        }
    }
    return best;
}
''')
add(730, r'''
#include <stdio.h>

int sumRecursive(int n);
int sumIterative(int n);

int main(void)
{
    int n = 10;
    printf("Recursive sum of 1..%d = %d\n", n, sumRecursive(n));
    printf("Iterative sum of 1..%d = %d\n", n, sumIterative(n));
    return 0;
}

int sumRecursive(int n)
{
    if (n == 0)                 /* base case */
    {
        return 0;
    }
    return n + sumRecursive(n - 1);
}

int sumIterative(int n)
{
    int sum = 0, i;
    for (i = 1; i <= n; i++)
    {
        sum += i;
    }
    return sum;
}
''')
add(731, r'''
#include <stdio.h>

int median3(int a, int b, int c);

int main(void)
{
    printf("Median of 3, 9, 5  = %d\n", median3(3, 9, 5));
    printf("Median of 10, 2, 7 = %d\n", median3(10, 2, 7));
    printf("Median of 4, 4, 1  = %d\n", median3(4, 4, 1));
    return 0;
}

int median3(int a, int b, int c)
{
    if ((a >= b && a <= c) || (a <= b && a >= c))
    {
        return a;
    }
    if ((b >= a && b <= c) || (b <= a && b >= c))
    {
        return b;
    }
    return c;
}
''')
add(732, r'''
#include <stdio.h>

int countSetBits(unsigned int n);

int main(void)
{
    unsigned int tests[4] = {0, 7, 255, 1024};
    int i;
    for (i = 0; i < 4; i++)
    {
        printf("Set bits in %u = %d\n", tests[i], countSetBits(tests[i]));
    }
    return 0;
}

int countSetBits(unsigned int n)
{
    int count = 0;
    while (n != 0)
    {
        count += n & 1;     /* check the lowest bit */
        n >>= 1;
    }
    return count;
}
''')
add(733, r'''
#include <stdio.h>

int indexOf(const int arr[], int n, int target);

int main(void)
{
    int data[7] = {5, 12, 9, 30, 12, 7, 21};
    int targets[3] = {30, 12, 100};
    int i;
    for (i = 0; i < 3; i++)
    {
        int idx = indexOf(data, 7, targets[i]);
        if (idx >= 0)
        {
            printf("Target %d first found at index %d\n", targets[i], idx);
        }
        else
        {
            printf("Target %d not present (returned %d)\n", targets[i], idx);
        }
    }
    return 0;
}

int indexOf(const int arr[], int n, int target)
{
    int i;
    for (i = 0; i < n; i++)
    {
        if (arr[i] == target)
        {
            return i;
        }
    }
    return -1;
}
''')
add(734, r'''
#include <stdio.h>

int isLeap(int y);
int isValidDate(int d, int m, int y);

int main(void)
{
    int dates[5][3] = {{29, 2, 2024}, {29, 2, 2023}, {31, 4, 2022}, {15, 8, 1947}, {10, 13, 2020}};
    int i;
    for (i = 0; i < 5; i++)
    {
        printf("%02d/%02d/%d is %s\n", dates[i][0], dates[i][1], dates[i][2],
               isValidDate(dates[i][0], dates[i][1], dates[i][2]) ? "valid" : "invalid");
    }
    return 0;
}

int isLeap(int y)
{
    return (y % 4 == 0 && y % 100 != 0) || (y % 400 == 0);
}

int isValidDate(int d, int m, int y)
{
    int days[13] = {0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
    if (y < 1 || m < 1 || m > 12 || d < 1)
    {
        return 0;
    }
    if (m == 2 && isLeap(y))
    {
        return d <= 29;
    }
    return d <= days[m];
}
''')
add(735, r'''
#include <stdio.h>

void formatTime(int totalSeconds, char out[]);

int main(void)
{
    int tests[4] = {0, 59, 3725, 86399};
    char buffer[16];
    int i;
    for (i = 0; i < 4; i++)
    {
        formatTime(tests[i], buffer);
        printf("%6d seconds = %s\n", tests[i], buffer);
    }
    return 0;
}

void formatTime(int totalSeconds, char out[])
{
    int h = totalSeconds / 3600;
    int m = (totalSeconds % 3600) / 60;
    int s = totalSeconds % 60;
    sprintf(out, "%02d:%02d:%02d", h, m, s);
}
''')
add(736, r'''
#include <stdio.h>

int add(int a, int b);

int main(void)
{
    int x, y;
    printf("Enter first integer: ");
    scanf("%d", &x);
    printf("Enter second integer: ");
    scanf("%d", &y);
    printf("Sum = %d\n", add(x, y));
    return 0;
}

int add(int a, int b)
{
    return a + b;
}
''', "45\n-12")
add(737, r'''
#include <stdio.h>

int findMax(int a, int b);      /* separate user-defined function */

int main(void)
{
    int first, second;
    printf("Enter two numbers: ");
    scanf("%d %d", &first, &second);
    printf("The maximum of %d and %d is %d\n", first, second, findMax(first, second));
    return 0;
}

int findMax(int a, int b)
{
    if (a >= b)
    {
        return a;
    }
    return b;
}
''', "23 58")
add(738, r'''
#include <stdio.h>

int maxOfThree(int a, int b, int c);

int main(void)
{
    int a, b, c;
    printf("Enter three integers: ");
    if (scanf("%d %d %d", &a, &b, &c) != 3)
    {
        printf("Error: please enter exactly three integers.\n");
        return 0;
    }
    if (a < -1000000 || a > 1000000 || b < -1000000 || b > 1000000 || c < -1000000 || c > 1000000)
    {
        printf("Error: values must be between -1000000 and 1000000.\n");
        return 0;
    }
    printf("Maximum = %d\n", maxOfThree(a, b, c));
    return 0;
}

int maxOfThree(int a, int b, int c)
{
    int max = a;
    if (b > max)
    {
        max = b;
    }
    if (c > max)
    {
        max = c;
    }
    return max;
}
''', "15 88 42")
add(739, r'''
#include <stdio.h>

long long factorial(int n);

int main(void)
{
    int tests, i, n;
    printf("How many test inputs? ");
    scanf("%d", &tests);
    for (i = 1; i <= tests; i++)
    {
        printf("Test %d - enter n (0 to 20): ", i);
        scanf("%d", &n);
        if (n < 0 || n > 20)
        {
            printf("  Invalid: n must be between 0 and 20.\n");
        }
        else
        {
            printf("  %d! = %lld\n", n, factorial(n));
        }
    }
    return 0;
}

long long factorial(int n)
{
    long long f = 1;
    int i;
    for (i = 2; i <= n; i++)
    {
        f *= i;
    }
    return f;
}
''', "3\n5\n0\n12")
add(740, r'''
#include <stdio.h>

int isPrime(int n);

int main(void)
{
    int n;
    printf("Enter a number: ");
    scanf("%d", &n);
    if (isPrime(n))
    {
        printf("%d is a prime number.\n", n);
    }
    else
    {
        printf("%d is not a prime number.\n", n);
    }
    return 0;
}

/* Returns 1 if n is prime, otherwise 0. */
int isPrime(int n)
{
    int i;
    /* numbers below 2 are never prime */
    if (n < 2)
    {
        return 0;
    }
    /* a composite number has a divisor not greater than its square root,
       so we only test i up to sqrt(n) */
    for (i = 2; i * i <= n; i++)
    {
        if (n % i == 0)
        {
            return 0;   /* found a divisor */
        }
    }
    return 1;           /* no divisor found */
}
''', "29")
add(741, r'''
#include <stdio.h>

int gcd(int a, int b);

int main(void)
{
    int tests[6][2] = {{0, 5}, {7, 0}, {0, 0}, {-12, 18}, {1, 999}, {36, 36}};
    int i;
    for (i = 0; i < 6; i++)
    {
        int a = tests[i][0], b = tests[i][1];
        if (a == 0 && b == 0)
        {
            printf("GCD(0, 0) is undefined\n");     /* boundary case */
        }
        else
        {
            printf("GCD(%d, %d) = %d\n", a, b, gcd(a, b));
        }
    }
    return 0;
}

/* works with zero and negative values too */
int gcd(int a, int b)
{
    if (a < 0)
    {
        a = -a;
    }
    if (b < 0)
    {
        b = -b;
    }
    while (b != 0)
    {
        int rem = a % b;
        a = b;
        b = rem;
    }
    return a;
}
''')
add(742, r'''
#include <stdio.h>

int gcd(int a, int b);
int lcm(int a, int b);

int main(void)
{
    int choice, a, b;
    do
    {
        printf("\n--- MENU ---\n");
        printf("1. Find LCM\n");
        printf("2. Find GCD\n");
        printf("3. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);
        if (choice == 1 || choice == 2)
        {
            printf("Enter two positive integers: ");
            scanf("%d %d", &a, &b);
            if (a <= 0 || b <= 0)
            {
                printf("Error: numbers must be positive.\n");
            }
            else if (choice == 1)
            {
                printf("LCM(%d, %d) = %d\n", a, b, lcm(a, b));
            }
            else
            {
                printf("GCD(%d, %d) = %d\n", a, b, gcd(a, b));
            }
        }
        else if (choice != 3)
        {
            printf("Invalid choice.\n");
        }
    } while (choice != 3);
    printf("Goodbye!\n");
    return 0;
}

int gcd(int a, int b)
{
    while (b != 0)
    {
        int rem = a % b;
        a = b;
        b = rem;
    }
    return a;
}

int lcm(int a, int b)
{
    return a / gcd(a, b) * b;
}
''', "1\n4 6\n2\n24 36\n1\n0 5\n9\n3\n")
add(743, r'''
#include <stdio.h>

int reverseInteger(int n);

int main(void)
{
    int n;
    printf("Enter a positive integer: ");
    scanf("%d", &n);
    printf("Reverse of %d is %d\n", n, reverseInteger(n));
    return 0;
}

int reverseInteger(int n)
{
    int rev = 0, step = 1;
    while (n > 0)
    {
        int digit = n % 10;
        rev = rev * 10 + digit;
        printf("Step %d: digit = %d, reversed so far = %d\n", step, digit, rev);
        n /= 10;
        step++;
    }
    return rev;
}
''', "4096")
add(744, r'''
#include <stdio.h>

int sumOfDigits(int n);

int main(void)
{
    int n;
    printf("Enter a non-negative integer: ");
    scanf("%d", &n);
    printf("Sum of digits of %d = %d\n", n, sumOfDigits(n));
    return 0;
}

/* the loop repeats the same two statements for every digit */
int sumOfDigits(int n)
{
    int sum = 0;
    while (n > 0)
    {
        sum += n % 10;      /* add last digit */
        n /= 10;            /* drop last digit */
    }
    return sum;
}
''', "98765")
add(745, r'''
#include <stdio.h>

int isPalindrome(const int *num);

int main(void)
{
    int n;
    int *ptr = &n;          /* pointer to the number */
    printf("Enter an integer: ");
    scanf("%d", ptr);
    if (isPalindrome(ptr))
    {
        printf("%d is a palindrome.\n", *ptr);
    }
    else
    {
        printf("%d is not a palindrome.\n", *ptr);
    }
    return 0;
}

int isPalindrome(const int *num)
{
    int temp = *num, rev = 0;
    if (temp < 0)
    {
        return 0;
    }
    while (temp > 0)
    {
        rev = rev * 10 + temp % 10;
        temp /= 10;
    }
    return rev == *num;
}
''', "12321")
add(746, r'''
#include <stdio.h>

int isArmstrong(int n);

int main(void)
{
    int n;
    printf("Enter a positive integer: ");
    scanf("%d", &n);
    if (isArmstrong(n))
    {
        printf("%d is an Armstrong number.\n", n);
    }
    else
    {
        printf("%d is not an Armstrong number.\n", n);
    }
    return 0;
}

int isArmstrong(int n)
{
    int digits[10];             /* array holding the digits */
    int count = 0, i, j, sum = 0, temp = n;
    if (n <= 0)
    {
        return 0;
    }
    while (temp > 0)
    {
        digits[count++] = temp % 10;
        temp /= 10;
    }
    for (i = 0; i < count; i++)
    {
        int term = 1;
        for (j = 0; j < count; j++)
        {
            term *= digits[i];
        }
        sum += term;            /* digit raised to number of digits */
    }
    return sum == n;
}
''', "9474")
add(747, r'''
#include <stdio.h>

struct PowerInput
{
    int base;
    int exponent;
};

long long power(struct PowerInput in);

int main(void)
{
    struct PowerInput in;
    printf("Enter base: ");
    scanf("%d", &in.base);
    printf("Enter exponent (non-negative): ");
    scanf("%d", &in.exponent);
    if (in.exponent < 0)
    {
        printf("Error: negative exponent not supported.\n");
        return 0;
    }
    printf("%d ^ %d = %lld\n", in.base, in.exponent, power(in));
    return 0;
}

long long power(struct PowerInput in)
{
    long long result = 1;
    int i;
    for (i = 0; i < in.exponent; i++)
    {
        result *= in.base;
    }
    return result;
}
''', "3\n8")
add(748, r'''
#include <stdio.h>

void swap(int *a, int *b);

int main(void)
{
    int n, i;
    int first[10], second[10];
    printf("How many pairs (1 to 10)? ");
    scanf("%d", &n);
    if (n < 1 || n > 10)
    {
        printf("Error: invalid number of pairs.\n");
        return 0;
    }
    for (i = 0; i < n; i++)
    {
        printf("Enter pair %d (two integers): ", i + 1);
        scanf("%d %d", &first[i], &second[i]);
    }
    printf("\nResults after swapping:\n");
    for (i = 0; i < n; i++)
    {
        printf("Pair %d before: (%d, %d)", i + 1, first[i], second[i]);
        swap(&first[i], &second[i]);
        printf("  after: (%d, %d)\n", first[i], second[i]);
    }
    return 0;
}

void swap(int *a, int *b)
{
    int temp = *a;
    *a = *b;
    *b = temp;
}
''', "3\n1 2\n10 20\n-5 7")
add(749, r'''
#include <stdio.h>

void doubleIt(int n);

int main(void)
{
    int original = 15;
    printf("+----------------------+-------+\n");
    printf("| Stage                | Value |\n");
    printf("+----------------------+-------+\n");
    printf("| Before function call | %5d |\n", original);
    doubleIt(original);
    printf("| After function call  | %5d |\n", original);
    printf("+----------------------+-------+\n");
    printf("The original value is unchanged: call by value.\n");
    return 0;
}

void doubleIt(int n)
{
    n = n * 2;
    printf("| Inside (the copy)    | %5d |\n", n);
}
''')
add(750, r'''
#include <stdio.h>

void computeBoth(int a, int b, int *sum, int *product);

int main(void)
{
    int a, b, sum = 0, product = 0;
    printf("Enter two integers between 1 and 1000: ");
    if (scanf("%d %d", &a, &b) != 2)
    {
        printf("Error: input is not a pair of integers.\n");
        return 0;
    }
    if (a < 1 || a > 1000 || b < 1 || b > 1000)
    {
        printf("Error: numbers must be between 1 and 1000.\n");
        return 0;
    }
    computeBoth(a, b, &sum, &product);      /* function fills caller's variables */
    printf("Sum     = %d\n", sum);
    printf("Product = %d\n", product);
    return 0;
}

void computeBoth(int a, int b, int *sum, int *product)
{
    *sum = a + b;
    *product = a * b;
}
''', "25 40")
