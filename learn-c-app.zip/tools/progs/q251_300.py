# programs 251-300 : id -> (stdin, code)
P = {}
def add(i, code, stdin=""): P[i] = (stdin, code.strip("\n"))

add(251, r'''
#include <stdio.h>

int main(void)
{
    int n, i;

    printf("Enter N: ");
    if (scanf("%d", &n) != 1) {
        printf("Invalid input.\n");
        return 1;
    }
    for (i = 1; i <= n; i++)
        printf("%d ", i);
    printf("\n");
    return 0;
}
''', "10")
add(252, r'''
#include <stdio.h>

int main(void)
{
    int n;

    printf("Enter N: ");
    if (scanf("%d", &n) != 1) {
        printf("Invalid input.\n");
        return 1;
    }
    while (n >= 1) {            /* count down until 1 is printed */
        printf("%d ", n);
        n--;
    }
    printf("\n");
    return 0;
}
''', "8")
add(253, r'''
#include <stdio.h>

int main(void)
{
    int n, i;

    printf("Enter N: ");
    if (scanf("%d", &n) != 1) {
        printf("Invalid input.\n");
        return 1;
    }
    printf("Even numbers from 1 to %d:\n", n);
    for (i = 2; i <= n; i += 2)
        printf("%d ", i);
    printf("\n");
    return 0;
}
''', "20")
add(254, r'''
#include <stdio.h>

int main(void)
{
    int n, i;

    printf("Enter N: ");
    if (scanf("%d", &n) != 1) {
        printf("Invalid input.\n");
        return 1;
    }
    printf("Odd numbers from 1 to %d:\n", n);
    for (i = 1; i <= n; i += 2)
        printf("%d ", i);
    printf("\n");
    return 0;
}
''', "15")
add(255, r'''
#include <stdio.h>

int main(void)
{
    int n, i;
    long sum = 0;

    printf("Enter N: ");
    if (scanf("%d", &n) != 1) {
        printf("Invalid input.\n");
        return 1;
    }
    for (i = 1; i <= n; i++)
        sum += i;
    printf("Sum of 1 to %d = %ld\n", n, sum);
    return 0;
}
''', "100")
add(256, r'''
#include <stdio.h>

int main(void)
{
    int n, i;
    long sum = 0;

    printf("Enter N: ");
    if (scanf("%d", &n) != 1) {
        printf("Invalid input.\n");
        return 1;
    }
    for (i = 1; i <= n; i++)
        if (i % 2 == 0)
            sum += i;
    printf("Sum of even numbers from 1 to %d = %ld\n", n, sum);
    return 0;
}
''', "10")
add(257, r'''
#include <stdio.h>

int main(void)
{
    int n, i;
    long sum = 0;

    printf("Enter N: ");
    if (scanf("%d", &n) != 1) {
        printf("Invalid input.\n");
        return 1;
    }
    for (i = 1; i <= n; i += 2)
        sum += i;
    printf("Sum of odd numbers from 1 to %d = %ld\n", n, sum);
    return 0;
}
''', "9")
add(258, r'''
#include <stdio.h>

int main(void)
{
    int num, i;

    printf("Enter a number: ");
    if (scanf("%d", &num) != 1) {
        printf("Invalid input.\n");
        return 1;
    }
    for (i = 1; i <= 10; i++)
        printf("%d x %2d = %d\n", num, i, num * i);
    return 0;
}
''', "7")
add(259, r'''
#include <stdio.h>

int main(void)
{
    int table, i;

    for (table = 1; table <= 10; table++) {
        printf("Table of %2d:", table);
        for (i = 1; i <= 10; i++)
            printf(" %3d", table * i);
        printf("\n");
    }
    return 0;
}
''')
add(260, r'''
#include <stdio.h>

int main(void)
{
    int n, i, count = 0;

    printf("Enter N: ");
    if (scanf("%d", &n) != 1) {
        printf("Invalid input.\n");
        return 1;
    }
    for (i = 1; i <= n; i++)
        if (i % 3 == 0)
            count++;
    printf("Numbers from 1 to %d divisible by 3: %d\n", n, count);
    return 0;
}
''', "50")
add(261, r'''
#include <stdio.h>

int main(void)
{
    int n, i;
    unsigned long long fact = 1;

    printf("Enter a number (0-20): ");
    if (scanf("%d", &n) != 1 || n < 0 || n > 20) {
        printf("Invalid input.\n");
        return 1;
    }
    for (i = 2; i <= n; i++)
        fact *= i;
    printf("%d! = %llu\n", n, fact);
    return 0;
}
''', "10")
add(262, r'''
#include <stdio.h>

int main(void)
{
    int a, b, i;
    long long result = 1;

    printf("Enter base a and exponent b: ");
    if (scanf("%d %d", &a, &b) != 2 || b < 0) {
        printf("Invalid input (b must be >= 0).\n");
        return 1;
    }
    for (i = 0; i < b; i++)     /* multiply a by itself b times */
        result *= a;
    printf("%d^%d = %lld\n", a, b, result);
    return 0;
}
''', "2 10")
add(263, r'''
#include <stdio.h>

int main(void)
{
    int n, i;

    printf("Enter N: ");
    if (scanf("%d", &n) != 1) {
        printf("Invalid input.\n");
        return 1;
    }
    printf("Number  Square\n");
    for (i = 1; i <= n; i++)
        printf("%6d  %6d\n", i, i * i);
    return 0;
}
''', "8")
add(264, r'''
#include <stdio.h>

int main(void)
{
    int n, i;

    printf("Enter N: ");
    if (scanf("%d", &n) != 1) {
        printf("Invalid input.\n");
        return 1;
    }
    printf("Number  Cube\n");
    for (i = 1; i <= n; i++)
        printf("%6d  %6d\n", i, i * i * i);
    return 0;
}
''', "6")
add(265, r'''
#include <stdio.h>

int main(void)
{
    int n, i;
    double x, sum = 0.0;

    printf("How many numbers? ");
    if (scanf("%d", &n) != 1 || n <= 0) {
        printf("Invalid count.\n");
        return 1;
    }
    for (i = 1; i <= n; i++) {
        printf("Enter number %d: ", i);
        if (scanf("%lf", &x) != 1) {
            printf("Invalid number.\n");
            return 1;
        }
        sum += x;
    }
    printf("Sum = %.2f, Average = %.2f\n", sum, sum / n);
    return 0;
}
''', "5 10 20 30 40 55")
add(266, r'''
#include <stdio.h>

int main(void)
{
    int x, sum = 0;

    printf("Enter numbers (0 to stop):\n");
    while (scanf("%d", &x) == 1 && x != 0)
        sum += x;
    printf("Sum = %d\n", sum);
    return 0;
}
''', "4 8 15 16 23 42 0")
add(267, r'''
#include <stdio.h>

int main(void)
{
    int num;

    do {
        printf("Enter a positive number: ");
        if (scanf("%d", &num) != 1) {
            printf("Input ended without a valid number.\n");
            return 1;
        }
        if (num <= 0)
            printf("Invalid! %d is not positive. Try again.\n", num);
    } while (num <= 0);
    printf("You entered %d.\n", num);
    return 0;
}
''', "-3 0 -8 12")
add(268, r'''
#include <stdio.h>

int main(void)
{
    int choice = 0;

    do {
        printf("\n1. Say Hello\n2. Say Goodbye\n3. Exit\nChoice: ");
        if (scanf("%d", &choice) != 1)
            break;
        if (choice == 1)
            printf("Hello!\n");
        else if (choice == 2)
            printf("Goodbye!\n");
        else if (choice != 3)
            printf("Invalid choice.\n");
    } while (choice != 3);
    printf("Program ended.\n");
    return 0;
}
''', "1 2 9 3")
add(269, r'''
#include <stdio.h>

int main(void)
{
    int lo, hi, i;

    printf("Enter range (low high): ");
    if (scanf("%d %d", &lo, &hi) != 2) {
        printf("Invalid input.\n");
        return 1;
    }
    printf("Divisible by both 2 and 7 in [%d, %d]:\n", lo, hi);
    for (i = lo; i <= hi; i++)
        if (i % 2 == 0 && i % 7 == 0)
            printf("%d ", i);
    printf("\n");
    return 0;
}
''', "1 100")
add(270, r'''
#include <stdio.h>

int main(void)
{
    int a = 10, b = 10;

    printf("Condition is false from the start (value 10 < 5).\n");

    printf("while loop:\n");
    while (a < 5) {
        printf("  while body runs, a = %d\n", a);
        a++;
    }
    printf("  (while body never ran)\n");

    printf("do-while loop:\n");
    do {
        printf("  do-while body runs, b = %d\n", b);
        b++;
    } while (b < 5);
    return 0;
}
''')
add(271, r'''
#include <stdio.h>

int main(void)
{
    int lo, hi, k;

    printf("Enter range (low high): ");
    if (scanf("%d %d", &lo, &hi) != 2) {
        printf("Invalid input.\n");
        return 1;
    }
    printf("Perfect squares in [%d, %d]:\n", lo, hi);
    for (k = 0; k * k <= hi; k++)
        if (k * k >= lo)
            printf("%d ", k * k);
    printf("\n");
    return 0;
}
''', "10 150")
add(272, r'''
#include <stdio.h>

int main(void)
{
    int n, i;
    double sum = 0.0;

    printf("Enter N: ");
    if (scanf("%d", &n) != 1 || n < 1) {
        printf("Invalid input.\n");
        return 1;
    }
    for (i = 1; i <= n; i++)
        sum += 1.0 / i;
    printf("1 + 1/2 + ... + 1/%d = %.6f\n", n, sum);
    return 0;
}
''', "10")
add(273, r'''
#include <stdio.h>

int main(void)
{
    int terms, i;
    double pi = 0.0, sign = 1.0;

    printf("Enter number of terms: ");
    if (scanf("%d", &terms) != 1 || terms < 1) {
        printf("Invalid input.\n");
        return 1;
    }
    /* Leibniz series: pi/4 = 1 - 1/3 + 1/5 - 1/7 + ... */
    for (i = 0; i < terms; i++) {
        pi += sign / (2 * i + 1);
        sign = -sign;
    }
    pi *= 4.0;
    printf("pi after %d terms = %.6f\n", terms, pi);
    return 0;
}
''', "1000")
add(274, r'''
#include <stdio.h>

int main(void)
{
    int row, col;

    printf("    |");
    for (col = 1; col <= 10; col++)
        printf("%4d", col);
    printf("\n----+----------------------------------------\n");
    for (row = 1; row <= 10; row++) {
        printf("%3d |", row);
        for (col = 1; col <= 10; col++)
            printf("%4d", row * col);
        printf("\n");
    }
    return 0;
}
''')
add(275, r'''
#include <stdio.h>

int main(void)
{
    int x, positives = 0;

    printf("Enter numbers (9999 to stop):\n");
    while (scanf("%d", &x) == 1 && x != 9999)
        if (x > 0)
            positives++;
    printf("Positive numbers entered: %d\n", positives);
    return 0;
}
''', "5 -2 8 0 12 7 -9 9999")
add(276, r'''
#include <stdio.h>

int main(void)
{
    int n, i;

    printf("Enter the value of N: ");
    if (scanf("%d", &n) != 1) {
        printf("Invalid input.\n");
        return 1;
    }
    printf("Numbers from 1 to %d:\n", n);
    for (i = 1; i <= n; i++)
        printf("%d\n", i);
    return 0;
}
''', "6")
add(277, r'''
#include <stdio.h>

/* prints n, n-1, ..., 1 using a while loop */
void print_down(int n)
{
    while (n >= 1) {
        printf("%d ", n);
        n--;
    }
    printf("\n");
}

int main(void)
{
    int n;

    printf("Enter N: ");
    if (scanf("%d", &n) != 1) {
        printf("Invalid input.\n");
        return 1;
    }
    print_down(n);
    return 0;
}
''', "12")
add(278, r'''
#include <stdio.h>

int main(void)
{
    int n, i;

    printf("Enter a positive N: ");
    while (scanf("%d", &n) == 1 && n < 1) {
        printf("Error: N must be at least 1. Try again: ");
    }
    if (n < 1) {
        printf("Error: no valid number was entered.\n");
        return 1;
    }
    printf("Even numbers from 1 to %d:\n", n);
    for (i = 2; i <= n; i += 2)
        printf("%d ", i);
    printf("\n");
    return 0;
}
''', "-5 0 14")
add(279, r'''
#include <stdio.h>

int main(void)
{
    int n, i, t;

    for (t = 1; t <= 3; t++) {
        printf("Test %d - enter N: ", t);
        if (scanf("%d", &n) != 1) {
            printf("Invalid input.\n");
            return 1;
        }
        printf("Odd numbers from 1 to %d:", n);
        for (i = 1; i <= n; i += 2)
            printf(" %d", i);
        printf("\n");
    }
    return 0;
}
''', "5 10 1")
add(280, r'''
#include <stdio.h>

int main(void)
{
    int n, i;
    long sum = 0;

    printf("Enter N: ");
    if (scanf("%d", &n) != 1) {
        printf("Invalid input.\n");
        return 1;
    }
    /* Add each number from 1 to n into sum, one at a time */
    for (i = 1; i <= n; i++)
        sum = sum + i;

    printf("Sum by loop    = %ld\n", sum);
    /* Check using the formula n(n+1)/2 */
    printf("Sum by formula = %ld\n", (long)n * (n + 1) / 2);
    return 0;
}
''', "50")
add(281, r'''
#include <stdio.h>

int main(void)
{
    int count, n, i, k;

    printf("How many values to test? ");
    if (scanf("%d", &count) != 1 || count < 1) {
        printf("Invalid input.\n");
        return 1;
    }
    for (k = 0; k < count; k++) {
        long sum = 0;
        if (scanf("%d", &n) != 1) {
            printf("Invalid input.\n");
            return 1;
        }
        if (n < 2) {            /* boundary: no even number exists in 1..n */
            printf("N = %d: no even numbers, sum = 0\n", n);
            continue;
        }
        for (i = 2; i <= n; i += 2)
            sum += i;
        printf("N = %d: sum of evens = %ld\n", n, sum);
    }
    return 0;
}
''', "5 0 1 2 3 11")
add(282, r'''
#include <stdio.h>

int main(void)
{
    int choice, n, i;

    do {
        printf("\n--- MENU ---\n1. Sum of odd numbers 1..N\n2. Exit\nChoice: ");
        if (scanf("%d", &choice) != 1)
            break;
        if (choice == 1) {
            long sum = 0;
            printf("Enter N: ");
            if (scanf("%d", &n) != 1)
                break;
            for (i = 1; i <= n; i += 2)
                sum += i;
            printf("Sum of odd numbers 1..%d = %ld\n", n, sum);
        } else if (choice != 2) {
            printf("Invalid choice.\n");
        }
    } while (choice != 2);
    printf("Goodbye!\n");
    return 0;
}
''', "1 9 1 100 2")
add(283, r'''
#include <stdio.h>

int main(void)
{
    int num, i, total = 0;

    printf("Enter a number: ");
    if (scanf("%d", &num) != 1) {
        printf("Invalid input.\n");
        return 1;
    }
    printf("Multiplication table of %d (each row adds %d to the previous):\n", num, num);
    for (i = 1; i <= 10; i++) {
        int before = total;
        total += num;
        printf("%d x %2d = %3d   (%3d + %d)\n", num, i, total, before, num);
    }
    return 0;
}
''', "6")
add(284, r'''
#include <stdio.h>

int main(void)
{
    int table, i;

    for (table = 1; table <= 10; table++) {
        printf("--- Table of %d ---\n", table);
        for (i = 1; i <= 10; i++)
            printf("%2d x %2d = %3d\n", table, i, table * i);
    }
    return 0;
}
''')
add(285, r'''
#include <stdio.h>

/* counts multiples of 3 in 1..n and stores the answer via the pointer */
void count_div3(int n, int *count)
{
    int i;

    *count = 0;
    for (i = 1; i <= n; i++)
        if (i % 3 == 0)
            (*count)++;
}

int main(void)
{
    int n, result;

    printf("Enter N: ");
    if (scanf("%d", &n) != 1) {
        printf("Invalid input.\n");
        return 1;
    }
    count_div3(n, &result);
    printf("Numbers from 1 to %d divisible by 3: %d\n", n, result);
    return 0;
}
''', "40")
add(286, r'''
#include <stdio.h>

int main(void)
{
    unsigned long long fact[21];    /* fact[i] holds i! */
    int n, i;

    printf("Enter N (0-20): ");
    if (scanf("%d", &n) != 1 || n < 0 || n > 20) {
        printf("Invalid input.\n");
        return 1;
    }
    fact[0] = 1;
    for (i = 1; i <= n; i++)
        fact[i] = fact[i - 1] * i;
    for (i = 0; i <= n; i++)
        printf("%2d! = %llu\n", i, fact[i]);
    printf("Factorial of %d is %llu\n", n, fact[n]);
    return 0;
}
''', "10")
add(287, r'''
#include <stdio.h>

struct Power {
    int base;
    int exponent;
    long long result;
};

int main(void)
{
    struct Power p;
    int i;

    printf("Enter base and exponent: ");
    if (scanf("%d %d", &p.base, &p.exponent) != 2 || p.exponent < 0) {
        printf("Invalid input.\n");
        return 1;
    }
    p.result = 1;
    for (i = 0; i < p.exponent; i++)
        p.result *= p.base;
    printf("%d^%d = %lld\n", p.base, p.exponent, p.result);
    return 0;
}
''', "3 13")
add(288, r'''
#include <stdio.h>

int main(void)
{
    int sets, s, n, i;

    printf("How many values of N will you enter? ");
    if (scanf("%d", &sets) != 1 || sets < 1) {
        printf("Invalid input.\n");
        return 1;
    }
    for (s = 1; s <= sets; s++) {
        printf("Enter N for set %d: ", s);
        if (scanf("%d", &n) != 1) {
            printf("Invalid input.\n");
            return 1;
        }
        printf("Set %d:", s);
        for (i = 1; i <= n; i++)
            printf(" %d^2=%d", i, i * i);
        printf("\n");
    }
    return 0;
}
''', "3 4 6 3")
add(289, r'''
#include <stdio.h>

int main(void)
{
    int n, i;

    printf("Enter N: ");
    if (scanf("%d", &n) != 1) {
        printf("Invalid input.\n");
        return 1;
    }
    printf("+--------+--------+\n");
    printf("| Number |  Cube  |\n");
    printf("+--------+--------+\n");
    for (i = 1; i <= n; i++)
        printf("| %6d | %6d |\n", i, i * i * i);
    printf("+--------+--------+\n");
    return 0;
}
''', "7")
add(290, r'''
#include <stdio.h>

int main(void)
{
    int n, i;
    double x, sum = 0.0;

    printf("How many numbers? ");
    if (scanf("%d", &n) != 1) {
        printf("Error: count is not a valid integer.\n");
        return 1;
    }
    if (n <= 0) {
        printf("Error: count must be greater than zero.\n");
        return 1;
    }
    for (i = 1; i <= n; i++) {
        printf("Number %d: ", i);
        if (scanf("%lf", &x) != 1) {
            printf("Error: that is not a valid number.\n");
            return 1;
        }
        sum += x;
    }
    printf("Average of %d numbers = %.3f\n", n, sum / n);
    return 0;
}
''', "4 12.5 7 9.25 20")
add(291, r'''
#include <stdio.h>

/* reads integers until 0 and returns their sum */
int read_and_sum(void)
{
    int x, sum = 0;

    while (scanf("%d", &x) == 1 && x != 0)
        sum += x;
    return sum;
}

void show_result(int sum)
{
    printf("Sum of the numbers = %d\n", sum);
}

int main(void)
{
    printf("Enter numbers (0 to stop): ");
    show_result(read_and_sum());
    return 0;
}
''', "10 20 30 -5 0")
add(292, r'''
#include <stdio.h>

/* Time cost: O(k) for k attempts. Space cost: O(1), only a few variables. */
int get_positive(void)
{
    int num;

    do {
        printf("Enter a positive number: ");
        if (scanf("%d", &num) != 1)
            return -1;          /* input ended or was not a number */
        if (num <= 0)
            printf("Not positive, try again.\n");
    } while (num <= 0);
    return num;
}

int main(void)
{
    int value = get_positive();

    if (value < 0) {
        printf("No valid input.\n");
        return 1;
    }
    printf("Accepted: %d\n", value);
    return 0;
}
''', "-1 0 -7 25")
add(293, r'''
#include <stdio.h>

int main(void)
{
    int choice;
    long long v;

    /* Test cases to type: normal (5), minimum (0), maximum (1000) */
    do {
        printf("\n1. Square\n2. Cube\n3. Exit\nChoice: ");
        if (scanf("%d", &choice) != 1)
            break;
        if (choice == 1 || choice == 2) {
            printf("Enter a value (0-1000): ");
            if (scanf("%lld", &v) != 1 || v < 0 || v > 1000) {
                printf("Value out of range.\n");
                continue;
            }
            if (choice == 1)
                printf("Square of %lld = %lld\n", v, v * v);
            else
                printf("Cube of %lld = %lld\n", v, v * v * v);
        } else if (choice != 3) {
            printf("Invalid choice.\n");
        }
    } while (choice != 3);
    printf("Exiting.\n");
    return 0;
}
''', "1 5 1 0 2 1000 2 1001 3")
add(294, r'''
#include <stdio.h>

int divisible_by_2_and_7(int n)
{
    return n % 2 == 0 && n % 7 == 0;
}

int main(void)
{
    int lo, hi, i, found = 0;

    printf("Enter range (low high): ");
    if (scanf("%d %d", &lo, &hi) != 2) {
        printf("Invalid input.\n");
        return 1;
    }
    for (i = lo; i <= hi; i++)
        if (divisible_by_2_and_7(i)) {
            printf("%d ", i);
            found++;
        }
    if (found == 0)
        printf("No such numbers.");
    printf("\n");
    return 0;
}
''', "50 200")
add(295, r'''
#include <stdio.h>

int main(void)
{
    int limit, a, b;

    printf("Enter a starting value: ");
    if (scanf("%d", &limit) != 1) {
        printf("Error: invalid input, nothing to demonstrate.\n");
        return 1;
    }
    a = b = limit;
    printf("Loop condition: value < 5\n");

    printf("while: ");
    while (a < 5) {
        printf("%d ", a);
        a++;
    }
    printf("\ndo-while: ");
    do {
        printf("%d ", b);
        b++;
    } while (b < 5);
    printf("\n");
    return 0;
}
''', "8")
add(296, r'''
#include <stdio.h>

int main(void)
{
    int n, i;
    long sum = 0;

    printf("Enter N: ");
    if (scanf("%d", &n) != 1) {
        printf("Invalid input.\n");
        return 1;
    }
    /* Time cost: O(N), the loop runs about N/2 times.
       Space cost: O(1), only a few variables are used. */
    for (i = 1; i <= n; i += 2)
        sum += i;
    printf("Sum of odd numbers from 1 to %d = %ld\n", n, sum);
    return 0;
}
''', "15")
add(297, r'''
#include <stdio.h>

int main(void)
{
    int terms, table, i;

    printf("How many multiples per table (1-12)? ");
    if (scanf("%d", &terms) != 1 || terms < 1 || terms > 12) {
        printf("Invalid input.\n");
        return 1;
    }
    for (table = 1; table <= 10; table++) {
        printf("Table %2d:", table);
        for (i = 1; i <= terms; i++)
            printf(" %3d", table * i);
        printf("\n");
    }
    return 0;
}
''', "5")
add(298, r'''
#include <stdio.h>

int main(void)
{
    int n, i;
    unsigned long long fact = 1;

    printf("Enter a number: ");
    if (scanf("%d", &n) != 1 || n < 0 || n > 20) {
        printf("Enter an integer between 0 and 20.\n");
        return 1;
    }
    /* n! = 1 x 2 x 3 x ... x n, so multiply fact by each i in turn */
    for (i = 1; i <= n; i++) {
        fact *= i;
        printf("after multiplying by %d: %llu\n", i, fact);
    }
    printf("%d! = %llu\n", n, fact);
    return 0;
}
''', "7")
add(299, r'''
#include <stdio.h>

int main(void)
{
    int n, i, square = 0;

    printf("Enter N: ");
    if (scanf("%d", &n) != 1) {
        printf("Invalid input.\n");
        return 1;
    }
    for (i = 1; i <= n; i++) {
        square += 2 * i - 1;    /* each square is the previous plus next odd number */
        printf("%2d squared = %3d\n", i, square);
    }
    return 0;
}
''', "9")
add(300, r'''
#include <stdio.h>

int main(void)
{
    int n, i;
    double x, sum = 0.0, max = 0.0, min = 0.0;

    printf("How many records? ");
    if (scanf("%d", &n) != 1 || n < 1) {
        printf("Invalid count.\n");
        return 1;
    }
    for (i = 1; i <= n; i++) {
        printf("Value %d: ", i);
        if (scanf("%lf", &x) != 1) {
            printf("Invalid value.\n");
            return 1;
        }
        if (i == 1 || x > max) max = x;
        if (i == 1 || x < min) min = x;
        sum += x;
    }
    printf("Count=%d  Sum=%.1f  Average=%.2f  Max=%.1f  Min=%.1f\n",
           n, sum, sum / n, max, min);
    return 0;
}
''', "6 72 85 90 66 78 94")
