# programs 751-800 : id -> (stdin, code)
P = {}
def add(i, code, stdin=""): P[i] = (stdin, code.strip("\n"))

add(751, r'''
#include <stdio.h>

/* n! = n * (n-1)!, with 0! = 1 as the base case */
unsigned long long factorial(int n)
{
    if (n <= 1)
        return 1;
    return n * factorial(n - 1);
}

int main(void)
{
    printf("%-4s %s\n", "n", "n!");
    for (int n = 0; n <= 10; n++)
        printf("%-4d %llu\n", n, factorial(n));
    return 0;
}
''')
add(752, r'''
#include <stdio.h>

/* fib(0)=0, fib(1)=1, fib(n)=fib(n-1)+fib(n-2) */
int fib(int n)
{
    if (n < 2)
        return n;
    return fib(n - 1) + fib(n - 2);
}

int main(void)
{
    printf("First 12 Fibonacci numbers:\n");
    for (int i = 0; i < 12; i++)
        printf("%d ", fib(i));
    printf("\n\nThe 20th Fibonacci number (n = 20) is %d\n", fib(20));
    return 0;
}
''')
add(753, r'''
#include <stdio.h>

/* sum(n) = n + sum(n-1), sum(0) = 0 */
int sumTo(int n)
{
    if (n == 0)
        return 0;
    return n + sumTo(n - 1);
}

int main(void)
{
    int tests[] = {1, 5, 10, 100};
    for (int i = 0; i < 4; i++)
        printf("Sum of 1 to %d = %d\n", tests[i], sumTo(tests[i]));
    return 0;
}
''')
add(754, r'''
#include <stdio.h>

/* last digit + sum of the remaining digits */
int digitSum(int n)
{
    if (n == 0)
        return 0;
    return n % 10 + digitSum(n / 10);
}

int main(void)
{
    int numbers[] = {5, 123, 9045, 99999, 2026};
    for (int i = 0; i < 5; i++)
        printf("Sum of digits of %d = %d\n", numbers[i], digitSum(numbers[i]));
    return 0;
}
''')
add(755, r'''
#include <stdio.h>

/* rev accumulates the reversed digits as we go down the recursion */
int reverseHelper(int n, int rev)
{
    if (n == 0)
        return rev;
    return reverseHelper(n / 10, rev * 10 + n % 10);
}

int reverseNumber(int n)
{
    return reverseHelper(n, 0);
}

int main(void)
{
    int numbers[] = {12345, 9870, 7, 1001};
    for (int i = 0; i < 4; i++)
        printf("Reverse of %d is %d\n", numbers[i], reverseNumber(numbers[i]));
    return 0;
}
''')
add(756, r'''
#include <stdio.h>

/* a^b = a * a^(b-1), a^0 = 1 */
long long power(int a, int b)
{
    if (b == 0)
        return 1;
    return a * power(a, b - 1);
}

int main(void)
{
    int a[] = {2, 3, 5, 10, 7};
    int b[] = {10, 4, 3, 6, 0};
    for (int i = 0; i < 5; i++)
        printf("%d ^ %d = %lld\n", a[i], b[i], power(a[i], b[i]));
    return 0;
}
''')
add(757, r'''
#include <stdio.h>

/* Euclid: gcd(a, b) = gcd(b, a % b), gcd(a, 0) = a */
int gcd(int a, int b)
{
    if (b == 0)
        return a;
    return gcd(b, a % b);
}

int main(void)
{
    int pairs[][2] = {{48, 18}, {100, 75}, {17, 5}, {270, 192}};
    for (int i = 0; i < 4; i++)
        printf("GCD(%d, %d) = %d\n", pairs[i][0], pairs[i][1],
               gcd(pairs[i][0], pairs[i][1]));
    return 0;
}
''')
add(758, r'''
#include <stdio.h>

/* print the smaller numbers first, then n */
void printUp(int n)
{
    if (n == 0)
        return;
    printUp(n - 1);
    printf("%d ", n);
}

int main(void)
{
    int n = 10;
    printf("Numbers from 1 to %d: ", n);
    printUp(n);
    printf("\n");
    return 0;
}
''')
add(759, r'''
#include <stdio.h>

/* print n first, then the smaller numbers */
void printDown(int n)
{
    if (n == 0)
        return;
    printf("%d ", n);
    printDown(n - 1);
}

int main(void)
{
    int n = 10;
    printf("Numbers from %d to 1: ", n);
    printDown(n);
    printf("\n");
    return 0;
}
''')
add(760, r'''
#include <stdio.h>

/* T(n) = n + T(n-1), T(0) = 0 */
int triangular(int n)
{
    if (n == 0)
        return 0;
    return n + triangular(n - 1);
}

int main(void)
{
    for (int n = 1; n <= 10; n++)
        printf("Triangular number %2d = %d\n", n, triangular(n));
    return 0;
}
''')
add(761, r'''
#include <stdio.h>

/* binary of n = binary of (n/2) followed by the bit n%2 */
void toBinary(unsigned int n)
{
    if (n > 1)
        toBinary(n / 2);
    printf("%u", n % 2);
}

int main(void)
{
    unsigned int values[] = {0, 5, 10, 37, 255, 1024};
    for (int i = 0; i < 6; i++) {
        printf("%4u in binary = ", values[i]);
        toBinary(values[i]);
        printf("\n");
    }
    return 0;
}
''')
add(762, r'''
#include <stdio.h>

/* product of digits: last digit * product of the rest */
int digitProduct(int n)
{
    if (n < 10)
        return n;
    return (n % 10) * digitProduct(n / 10);
}

int main(void)
{
    int numbers[] = {7, 234, 1111, 5678, 1203};
    for (int i = 0; i < 5; i++)
        printf("Product of digits of %d = %d\n", numbers[i], digitProduct(numbers[i]));
    return 0;
}
''')
add(763, r'''
#include <stdio.h>
#include <string.h>

/* compare the outer characters, then check the inside part */
int isPalindrome(const char *s, int left, int right)
{
    if (left >= right)
        return 1;
    if (s[left] != s[right])
        return 0;
    return isPalindrome(s, left + 1, right - 1);
}

int main(void)
{
    const char *words[] = {"madam", "level", "hello", "racecar", "abca"};
    for (int i = 0; i < 5; i++) {
        int len = (int)strlen(words[i]);
        printf("%-8s -> %s\n", words[i],
               isPalindrome(words[i], 0, len - 1) ? "palindrome" : "not a palindrome");
    }
    return 0;
}
''')
add(764, r'''
#include <stdio.h>

/* length = 0 for an empty string, else 1 + length of the rest */
int length(const char *s)
{
    if (*s == '\0')
        return 0;
    return 1 + length(s + 1);
}

int main(void)
{
    const char *words[] = {"", "C", "recursion", "Hello, World!"};
    for (int i = 0; i < 4; i++)
        printf("Length of \"%s\" = %d\n", words[i], length(words[i]));
    return 0;
}
''')
add(765, r'''
#include <stdio.h>
#include <string.h>

/* swap the outer characters, then reverse the inside part */
void reverse(char *s, int left, int right)
{
    if (left >= right)
        return;
    char tmp = s[left];
    s[left] = s[right];
    s[right] = tmp;
    reverse(s, left + 1, right - 1);
}

int main(void)
{
    char text[] = "recursion";
    printf("Original: %s\n", text);
    reverse(text, 0, (int)strlen(text) - 1);
    printf("Reversed: %s\n", text);
    return 0;
}
''')
add(766, r'''
#include <stdio.h>

/* returns the index of key in the sorted array a[low..high], or -1 */
int binarySearch(const int a[], int low, int high, int key)
{
    if (low > high)
        return -1;
    int mid = low + (high - low) / 2;
    if (a[mid] == key)
        return mid;
    if (key < a[mid])
        return binarySearch(a, low, mid - 1, key);
    return binarySearch(a, mid + 1, high, key);
}

int main(void)
{
    int a[] = {3, 8, 15, 22, 31, 40, 57, 63, 79, 90};
    int n = 10;
    int keys[] = {40, 3, 90, 50};
    for (int i = 0; i < 4; i++) {
        int pos = binarySearch(a, 0, n - 1, keys[i]);
        if (pos >= 0)
            printf("%d found at index %d\n", keys[i], pos);
        else
            printf("%d not found\n", keys[i]);
    }
    return 0;
}
''')
add(767, r'''
#include <stdio.h>

static int moves = 0;

/* move n disks from 'from' to 'to' using 'via' as the spare peg */
void hanoi(int n, char from, char to, char via)
{
    if (n == 0)
        return;
    hanoi(n - 1, from, via, to);
    moves++;
    printf("Move %d: disk %d from %c to %c\n", moves, n, from, to);
    hanoi(n - 1, via, to, from);
}

int main(void)
{
    int n = 3;
    printf("Tower of Hanoi with %d disks\n", n);
    hanoi(n, 'A', 'C', 'B');
    printf("Total moves = %d (2^%d - 1)\n", moves, n);
    return 0;
}
''')
add(768, r'''
#include <stdio.h>

/* maximum of the first n elements */
int maxElement(const int a[], int n)
{
    if (n == 1)
        return a[0];
    int rest = maxElement(a, n - 1);
    return a[n - 1] > rest ? a[n - 1] : rest;
}

int main(void)
{
    int a[] = {12, 45, 7, 89, 23, 56, 3};
    int n = 7;
    printf("Array:");
    for (int i = 0; i < n; i++)
        printf(" %d", a[i]);
    printf("\nMaximum element = %d\n", maxElement(a, n));
    return 0;
}
''')
add(769, r'''
#include <stdio.h>

/* sum of the first n elements */
int arraySum(const int a[], int n)
{
    if (n == 0)
        return 0;
    return a[n - 1] + arraySum(a, n - 1);
}

int main(void)
{
    int a[] = {4, 8, 15, 16, 23, 42};
    int n = 6;
    printf("Array:");
    for (int i = 0; i < n; i++)
        printf(" %d", a[i]);
    printf("\nSum of elements = %d\n", arraySum(a, n));
    return 0;
}
''')
add(770, r'''
#include <stdio.h>

/* count how many of the first n elements equal target */
int countTarget(const int a[], int n, int target)
{
    if (n == 0)
        return 0;
    return (a[n - 1] == target) + countTarget(a, n - 1, target);
}

int main(void)
{
    int a[] = {2, 5, 2, 7, 2, 9, 5, 2};
    int n = 8;
    int targets[] = {2, 5, 9, 4};
    for (int i = 0; i < 4; i++)
        printf("%d occurs %d time(s)\n", targets[i], countTarget(a, n, targets[i]));
    return 0;
}
''')
add(771, r'''
#include <stdio.h>

/* for each element: either leave it out or include it */
void subsets(const char set[], int n, int index, char current[], int size)
{
    if (index == n) {
        printf("{ ");
        for (int i = 0; i < size; i++)
            printf("%c ", current[i]);
        printf("}\n");
        return;
    }
    subsets(set, n, index + 1, current, size);          /* exclude */
    current[size] = set[index];
    subsets(set, n, index + 1, current, size + 1);      /* include */
}

int main(void)
{
    char set[] = {'a', 'b', 'c'};
    char current[3];
    printf("All subsets of {a, b, c}:\n");
    subsets(set, 3, 0, current, 0);
    return 0;
}
''')
add(772, r'''
#include <stdio.h>
#include <string.h>

static int count = 0;

/* fix one character at position 'start' and permute the rest */
void permute(char *s, int start, int end)
{
    if (start == end) {
        count++;
        printf("%d. %s\n", count, s);
        return;
    }
    for (int i = start; i <= end; i++) {
        char t = s[start]; s[start] = s[i]; s[i] = t;
        permute(s, start + 1, end);
        t = s[start]; s[start] = s[i]; s[i] = t;     /* backtrack */
    }
}

int main(void)
{
    char s[] = "ABC";
    printf("Permutations of %s:\n", s);
    permute(s, 0, (int)strlen(s) - 1);
    return 0;
}
''')
add(773, r'''
#include <stdio.h>

#define N 5

/* 1 = open cell, 0 = wall; path marks the route with 2 */
int maze[N][N] = {
    {1, 0, 0, 0, 0},
    {1, 1, 0, 1, 0},
    {0, 1, 0, 0, 0},
    {1, 1, 1, 1, 0},
    {0, 0, 0, 1, 1}
};

int solve(int r, int c)
{
    if (r < 0 || c < 0 || r >= N || c >= N || maze[r][c] != 1)
        return 0;
    maze[r][c] = 2;                      /* mark as part of path */
    if (r == N - 1 && c == N - 1)
        return 1;
    if (solve(r + 1, c) || solve(r, c + 1) || solve(r - 1, c) || solve(r, c - 1))
        return 1;
    maze[r][c] = 3;                      /* dead end: backtrack */
    return 0;
}

int main(void)
{
    if (solve(0, 0)) {
        printf("Path found (* = path):\n");
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++)
                printf("%c ", maze[i][j] == 2 ? '*' : (maze[i][j] == 0 ? '#' : '.'));
            printf("\n");
        }
    } else {
        printf("No path exists.\n");
    }
    return 0;
}
''')
add(774, r'''
#include <stdio.h>
#include <stdlib.h>

static int n, solutions = 0;
static int col[16];            /* col[row] = column of queen in that row */

int safe(int row, int c)
{
    for (int r = 0; r < row; r++)
        if (col[r] == c || abs(col[r] - c) == row - r)
            return 0;
    return 1;
}

void place(int row)
{
    if (row == n) {
        solutions++;
        if (solutions == 1) {
            printf("First solution:\n");
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < n; j++)
                    printf("%c ", col[i] == j ? 'Q' : '.');
                printf("\n");
            }
        }
        return;
    }
    for (int c = 0; c < n; c++)
        if (safe(row, c)) {
            col[row] = c;
            place(row + 1);
        }
}

int main(void)
{
    printf("Enter N: ");
    if (scanf("%d", &n) != 1 || n < 1 || n > 15) {
        printf("Invalid N.\n");
        return 1;
    }
    place(0);
    printf("Total solutions for %d queens = %d\n", n, solutions);
    return 0;
}
''', "6")
add(775, r'''
#include <stdio.h>

/* open = '(' used so far, close = ')' used so far */
void generate(char buf[], int pos, int open, int close, int n)
{
    if (pos == 2 * n) {
        buf[pos] = '\0';
        printf("%s\n", buf);
        return;
    }
    if (open < n) {
        buf[pos] = '(';
        generate(buf, pos + 1, open + 1, close, n);
    }
    if (close < open) {
        buf[pos] = ')';
        generate(buf, pos + 1, open, close + 1, n);
    }
}

int main(void)
{
    int n = 3;
    char buf[32];
    printf("Balanced parentheses for N = %d:\n", n);
    generate(buf, 0, 0, 0, n);
    return 0;
}
''')
add(776, r'''
#include <stdio.h>

unsigned long long factRecursive(int n)
{
    if (n <= 1)
        return 1;
    return n * factRecursive(n - 1);
}

unsigned long long factIterative(int n)
{
    unsigned long long result = 1;
    for (int i = 2; i <= n; i++)
        result *= i;
    return result;
}

int main(void)
{
    printf("%-3s %-22s %-22s %s\n", "n", "Recursive", "Iterative", "Same?");
    for (int n = 0; n <= 20; n += 4) {
        unsigned long long r = factRecursive(n), it = factIterative(n);
        printf("%-3d %-22llu %-22llu %s\n", n, r, it, r == it ? "yes" : "no");
    }
    return 0;
}
''')
add(777, r'''
#include <stdio.h>

/* sum of the first n terms: a, a+d, a+2d, ... */
int apSum(int a, int d, int n)
{
    if (n == 0)
        return 0;
    return a + (n - 1) * d + apSum(a, d, n - 1);
}

int main(void)
{
    int a = 2, d = 3, n = 10;
    printf("AP: ");
    for (int i = 0; i < n; i++)
        printf("%d ", a + i * d);
    printf("\nSum of first %d terms = %d\n", n, apSum(a, d, n));
    printf("Check with formula n/2*(2a+(n-1)d) = %d\n", n * (2 * a + (n - 1) * d) / 2);
    return 0;
}
''')
add(778, r'''
#include <stdio.h>

/* count occurrences of ch in the string s */
int countChar(const char *s, char ch)
{
    if (*s == '\0')
        return 0;
    return (*s == ch) + countChar(s + 1, ch);
}

int main(void)
{
    const char *text = "recursion is fun and recursive";
    char letters[] = {'r', 'e', 'n', 'z'};
    printf("Text: %s\n", text);
    for (int i = 0; i < 4; i++)
        printf("'%c' appears %d time(s)\n", letters[i], countChar(text, letters[i]));
    return 0;
}
''')
add(779, r'''
#include <stdio.h>

/* choose k items from 1..n; chosen[] holds the current selection */
void combine(int start, int n, int k, int chosen[], int size)
{
    if (size == k) {
        for (int i = 0; i < k; i++)
            printf("%d ", chosen[i]);
        printf("\n");
        return;
    }
    for (int i = start; i <= n; i++) {
        chosen[size] = i;
        combine(i + 1, n, k, chosen, size + 1);
    }
}

int main(void)
{
    int n = 5, k = 3;
    int chosen[10];
    printf("Combinations of %d items taken %d at a time:\n", n, k);
    combine(1, n, k, chosen, 0);
    return 0;
}
''')
add(780, r'''
#include <stdio.h>

/* can some subset of the first n elements add up to target? */
int subsetSum(const int a[], int n, int target)
{
    if (target == 0)
        return 1;
    if (n == 0 || target < 0)
        return 0;
    return subsetSum(a, n - 1, target - a[n - 1]) || subsetSum(a, n - 1, target);
}

int main(void)
{
    int a[] = {3, 34, 4, 12, 5, 2};
    int targets[] = {9, 30, 11, 58};
    printf("Set: 3 34 4 12 5 2\n");
    for (int i = 0; i < 4; i++)
        printf("Subset with sum %2d exists? %s\n", targets[i],
               subsetSum(a, 6, targets[i]) ? "Yes" : "No");
    return 0;
}
''')
add(781, r'''
#include <stdio.h>
#include <stdlib.h>

struct Node {
    int data;
    struct Node *next;
};

struct Node *newNode(int data, struct Node *next)
{
    struct Node *node = malloc(sizeof(struct Node));
    if (node == NULL)
        exit(1);
    node->data = data;
    node->next = next;
    return node;
}

/* print this node, then the rest of the list */
void printList(const struct Node *head)
{
    if (head == NULL) {
        printf("NULL\n");
        return;
    }
    printf("%d -> ", head->data);
    printList(head->next);
}

int main(void)
{
    struct Node *head = NULL;
    for (int v = 50; v >= 10; v -= 10)
        head = newNode(v, head);
    printf("Linked list: ");
    printList(head);
    while (head != NULL) {
        struct Node *tmp = head->next;
        free(head);
        head = tmp;
    }
    return 0;
}
''')
add(782, r'''
#include <stdio.h>

unsigned long long factorial(int n)
{
    if (n <= 1)
        return 1;
    return n * factorial(n - 1);
}

int main(void)
{
    int n;
    printf("Enter a number (0-20): ");
    if (scanf("%d", &n) != 1 || n < 0 || n > 20) {
        printf("Invalid input.\n");
        return 1;
    }
    printf("%d! = %llu\n", n, factorial(n));
    return 0;
}
''', "7")
add(783, r'''
#include <stdio.h>

/* separate user-defined recursive function */
long long fib(int n)
{
    if (n < 2)
        return n;
    return fib(n - 1) + fib(n - 2);
}

int main(void)
{
    int n;
    printf("Enter n: ");
    if (scanf("%d", &n) != 1 || n < 0 || n > 40) {
        printf("Please enter n between 0 and 40.\n");
        return 1;
    }
    printf("Fibonacci number %d is %lld\n", n, fib(n));
    return 0;
}
''', "15")
add(784, r'''
#include <stdio.h>

int sumTo(int n)
{
    if (n == 0)
        return 0;
    return n + sumTo(n - 1);
}

int main(void)
{
    int n;
    printf("Enter N (1 to 10000): ");
    if (scanf("%d", &n) != 1) {
        printf("Error: input is not a valid integer.\n");
        return 1;
    }
    if (n < 1 || n > 10000) {
        printf("Error: N must be between 1 and 10000.\n");
        return 1;
    }
    printf("Sum of 1 to %d = %d\n", n, sumTo(n));
    return 0;
}
''', "250")
add(785, r'''
#include <stdio.h>

int digitSum(int n)
{
    if (n == 0)
        return 0;
    return n % 10 + digitSum(n / 10);
}

int main(void)
{
    int n;
    for (int i = 1; i <= 3; i++) {
        printf("Test %d - enter a number: ", i);
        if (scanf("%d", &n) != 1 || n < 0) {
            printf("\nInvalid number.\n");
            return 1;
        }
        printf("%d\n", n);
        printf("  Sum of digits of %d = %d\n", n, digitSum(n));
    }
    return 0;
}
''', "456 90001 987654321")
add(786, r'''
#include <stdio.h>

/* Main logic: each call peels off the last digit (n % 10) and
   appends it to rev (rev * 10 + digit). When n becomes 0, rev
   holds the digits in reverse order. */
int reverse(int n, int rev)
{
    if (n == 0)
        return rev;
    return reverse(n / 10, rev * 10 + n % 10);
}

int main(void)
{
    int n;
    printf("Enter a positive number: ");
    if (scanf("%d", &n) != 1 || n < 0) {
        printf("Invalid input.\n");
        return 1;
    }
    printf("Reverse of %d = %d\n", n, reverse(n, 0));
    return 0;
}
''', "48210")
add(787, r'''
#include <stdio.h>

/* a^0 = 1 for any a (including 0^0 treated as 1 here);
   negative exponents give 1/a^|b| */
double power(double a, int b)
{
    if (b == 0)
        return 1.0;
    if (b < 0)
        return 1.0 / power(a, -b);
    return a * power(a, b - 1);
}

int main(void)
{
    double base[] = {2, 0, 5, 0, -3, 2, 10};
    int exp[] = {10, 5, 0, 0, 3, -3, 1};
    printf("%-8s %-8s %s\n", "base", "exp", "result");
    for (int i = 0; i < 7; i++) {
        if (base[i] == 0 && exp[i] < 0) {
            printf("%-8.0f %-8d undefined\n", base[i], exp[i]);
            continue;
        }
        printf("%-8.0f %-8d %g\n", base[i], exp[i], power(base[i], exp[i]));
    }
    return 0;
}
''')
add(788, r'''
#include <stdio.h>

int gcd(int a, int b)
{
    if (b == 0)
        return a;
    return gcd(b, a % b);
}

int main(void)
{
    int choice, a, b;
    do {
        printf("\n1. Find GCD\n2. Find LCM\n3. Exit\nChoice: ");
        if (scanf("%d", &choice) != 1)
            break;
        if (choice == 1 || choice == 2) {
            printf("Enter two positive numbers: ");
            if (scanf("%d %d", &a, &b) != 2 || a <= 0 || b <= 0) {
                printf("Invalid numbers.\n");
                break;
            }
            if (choice == 1)
                printf("GCD(%d, %d) = %d\n", a, b, gcd(a, b));
            else
                printf("LCM(%d, %d) = %d\n", a, b, a / gcd(a, b) * b);
        } else if (choice != 3) {
            printf("Invalid choice.\n");
        }
    } while (choice != 3);
    printf("Goodbye!\n");
    return 0;
}
''', "1 48 36 2 4 6 9 3")
add(789, r'''
#include <stdio.h>

void printUp(int i, int n)
{
    if (i > n)
        return;
    printf("Step %d: printing %d\n", i, i);
    printUp(i + 1, n);
    printf("  returning from call with i = %d\n", i);
}

int main(void)
{
    int n;
    printf("Enter N: ");
    if (scanf("%d", &n) != 1 || n < 1) {
        printf("Invalid input.\n");
        return 1;
    }
    printUp(1, n);
    return 0;
}
''', "5")
add(790, r'''
#include <stdio.h>

void printDown(int n)
{
    if (n == 0)
        return;
    printf("%d ", n);
    printDown(n - 1);
}

int main(void)
{
    int sizes[] = {5, 8, 3};
    /* a loop runs the test for each value instead of repeating statements */
    for (int i = 0; i < 3; i++) {
        printf("From %d down to 1: ", sizes[i]);
        printDown(sizes[i]);
        printf("\n");
    }
    return 0;
}
''')
add(791, r'''
#include <stdio.h>

/* the result is returned through a pointer */
void triangular(int n, int *result)
{
    if (n == 0) {
        *result = 0;
        return;
    }
    triangular(n - 1, result);
    *result += n;
}

int main(void)
{
    int n, result;
    printf("Enter n: ");
    if (scanf("%d", &n) != 1 || n < 0) {
        printf("Invalid input.\n");
        return 1;
    }
    triangular(n, &result);
    printf("Triangular number %d = %d\n", n, result);
    return 0;
}
''', "12")
add(792, r'''
#include <stdio.h>

/* store bits in an array, least significant bit first */
int toBinary(unsigned int n, int bits[], int pos)
{
    if (n == 0)
        return pos;
    bits[pos] = n % 2;
    return toBinary(n / 2, bits, pos + 1);
}

int main(void)
{
    unsigned int n;
    int bits[32];
    printf("Enter a non-negative number: ");
    if (scanf("%u", &n) != 1) {
        printf("Invalid input.\n");
        return 1;
    }
    int count = toBinary(n, bits, 0);
    printf("Binary of %u = ", n);
    if (count == 0)
        printf("0");
    for (int i = count - 1; i >= 0; i--)
        printf("%d", bits[i]);
    printf("\n");
    return 0;
}
''', "202")
add(793, r'''
#include <stdio.h>

struct Record {
    int number;
    int product;
};

int digitProduct(int n)
{
    if (n < 10)
        return n;
    return (n % 10) * digitProduct(n / 10);
}

int main(void)
{
    struct Record r;
    printf("Enter a number: ");
    if (scanf("%d", &r.number) != 1 || r.number < 0) {
        printf("Invalid input.\n");
        return 1;
    }
    r.product = digitProduct(r.number);
    printf("Number  : %d\nProduct of digits: %d\n", r.number, r.product);
    return 0;
}
''', "3452")
add(794, r'''
#include <stdio.h>
#include <string.h>

int isPalindrome(const char *s, int left, int right)
{
    if (left >= right)
        return 1;
    if (s[left] != s[right])
        return 0;
    return isPalindrome(s, left + 1, right - 1);
}

int main(void)
{
    int count;
    char word[100];
    printf("How many words? ");
    if (scanf("%d", &count) != 1 || count < 1) {
        printf("Invalid count.\n");
        return 1;
    }
    for (int i = 1; i <= count; i++) {
        if (scanf("%99s", word) != 1) {
            printf("Missing word.\n");
            return 1;
        }
        printf("%d. %-10s : %s\n", i, word,
               isPalindrome(word, 0, (int)strlen(word) - 1) ? "palindrome" : "not palindrome");
    }
    return 0;
}
''', "4 noon apple refer programming")
add(795, r'''
#include <stdio.h>

int length(const char *s)
{
    if (*s == '\0')
        return 0;
    return 1 + length(s + 1);
}

int main(void)
{
    char text[100];
    printf("Enter a word: ");
    if (scanf("%99s", text) != 1) {
        printf("No input.\n");
        return 1;
    }
    printf("+----------+------------------+\n");
    printf("| %-8s | %-16s |\n", "Field", "Value");
    printf("+----------+------------------+\n");
    printf("| %-8s | %-16s |\n", "String", text);
    printf("| %-8s | %-16d |\n", "Length", length(text));
    printf("+----------+------------------+\n");
    return 0;
}
''', "algorithm")
add(796, r'''
#include <stdio.h>
#include <string.h>

void reverse(char *s, int left, int right)
{
    if (left >= right)
        return;
    char tmp = s[left];
    s[left] = s[right];
    s[right] = tmp;
    reverse(s, left + 1, right - 1);
}

int main(void)
{
    char text[50];
    printf("Enter a string (max 49 characters, no spaces): ");
    if (scanf("%49s", text) != 1) {
        printf("Error: no string entered.\n");
        return 1;
    }
    if (strlen(text) == 0) {
        printf("Error: empty string.\n");
        return 1;
    }
    reverse(text, 0, (int)strlen(text) - 1);
    printf("Reversed string: %s\n", text);
    return 0;
}
''', "stressed")
add(797, r'''
#include <stdio.h>

void readArray(int a[], int n)
{
    for (int i = 0; i < n; i++)
        scanf("%d", &a[i]);
}

int binarySearch(const int a[], int low, int high, int key)
{
    if (low > high)
        return -1;
    int mid = low + (high - low) / 2;
    if (a[mid] == key)
        return mid;
    if (key < a[mid])
        return binarySearch(a, low, mid - 1, key);
    return binarySearch(a, mid + 1, high, key);
}

void report(const int a[], int n, int key)
{
    int pos = binarySearch(a, 0, n - 1, key);
    if (pos >= 0)
        printf("%d found at position %d\n", key, pos + 1);
    else
        printf("%d is not in the array\n", key);
}

int main(void)
{
    int a[20], n, key;
    printf("Enter number of elements (1-20): ");
    if (scanf("%d", &n) != 1 || n < 1 || n > 20) {
        printf("Invalid size.\n");
        return 1;
    }
    printf("Enter %d elements in ascending order: ", n);
    readArray(a, n);
    printf("Enter key: ");
    if (scanf("%d", &key) != 1) {
        printf("Invalid key.\n");
        return 1;
    }
    report(a, n, key);
    return 0;
}
''', "7 2 5 9 14 20 33 41 20")
add(798, r'''
#include <stdio.h>

/* Time cost: T(n) = 2*T(n-1) + 1, so 2^n - 1 moves -> O(2^n).
   Space cost: recursion depth is n, so O(n) stack space. */
long long hanoi(int n, char from, char to, char via)
{
    if (n == 0)
        return 0;
    long long moves = hanoi(n - 1, from, via, to);
    printf("Move disk %d from %c to %c\n", n, from, to);
    moves += 1;
    moves += hanoi(n - 1, via, to, from);
    return moves;
}

int main(void)
{
    int n;
    printf("Enter number of disks (1-10): ");
    if (scanf("%d", &n) != 1 || n < 1 || n > 10) {
        printf("Invalid number of disks.\n");
        return 1;
    }
    long long moves = hanoi(n, 'A', 'C', 'B');
    printf("Moves made: %lld (expected 2^%d - 1 = %d)\n", moves, n, (1 << n) - 1);
    return 0;
}
''', "4")
add(799, r'''
#include <stdio.h>
#include <limits.h>

int maxElement(const int a[], int n)
{
    if (n == 1)
        return a[0];
    int rest = maxElement(a, n - 1);
    return a[n - 1] > rest ? a[n - 1] : rest;
}

void runTest(const char *name, const int a[], int n)
{
    printf("%-22s -> max = %d\n", name, maxElement(a, n));
}

int main(void)
{
    int normal[] = {14, 82, 5, 67, 31};
    int single[] = {42};
    int negatives[] = {-8, -3, -50, -1, -20};
    int extremes[] = {INT_MIN, 0, INT_MAX, 100};
    int same[] = {7, 7, 7, 7};

    runTest("Normal values", normal, 5);
    runTest("Single element", single, 1);
    runTest("All negative", negatives, 5);
    runTest("Min and max of int", extremes, 4);
    runTest("All equal", same, 4);
    return 0;
}
''')
add(800, r'''
#include <stdio.h>

/* no global variables: everything is passed as parameters */
int arraySum(const int a[], int n)
{
    if (n == 0)
        return 0;
    return a[n - 1] + arraySum(a, n - 1);
}

int main(void)
{
    int a[] = {10, 20, 30, 40, 50, 60};
    int n = (int)(sizeof(a) / sizeof(a[0]));
    int total = arraySum(a, n);
    printf("Elements: %d\n", n);
    printf("Sum = %d\n", total);
    printf("Average = %.2f\n", (double)total / n);
    return 0;
}
''')
