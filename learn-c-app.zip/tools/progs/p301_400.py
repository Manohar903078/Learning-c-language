# programs 301-400
P = {}
def add(i, code, stdin=""): P[i] = (stdin, code.strip("\n"))

add(301, r'''
#include <stdio.h>

int main(void)
{
    int n, i, isPrime = 1;
    printf("Enter a number: ");
    scanf("%d", &n);
    if (n < 2)
    {
        isPrime = 0;
    }
    for (i = 2; i * i <= n; i++)
    {
        if (n % i == 0)
        {
            isPrime = 0;
            break;
        }
    }
    if (isPrime)
        printf("%d is a prime number.\n", n);
    else
        printf("%d is not a prime number.\n", n);
    return 0;
}
''', "29")
add(302, r'''
#include <stdio.h>

int main(void)
{
    int low, high, n, i, isPrime;
    printf("Enter the lower limit: ");
    scanf("%d", &low);
    printf("Enter the upper limit: ");
    scanf("%d", &high);
    printf("Prime numbers between %d and %d:\n", low, high);
    for (n = low; n <= high; n++)
    {
        isPrime = (n >= 2);
        for (i = 2; i * i <= n; i++)
        {
            if (n % i == 0)
            {
                isPrime = 0;
                break;
            }
        }
        if (isPrime)
            printf("%d ", n);
    }
    printf("\n");
    return 0;
}
''', "10\n50")
add(303, r'''
#include <stdio.h>

int main(void)
{
    int n, i, sum = 0;
    printf("Enter a number: ");
    scanf("%d", &n);
    /* add all proper divisors (divisors smaller than n) */
    for (i = 1; i < n; i++)
    {
        if (n % i == 0)
            sum += i;
    }
    printf("Sum of proper divisors = %d\n", sum);
    if (n > 1 && sum == n)
        printf("%d is a perfect number.\n", n);
    else
        printf("%d is not a perfect number.\n", n);
    return 0;
}
''', "28")
add(304, r'''
#include <stdio.h>

int main(void)
{
    int low, high, n, i, sum;
    printf("Enter the lower limit: ");
    scanf("%d", &low);
    printf("Enter the upper limit: ");
    scanf("%d", &high);
    printf("Perfect numbers between %d and %d:\n", low, high);
    for (n = low; n <= high; n++)
    {
        sum = 0;
        for (i = 1; i < n; i++)
        {
            if (n % i == 0)
                sum += i;
        }
        if (n > 1 && sum == n)
            printf("%d\n", n);
    }
    return 0;
}
''', "1\n1000")
add(305, r'''
#include <stdio.h>

int main(void)
{
    int n, temp, digit, digits = 0, power, i;
    int sum = 0;
    printf("Enter a number: ");
    scanf("%d", &n);
    /* count the digits */
    for (temp = n; temp > 0; temp /= 10)
        digits++;
    /* add each digit raised to the power of digit count */
    for (temp = n; temp > 0; temp /= 10)
    {
        digit = temp % 10;
        power = 1;
        for (i = 0; i < digits; i++)
            power *= digit;
        sum += power;
    }
    if (sum == n)
        printf("%d is an Armstrong number.\n", n);
    else
        printf("%d is not an Armstrong number (sum = %d).\n", n, sum);
    return 0;
}
''', "153")
add(306, r'''
#include <stdio.h>

int main(void)
{
    int low, high, n, temp, digits, digit, power, i, sum;
    printf("Enter the lower limit: ");
    scanf("%d", &low);
    printf("Enter the upper limit: ");
    scanf("%d", &high);
    printf("Armstrong numbers between %d and %d:\n", low, high);
    for (n = low; n <= high; n++)
    {
        digits = 0;
        for (temp = n; temp > 0; temp /= 10)
            digits++;
        sum = 0;
        for (temp = n; temp > 0; temp /= 10)
        {
            digit = temp % 10;
            power = 1;
            for (i = 0; i < digits; i++)
                power *= digit;
            sum += power;
        }
        if (n > 0 && sum == n)
            printf("%d ", n);
    }
    printf("\n");
    return 0;
}
''', "1\n1000")
add(307, r'''
#include <stdio.h>

int main(void)
{
    int n, temp, reversed = 0;
    printf("Enter a number: ");
    scanf("%d", &n);
    for (temp = n; temp > 0; temp /= 10)
        reversed = reversed * 10 + temp % 10;
    printf("Reverse = %d\n", reversed);
    if (reversed == n)
        printf("%d is a palindrome.\n", n);
    else
        printf("%d is not a palindrome.\n", n);
    return 0;
}
''', "12321")
add(308, r'''
#include <stdio.h>

int main(void)
{
    int low, high, n, temp, reversed;
    printf("Enter the lower limit: ");
    scanf("%d", &low);
    printf("Enter the upper limit: ");
    scanf("%d", &high);
    printf("Palindrome numbers between %d and %d:\n", low, high);
    for (n = low; n <= high; n++)
    {
        reversed = 0;
        for (temp = n; temp > 0; temp /= 10)
            reversed = reversed * 10 + temp % 10;
        if (n > 0 && reversed == n)
            printf("%d ", n);
    }
    printf("\n");
    return 0;
}
''', "100\n200")
add(309, r'''
#include <stdio.h>

int main(void)
{
    int n, temp, digit, i, fact, sum = 0;
    printf("Enter a number: ");
    scanf("%d", &n);
    /* sum of factorials of the digits */
    for (temp = n; temp > 0; temp /= 10)
    {
        digit = temp % 10;
        fact = 1;
        for (i = 2; i <= digit; i++)
            fact *= i;
        sum += fact;
    }
    printf("Sum of factorials of digits = %d\n", sum);
    if (n > 0 && sum == n)
        printf("%d is a strong number.\n", n);
    else
        printf("%d is not a strong number.\n", n);
    return 0;
}
''', "145")
add(310, r'''
#include <stdio.h>

int main(void)
{
    int low, high, n, temp, i, fact, sum;
    printf("Enter the lower limit: ");
    scanf("%d", &low);
    printf("Enter the upper limit: ");
    scanf("%d", &high);
    printf("Strong numbers between %d and %d:\n", low, high);
    for (n = low; n <= high; n++)
    {
        sum = 0;
        for (temp = n; temp > 0; temp /= 10)
        {
            fact = 1;
            for (i = 2; i <= temp % 10; i++)
                fact *= i;
            sum += fact;
        }
        if (n > 0 && sum == n)
            printf("%d ", n);
    }
    printf("\n");
    return 0;
}
''', "1\n100000")
add(311, r'''
#include <stdio.h>

int main(void)
{
    int n, temp, digitSum = 0;
    printf("Enter a number: ");
    scanf("%d", &n);
    for (temp = n; temp > 0; temp /= 10)
        digitSum += temp % 10;
    printf("Sum of digits = %d\n", digitSum);
    if (digitSum > 0 && n % digitSum == 0)
        printf("%d is a Harshad (Niven) number.\n", n);
    else
        printf("%d is not a Harshad (Niven) number.\n", n);
    return 0;
}
''', "156")
add(312, r'''
#include <stdio.h>

int main(void)
{
    int n, square, temp;
    int divisor = 1;
    printf("Enter a number: ");
    scanf("%d", &n);
    /* divisor = 10 raised to the number of digits of n */
    for (temp = n; temp > 0; temp /= 10)
        divisor *= 10;
    square = n * n;
    printf("Square = %d\n", square);
    /* an automorphic number's square ends with the number itself */
    if (square % divisor == n)
        printf("%d is an automorphic number.\n", n);
    else
        printf("%d is not an automorphic number.\n", n);
    return 0;
}
''', "76")
add(313, r'''
#include <stdio.h>

int main(void)
{
    int n, square, temp, sum = 0;
    printf("Enter a number: ");
    scanf("%d", &n);
    square = n * n;
    for (temp = square; temp > 0; temp /= 10)
        sum += temp % 10;
    printf("Square = %d, sum of its digits = %d\n", square, sum);
    if (sum == n)
        printf("%d is a neon number.\n", n);
    else
        printf("%d is not a neon number.\n", n);
    return 0;
}
''', "9")
add(314, r'''
#include <stdio.h>

int main(void)
{
    int n, temp, sum = 0, product = 1;
    printf("Enter a number: ");
    scanf("%d", &n);
    for (temp = n; temp > 0; temp /= 10)
    {
        sum += temp % 10;
        product *= temp % 10;
    }
    printf("Sum of digits = %d, product of digits = %d\n", sum, product);
    if (sum == product)
        printf("%d is a spy number.\n", n);
    else
        printf("%d is not a spy number.\n", n);
    return 0;
}
''', "1124")
add(315, r'''
#include <stdio.h>

int main(void)
{
    int n, temp, digit;
    int hasZero = 0;
    int first;
    printf("Enter a number: ");
    scanf("%d", &n);
    /* a duck number has a zero digit but does not start with zero */
    first = n;
    while (first >= 10)
        first /= 10;
    for (temp = n; temp > 0; temp /= 10)
    {
        digit = temp % 10;
        if (digit == 0)
            hasZero = 1;
    }
    if (hasZero && first != 0)
        printf("%d is a duck number.\n", n);
    else
        printf("%d is not a duck number.\n", n);
    return 0;
}
''', "30709")
add(316, r'''
#include <stdio.h>

int main(void)
{
    int n, k;
    int found = 0;
    printf("Enter a number: ");
    scanf("%d", &n);
    /* sunny number: n + 1 is a perfect square */
    for (k = 1; k * k <= n + 1; k++)
    {
        if (k * k == n + 1)
            found = 1;
    }
    if (found)
        printf("%d is a sunny number (%d + 1 is a perfect square).\n", n, n);
    else
        printf("%d is not a sunny number.\n", n);
    return 0;
}
''', "8")
add(317, r'''
#include <stdio.h>

int main(void)
{
    int n, k = 1, total = 0;
    printf("Enter a number: ");
    scanf("%d", &n);
    /* add 1 + 2 + 3 + ... until the total reaches n */
    while (total < n)
    {
        total += k;
        k++;
    }
    if (n > 0 && total == n)
        printf("%d is a triangular number (sum of 1 to %d).\n", n, k - 1);
    else
        printf("%d is not a triangular number.\n", n);
    return 0;
}
''', "28")
add(318, r'''
#include <stdio.h>

int main(void)
{
    int n, i = 0;
    printf("Enter a number: ");
    scanf("%d", &n);
    if (n < 0)
    {
        printf("A negative number cannot be a perfect square.\n");
        return 0;
    }
    /* find the smallest i with i*i >= n, no sqrt() needed */
    while (i * i < n)
        i++;
    if (i * i == n)
        printf("%d is a perfect square (%d x %d).\n", n, i, i);
    else
        printf("%d is not a perfect square.\n", n);
    return 0;
}
''', "144")
add(319, r'''
#include <stdio.h>

int main(void)
{
    int n;
    printf("Enter a number: ");
    scanf("%d", &n);
    /* a power of 2 has exactly one bit set, so n & (n-1) is zero */
    if (n > 0 && (n & (n - 1)) == 0)
        printf("%d is a power of 2.\n", n);
    else
        printf("%d is not a power of 2.\n", n);
    return 0;
}
''', "64")
add(320, r'''
#include <stdio.h>

int main(void)
{
    int n, i;
    printf("Enter a positive number: ");
    scanf("%d", &n);
    printf("Factors of %d: ", n);
    for (i = 1; i <= n; i++)
    {
        if (n % i == 0)
            printf("%d ", i);
    }
    printf("\n");
    return 0;
}
''', "36")
add(321, r'''
#include <stdio.h>

int main(void)
{
    int n, i, count = 0;
    printf("Enter a positive number: ");
    scanf("%d", &n);
    for (i = 1; i <= n; i++)
    {
        if (n % i == 0)
            count++;
    }
    printf("%d has %d factors.\n", n, count);
    return 0;
}
''', "60")
add(322, r'''
#include <stdio.h>

int main(void)
{
    int n, i, sum = 0;
    printf("Enter a positive number: ");
    scanf("%d", &n);
    for (i = 1; i < n; i++)
    {
        if (n % i == 0)
            sum += i;
    }
    printf("Sum of proper divisors of %d = %d\n", n, sum);
    return 0;
}
''', "12")
add(323, r'''
#include <stdio.h>

int main(void)
{
    int a, b, i, gcd = 1;
    printf("Enter two integers: ");
    scanf("%d %d", &a, &b);
    if (a < 0) a = -a;
    if (b < 0) b = -b;
    /* try every number up to the smaller value */
    for (i = 1; i <= a && i <= b; i++)
    {
        if (a % i == 0 && b % i == 0)
            gcd = i;
    }
    if (a == 0 || b == 0)
        gcd = a + b;
    printf("GCD of %d and %d = %d\n", a, b, gcd);
    return 0;
}
''', "48 180")
add(324, r'''
#include <stdio.h>

int main(void)
{
    int a, b, multiple;
    printf("Enter two positive integers: ");
    scanf("%d %d", &a, &b);
    if (a <= 0 || b <= 0)
    {
        printf("Both numbers must be positive.\n");
        return 0;
    }
    /* start at the larger number and step until both divide it */
    multiple = (a > b) ? a : b;
    while (multiple % a != 0 || multiple % b != 0)
        multiple++;
    printf("LCM of %d and %d = %d\n", a, b, multiple);
    return 0;
}
''', "12 18")
add(325, r'''
#include <stdio.h>

int main(void)
{
    int a, b, remainder;
    printf("Enter two integers: ");
    scanf("%d %d", &a, &b);
    if (a < 0) a = -a;
    if (b < 0) b = -b;
    printf("Original numbers: %d and %d\n", a, b);
    /* Euclid: replace (a, b) by (b, a mod b) until b becomes 0 */
    while (b != 0)
    {
        remainder = a % b;
        a = b;
        b = remainder;
    }
    printf("GCD (Euclid's algorithm) = %d\n", a);
    return 0;
}
''', "252 105")
add(326, r'''
#include <stdio.h>

int main(void)
{
    int n, original, factor = 2;
    int first = 1;
    printf("Enter an integer greater than 1: ");
    scanf("%d", &n);
    if (n < 2)
    {
        printf("Error: prime factorization needs a number >= 2.\n");
        return 0;
    }
    original = n;
    printf("Prime factorization of %d = ", original);
    while (n > 1)
    {
        /* divide out each factor as many times as possible */
        while (n % factor == 0)
        {
            if (!first)
                printf(" x ");
            printf("%d", factor);
            first = 0;
            n /= factor;
        }
        factor++;
    }
    printf("\n");
    return 0;
}
''', "360")
add(327, r'''
#include <stdio.h>

/* returns 1 if n is prime, otherwise 0 */
int isPrime(int n)
{
    int i;
    if (n < 2)
        return 0;
    for (i = 2; i * i <= n; i++)
    {
        if (n % i == 0)
            return 0;
    }
    return 1;
}

int main(void)
{
    int low, high, n, count = 0;
    printf("Enter the lower limit: ");
    scanf("%d", &low);
    printf("Enter the upper limit: ");
    scanf("%d", &high);
    printf("Twin prime pairs between %d and %d:\n", low, high);
    for (n = low; n + 2 <= high; n++)
    {
        if (isPrime(n) && isPrime(n + 2))
        {
            printf("(%d, %d)\n", n, n + 2);
            count++;
        }
    }
    printf("Total pairs = %d\n", count);
    return 0;
}
''', "1\n100")
add(328, r'''
#include <stdio.h>

/* sum of proper divisors of n */
int divisorSum(int n)
{
    int i, sum = 0;
    for (i = 1; i < n; i++)
    {
        if (n % i == 0)
            sum += i;
    }
    return sum;
}

int main(void)
{
    int a, b;
    printf("Enter two numbers: ");
    scanf("%d %d", &a, &b);
    printf("Sum of divisors of %d = %d\n", a, divisorSum(a));
    printf("Sum of divisors of %d = %d\n", b, divisorSum(b));
    if (a != b && divisorSum(a) == b && divisorSum(b) == a)
        printf("%d and %d are amicable numbers.\n", a, b);
    else
        printf("%d and %d are not amicable numbers.\n", a, b);
    return 0;
}
''', "220 284")
add(329, r'''
#include <stdio.h>

int main(void)
{
    int n, a = 0, b = 1, next;
    printf("Enter a number: ");
    scanf("%d", &n);
    /* generate Fibonacci numbers until we reach or pass n */
    while (a < n)
    {
        next = a + b;
        a = b;
        b = next;
    }
    if (n >= 0 && a == n)
        printf("%d is a Fibonacci number.\n", n);
    else
        printf("%d is not a Fibonacci number.\n", n);
    return 0;
}
''', "21")
add(330, r'''
#include <stdio.h>

int main(void)
{
    int limit, a = 0, b = 1, next;
    printf("Enter the limit: ");
    scanf("%d", &limit);
    printf("Fibonacci numbers up to %d:\n", limit);
    while (a <= limit)
    {
        printf("%d ", a);
        next = a + b;
        a = b;
        b = next;
    }
    printf("\n");
    return 0;
}
''', "100")
add(331, r'''
#include <stdio.h>

int main(void)
{
    int n, i;
    long long a = 0, b = 1, next;
    printf("Enter n (0 to 90): ");
    scanf("%d", &n);
    if (n < 0 || n > 90)
    {
        printf("n is out of range.\n");
        return 0;
    }
    /* F(0) = 0, F(1) = 1, each next term is the sum of the previous two */
    for (i = 0; i < n; i++)
    {
        next = a + b;
        a = b;
        b = next;
    }
    printf("Fibonacci number F(%d) = %lld\n", n, a);
    return 0;
}
''', "10")
add(332, r'''
#include <stdio.h>

int main(void)
{
    int n, temp, i, fact, sum = 0;
    printf("Enter a number: ");
    scanf("%d", &n);
    /* Krishnamurthy: sum of digit factorials equals the number */
    for (temp = n; temp > 0; temp /= 10)
    {
        fact = 1;
        for (i = 2; i <= temp % 10; i++)
            fact *= i;
        sum += fact;
    }
    printf("Sum of digit factorials = %d\n", sum);
    if (n > 0 && sum == n)
        printf("%d is a Krishnamurthy number.\n", n);
    else
        printf("%d is not a Krishnamurthy number.\n", n);
    return 0;
}
''', "40585")
add(333, r'''
#include <stdio.h>

int main(void)
{
    int n, temp, digits = 0, position, digit, i, power;
    int sum = 0;
    printf("Enter a number: ");
    scanf("%d", &n);
    for (temp = n; temp > 0; temp /= 10)
        digits++;
    /* digit at position p (from the left) is raised to power p */
    position = digits;
    for (temp = n; temp > 0; temp /= 10)
    {
        digit = temp % 10;
        power = 1;
        for (i = 0; i < position; i++)
            power *= digit;
        sum += power;
        position--;
    }
    printf("Sum of digits powered by position = %d\n", sum);
    if (n > 0 && sum == n)
        printf("%d is a Disarium number.\n", n);
    else
        printf("%d is not a Disarium number.\n", n);
    return 0;
}
''', "175")
add(334, r'''
#include <stdio.h>

int main(void)
{
    long n, square, temp, divisor = 1, left, right;
    printf("Enter a number: ");
    scanf("%ld", &n);
    square = n * n;
    /* divisor = 10 ^ (digits of n); split the square into two parts */
    for (temp = n; temp > 0; temp /= 10)
        divisor *= 10;
    left = square / divisor;
    right = square % divisor;
    printf("Square = %ld, parts = %ld and %ld\n", square, left, right);
    if (n > 0 && left + right == n)
        printf("%ld is a Kaprekar number.\n", n);
    else
        printf("%ld is not a Kaprekar number.\n", n);
    return 0;
}
''', "45")
add(335, r'''
#include <stdio.h>

int main(void)
{
    int n, temp, sum, steps = 0;
    printf("Enter a number: ");
    scanf("%d", &n);
    temp = n;
    /* repeat sum of squares of digits; happy numbers reach 1, others reach 4 */
    while (temp != 1 && temp != 4 && steps < 100)
    {
        sum = 0;
        while (temp > 0)
        {
            sum += (temp % 10) * (temp % 10);
            temp /= 10;
        }
        temp = sum;
        printf("Step %d: %d\n", steps + 1, temp);
        steps++;
    }
    if (temp == 1)
        printf("%d is a happy number.\n", n);
    else
        printf("%d is not a happy number.\n", n);
    return 0;
}
''', "19")
add(336, r'''
#include <stdio.h>

int main(void)
{
    int n, sum;
    printf("Enter a number: ");
    scanf("%d", &n);
    sum = n;
    /* keep adding digits until a single digit remains */
    while (sum > 9)
    {
        int temp = sum;
        sum = 0;
        while (temp > 0)
        {
            sum += temp % 10;
            temp /= 10;
        }
        printf("Digit sum: %d\n", sum);
    }
    if (n > 0 && sum == 1)
        printf("%d is a magic number.\n", n);
    else
        printf("%d is not a magic number.\n", n);
    return 0;
}
''', "1234")
add(337, r'''
#include <stdio.h>

int main(void)
{
    int n;
    printf("Enter a number: ");
    scanf("%d", &n);
    /* buzz number: divisible by 7 or ends with 7 */
    if (n % 7 == 0 || n % 10 == 7)
        printf("%d is a buzz number.\n", n);
    else
        printf("%d is not a buzz number.\n", n);
    return 0;
}
''', "147")
add(338, r'''
#include <stdio.h>
#include <string.h>

int main(void)
{
    long n;
    int k, len, isCyclic = 1;
    char original[30], doubled[60], product[30];
    printf("Enter a number: ");
    scanf("%ld", &n);
    sprintf(original, "%ld", n);
    len = (int)strlen(original);
    /* original twice in a row contains every rotation of itself */
    sprintf(doubled, "%s%s", original, original);
    /* multiples 1..len must all be rotations of the original digits */
    for (k = 1; k <= len; k++)
    {
        sprintf(product, "%ld", n * k);
        printf("%ld x %d = %s\n", n, k, product);
        if ((int)strlen(product) != len || strstr(doubled, product) == NULL)
            isCyclic = 0;
    }
    if (n > 9 && isCyclic)
        printf("%ld is a cyclic number.\n", n);
    else
        printf("%ld is not a cyclic number.\n", n);
    return 0;
}
''', "142857")
add(339, r'''
#include <stdio.h>

int main(void)
{
    int n, sum;
    printf("Enter an integer: ");
    scanf("%d", &n);
    if (n < 0)
        n = -n;
    /* repeat the digit sum until a single digit is left */
    while (n > 9)
    {
        sum = 0;
        while (n > 0)
        {
            sum += n % 10;
            n /= 10;
        }
        n = sum;
    }
    printf("Digital root = %d\n", n);
    return 0;
}
''', "9875")
add(340, r'''
#include <stdio.h>

int main(void)
{
    int n, i, j, isPrime;
    long sum = 0;
    printf("Enter N: ");
    scanf("%d", &n);
    for (i = 2; i <= n; i++)
    {
        isPrime = 1;
        for (j = 2; j * j <= i; j++)
        {
            if (i % j == 0)
            {
                isPrime = 0;
                break;
            }
        }
        if (isPrime)
            sum += i;
    }
    printf("Sum of all primes up to %d = %ld\n", n, sum);
    return 0;
}
''', "50")
add(341, r'''
#include <stdio.h>

int main(void)
{
    int n, temp;
    long product = 1;
    printf("Enter an integer: ");
    scanf("%d", &n);
    temp = (n < 0) ? -n : n;
    if (temp == 0)
        product = 0;
    while (temp > 0)
    {
        product *= temp % 10;
        temp /= 10;
    }
    printf("Product of the digits of %d = %ld\n", n, product);
    return 0;
}
''', "2345")
add(342, r'''
#include <stdio.h>

int main(void)
{
    int n, k;
    int found = 0;
    printf("Enter a number: ");
    scanf("%d", &n);
    /* pronic number = k * (k + 1) for some integer k */
    for (k = 0; k * (k + 1) <= n; k++)
    {
        if (k * (k + 1) == n)
        {
            found = 1;
            printf("%d = %d x %d\n", n, k, k + 1);
        }
    }
    if (found)
        printf("%d is a pronic number.\n", n);
    else
        printf("%d is not a pronic number.\n", n);
    return 0;
}
''', "56")
add(343, r'''
#include <stdio.h>

int main(void)
{
    long n, fact = 1;
    int i = 1;
    printf("Enter a number: ");
    scanf("%ld", &n);
    /* multiply 1 * 2 * 3 ... until the factorial reaches n */
    while (fact < n)
    {
        i++;
        fact *= i;
    }
    if (n >= 1 && fact == n)
        printf("%ld is a factorial number (%d! = %ld).\n", n, i, n);
    else
        printf("%ld is not a factorial number.\n", n);
    return 0;
}
''', "120")
add(344, r'''
#include <stdio.h>

int main(void)
{
    int n, base, temp, digits[40], count = 0, i;
    int isPalindrome = 1;
    printf("Enter a number: ");
    scanf("%d", &n);
    printf("Enter the base (2 to 16): ");
    scanf("%d", &base);
    if (n < 1 || base < 2 || base > 16)
    {
        printf("Invalid number or base.\n");
        return 0;
    }
    /* store the digits of n in the chosen base */
    for (temp = n; temp > 0; temp /= base)
        digits[count++] = temp % base;
    printf("Digits in base %d (least significant first):", base);
    for (i = 0; i < count; i++)
        printf(" %d", digits[i]);
    printf("\n");
    for (i = 0; i < count / 2; i++)
    {
        if (digits[i] != digits[count - 1 - i])
            isPalindrome = 0;
    }
    if (isPalindrome)
        printf("%d is a palindrome in base %d.\n", n, base);
    else
        printf("%d is not a palindrome in base %d.\n", n, base);
    return 0;
}
''', "9\n2")
add(345, r'''
#include <stdio.h>

int main(void)
{
    int low, high, n, i, sum;
    printf("Enter the lower limit: ");
    scanf("%d", &low);
    printf("Enter the upper limit: ");
    scanf("%d", &high);
    printf("Abundant numbers between %d and %d:\n", low, high);
    for (n = low; n <= high; n++)
    {
        sum = 0;
        for (i = 1; i <= n / 2; i++)
        {
            if (n % i == 0)
                sum += i;
        }
        /* abundant: proper divisors add up to more than the number */
        if (n > 0 && sum > n)
            printf("%d ", n);
    }
    printf("\n");
    return 0;
}
''', "1\n60")
add(346, r'''
#include <stdio.h>

/* sum of the digits of n */
int digitSum(int n)
{
    int sum = 0;
    while (n > 0)
    {
        sum += n % 10;
        n /= 10;
    }
    return sum;
}

int main(void)
{
    int n, temp, factor = 2, factorSum = 0, factorCount = 0;
    printf("Enter a positive number: ");
    scanf("%d", &n);
    if (n <= 1)
    {
        printf("Error: please enter a number greater than 1.\n");
        return 0;
    }
    temp = n;
    while (temp > 1)
    {
        while (temp % factor == 0)
        {
            factorSum += digitSum(factor);
            factorCount++;
            temp /= factor;
        }
        factor++;
    }
    printf("Digit sum of %d = %d\n", n, digitSum(n));
    printf("Digit sum of its prime factors = %d\n", factorSum);
    /* a Smith number is composite and both sums are equal */
    if (factorCount > 1 && digitSum(n) == factorSum)
        printf("%d is a Smith number.\n", n);
    else
        printf("%d is not a Smith number.\n", n);
    return 0;
}
''', "85")
add(347, r'''
#include <stdio.h>

int main(void)
{
    int number, i, isPrime = 1;
    /* the number is entered by the user */
    printf("Please enter an integer to test: ");
    scanf("%d", &number);
    if (number < 2)
        isPrime = 0;
    for (i = 2; i <= number / 2; i++)
    {
        if (number % i == 0)
        {
            isPrime = 0;
            printf("%d is divisible by %d.\n", number, i);
            break;
        }
    }
    if (isPrime)
        printf("%d is prime.\n", number);
    else
        printf("%d is NOT prime.\n", number);
    return 0;
}
''', "91")
add(348, r'''
#include <stdio.h>

/* returns 1 when n is prime, 0 otherwise */
int isPrime(int n)
{
    int i;
    if (n < 2)
        return 0;
    for (i = 2; i * i <= n; i++)
    {
        if (n % i == 0)
            return 0;
    }
    return 1;
}

/* prints every prime from low to high */
void printPrimes(int low, int high)
{
    int n;
    for (n = low; n <= high; n++)
    {
        if (isPrime(n))
            printf("%d ", n);
    }
    printf("\n");
}

int main(void)
{
    int low, high;
    printf("Enter range start and end: ");
    scanf("%d %d", &low, &high);
    printf("Primes from %d to %d:\n", low, high);
    printPrimes(low, high);
    return 0;
}
''', "20 80")
add(349, r'''
#include <stdio.h>

int main(void)
{
    int n, i, sum = 0;
    printf("Enter a positive integer: ");
    if (scanf("%d", &n) != 1)
    {
        printf("Error: input is not a valid integer.\n");
        return 0;
    }
    if (n <= 0)
    {
        printf("Error: the number must be positive.\n");
        return 0;
    }
    for (i = 1; i <= n / 2; i++)
    {
        if (n % i == 0)
            sum += i;
    }
    if (n > 1 && sum == n)
        printf("%d is a perfect number.\n", n);
    else
        printf("%d is not a perfect number (divisor sum = %d).\n", n, sum);
    return 0;
}
''', "496")
add(350, r'''
#include <stdio.h>

/* prints the perfect numbers from low to high; returns how many were found */
int printPerfect(int low, int high)
{
    int n, i, sum, count = 0;
    for (n = low; n <= high; n++)
    {
        sum = 0;
        for (i = 1; i <= n / 2; i++)
        {
            if (n % i == 0)
                sum += i;
        }
        if (n > 1 && sum == n)
        {
            printf("  %d\n", n);
            count++;
        }
    }
    return count;
}

int main(void)
{
    /* three different test ranges */
    int lows[3] = {1, 100, 1000};
    int highs[3] = {10, 500, 1100};
    int t, found;
    for (t = 0; t < 3; t++)
    {
        printf("Test %d: range %d to %d\n", t + 1, lows[t], highs[t]);
        found = printPerfect(lows[t], highs[t]);
        if (found == 0)
            printf("  none found\n");
    }
    return 0;
}
''')
