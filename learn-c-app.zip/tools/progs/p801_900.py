# programs 801-900 : id -> (stdin, code)
P = {}
def add(i, code, stdin=""): P[i] = (stdin, code.strip("\n"))

add(801, r'''
#include <stdio.h>

int main(void)
{
    int value = 42;
    int *ptr = &value;          /* ptr holds the address of value */

    printf("Value of variable   : %d\n", value);
    printf("Value through *ptr  : %d\n", *ptr);
    printf("ptr == &value ?     : %s\n", (ptr == &value) ? "yes" : "no");
    printf("Size of pointer     : %zu bytes\n", sizeof(ptr));
    return 0;
}
''')
add(802, r'''
#include <stdio.h>

int main(void)
{
    int number = 10;
    int *ptr = NULL;            /* safe initialization */

    printf("ptr is %s\n", ptr == NULL ? "NULL" : "not NULL");
    ptr = &number;              /* point to number */
    printf("After ptr = &number, ptr == &number -> %s\n", ptr == &number ? "yes" : "no");
    printf("*ptr = %d\n", *ptr);
    *ptr = *ptr + 5;            /* change number through the pointer */
    printf("After *ptr = *ptr + 5, number = %d\n", number);
    return 0;
}
''')
add(803, r'''
#include <stdio.h>

void swap(int *a, int *b)
{
    int temp = *a;
    *a = *b;
    *b = temp;
}

int main(void)
{
    int x = 15, y = 40;

    printf("Before swap: x = %d, y = %d\n", x, y);
    swap(&x, &y);
    printf("After swap : x = %d, y = %d\n", x, y);
    return 0;
}
''')
add(804, r'''
#include <stdio.h>

int *larger(int *a, int *b)
{
    return (*a >= *b) ? a : b;
}

int main(void)
{
    int first = 37, second = 52;
    int *big = larger(&first, &second);

    printf("first = %d, second = %d\n", first, second);
    printf("Larger value = %d\n", *big);
    printf("It is the variable '%s'\n", big == &first ? "first" : "second");
    return 0;
}
''')
add(805, r'''
#include <stdio.h>

int main(void)
{
    int data[6] = {11, 22, 33, 44, 55, 66};
    int *ptr = data;
    int i;

    for (i = 0; i < 6; i++)
    {
        printf("*(ptr + %d) = %d\n", i, *(ptr + i));
    }
    printf("Traversing by incrementing the pointer: ");
    for (ptr = data; ptr < data + 6; ptr++)
    {
        printf("%d ", *ptr);
    }
    printf("\n");
    return 0;
}
''')
add(806, r'''
#include <stdio.h>

int main(void)
{
    int data[5] = {4, 8, 15, 16, 23};
    int *ptr = data;
    int sum = 0;
    int i;

    for (i = 0; i < 5; i++)
    {
        sum += *(ptr + i);
    }
    printf("Sum of the array elements = %d\n", sum);
    return 0;
}
''')
add(807, r'''
#include <stdio.h>

int main(void)
{
    char source[] = "Pointers are fun";
    char dest[50];
    char *src = source;
    char *dst = dest;

    while (*src != '\0')
    {
        *dst = *src;
        src++;
        dst++;
    }
    *dst = '\0';                /* terminate the copy */

    printf("Source : %s\n", source);
    printf("Copy   : %s\n", dest);
    return 0;
}
''')
add(808, r'''
#include <stdio.h>

int main(void)
{
    char text[] = "pointer";
    char *start = text;
    char *end = text;
    char temp;

    while (*end != '\0')
    {
        end++;
    }
    end--;                      /* last character */

    while (start < end)
    {
        temp = *start;
        *start = *end;
        *end = temp;
        start++;
        end--;
    }
    printf("Reversed string: %s\n", text);
    return 0;
}
''')
add(809, r'''
#include <stdio.h>

int main(void)
{
    char a[] = "apple";
    char b[] = "applet";
    char *p = a;
    char *q = b;

    while (*p != '\0' && *p == *q)
    {
        p++;
        q++;
    }
    if (*p == *q)
    {
        printf("\"%s\" and \"%s\" are equal\n", a, b);
    }
    else
    {
        printf("\"%s\" and \"%s\" differ at position %d\n", a, b, (int)(p - a) + 1);
        printf("\"%s\" is %s than \"%s\"\n", a, (*p < *q) ? "smaller" : "greater", b);
    }
    return 0;
}
''')
add(810, r'''
#include <stdio.h>

int main(void)
{
    char text[] = "Hello Pointers";
    char *p = text;
    int count = 0;

    while (*p != '\0')
    {
        count++;
        p++;
    }
    printf("String : %s\n", text);
    printf("Number of characters = %d\n", count);
    return 0;
}
''')
add(811, r'''
#include <stdio.h>

void addTen(int *num)
{
    *num = *num + 10;
}

int main(void)
{
    int value = 25;

    printf("Before call: value = %d\n", value);
    addTen(&value);
    printf("After call : value = %d\n", value);
    return 0;
}
''')
add(812, r'''
#include <stdio.h>

int main(void)
{
    int number = 99;
    int *p = &number;
    int **pp = &p;

    printf("number    = %d\n", number);
    printf("*p        = %d\n", *p);
    printf("**pp      = %d\n", **pp);
    printf("*pp == p  -> %s\n", *pp == p ? "yes" : "no");
    **pp = 123;                 /* modify through pointer to pointer */
    printf("After **pp = 123, number = %d\n", number);
    return 0;
}
''')
add(813, r'''
#include <stdio.h>

int main(void)
{
    const char *days[] = {"Monday", "Tuesday", "Wednesday", "Thursday", "Friday"};
    int i;

    for (i = 0; i < 5; i++)
    {
        printf("days[%d] = %-10s first letter = %c\n", i, days[i], *days[i]);
    }
    return 0;
}
''')
add(814, r'''
#include <stdio.h>

int main(void)
{
    int marks[5] = {70, 80, 90, 60, 50};
    int (*ptr)[5] = &marks;     /* pointer to the whole array */
    int i;

    printf("Size of whole array via *ptr = %zu bytes\n", sizeof(*ptr));
    for (i = 0; i < 5; i++)
    {
        printf("(*ptr)[%d] = %d\n", i, (*ptr)[i]);
    }
    return 0;
}
''')
add(815, r'''
#include <stdio.h>

int add(int a, int b) { return a + b; }
int subtract(int a, int b) { return a - b; }
int multiply(int a, int b) { return a * b; }

int main(void)
{
    int (*operation)(int, int);
    int (*table[3])(int, int) = {add, subtract, multiply};
    const char *names[3] = {"add", "subtract", "multiply"};
    int i;

    operation = add;
    printf("Single function pointer: 12 + 5 = %d\n", operation(12, 5));
    for (i = 0; i < 3; i++)
    {
        printf("%-8s(12, 5) = %d\n", names[i], table[i](12, 5));
    }
    return 0;
}
''')
add(816, r'''
#include <stdio.h>

int add(int a, int b) { return a + b; }
int subtract(int a, int b) { return a - b; }
int multiply(int a, int b) { return a * b; }

int main(void)
{
    int (*ops[3])(int, int) = {add, subtract, multiply};
    int choice, x, y;

    printf("1. Add\n2. Subtract\n3. Multiply\n");
    printf("Enter your choice: ");
    scanf("%d", &choice);
    printf("Enter two integers: ");
    scanf("%d %d", &x, &y);
    if (choice < 1 || choice > 3)
    {
        printf("Invalid choice\n");
        return 0;
    }
    printf("Result = %d\n", ops[choice - 1](x, y));
    return 0;
}
''', "3\n12 4\n")
add(817, r'''
#include <stdio.h>

int *getCounter(void)
{
    static int counter = 100;   /* lives for the whole program */
    counter++;
    return &counter;
}

int main(void)
{
    int *p1 = getCounter();
    int *p2 = getCounter();

    printf("After two calls, *p1 = %d, *p2 = %d\n", *p1, *p2);
    printf("Both pointers refer to the same object: %s\n", p1 == p2 ? "yes" : "no");
    return 0;
}
''')
add(818, r'''
#include <stdio.h>

void show(const int *p)
{
    if (p == NULL)
    {
        printf("Pointer is NULL, cannot dereference\n");
        return;
    }
    printf("Value = %d\n", *p);
}

int main(void)
{
    int number = 77;
    int *valid = &number;
    int *empty = NULL;

    show(valid);
    show(empty);
    return 0;
}
''')
add(819, r'''
#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int *p = (int *)malloc(sizeof(int));

    if (p == NULL)
    {
        printf("Memory allocation failed\n");
        return 1;
    }
    *p = 2024;
    printf("Stored value = %d\n", *p);
    free(p);
    p = NULL;                   /* avoid dangling pointer */
    printf("Memory released\n");
    return 0;
}
''')
add(820, r'''
#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int n = 6, i, sum = 0;
    int *arr = (int *)malloc(n * sizeof(int));

    if (arr == NULL)
    {
        printf("Memory allocation failed\n");
        return 1;
    }
    for (i = 0; i < n; i++)
    {
        arr[i] = (i + 1) * 5;
        sum += arr[i];
    }
    printf("Array has %d elements, sum = %d\n", n, sum);
    free(arr);
    return 0;
}
''')
add(821, r'''
#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int i, *arr = (int *)malloc(3 * sizeof(int));
    int *temp;

    if (arr == NULL)
    {
        printf("Allocation failed\n");
        return 1;
    }
    for (i = 0; i < 3; i++)
    {
        arr[i] = (i + 1) * 10;
    }
    temp = (int *)realloc(arr, 6 * sizeof(int));
    if (temp == NULL)
    {
        printf("Reallocation failed\n");
        free(arr);
        return 1;
    }
    arr = temp;
    for (i = 3; i < 6; i++)
    {
        arr[i] = (i + 1) * 10;
    }
    printf("Resized array (3 -> 6):");
    for (i = 0; i < 6; i++)
    {
        printf(" %d", arr[i]);
    }
    printf("\n");
    free(arr);
    return 0;
}
''')
add(822, r'''
#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int n = 5, i;
    int *arr = (int *)calloc(n, sizeof(int));

    if (arr == NULL)
    {
        printf("Allocation failed\n");
        return 1;
    }
    printf("calloc() initial contents:");
    for (i = 0; i < n; i++)
    {
        printf(" %d", arr[i]);
    }
    printf("\n");
    free(arr);
    return 0;
}
''')
add(823, r'''
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(void)
{
    size_t capacity = 10;
    const char *text = "Hello, dynamic world";
    char *buffer = (char *)malloc(capacity);

    if (buffer == NULL)
    {
        printf("Allocation failed\n");
        return 1;
    }
    /* bounds checking: copy at most capacity - 1 characters */
    if (strlen(text) >= capacity)
    {
        printf("Text has %zu characters, buffer holds only %zu; truncating\n", strlen(text), capacity - 1);
    }
    strncpy(buffer, text, capacity - 1);
    buffer[capacity - 1] = '\0';
    printf("Buffer contains: \"%s\"\n", buffer);
    free(buffer);
    return 0;
}
''')
add(824, r'''
#include <stdio.h>

int main(void)
{
    int a = 10, b = 20;
    const int *ptrToConst = &a;     /* data is read-only, pointer can move */
    int *const constPtr = &a;       /* pointer is fixed, data can change */

    printf("ptrToConst: *ptrToConst = %d\n", *ptrToConst);
    ptrToConst = &b;                /* allowed */
    printf("  re-pointed to b: *ptrToConst = %d\n", *ptrToConst);
    /* *ptrToConst = 5;  would be a compile error */

    *constPtr = 15;                 /* allowed */
    printf("constPtr: after *constPtr = 15, a = %d\n", a);
    /* constPtr = &b;  would be a compile error */
    return 0;
}
''')
add(825, r'''
#include <stdio.h>

int main(void)
{
    int arr[5] = {10, 20, 30, 40, 50};
    int *p = arr;
    int *q = arr + 4;

    printf("*p = %d\n", *p);
    p = p + 2;
    printf("After p = p + 2, *p = %d\n", *p);
    p--;
    printf("After p--, *p = %d\n", *p);
    printf("Distance between q and p = %d elements\n", (int)(q - p));
    printf("*(arr + 3) = %d, arr[3] = %d\n", *(arr + 3), arr[3]);
    return 0;
}
''')
