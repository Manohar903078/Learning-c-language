# programs 526-575 : id -> (stdin, code)
P = {}
def add(i, code, stdin=""): P[i] = (stdin, code.strip("\n"))

add(526, r'''
#include <stdio.h>

struct Date { int day, month, year; };

/* returns >0 if a is later than b: compare year, then month, then day */
int compare(struct Date a, struct Date b)
{
    if (a.year != b.year)   return a.year - b.year;
    if (a.month != b.month) return a.month - b.month;
    return a.day - b.day;
}

int main(void)
{
    struct Date d[20], key;
    int n, i, j;

    printf("How many dates? ");
    if (scanf("%d", &n) != 1 || n < 1 || n > 20) { printf("Invalid count\n"); return 1; }
    printf("Enter dates as dd mm yyyy:\n");
    for (i = 0; i < n; i++)
        if (scanf("%d %d %d", &d[i].day, &d[i].month, &d[i].year) != 3) { printf("Invalid date\n"); return 1; }

    for (i = 1; i < n; i++) {            /* insertion sort */
        key = d[i];
        for (j = i - 1; j >= 0 && compare(d[j], key) > 0; j--)
            d[j + 1] = d[j];
        d[j + 1] = key;
    }
    printf("Sorted dates:\n");
    for (i = 0; i < n; i++)
        printf("%02d-%02d-%04d\n", d[i].day, d[i].month, d[i].year);
    return 0;
}
''', "5\n15 8 2021\n3 12 2019\n20 8 2021\n1 1 2020\n15 3 2021\n")

add(527, r'''
#include <stdio.h>
#include <string.h>

int main(void)
{
    char w[10][20], temp[20];
    int n, i, j;

    printf("How many words? ");
    if (scanf("%d", &n) != 1 || n < 1 || n > 10) { printf("Invalid count\n"); return 1; }
    printf("Enter %d words: ", n);
    for (i = 0; i < n; i++)
        scanf("%19s", w[i]);

    for (i = 0; i < n - 1; i++)           /* bubble sort by length */
        for (j = 0; j < n - 1 - i; j++)
            if (strlen(w[j]) > strlen(w[j + 1])) {
                strcpy(temp, w[j]);
                strcpy(w[j], w[j + 1]);
                strcpy(w[j + 1], temp);
            }

    printf("Words sorted by length:\n");
    for (i = 0; i < n; i++)
        printf("%-12s (length %zu)\n", w[i], strlen(w[i]));
    return 0;
}
''', "6 elephant cat programming sun apple to\n")

add(528, r'''
#include <stdio.h>

int main(void)
{
    double a[20], temp;
    int n, i, j;

    printf("How many numbers? ");
    if (scanf("%d", &n) != 1 || n < 1 || n > 20) { printf("Invalid count\n"); return 1; }
    printf("Enter %d floating-point numbers: ", n);
    for (i = 0; i < n; i++)
        scanf("%lf", &a[i]);

    for (i = 0; i < n - 1; i++)
        for (j = 0; j < n - 1 - i; j++)
            if (a[j] > a[j + 1]) {
                temp = a[j];
                a[j] = a[j + 1];
                a[j + 1] = temp;
            }

    printf("Ascending order:");
    for (i = 0; i < n; i++)
        printf(" %.2f", a[i]);
    printf("\n");
    return 0;
}
''', "6 3.14 -2.5 9.75 0.5 7.25 -10.125\n")

add(529, r'''
#include <stdio.h>

int main(void)
{
    int a[20], n, i, j, min, temp;

    printf("Enter number of elements: ");
    if (scanf("%d", &n) != 1 || n < 1 || n > 20) { printf("Invalid count\n"); return 1; }
    printf("Enter %d integers: ", n);
    for (i = 0; i < n; i++)
        scanf("%d", &a[i]);

    /* selection sort written by hand: no qsort() or other library sort */
    for (i = 0; i < n - 1; i++) {
        min = i;
        for (j = i + 1; j < n; j++)
            if (a[j] < a[min])
                min = j;
        temp = a[i]; a[i] = a[min]; a[min] = temp;
    }

    printf("Sorted array:");
    for (i = 0; i < n; i++)
        printf(" %d", a[i]);
    printf("\n");
    return 0;
}
''', "7 64 25 12 22 11 90 -5\n")

add(530, r'''
#include <stdio.h>

#define MAX 20

void bubble(int a[], int n)
{
    int i, j, t;
    for (i = 0; i < n - 1; i++)
        for (j = 0; j < n - 1 - i; j++)
            if (a[j] > a[j + 1]) { t = a[j]; a[j] = a[j + 1]; a[j + 1] = t; }
}

void selection(int a[], int n)
{
    int i, j, m, t;
    for (i = 0; i < n - 1; i++) {
        m = i;
        for (j = i + 1; j < n; j++)
            if (a[j] < a[m]) m = j;
        t = a[i]; a[i] = a[m]; a[m] = t;
    }
}

void insertion(int a[], int n)
{
    int i, j, key;
    for (i = 1; i < n; i++) {
        key = a[i];
        for (j = i - 1; j >= 0 && a[j] > key; j--) a[j + 1] = a[j];
        a[j + 1] = key;
    }
}

int main(void)
{
    int orig[MAX], a[MAX], n, i, choice;

    printf("Enter n and the elements: ");
    if (scanf("%d", &n) != 1 || n < 1 || n > MAX) { printf("Invalid count\n"); return 1; }
    for (i = 0; i < n; i++) scanf("%d", &orig[i]);

    while (1) {
        printf("\n1. Bubble sort\n2. Selection sort\n3. Insertion sort\n0. Exit\nChoice: ");
        if (scanf("%d", &choice) != 1 || choice == 0) break;
        for (i = 0; i < n; i++) a[i] = orig[i];
        if (choice == 1) bubble(a, n);
        else if (choice == 2) selection(a, n);
        else if (choice == 3) insertion(a, n);
        else { printf("Invalid choice\n"); continue; }
        printf("Sorted:");
        for (i = 0; i < n; i++) printf(" %d", a[i]);
        printf("\n");
    }
    printf("Goodbye\n");
    return 0;
}
''', "6 45 12 78 3 56 21\n1\n2\n3\n7\n0\n")

add(531, r'''
#include <stdio.h>

struct Pair { int first, second; };

int main(void)
{
    struct Pair p[20], key;
    int n, i, j;

    printf("How many pairs? ");
    if (scanf("%d", &n) != 1 || n < 1 || n > 20) { printf("Invalid count\n"); return 1; }
    printf("Enter pairs (first second):\n");
    for (i = 0; i < n; i++)
        scanf("%d %d", &p[i].first, &p[i].second);

    for (i = 1; i < n; i++) {
        key = p[i];
        j = i - 1;
        while (j >= 0 && (p[j].first > key.first ||
               (p[j].first == key.first && p[j].second > key.second))) {
            p[j + 1] = p[j];
            j--;
        }
        p[j + 1] = key;
    }

    printf("Sorted pairs:\n");
    for (i = 0; i < n; i++)
        printf("(%d, %d)\n", p[i].first, p[i].second);
    return 0;
}
''', "6\n3 9\n1 5\n3 2\n2 8\n1 1\n2 4\n")

add(532, r'''
#include <stdio.h>
#include <string.h>

/* shorter first; equal length -> alphabetical */
int goes_after(const char *a, const char *b)
{
    size_t la = strlen(a), lb = strlen(b);
    if (la != lb) return la > lb;
    return strcmp(a, b) > 0;
}

int main(void)
{
    char s[12][20], temp[20];
    int n, i, j;

    printf("How many strings? ");
    if (scanf("%d", &n) != 1 || n < 1 || n > 12) { printf("Invalid count\n"); return 1; }
    for (i = 0; i < n; i++) scanf("%19s", s[i]);

    for (i = 0; i < n - 1; i++)
        for (j = 0; j < n - 1 - i; j++)
            if (goes_after(s[j], s[j + 1])) {
                strcpy(temp, s[j]); strcpy(s[j], s[j + 1]); strcpy(s[j + 1], temp);
            }

    printf("Sorted by length, then alphabetically:\n");
    for (i = 0; i < n; i++) printf("%s\n", s[i]);
    return 0;
}
''', "8 pear fig apple kiwi date plum banana cherry\n")

add(533, r'''
#include <stdio.h>

struct Student { char name[20]; int marks; };

int main(void)
{
    struct Student s[15], key;
    int n, i, j;

    printf("Number of students: ");
    if (scanf("%d", &n) != 1 || n < 1 || n > 15) { printf("Invalid count\n"); return 1; }
    for (i = 0; i < n; i++)
        scanf("%19s %d", s[i].name, &s[i].marks);

    /* insertion sort is stable: equal marks keep their original order
       because we shift only while the left element is strictly smaller */
    for (i = 1; i < n; i++) {
        key = s[i];
        for (j = i - 1; j >= 0 && s[j].marks < key.marks; j--)
            s[j + 1] = s[j];
        s[j + 1] = key;
    }

    printf("\nRank list (highest marks first, ties keep input order)\n");
    printf("%-4s %-10s %s\n", "No.", "Name", "Marks");
    for (i = 0; i < n; i++)
        printf("%-4d %-10s %d\n", i + 1, s[i].name, s[i].marks);
    return 0;
}
''', "6\nAsha 85\nRavi 92\nMeena 85\nJohn 70\nKiran 92\nSara 85\n")

add(534, r'''
#include <stdio.h>

int main(void)
{
    int a[20], n, i, j, t;
    int comparisons = 0, swaps = 0;

    printf("Enter n and the elements: ");
    if (scanf("%d", &n) != 1 || n < 1 || n > 20) { printf("Invalid count\n"); return 1; }
    for (i = 0; i < n; i++) scanf("%d", &a[i]);

    for (i = 0; i < n - 1; i++)
        for (j = 0; j < n - 1 - i; j++) {
            comparisons++;                      /* count every comparison */
            if (a[j] > a[j + 1]) {
                t = a[j]; a[j] = a[j + 1]; a[j + 1] = t;
                swaps++;
            }
        }

    printf("Sorted:");
    for (i = 0; i < n; i++) printf(" %d", a[i]);
    printf("\nComparisons made: %d\nSwaps made      : %d\n", comparisons, swaps);
    return 0;
}
''', "8 29 10 14 37 13 5 42 1\n")

add(535, r'''
#include <stdio.h>

int main(void)
{
    int a[20], n, i, j, key, from, to;

    printf("Enter n and the elements: ");
    if (scanf("%d", &n) != 1 || n < 1 || n > 20) { printf("Invalid count\n"); return 1; }
    for (i = 0; i < n; i++) scanf("%d", &a[i]);

    printf("Enter start and end index to sort (0-based): ");
    if (scanf("%d %d", &from, &to) != 2 || from < 0 || to >= n || from > to) {
        printf("Invalid range\n");
        return 1;
    }

    for (i = from + 1; i <= to; i++) {        /* insertion sort only on a[from..to] */
        key = a[i];
        for (j = i - 1; j >= from && a[j] > key; j--)
            a[j + 1] = a[j];
        a[j + 1] = key;
    }

    printf("Array after sorting indices %d to %d:", from, to);
    for (i = 0; i < n; i++) printf(" %d", a[i]);
    printf("\n");
    return 0;
}
''', "9 50 40 90 70 30 80 20 60 10\n2 6\n")

add(536, r'''
#include <stdio.h>

int main(void)
{
    int a[30], n, i, j, temp;

    printf("Enter the number of elements: ");
    if (scanf("%d", &n) != 1 || n < 1 || n > 30) { printf("Invalid size\n"); return 1; }
    printf("Enter %d elements: ", n);
    for (i = 0; i < n; i++)
        scanf("%d", &a[i]);

    for (i = 0; i < n - 1; i++)
        for (j = 0; j < n - 1 - i; j++)
            if (a[j] > a[j + 1]) {          /* swap if out of order */
                temp = a[j];
                a[j] = a[j + 1];
                a[j + 1] = temp;
            }

    printf("Ascending order (bubble sort):");
    for (i = 0; i < n; i++) printf(" %d", a[i]);
    printf("\n");
    return 0;
}
''', "7 34 8 64 51 32 21 8\n")

add(537, r'''
#include <stdio.h>

/* bubble sort into descending order */
void bubble_desc(int a[], int n)
{
    int i, j, temp, swapped;
    for (i = 0; i < n - 1; i++) {
        swapped = 0;
        for (j = 0; j < n - 1 - i; j++)
            if (a[j] < a[j + 1]) {
                temp = a[j]; a[j] = a[j + 1]; a[j + 1] = temp;
                swapped = 1;
            }
        if (!swapped) break;               /* already sorted */
    }
}

int main(void)
{
    int a[30], n, i;

    printf("Enter number of elements: ");
    if (scanf("%d", &n) != 1 || n < 1 || n > 30) { printf("Invalid size\n"); return 1; }
    for (i = 0; i < n; i++) scanf("%d", &a[i]);

    bubble_desc(a, n);
    printf("Descending order:");
    for (i = 0; i < n; i++) printf(" %d", a[i]);
    printf("\n");
    return 0;
}
''', "6 12 45 7 99 23 61\n")

add(538, r'''
#include <stdio.h>

int main(void)
{
    int a[20], n, i, j, min, t;

    printf("Enter number of elements (1-20): ");
    if (scanf("%d", &n) != 1) { printf("Error: size must be a number.\n"); return 1; }
    if (n < 1 || n > 20)     { printf("Error: size must be between 1 and 20.\n"); return 1; }

    for (i = 0; i < n; i++) {
        printf("Element %d: ", i + 1);
        if (scanf("%d", &a[i]) != 1) {
            printf("Error: element %d is not a valid integer.\n", i + 1);
            return 1;
        }
    }

    for (i = 0; i < n - 1; i++) {           /* selection sort, ascending */
        min = i;
        for (j = i + 1; j < n; j++)
            if (a[j] < a[min]) min = j;
        if (min != i) { t = a[i]; a[i] = a[min]; a[min] = t; }
    }

    printf("Sorted (ascending):");
    for (i = 0; i < n; i++) printf(" %d", a[i]);
    printf("\n");
    return 0;
}
''', "5\n40\n-3\n17\n0\n25\n")

add(539, r'''
#include <stdio.h>

void selection_desc(int a[], int n)
{
    int i, j, max, t;
    for (i = 0; i < n - 1; i++) {
        max = i;
        for (j = i + 1; j < n; j++)
            if (a[j] > a[max]) max = j;     /* pick the largest remaining */
        t = a[i]; a[i] = a[max]; a[max] = t;
    }
}

void show(const char *label, int a[], int n)
{
    int i;
    printf("%s", label);
    for (i = 0; i < n; i++) printf(" %d", a[i]);
    printf("\n");
}

int main(void)
{
    int t1[] = {5, 1, 4, 2, 8};
    int t2[] = {10, 10, 3, 7, 3, 9};
    int t3[] = {-4, 0, -9, 6};

    printf("Test 1\n"); show("Before:", t1, 5); selection_desc(t1, 5); show("After :", t1, 5);
    printf("Test 2 (duplicates)\n"); show("Before:", t2, 6); selection_desc(t2, 6); show("After :", t2, 6);
    printf("Test 3 (negatives)\n"); show("Before:", t3, 4); selection_desc(t3, 4); show("After :", t3, 4);
    return 0;
}
''')

add(540, r'''
#include <stdio.h>

int main(void)
{
    int a[30], n, i, j, key;

    printf("Enter n and the elements: ");
    if (scanf("%d", &n) != 1 || n < 1 || n > 30) { printf("Invalid size\n"); return 1; }
    for (i = 0; i < n; i++) scanf("%d", &a[i]);

    /* a[0..i-1] is always sorted; insert a[i] into its correct place */
    for (i = 1; i < n; i++) {
        key = a[i];                       /* element to insert */
        j = i - 1;
        while (j >= 0 && a[j] > key) {    /* shift larger elements right */
            a[j + 1] = a[j];
            j--;
        }
        a[j + 1] = key;                   /* drop key into the gap */
    }

    printf("Sorted ascending:");
    for (i = 0; i < n; i++) printf(" %d", a[i]);
    printf("\n");
    return 0;
}
''', "7 31 41 59 26 41 58 3\n")

add(541, r'''
#include <stdio.h>

void insertion_desc(int a[], int n)
{
    int i, j, key;
    for (i = 1; i < n; i++) {             /* n = 0 or 1 skips the loop safely */
        key = a[i];
        for (j = i - 1; j >= 0 && a[j] < key; j--)
            a[j + 1] = a[j];
        a[j + 1] = key;
    }
}

void run(const char *title, int a[], int n)
{
    int i;
    insertion_desc(a, n);
    printf("%-22s:", title);
    if (n == 0) printf(" (empty)");
    for (i = 0; i < n; i++) printf(" %d", a[i]);
    printf("\n");
}

int main(void)
{
    int empty[1] = {0};
    int single[] = {42};
    int same[] = {7, 7, 7, 7};
    int sorted[] = {1, 2, 3, 4, 5};
    int reverse[] = {9, 8, 7, 6};
    int mixed[] = {3, -1, 0, 3, -8};

    run("Empty array", empty, 0);
    run("Single element", single, 1);
    run("All equal", same, 4);
    run("Already ascending", sorted, 5);
    run("Already descending", reverse, 4);
    run("Negatives/duplicates", mixed, 5);
    return 0;
}
''')

add(542, r'''
#include <stdio.h>

#define MAX 20

/* merge a[lo..mid] and a[mid+1..hi]; asc = 1 for ascending, 0 for descending */
void merge(int a[], int lo, int mid, int hi, int asc)
{
    int tmp[MAX], i = lo, j = mid + 1, k = lo;
    while (i <= mid && j <= hi) {
        if (asc ? a[i] <= a[j] : a[i] >= a[j]) tmp[k++] = a[i++];
        else tmp[k++] = a[j++];
    }
    while (i <= mid) tmp[k++] = a[i++];
    while (j <= hi) tmp[k++] = a[j++];
    for (k = lo; k <= hi; k++) a[k] = tmp[k];
}

void merge_sort(int a[], int lo, int hi, int asc)
{
    int mid;
    if (lo >= hi) return;
    mid = (lo + hi) / 2;
    merge_sort(a, lo, mid, asc);
    merge_sort(a, mid + 1, hi, asc);
    merge(a, lo, mid, hi, asc);
}

int main(void)
{
    int orig[MAX], a[MAX], n, i, choice;

    printf("Enter n and the elements: ");
    if (scanf("%d", &n) != 1 || n < 1 || n > MAX) { printf("Invalid size\n"); return 1; }
    for (i = 0; i < n; i++) scanf("%d", &orig[i]);

    do {
        printf("\n1. Merge sort ascending\n2. Merge sort descending\n3. Exit\nChoice: ");
        if (scanf("%d", &choice) != 1) break;
        if (choice == 1 || choice == 2) {
            for (i = 0; i < n; i++) a[i] = orig[i];
            merge_sort(a, 0, n - 1, choice == 1);
            printf("Result:");
            for (i = 0; i < n; i++) printf(" %d", a[i]);
            printf("\n");
        } else if (choice != 3) {
            printf("Invalid choice\n");
        }
    } while (choice != 3);
    return 0;
}
''', "8 38 27 43 3 9 82 10 27\n1\n2\n5\n3\n")

add(543, r'''
#include <stdio.h>

void print_array(int a[], int n)
{
    int i;
    for (i = 0; i < n; i++) printf("%d ", a[i]);
    printf("\n");
}

int partition(int a[], int lo, int hi, int n)
{
    int pivot = a[hi], i = lo - 1, j, t;
    for (j = lo; j < hi; j++)
        if (a[j] < pivot) {
            i++;
            t = a[i]; a[i] = a[j]; a[j] = t;
        }
    t = a[i + 1]; a[i + 1] = a[hi]; a[hi] = t;
    printf("Pivot %2d placed at index %d : ", pivot, i + 1);
    print_array(a, n);                      /* intermediate step */
    return i + 1;
}

void quick_sort(int a[], int lo, int hi, int n)
{
    int p;
    if (lo < hi) {
        p = partition(a, lo, hi, n);
        quick_sort(a, lo, p - 1, n);
        quick_sort(a, p + 1, hi, n);
    }
}

int main(void)
{
    int a[20], n, i;

    printf("Enter n and the elements: ");
    if (scanf("%d", &n) != 1 || n < 1 || n > 20) { printf("Invalid size\n"); return 1; }
    for (i = 0; i < n; i++) scanf("%d", &a[i]);

    printf("Initial array: "); print_array(a, n);
    quick_sort(a, 0, n - 1, n);
    printf("Sorted array : "); print_array(a, n);
    return 0;
}
''', "8 10 80 30 90 40 50 70 20\n")

add(544, r'''
#include <stdio.h>

/* push a[i] down so the subtree rooted at i is a max-heap */
void heapify(int a[], int n, int i)
{
    int largest, l, r, t;
    while (1) {
        largest = i; l = 2 * i + 1; r = 2 * i + 2;
        if (l < n && a[l] > a[largest]) largest = l;
        if (r < n && a[r] > a[largest]) largest = r;
        if (largest == i) break;
        t = a[i]; a[i] = a[largest]; a[largest] = t;
        i = largest;
    }
}

int main(void)
{
    int a[20], n, i, t;

    printf("Enter n and the elements: ");
    if (scanf("%d", &n) != 1 || n < 1 || n > 20) { printf("Invalid size\n"); return 1; }
    for (i = 0; i < n; i++) scanf("%d", &a[i]);

    for (i = n / 2 - 1; i >= 0; i--)          /* build max-heap */
        heapify(a, n, i);
    for (i = n - 1; i > 0; i--) {             /* move max to the end, shrink heap */
        t = a[0]; a[0] = a[i]; a[i] = t;
        heapify(a, i, 0);
    }

    printf("Heap sorted:");
    for (i = 0; i < n; i++) printf(" %d", a[i]);
    printf("\n");
    return 0;
}
''', "9 12 11 13 5 6 7 20 1 15\n")

add(545, r'''
#include <stdio.h>
#include <string.h>

#define RANGE 100

void counting_sort(int *arr, int n)
{
    int count[RANGE], *p, i, k = 0;
    memset(count, 0, sizeof count);
    for (p = arr; p < arr + n; p++)          /* count each value */
        (*(count + *p))++;
    for (i = 0; i < RANGE; i++)              /* write values back in order */
        while (*(count + i) > 0) {
            *(arr + k++) = i;
            (*(count + i))--;
        }
}

int main(void)
{
    int a[30], n, i;

    printf("Enter n and the elements (0 to %d): ", RANGE - 1);
    if (scanf("%d", &n) != 1 || n < 1 || n > 30) { printf("Invalid size\n"); return 1; }
    for (i = 0; i < n; i++)
        if (scanf("%d", &a[i]) != 1 || a[i] < 0 || a[i] >= RANGE) {
            printf("Value must be in range 0-%d\n", RANGE - 1);
            return 1;
        }

    counting_sort(a, n);
    printf("Sorted:");
    for (i = 0; i < n; i++) printf(" %d", *(a + i));
    printf("\n");
    return 0;
}
''', "10 4 2 2 8 3 3 1 0 99 8\n")

add(546, r'''
#include <stdio.h>

/* stable counting sort on the digit given by exp (1, 10, 100, ...) */
void digit_sort(int a[], int n, int exp)
{
    int out[30], count[10] = {0}, i;
    for (i = 0; i < n; i++) count[(a[i] / exp) % 10]++;
    for (i = 1; i < 10; i++) count[i] += count[i - 1];
    for (i = n - 1; i >= 0; i--)
        out[--count[(a[i] / exp) % 10]] = a[i];
    for (i = 0; i < n; i++) a[i] = out[i];
}

int main(void)
{
    int a[30], n, i, max, exp;

    printf("Enter n and the non-negative elements: ");
    if (scanf("%d", &n) != 1 || n < 1 || n > 30) { printf("Invalid size\n"); return 1; }
    for (i = 0; i < n; i++)
        if (scanf("%d", &a[i]) != 1 || a[i] < 0) { printf("Invalid element\n"); return 1; }

    max = a[0];
    for (i = 1; i < n; i++) if (a[i] > max) max = a[i];

    for (exp = 1; max / exp > 0; exp *= 10) {
        digit_sort(a, n, exp);
        printf("After sorting by digit place %-4d:", exp);
        for (i = 0; i < n; i++) printf(" %d", a[i]);
        printf("\n");
    }
    return 0;
}
''', "8 170 45 75 90 802 24 2 66\n")

add(547, r'''
#include <stdio.h>

struct List {
    int data[30];
    int size;
};

void shell_sort(struct List *l)
{
    int gap, i, j, temp;
    for (gap = l->size / 2; gap > 0; gap /= 2)
        for (i = gap; i < l->size; i++) {
            temp = l->data[i];
            for (j = i; j >= gap && l->data[j - gap] > temp; j -= gap)
                l->data[j] = l->data[j - gap];
            l->data[j] = temp;
        }
}

int main(void)
{
    struct List list;
    int i;

    printf("Enter n and the elements: ");
    if (scanf("%d", &list.size) != 1 || list.size < 1 || list.size > 30) {
        printf("Invalid size\n");
        return 1;
    }
    for (i = 0; i < list.size; i++) scanf("%d", &list.data[i]);

    shell_sort(&list);
    printf("Shell sorted:");
    for (i = 0; i < list.size; i++) printf(" %d", list.data[i]);
    printf("\n");
    return 0;
}
''', "10 23 12 1 8 34 54 2 3 77 19\n")

add(548, r'''
#include <stdio.h>

void cocktail(int a[], int n)
{
    int start = 0, end = n - 1, swapped = 1, i, t;
    while (swapped) {
        swapped = 0;
        for (i = start; i < end; i++)            /* forward pass */
            if (a[i] > a[i + 1]) { t = a[i]; a[i] = a[i + 1]; a[i + 1] = t; swapped = 1; }
        end--;
        for (i = end; i > start; i--)            /* backward pass */
            if (a[i] < a[i - 1]) { t = a[i]; a[i] = a[i - 1]; a[i - 1] = t; swapped = 1; }
        start++;
    }
}

int main(void)
{
    int sets, s, n, i, a[20];

    printf("How many sets of values? ");
    if (scanf("%d", &sets) != 1 || sets < 1) { printf("Invalid\n"); return 1; }
    for (s = 1; s <= sets; s++) {
        if (scanf("%d", &n) != 1 || n < 1 || n > 20) { printf("Invalid size\n"); return 1; }
        for (i = 0; i < n; i++) scanf("%d", &a[i]);
        cocktail(a, n);
        printf("Set %d sorted:", s);
        for (i = 0; i < n; i++) printf(" %d", a[i]);
        printf("\n");
    }
    return 0;
}
''', "3\n6 5 1 4 2 8 0\n4 9 7 3 1\n5 2 2 1 1 3\n")

add(549, r'''
#include <stdio.h>

int main(void)
{
    int a[20], n, i, gap, swapped, t, pass = 0;

    printf("Enter n and the elements: ");
    if (scanf("%d", &n) != 1 || n < 1 || n > 20) { printf("Invalid size\n"); return 1; }
    for (i = 0; i < n; i++) scanf("%d", &a[i]);

    printf("\n%-6s %-5s %s\n", "Pass", "Gap", "Array");
    gap = n;
    swapped = 1;
    while (gap > 1 || swapped) {
        gap = gap * 10 / 13;                 /* shrink factor about 1.3 */
        if (gap < 1) gap = 1;
        swapped = 0;
        for (i = 0; i + gap < n; i++)
            if (a[i] > a[i + gap]) {
                t = a[i]; a[i] = a[i + gap]; a[i + gap] = t;
                swapped = 1;
            }
        pass++;
        printf("%-6d %-5d", pass, gap);
        for (i = 0; i < n; i++) printf(" %d", a[i]);
        printf("\n");
    }
    printf("\nFinal sorted array:");
    for (i = 0; i < n; i++) printf(" %d", a[i]);
    printf("\n");
    return 0;
}
''', "8 8 4 1 56 3 -44 23 -6\n")

add(550, r'''
#include <stdio.h>
#include <string.h>

int main(void)
{
    char s[10][20], temp[20];
    int n, i, j;

    printf("How many strings (1-10)? ");
    if (scanf("%d", &n) != 1) { printf("Error: please enter a number.\n"); return 1; }
    if (n < 1 || n > 10)     { printf("Error: count must be 1 to 10.\n"); return 1; }

    printf("Enter %d strings:\n", n);
    for (i = 0; i < n; i++)
        if (scanf("%19s", s[i]) != 1) { printf("Error: string %d missing.\n", i + 1); return 1; }

    for (i = 0; i < n - 1; i++)
        for (j = i + 1; j < n; j++)
            if (strcmp(s[i], s[j]) > 0) {
                strcpy(temp, s[i]); strcpy(s[i], s[j]); strcpy(s[j], temp);
            }

    printf("Alphabetical order:\n");
    for (i = 0; i < n; i++) printf("%d. %s\n", i + 1, s[i]);
    return 0;
}
''', "6 mango banana cherry apple grape blueberry\n")

# ---------------- searching ----------------
add(551, r'''
#include <stdio.h>

int main(void)
{
    int a[20], n, i, target, pos = -1;

    printf("Enter n and the elements: ");
    if (scanf("%d", &n) != 1 || n < 1 || n > 20) { printf("Invalid size\n"); return 1; }
    for (i = 0; i < n; i++) scanf("%d", &a[i]);
    printf("Enter value to search: ");
    scanf("%d", &target);

    for (i = 0; i < n; i++)
        if (a[i] == target) { pos = i; break; }

    if (pos >= 0) printf("%d found at index %d (position %d)\n", target, pos, pos + 1);
    else printf("%d not found in the array\n", target);
    return 0;
}
''', "7 14 8 23 5 42 16 9\n42\n")

add(552, r'''
#include <stdio.h>

int binary_search(int a[], int n, int target)
{
    int low = 0, high = n - 1, mid;
    while (low <= high) {
        mid = low + (high - low) / 2;
        if (a[mid] == target) return mid;
        if (a[mid] < target) low = mid + 1;
        else high = mid - 1;
    }
    return -1;
}

int main(void)
{
    int a[20], n, i, target, pos;

    printf("Enter n and the sorted elements: ");
    if (scanf("%d", &n) != 1 || n < 1 || n > 20) { printf("Invalid size\n"); return 1; }
    for (i = 0; i < n; i++) scanf("%d", &a[i]);
    printf("Enter target: ");
    scanf("%d", &target);

    pos = binary_search(a, n, target);
    if (pos >= 0) printf("%d found at index %d\n", target, pos);
    else printf("%d not found\n", target);
    return 0;
}
''', "9 2 5 8 12 16 23 38 56 72\n23\n")

add(553, r'''
#include <stdio.h>

int bsearch_rec(int a[], int low, int high, int target)
{
    int mid;
    if (low > high) return -1;               /* base case: not found */
    mid = low + (high - low) / 2;
    if (a[mid] == target) return mid;
    if (a[mid] < target) return bsearch_rec(a, mid + 1, high, target);
    return bsearch_rec(a, low, mid - 1, target);
}

int main(void)
{
    int a[20], n, i, target, pos;

    printf("Enter n and the sorted elements: ");
    if (scanf("%d", &n) != 1 || n < 1 || n > 20) { printf("Invalid size\n"); return 1; }
    for (i = 0; i < n; i++) scanf("%d", &a[i]);
    printf("Enter target: ");
    scanf("%d", &target);

    pos = bsearch_rec(a, 0, n - 1, target);
    if (pos >= 0) printf("%d found at index %d\n", target, pos);
    else printf("%d not found\n", target);
    return 0;
}
''', "8 3 9 14 20 27 35 41 50\n30\n")

add(554, r'''
#include <stdio.h>

int first_occurrence(int a[], int n, int target)
{
    int low = 0, high = n - 1, mid, result = -1;
    while (low <= high) {
        mid = low + (high - low) / 2;
        if (a[mid] == target) { result = mid; high = mid - 1; }   /* keep looking left */
        else if (a[mid] < target) low = mid + 1;
        else high = mid - 1;
    }
    return result;
}

int main(void)
{
    int a[20], n, i, target, pos;

    printf("Enter n and the sorted elements: ");
    if (scanf("%d", &n) != 1 || n < 1 || n > 20) { printf("Invalid size\n"); return 1; }
    for (i = 0; i < n; i++) scanf("%d", &a[i]);
    printf("Enter target: ");
    scanf("%d", &target);

    pos = first_occurrence(a, n, target);
    if (pos >= 0) printf("First occurrence of %d is at index %d\n", target, pos);
    else printf("%d not found\n", target);
    return 0;
}
''', "10 1 2 4 4 4 4 7 9 9 12\n4\n")

add(555, r'''
#include <stdio.h>

int last_occurrence(int a[], int n, int target)
{
    int low = 0, high = n - 1, mid, result = -1;
    while (low <= high) {
        mid = low + (high - low) / 2;
        if (a[mid] == target) { result = mid; low = mid + 1; }    /* keep looking right */
        else if (a[mid] < target) low = mid + 1;
        else high = mid - 1;
    }
    return result;
}

int main(void)
{
    int a[20], n, i, target, pos;

    printf("Enter n and the sorted elements: ");
    if (scanf("%d", &n) != 1 || n < 1 || n > 20) { printf("Invalid size\n"); return 1; }
    for (i = 0; i < n; i++) scanf("%d", &a[i]);
    printf("Enter target: ");
    scanf("%d", &target);

    pos = last_occurrence(a, n, target);
    if (pos >= 0) printf("Last occurrence of %d is at index %d\n", target, pos);
    else printf("%d not found\n", target);
    return 0;
}
''', "10 1 2 4 4 4 4 7 9 9 12\n9\n")

add(556, r'''
#include <stdio.h>

int find_first(int a[], int n, int t)
{
    int lo = 0, hi = n - 1, mid, r = -1;
    while (lo <= hi) {
        mid = lo + (hi - lo) / 2;
        if (a[mid] == t) { r = mid; hi = mid - 1; }
        else if (a[mid] < t) lo = mid + 1;
        else hi = mid - 1;
    }
    return r;
}

int find_last(int a[], int n, int t)
{
    int lo = 0, hi = n - 1, mid, r = -1;
    while (lo <= hi) {
        mid = lo + (hi - lo) / 2;
        if (a[mid] == t) { r = mid; lo = mid + 1; }
        else if (a[mid] < t) lo = mid + 1;
        else hi = mid - 1;
    }
    return r;
}

int main(void)
{
    int a[20], n, i, target, first, last;

    printf("Enter n and the sorted elements: ");
    if (scanf("%d", &n) != 1 || n < 1 || n > 20) { printf("Invalid size\n"); return 1; }
    for (i = 0; i < n; i++) scanf("%d", &a[i]);
    printf("Enter target: ");
    scanf("%d", &target);

    first = find_first(a, n, target);
    last = find_last(a, n, target);
    if (first < 0) printf("%d occurs 0 times\n", target);
    else printf("%d occurs %d times (indices %d to %d)\n", target, last - first + 1, first, last);
    return 0;
}
''', "12 1 3 3 5 5 5 5 5 8 8 10 11\n5\n")

add(557, r'''
#include <stdio.h>

/* lower bound: first index whose value is >= target (n if none) */
int lower_bound(int a[], int n, int target)
{
    int lo = 0, hi = n;
    while (lo < hi) {
        int mid = lo + (hi - lo) / 2;
        if (a[mid] < target) lo = mid + 1;
        else hi = mid;
    }
    return lo;
}

int main(void)
{
    int a[20], n, i, target, pos;

    printf("Enter n and the sorted elements: ");
    if (scanf("%d", &n) != 1 || n < 1 || n > 20) { printf("Invalid size\n"); return 1; }
    for (i = 0; i < n; i++) scanf("%d", &a[i]);
    printf("Enter target: ");
    scanf("%d", &target);

    pos = lower_bound(a, n, target);
    printf("Lower bound index of %d is %d", target, pos);
    if (pos < n) printf(" (value %d)\n", a[pos]);
    else printf(" (past the end: all elements are smaller)\n");
    return 0;
}
''', "8 1 3 3 5 7 7 7 10\n7\n")

add(558, r'''
#include <stdio.h>

/* upper bound: first index whose value is > target (n if none) */
int upper_bound(int a[], int n, int target)
{
    int lo = 0, hi = n;
    while (lo < hi) {
        int mid = lo + (hi - lo) / 2;
        if (a[mid] <= target) lo = mid + 1;
        else hi = mid;
    }
    return lo;
}

int main(void)
{
    int a[20], n, i, target, pos;

    printf("Enter n and the sorted elements: ");
    if (scanf("%d", &n) != 1 || n < 1 || n > 20) { printf("Invalid size\n"); return 1; }
    for (i = 0; i < n; i++) scanf("%d", &a[i]);
    printf("Enter target: ");
    scanf("%d", &target);

    pos = upper_bound(a, n, target);
    printf("Upper bound index of %d is %d", target, pos);
    if (pos < n) printf(" (value %d)\n", a[pos]);
    else printf(" (past the end: no larger element)\n");
    return 0;
}
''', "8 1 3 3 5 7 7 7 10\n7\n")

add(559, r'''
#include <stdio.h>

int insert_position(int a[], int n, int target)
{
    int lo = 0, hi = n - 1, mid;
    while (lo <= hi) {
        mid = lo + (hi - lo) / 2;
        if (a[mid] == target) return mid;
        if (a[mid] < target) lo = mid + 1;
        else hi = mid - 1;
    }
    return lo;                               /* where the target would go */
}

int main(void)
{
    int a[20], n, i, target, pos;

    printf("Enter n and the sorted elements: ");
    if (scanf("%d", &n) != 1 || n < 1 || n > 20) { printf("Invalid size\n"); return 1; }
    for (i = 0; i < n; i++) scanf("%d", &a[i]);
    printf("Enter target: ");
    scanf("%d", &target);

    pos = insert_position(a, n, target);
    printf("Target %d belongs at index %d\n", target, pos);
    printf("Array after insertion:");
    for (i = 0; i < pos; i++) printf(" %d", a[i]);
    printf(" [%d]", target);
    for (i = pos; i < n; i++) printf(" %d", a[i]);
    printf("\n");
    return 0;
}
''', "6 1 3 5 6 9 12\n7\n")

add(560, r'''
#include <stdio.h>

int search_rotated(int a[], int n, int target)
{
    int lo = 0, hi = n - 1, mid;
    while (lo <= hi) {
        mid = lo + (hi - lo) / 2;
        if (a[mid] == target) return mid;
        if (a[lo] <= a[mid]) {                       /* left half is sorted */
            if (a[lo] <= target && target < a[mid]) hi = mid - 1;
            else lo = mid + 1;
        } else {                                     /* right half is sorted */
            if (a[mid] < target && target <= a[hi]) lo = mid + 1;
            else hi = mid - 1;
        }
    }
    return -1;
}

int main(void)
{
    int a[20], n, i, target, pos;

    printf("Enter n and the rotated sorted elements: ");
    if (scanf("%d", &n) != 1 || n < 1 || n > 20) { printf("Invalid size\n"); return 1; }
    for (i = 0; i < n; i++) scanf("%d", &a[i]);
    printf("Enter target: ");
    scanf("%d", &target);

    pos = search_rotated(a, n, target);
    if (pos >= 0) printf("%d found at index %d\n", target, pos);
    else printf("%d not found\n", target);
    return 0;
}
''', "8 15 18 22 2 4 6 9 12\n4\n")

add(561, r'''
#include <stdio.h>

int find_min_index(int a[], int n)
{
    int lo = 0, hi = n - 1, mid;
    while (lo < hi) {
        mid = lo + (hi - lo) / 2;
        if (a[mid] > a[hi]) lo = mid + 1;    /* minimum is to the right */
        else hi = mid;                       /* minimum is at mid or left */
    }
    return lo;
}

int main(void)
{
    int a[20], n, i, idx;

    printf("Enter n and the rotated sorted elements: ");
    if (scanf("%d", &n) != 1 || n < 1 || n > 20) { printf("Invalid size\n"); return 1; }
    for (i = 0; i < n; i++) scanf("%d", &a[i]);

    idx = find_min_index(a, n);
    printf("Minimum element is %d at index %d\n", a[idx], idx);
    printf("The array was rotated %d position(s)\n", idx);
    return 0;
}
''', "7 40 50 60 5 10 20 30\n")

add(562, r'''
#include <stdio.h>

/* a peak is an element not smaller than its neighbours */
int find_peak(int a[], int n)
{
    int lo = 0, hi = n - 1, mid;
    while (lo < hi) {
        mid = lo + (hi - lo) / 2;
        if (a[mid] < a[mid + 1]) lo = mid + 1;   /* a peak lies on the right */
        else hi = mid;
    }
    return lo;
}

int main(void)
{
    int a[20], n, i, p;

    printf("Enter n and the elements: ");
    if (scanf("%d", &n) != 1 || n < 1 || n > 20) { printf("Invalid size\n"); return 1; }
    for (i = 0; i < n; i++) scanf("%d", &a[i]);

    p = find_peak(a, n);
    printf("Peak element %d found at index %d\n", a[p], p);
    return 0;
}
''', "8 1 3 8 12 4 2 9 5\n")

add(563, r'''
#include <stdio.h>

int main(void)
{
    int m[10][10], rows, cols, i, j, target, lo, hi, mid, r, c, found = 0;

    printf("Enter rows and columns: ");
    if (scanf("%d %d", &rows, &cols) != 2 || rows < 1 || cols < 1 || rows > 10 || cols > 10) {
        printf("Invalid size\n");
        return 1;
    }
    printf("Enter the matrix (rows sorted, each row starts above previous row's last):\n");
    for (i = 0; i < rows; i++)
        for (j = 0; j < cols; j++) scanf("%d", &m[i][j]);
    printf("Enter target: ");
    scanf("%d", &target);

    /* treat the matrix as one sorted array of rows*cols values */
    lo = 0; hi = rows * cols - 1;
    while (lo <= hi) {
        mid = lo + (hi - lo) / 2;
        r = mid / cols; c = mid % cols;
        if (m[r][c] == target) { found = 1; break; }
        if (m[r][c] < target) lo = mid + 1;
        else hi = mid - 1;
    }

    if (found) printf("%d found at row %d, column %d\n", target, r, c);
    else printf("%d not found in the matrix\n", target);
    return 0;
}
''', "3 4\n1 3 5 7\n10 11 16 20\n23 30 34 60\n16\n")

add(564, r'''
#include <math.h>
#include <stdio.h>

int jump_search(int a[], int n, int target)
{
    int step = (int)sqrt((double)n), prev = 0, i;
    if (step < 1) step = 1;
    /* jump ahead in blocks until the block may contain the target */
    while (prev < n && a[(prev + step < n ? prev + step : n) - 1] < target)
        prev += step;
    /* linear search inside that block */
    for (i = prev; i < prev + step && i < n; i++)
        if (a[i] == target) return i;
    return -1;
}

int main(void)
{
    int a[30], n, i, target, pos;

    printf("Enter n and the sorted elements: ");
    if (scanf("%d", &n) != 1 || n < 1 || n > 30) { printf("Invalid size\n"); return 1; }
    for (i = 0; i < n; i++) scanf("%d", &a[i]);
    printf("Enter target: ");
    scanf("%d", &target);

    pos = jump_search(a, n, target);
    printf("Block size (jump) = %d\n", (int)sqrt((double)n));
    if (pos >= 0) printf("%d found at index %d\n", target, pos);
    else printf("%d not found\n", target);
    return 0;
}
''', "12 0 1 1 2 3 5 8 13 21 34 55 89\n55\n")

add(565, r'''
#include <stdio.h>

int interpolation_search(int a[], int n, int target)
{
    int lo = 0, hi = n - 1, pos;
    while (lo <= hi && target >= a[lo] && target <= a[hi]) {
        if (a[hi] == a[lo])                          /* avoid division by zero */
            return a[lo] == target ? lo : -1;
        pos = lo + (int)((long)(target - a[lo]) * (hi - lo) / (a[hi] - a[lo]));
        if (a[pos] == target) return pos;
        if (a[pos] < target) lo = pos + 1;
        else hi = pos - 1;
    }
    return -1;
}

int main(void)
{
    int a[20], n, i, target, pos;

    printf("Enter n and the sorted (uniform) elements: ");
    if (scanf("%d", &n) != 1 || n < 1 || n > 20) { printf("Invalid size\n"); return 1; }
    for (i = 0; i < n; i++) scanf("%d", &a[i]);
    printf("Enter target: ");
    scanf("%d", &target);

    pos = interpolation_search(a, n, target);
    if (pos >= 0) printf("%d found at index %d\n", target, pos);
    else printf("%d not found\n", target);
    return 0;
}
''', "10 10 20 30 40 50 60 70 80 90 100\n70\n")

add(566, r'''
#include <stdio.h>

int binary_range(int a[], int lo, int hi, int target)
{
    while (lo <= hi) {
        int mid = lo + (hi - lo) / 2;
        if (a[mid] == target) return mid;
        if (a[mid] < target) lo = mid + 1;
        else hi = mid - 1;
    }
    return -1;
}

int exponential_search(int a[], int n, int target)
{
    int bound = 1;
    if (a[0] == target) return 0;
    while (bound < n && a[bound] <= target)    /* double the range */
        bound *= 2;
    return binary_range(a, bound / 2, (bound < n ? bound : n - 1), target);
}

int main(void)
{
    int a[30], n, i, target, pos;

    printf("Enter n and the sorted elements: ");
    if (scanf("%d", &n) != 1 || n < 1 || n > 30) { printf("Invalid size\n"); return 1; }
    for (i = 0; i < n; i++) scanf("%d", &a[i]);
    printf("Enter target: ");
    scanf("%d", &target);

    pos = exponential_search(a, n, target);
    if (pos >= 0) printf("%d found at index %d\n", target, pos);
    else printf("%d not found\n", target);
    return 0;
}
''', "12 2 3 4 10 40 45 50 60 70 80 90 100\n70\n")

add(567, r'''
#include <stdio.h>

int ternary_search(int a[], int lo, int hi, int target)
{
    while (lo <= hi) {
        int third = (hi - lo) / 3;
        int m1 = lo + third, m2 = hi - third;
        if (a[m1] == target) return m1;
        if (a[m2] == target) return m2;
        if (target < a[m1]) hi = m1 - 1;             /* first third */
        else if (target > a[m2]) lo = m2 + 1;        /* last third */
        else { lo = m1 + 1; hi = m2 - 1; }           /* middle third */
    }
    return -1;
}

int main(void)
{
    int a[30], n, i, target, pos;

    printf("Enter n and the sorted elements: ");
    if (scanf("%d", &n) != 1 || n < 1 || n > 30) { printf("Invalid size\n"); return 1; }
    for (i = 0; i < n; i++) scanf("%d", &a[i]);
    printf("Enter target: ");
    scanf("%d", &target);

    pos = ternary_search(a, 0, n - 1, target);
    if (pos >= 0) printf("%d found at index %d\n", target, pos);
    else printf("%d not found\n", target);
    return 0;
}
''', "10 1 4 9 16 25 36 49 64 81 100\n36\n")

add(568, r'''
#include <stdio.h>

int main(void)
{
    int a[30], n, i, target;
    int lin_cmp = 0, bin_cmp = 0, lin_pos = -1, bin_pos = -1;
    int lo, hi, mid;

    printf("Enter n and the sorted elements: ");
    if (scanf("%d", &n) != 1 || n < 1 || n > 30) { printf("Invalid size\n"); return 1; }
    for (i = 0; i < n; i++) scanf("%d", &a[i]);
    printf("Enter target: ");
    scanf("%d", &target);

    for (i = 0; i < n; i++) {                /* linear search */
        lin_cmp++;
        if (a[i] == target) { lin_pos = i; break; }
    }

    lo = 0; hi = n - 1;                      /* binary search */
    while (lo <= hi) {
        mid = lo + (hi - lo) / 2;
        bin_cmp++;
        if (a[mid] == target) { bin_pos = mid; break; }
        if (a[mid] < target) lo = mid + 1;
        else hi = mid - 1;
    }

    printf("\n%-15s %-10s %s\n", "Method", "Index", "Comparisons");
    printf("%-15s %-10d %d\n", "Linear search", lin_pos, lin_cmp);
    printf("%-15s %-10d %d\n", "Binary search", bin_pos, bin_cmp);
    return 0;
}
''', "16 2 4 6 8 10 12 14 16 18 20 22 24 26 28 30 32\n30\n")

add(569, r'''
#include <stdio.h>

struct Student {
    int id;
    char name[20];
    float marks;
};

int main(void)
{
    struct Student s[5] = {
        {101, "Asha", 88.5f}, {102, "Ravi", 74.0f}, {103, "Meena", 91.25f},
        {104, "John", 65.5f}, {105, "Kiran", 79.0f}
    };
    int id, i, found = -1;

    printf("Enter student ID to search: ");
    if (scanf("%d", &id) != 1) { printf("Invalid ID\n"); return 1; }

    for (i = 0; i < 5; i++)
        if (s[i].id == id) { found = i; break; }

    if (found >= 0)
        printf("Found -> ID: %d, Name: %s, Marks: %.2f\n", s[found].id, s[found].name, s[found].marks);
    else
        printf("No student with ID %d\n", id);
    return 0;
}
''', "103\n")

add(570, r'''
#include <stdio.h>
#include <string.h>

int main(void)
{
    const char *words[] = {"apple", "banana", "cherry", "grape", "mango", "orange"};
    int count = 6, i, pos = -1;
    char target[30];

    printf("Enter the word to search: ");
    if (scanf("%29s", target) != 1) { printf("No word entered\n"); return 1; }

    for (i = 0; i < count; i++)
        if (strcmp(words[i], target) == 0) { pos = i; break; }

    if (pos >= 0) printf("\"%s\" found at index %d\n", target, pos);
    else printf("\"%s\" is not in the list\n", target);
    return 0;
}
''', "mango\n")

add(571, r'''
#include <stdio.h>

/* first element strictly greater than target; returns index or -1 */
int first_greater(int a[], int n, int target)
{
    int lo = 0, hi = n - 1, mid, result = -1;
    while (lo <= hi) {
        mid = lo + (hi - lo) / 2;
        if (a[mid] > target) { result = mid; hi = mid - 1; }
        else lo = mid + 1;
    }
    return result;
}

int main(void)
{
    int a[20], n, i, target, idx;

    printf("Enter n and the sorted elements: ");
    if (scanf("%d", &n) != 1 || n < 1 || n > 20) { printf("Invalid size\n"); return 1; }
    for (i = 0; i < n; i++) scanf("%d", &a[i]);
    printf("Enter target: ");
    scanf("%d", &target);

    idx = first_greater(a, n, target);
    if (idx >= 0) printf("First element greater than %d is %d (index %d)\n", target, a[idx], idx);
    else printf("No element is greater than %d\n", target);
    return 0;
}
''', "8 2 4 4 7 10 10 15 20\n10\n")

add(572, r'''
#include <stdio.h>

/* last element <= target; returns index or -1 */
int last_not_greater(int a[], int n, int target)
{
    int lo = 0, hi = n - 1, mid, result = -1;
    while (lo <= hi) {
        mid = lo + (hi - lo) / 2;
        if (a[mid] <= target) { result = mid; lo = mid + 1; }
        else hi = mid - 1;
    }
    return result;
}

int main(void)
{
    int a[20], n, i, target, idx;

    printf("Enter n and the sorted elements: ");
    if (scanf("%d", &n) != 1 || n < 1 || n > 20) { printf("Invalid size\n"); return 1; }
    for (i = 0; i < n; i++) scanf("%d", &a[i]);
    printf("Enter target: ");
    scanf("%d", &target);

    idx = last_not_greater(a, n, target);
    if (idx >= 0) printf("Last element <= %d is %d (index %d)\n", target, a[idx], idx);
    else printf("Every element is greater than %d\n", target);
    return 0;
}
''', "8 2 4 4 7 10 10 15 20\n12\n")

add(573, r'''
#include <stdio.h>

/* nearly sorted: element i may sit at position i-1, i or i+1 */
int nearly_sorted_search(int a[], int n, int target)
{
    int lo = 0, hi = n - 1, mid;
    while (lo <= hi) {
        mid = lo + (hi - lo) / 2;
        if (a[mid] == target) return mid;
        if (mid > lo && a[mid - 1] == target) return mid - 1;
        if (mid < hi && a[mid + 1] == target) return mid + 1;
        if (a[mid] > target) hi = mid - 2;
        else lo = mid + 2;
    }
    return -1;
}

int main(void)
{
    int a[20], n, i, target, pos;

    printf("Enter n and the nearly sorted elements: ");
    if (scanf("%d", &n) != 1 || n < 1 || n > 20) { printf("Invalid size\n"); return 1; }
    for (i = 0; i < n; i++) scanf("%d", &a[i]);
    printf("Enter target: ");
    scanf("%d", &target);

    pos = nearly_sorted_search(a, n, target);
    if (pos >= 0) printf("%d found at index %d\n", target, pos);
    else printf("%d not found\n", target);
    return 0;
}
''', "9 10 3 40 20 50 80 70 90 100\n20\n")

add(574, r'''
#include <stdio.h>

int main(void)
{
    int a[20], n, i, lo, hi, mid, missing;

    printf("Enter n and the sorted consecutive values (one is missing): ");
    if (scanf("%d", &n) != 1 || n < 2 || n > 20) { printf("Invalid size\n"); return 1; }
    for (i = 0; i < n; i++) scanf("%d", &a[i]);

    /* before the gap a[i] - i equals a[0]; after the gap it is a[0] + 1 */
    lo = 0; hi = n - 1;
    while (lo < hi) {
        mid = lo + (hi - lo) / 2;
        if (a[mid] - mid == a[0]) lo = mid + 1;
        else hi = mid;
    }
    if (a[lo] - lo == a[0]) {
        printf("No value is missing from the sequence\n");
    } else {
        missing = a[lo] - 1;
        printf("Missing value is %d\n", missing);
    }
    return 0;
}
''', "8 11 12 13 14 16 17 18 19\n")

add(575, r'''
#include <stdio.h>
#include <stdlib.h>

int closest(int a[], int n, int target)
{
    int lo = 0, hi = n;                       /* lower bound search */
    while (lo < hi) {
        int mid = lo + (hi - lo) / 2;
        if (a[mid] < target) lo = mid + 1;
        else hi = mid;
    }
    if (lo == 0) return a[0];
    if (lo == n) return a[n - 1];
    /* compare the neighbours on either side of the insertion point */
    return (abs(a[lo] - target) < abs(target - a[lo - 1])) ? a[lo] : a[lo - 1];
}

int main(void)
{
    int a[20], n, i, target;

    printf("Enter n and the sorted elements: ");
    if (scanf("%d", &n) != 1 || n < 1 || n > 20) { printf("Invalid size\n"); return 1; }
    for (i = 0; i < n; i++) scanf("%d", &a[i]);
    printf("Enter target: ");
    scanf("%d", &target);

    printf("Closest value to %d is %d\n", target, closest(a, n, target));
    return 0;
}
''', "7 1 5 9 14 20 27 33\n16\n")
