# programs 401-500 : id -> (stdin, code)
P = {}
def add(i, code, stdin=""): P[i] = (stdin, code.strip("\n"))

add(401, r'''
#include <stdio.h>

int main(void)
{
    int n, i, j;
    printf("Enter the size of the square: ");
    scanf("%d", &n);
    for (i = 0; i < n; i++)
    {
        for (j = 0; j < n; j++)
        {
            printf("* ");
        }
        printf("\n");
    }
    return 0;
}
''', "5")
add(402, r'''
#include <stdio.h>

int main(void)
{
    int n, i, j;
    printf("Enter the size of the square: ");
    scanf("%d", &n);
    for (i = 1; i <= n; i++)
    {
        for (j = 1; j <= n; j++)
        {
            /* stars only on the border */
            if (i == 1 || i == n || j == 1 || j == n)
                printf("* ");
            else
                printf("  ");
        }
        printf("\n");
    }
    return 0;
}
''', "6")
add(403, r'''
#include <stdio.h>

int main(void)
{
    int n, i, j;
    printf("Enter number of rows: ");
    scanf("%d", &n);
    for (i = 1; i <= n; i++)
    {
        for (j = 1; j <= i; j++)
        {
            printf("* ");
        }
        printf("\n");
    }
    return 0;
}
''', "5")
add(404, r'''
#include <stdio.h>

int main(void)
{
    int n, i, j;
    printf("Enter number of rows: ");
    scanf("%d", &n);
    for (i = n; i >= 1; i--)
    {
        for (j = 1; j <= i; j++)
        {
            printf("* ");
        }
        printf("\n");
    }
    return 0;
}
''', "5")
add(405, r'''
#include <stdio.h>

int main(void)
{
    int n, i, j;
    printf("Enter number of rows: ");
    scanf("%d", &n);
    for (i = 1; i <= n; i++)
    {
        for (j = 1; j <= i; j++)
        {
            printf("%d ", j);
        }
        printf("\n");
    }
    return 0;
}
''', "5")
add(406, r'''
#include <stdio.h>

int main(void)
{
    int n, i, j;
    printf("Enter number of rows: ");
    scanf("%d", &n);
    for (i = n; i >= 1; i--)
    {
        for (j = 1; j <= i; j++)
        {
            printf("%d ", j);
        }
        printf("\n");
    }
    return 0;
}
''', "5")
add(407, r'''
#include <stdio.h>

int main(void)
{
    int n, i, j;
    printf("Enter number of rows: ");
    scanf("%d", &n);
    for (i = 1; i <= n; i++)
    {
        for (j = 1; j <= n - i; j++)
            printf(" ");
        for (j = 1; j <= 2 * i - 1; j++)
            printf("*");
        printf("\n");
    }
    return 0;
}
''', "5")
add(408, r'''
#include <stdio.h>

int main(void)
{
    int n, i, j;
    printf("Enter number of rows: ");
    scanf("%d", &n);
    for (i = n; i >= 1; i--)
    {
        for (j = 1; j <= n - i; j++)
            printf(" ");
        for (j = 1; j <= 2 * i - 1; j++)
            printf("*");
        printf("\n");
    }
    return 0;
}
''', "5")
add(409, r'''
#include <stdio.h>

int main(void)
{
    int n, i, j;
    printf("Enter the number of rows in the upper half: ");
    scanf("%d", &n);
    /* upper half including the middle row */
    for (i = 1; i <= n; i++)
    {
        for (j = 1; j <= n - i; j++)
            printf(" ");
        for (j = 1; j <= 2 * i - 1; j++)
            printf("*");
        printf("\n");
    }
    /* lower half */
    for (i = n - 1; i >= 1; i--)
    {
        for (j = 1; j <= n - i; j++)
            printf(" ");
        for (j = 1; j <= 2 * i - 1; j++)
            printf("*");
        printf("\n");
    }
    return 0;
}
''', "4")
add(410, r'''
#include <stdio.h>

int main(void)
{
    int n, i, j, k;
    printf("Enter the number of rows in the upper half: ");
    scanf("%d", &n);
    for (k = 1; k <= 2 * n - 1; k++)
    {
        /* i is the half-width of the current row */
        i = (k <= n) ? k : 2 * n - k;
        for (j = 1; j <= n - i; j++)
            printf(" ");
        for (j = 1; j <= 2 * i - 1; j++)
        {
            if (j == 1 || j == 2 * i - 1)
                printf("*");
            else
                printf(" ");
        }
        printf("\n");
    }
    return 0;
}
''', "5")
add(411, r'''
#include <stdio.h>

int main(void)
{
    int n, i, j;
    printf("Enter the maximum width: ");
    scanf("%d", &n);
    for (i = 1; i <= n; i++)
    {
        for (j = 1; j <= i; j++)
            printf("*");
        printf("\n");
    }
    for (i = n - 1; i >= 1; i--)
    {
        for (j = 1; j <= i; j++)
            printf("*");
        printf("\n");
    }
    return 0;
}
''', "4")
add(412, r'''
#include <stdio.h>

int main(void)
{
    int n, i, j;
    printf("Enter the height of one wing: ");
    scanf("%d", &n);
    /* upper half */
    for (i = 1; i <= n; i++)
    {
        for (j = 1; j <= i; j++)
            printf("*");
        for (j = 1; j <= 2 * (n - i); j++)
            printf(" ");
        for (j = 1; j <= i; j++)
            printf("*");
        printf("\n");
    }
    /* lower half */
    for (i = n; i >= 1; i--)
    {
        for (j = 1; j <= i; j++)
            printf("*");
        for (j = 1; j <= 2 * (n - i); j++)
            printf(" ");
        for (j = 1; j <= i; j++)
            printf("*");
        printf("\n");
    }
    return 0;
}
''', "4")
add(413, r'''
#include <stdio.h>

int main(void)
{
    int n, i, j;
    printf("Enter number of rows: ");
    scanf("%d", &n);
    for (i = 1; i <= n; i++)
    {
        for (j = 1; j <= i; j++)
        {
            /* first column, last column of the row and the last row */
            if (j == 1 || j == i || i == n)
                printf("* ");
            else
                printf("  ");
        }
        printf("\n");
    }
    return 0;
}
''', "6")
add(414, r'''
#include <stdio.h>

int main(void)
{
    int rows, width, i, j;
    printf("Enter number of rows and width: ");
    scanf("%d %d", &rows, &width);
    for (i = 1; i <= rows; i++)
    {
        for (j = 1; j <= rows - i; j++)
            printf(" ");
        for (j = 1; j <= width; j++)
            printf("*");
        printf("\n");
    }
    return 0;
}
''', "5 8")
add(415, r'''
#include <stdio.h>

int main(void)
{
    int rows, width, i, j;
    printf("Enter number of rows and width: ");
    scanf("%d %d", &rows, &width);
    /* each row is shifted one step to the right: parallelogram leaning left */
    for (i = 0; i < rows; i++)
    {
        for (j = 0; j < i; j++)
            printf(" ");
        for (j = 0; j < width; j++)
            printf("*");
        printf("\n");
    }
    return 0;
}
''', "4 7")
add(416, r'''
#include <stdio.h>

int main(void)
{
    int n, i, j;
    printf("Enter number of rows: ");
    scanf("%d", &n);
    for (i = 1; i <= n; i++)
    {
        for (j = 1; j <= n - i; j++)
            printf("  ");
        for (j = 1; j <= i; j++)
            printf("* ");
        printf("\n");
    }
    return 0;
}
''', "5")
add(417, r'''
#include <stdio.h>

int main(void)
{
    int n, i, j, num = 1;
    printf("Enter number of rows: ");
    scanf("%d", &n);
    for (i = 1; i <= n; i++)
    {
        for (j = 1; j <= i; j++)
        {
            printf("%3d", num);
            num++;
        }
        printf("\n");
    }
    return 0;
}
''', "5")
add(418, r'''
#include <stdio.h>

int main(void)
{
    int n, i, j, value;
    printf("Enter number of rows: ");
    scanf("%d", &n);
    for (i = 0; i < n; i++)
    {
        for (j = 0; j < n - i - 1; j++)
            printf("  ");
        value = 1;
        for (j = 0; j <= i; j++)
        {
            printf("%4d", value);
            value = value * (i - j) / (j + 1);   /* next binomial coefficient */
        }
        printf("\n");
    }
    return 0;
}
''', "6")
add(419, r'''
#include <stdio.h>

int main(void)
{
    int n, i, j;
    printf("Enter number of rows: ");
    scanf("%d", &n);
    for (i = 1; i <= n; i++)
    {
        for (j = 1; j <= n - i; j++)
            printf(" ");
        for (j = 1; j <= i; j++)
            printf("%d ", i);
        printf("\n");
    }
    return 0;
}
''', "5")
add(420, r'''
#include <stdio.h>

int main(void)
{
    int n, i, j;
    printf("Enter number of rows: ");
    scanf("%d", &n);
    for (i = 1; i <= n; i++)
    {
        for (j = 1; j <= n - i; j++)
            printf(" ");
        for (j = 1; j <= i; j++)
            printf("%d", j);
        for (j = i - 1; j >= 1; j--)
            printf("%d", j);
        printf("\n");
    }
    return 0;
}
''', "5")
add(421, r'''
#include <stdio.h>

int main(void)
{
    int n, i, j;
    printf("Enter number of rows: ");
    scanf("%d", &n);
    for (i = 1; i <= n; i++)
    {
        /* the row number is repeated i times */
        for (j = 1; j <= i; j++)
            printf("%d", i);
        printf("\n");
    }
    return 0;
}
''', "5")
add(422, r'''
#include <stdio.h>

int main(void)
{
    int n, i, j;
    printf("Enter number of rows: ");
    scanf("%d", &n);
    for (i = 1; i <= n; i++)
    {
        for (j = 1; j <= i; j++)
            printf("%d ", (i + j + 1) % 2);
        printf("\n");
    }
    return 0;
}
''', "6")
add(423, r'''
#include <stdio.h>

int main(void)
{
    int n, i, j;
    printf("Enter number of rows: ");
    scanf("%d", &n);
    for (i = 1; i <= n; i++)
    {
        for (j = 0; j < i; j++)
            printf("%c ", 'A' + j);
        printf("\n");
    }
    return 0;
}
''', "5")
add(424, r'''
#include <stdio.h>

int main(void)
{
    int n, i, j;
    printf("Enter number of rows: ");
    scanf("%d", &n);
    for (i = n; i >= 1; i--)
    {
        for (j = 0; j < i; j++)
            printf("%c ", 'A' + j);
        printf("\n");
    }
    return 0;
}
''', "5")
add(425, r'''
#include <stdio.h>

int main(void)
{
    int n, i, j, count = 0;
    printf("Enter number of rows: ");
    scanf("%d", &n);
    for (i = 1; i <= n; i++)
    {
        for (j = 1; j <= i; j++)
        {
            printf("%c ", 'A' + count % 26);   /* wraps back to A after Z */
            count++;
        }
        printf("\n");
    }
    return 0;
}
''', "5")
add(426, r'''
#include <stdio.h>

int main(void)
{
    int n, i, j;
    printf("Enter number of rows: ");
    scanf("%d", &n);
    for (i = 1; i <= n; i++)
    {
        for (j = 1; j <= n - i; j++)
            printf(" ");
        for (j = 1; j <= 2 * i - 1; j++)
        {
            /* edges of every row and the whole last row */
            if (j == 1 || j == 2 * i - 1 || i == n)
                printf("*");
            else
                printf(" ");
        }
        printf("\n");
    }
    return 0;
}
''', "6")
add(427, r'''
#include <stdio.h>

int main(void)
{
    int rows, cols, i, j;
    printf("Enter rows and columns: ");
    scanf("%d %d", &rows, &cols);
    for (i = 1; i <= rows; i++)
    {
        for (j = 1; j <= cols; j++)
        {
            if (i == 1 || i == rows || j == 1 || j == cols)
                printf("*");
            else
                printf(" ");
        }
        printf("\n");
    }
    return 0;
}
''', "5 10")
add(428, r'''
#include <stdio.h>

int main(void)
{
    int n, i, j;
    printf("Enter the board size: ");
    scanf("%d", &n);
    for (i = 0; i < n; i++)
    {
        for (j = 0; j < n; j++)
        {
            if ((i + j) % 2 == 0)
                printf("# ");
            else
                printf(". ");
        }
        printf("\n");
    }
    return 0;
}
''', "8")
add(429, r'''
#include <stdio.h>

int main(void)
{
    int n, i, j;
    printf("Enter the size (odd number): ");
    scanf("%d", &n);
    for (i = 0; i < n; i++)
    {
        for (j = 0; j < n; j++)
        {
            /* main diagonal or anti-diagonal */
            if (i == j || i + j == n - 1)
                printf("*");
            else
                printf(" ");
        }
        printf("\n");
    }
    return 0;
}
''', "7")
add(430, r'''
#include <stdio.h>

int main(void)
{
    int n, i, j, mid;
    printf("Enter the size (odd number): ");
    scanf("%d", &n);
    mid = n / 2;
    for (i = 0; i < n; i++)
    {
        for (j = 0; j < n; j++)
        {
            if (i == mid || j == mid)
                printf("+");
            else
                printf(" ");
        }
        printf("\n");
    }
    return 0;
}
''', "7")
add(431, r'''
#include <stdio.h>

int main(void)
{
    int n, i, j;
    printf("Enter the half height: ");
    scanf("%d", &n);
    /* top: inverted pyramid */
    for (i = n; i >= 1; i--)
    {
        for (j = 1; j <= n - i; j++)
            printf(" ");
        for (j = 1; j <= 2 * i - 1; j++)
            printf("*");
        printf("\n");
    }
    /* bottom: pyramid (the narrow middle row is not repeated) */
    for (i = 2; i <= n; i++)
    {
        for (j = 1; j <= n - i; j++)
            printf(" ");
        for (j = 1; j <= 2 * i - 1; j++)
            printf("*");
        printf("\n");
    }
    return 0;
}
''', "4")
add(432, r'''
#include <stdio.h>

int main(void)
{
    int n, size, i, j, d, d1, d2;
    printf("Enter n: ");
    scanf("%d", &n);
    size = 2 * n - 1;
    for (i = 0; i < size; i++)
    {
        for (j = 0; j < size; j++)
        {
            /* distance to the nearest border decides the number */
            d1 = (i < size - 1 - i) ? i : size - 1 - i;
            d2 = (j < size - 1 - j) ? j : size - 1 - j;
            d = (d1 < d2) ? d1 : d2;
            printf("%d ", n - d);
        }
        printf("\n");
    }
    return 0;
}
''', "4")
add(433, r'''
#include <stdio.h>

int main(void)
{
    int n, i, j;
    printf("Enter N: ");
    scanf("%d", &n);
    for (i = 1; i <= n; i++)
    {
        for (j = 1; j <= n; j++)
            printf("%4d", i * j);
        printf("\n");
    }
    return 0;
}
''', "6")
add(434, r'''
#include <stdio.h>

int main(void)
{
    int n, i, j;
    printf("Enter the number of steps: ");
    scanf("%d", &n);
    for (i = 1; i <= n; i++)
    {
        for (j = 1; j <= n - i; j++)
            printf(" ");
        for (j = 1; j <= i; j++)
            printf("#");
        printf("\n");
    }
    return 0;
}
''', "6")
add(435, r'''
#include <stdio.h>

int main(void)
{
    int n, i, j;
    printf("Enter number of rows: ");
    scanf("%d", &n);
    for (i = 1; i <= n; i++)
    {
        printf("Row %d: ", i);
        for (j = 1; j <= i; j++)
            printf("%d ", i);
        printf("\n");
    }
    return 0;
}
''', "5")
add(436, r'''
#include <stdio.h>

int main(void)
{
    int rows, cols, i, j;
    printf("Enter rows and columns: ");
    scanf("%d %d", &rows, &cols);
    for (i = 0; i < rows; i++)
    {
        for (j = 0; j < cols; j++)
        {
            /* alternate 1 and 0 across the whole grid */
            printf("%d ", (i + j) % 2 == 0 ? 1 : 0);
        }
        printf("\n");
    }
    return 0;
}
''', "4 7")
add(437, r'''
#include <stdio.h>

int main(void)
{
    int n, i, j;
    printf("Enter the height: ");
    scanf("%d", &n);
    for (i = 1; i <= n; i++)
    {
        for (j = 1; j <= i; j++)
        {
            /* left edge, hypotenuse (j == i) and bottom row */
            if (j == 1 || j == i || i == n)
                printf("*");
            else
                printf(" ");
        }
        printf("\n");
    }
    return 0;
}
''', "7")
add(438, r'''
#include <stdio.h>

int main(void)
{
    int n, i, j;
    printf("Enter number of rows: ");
    scanf("%d", &n);
    for (i = 1; i <= n; i++)
    {
        for (j = 1; j <= n - i; j++)
            printf("  ");
        for (j = i; j >= 1; j--)
            printf("%d ", j);
        printf("\n");
    }
    return 0;
}
''', "5")
add(439, r'''
#include <stdio.h>

int main(void)
{
    int n, i, j;
    printf("Enter number of rows: ");
    scanf("%d", &n);
    for (i = 1; i <= n; i++)
    {
        for (j = 1; j <= i; j++)
        {
            /* 1 only when both the row and the column number are odd */
            if (i % 2 == 1 && j % 2 == 1)
                printf("1 ");
            else
                printf("0 ");
        }
        printf("\n");
    }
    return 0;
}
''', "6")
add(440, r'''
#include <stdio.h>

int main(void)
{
    int n, i, j, k;
    printf("Enter n: ");
    scanf("%d", &n);
    for (k = 1; k <= 2 * n - 1; k++)
    {
        i = (k <= n) ? k : 2 * n - k;
        for (j = 1; j <= n - i; j++)
            printf(" ");
        for (j = 1; j <= i; j++)     /* increasing part */
            printf("%d", j);
        for (j = i - 1; j >= 1; j--) /* decreasing part */
            printf("%d", j);
        printf("\n");
    }
    return 0;
}
''', "4")
add(441, r'''
#include <stdio.h>

int main(void)
{
    int n, i, j;
    printf("Enter number of rows: ");
    scanf("%d", &n);
    for (i = 1; i <= n; i++)
    {
        for (j = 1; j <= i; j++)
        {
            if (j % 2 == 1)
                printf("* ");
            else
                printf("+ ");
        }
        printf("\n");
    }
    return 0;
}
''', "6")
add(442, r'''
#include <stdio.h>

int main(void)
{
    int n, i, j;
    char symbol;
    printf("Enter the side length: ");
    scanf("%d", &n);
    printf("Enter the character to draw with: ");
    scanf(" %c", &symbol);
    for (i = 0; i < n; i++)
    {
        for (j = 0; j < n; j++)
            printf("%c ", symbol);
        printf("\n");
    }
    return 0;
}
''', "4\n*")
add(443, r'''
#include <stdio.h>

/* prints a hollow square of the given side length */
void printHollowSquare(int n)
{
    int i, j;
    for (i = 1; i <= n; i++)
    {
        for (j = 1; j <= n; j++)
        {
            if (i == 1 || i == n || j == 1 || j == n)
                printf("* ");
            else
                printf("  ");
        }
        printf("\n");
    }
}

int main(void)
{
    int n;
    printf("Enter the side length: ");
    scanf("%d", &n);
    printHollowSquare(n);
    return 0;
}
''', "5")
add(444, r'''
#include <stdio.h>

int main(void)
{
    int n, i, j;
    printf("Enter number of rows (1 to 20): ");
    if (scanf("%d", &n) != 1)
    {
        printf("Error: input is not a number.\n");
        return 0;
    }
    if (n < 1 || n > 20)
    {
        printf("Error: %d is outside the allowed range 1 to 20.\n", n);
        return 0;
    }
    for (i = 1; i <= n; i++)
    {
        for (j = 1; j <= i; j++)
            printf("* ");
        printf("\n");
    }
    return 0;
}
''', "4")
add(445, r'''
#include <stdio.h>

int main(void)
{
    int test, n, i, j;
    for (test = 1; test <= 3; test++)
    {
        printf("Test %d - enter number of rows: ", test);
        if (scanf("%d", &n) != 1)
            break;
        printf("Inverted triangle for n = %d\n", n);
        for (i = n; i >= 1; i--)
        {
            for (j = 1; j <= i; j++)
                printf("* ");
            printf("\n");
        }
        printf("\n");
    }
    return 0;
}
''', "3\n5\n1")
add(446, r'''
#include <stdio.h>

int main(void)
{
    int n, row, col;
    printf("Enter number of rows: ");
    scanf("%d", &n);

    /* the outer loop handles one row per iteration */
    for (row = 1; row <= n; row++)
    {
        /* row number r prints the numbers 1..r, so the triangle grows by one each row */
        for (col = 1; col <= row; col++)
        {
            printf("%d ", col);
        }
        /* move to the next line after each row */
        printf("\n");
    }
    return 0;
}
''', "6")
add(447, r'''
#include <stdio.h>

int main(void)
{
    int n, i, j;
    printf("Enter number of rows (1 to 15): ");
    if (scanf("%d", &n) != 1)
    {
        printf("Invalid input.\n");
        return 0;
    }
    if (n <= 0)
    {
        printf("Nothing to print: rows must be at least 1.\n");
        return 0;
    }
    if (n > 15)
    {
        printf("Too large, limiting to 15 rows.\n");
        n = 15;
    }
    for (i = n; i >= 1; i--)        /* n = 1 prints a single "1" */
    {
        for (j = 1; j <= i; j++)
            printf("%d ", j);
        printf("\n");
    }
    return 0;
}
''', "1")
add(448, r'''
#include <stdio.h>

void printPyramid(int n)
{
    int i, j;
    for (i = 1; i <= n; i++)
    {
        for (j = 1; j <= n - i; j++)
            printf(" ");
        for (j = 1; j <= 2 * i - 1; j++)
            printf("*");
        printf("\n");
    }
}

int main(void)
{
    int choice = 0, n;
    do
    {
        printf("\n--- MENU ---\n");
        printf("1. Print pyramid\n");
        printf("2. Exit\n");
        printf("Enter your choice: ");
        if (scanf("%d", &choice) != 1)
            break;
        if (choice == 1)
        {
            printf("Enter number of rows: ");
            if (scanf("%d", &n) != 1)
                break;
            printPyramid(n);
        }
        else if (choice != 2)
        {
            printf("Invalid choice, try again.\n");
        }
    } while (choice != 2);
    printf("Goodbye!\n");
    return 0;
}
''', "1\n4\n3\n1\n2\n2")
add(449, r'''
#include <stdio.h>

int main(void)
{
    int n, i, j, spaces, stars;
    printf("Enter number of rows: ");
    scanf("%d", &n);
    for (i = 1; i <= n; i++)
    {
        spaces = i - 1;
        stars = 2 * (n - i) + 1;
        /* intermediate step: show how the row is built */
        printf("Row %d: %d space(s) + %d star(s): ", i, spaces, stars);
        for (j = 0; j < spaces; j++)
            printf(" ");
        for (j = 0; j < stars; j++)
            printf("*");
        printf("\n");
    }
    return 0;
}
''', "4")
add(450, r'''
#include <stdio.h>

int main(void)
{
    int n, row, j, width;
    printf("Enter n (rows in the upper half): ");
    scanf("%d", &n);
    /* a single loop over all 2n-1 rows instead of repeating statements */
    for (row = 1; row <= 2 * n - 1; row++)
    {
        width = (row <= n) ? row : 2 * n - row;
        for (j = 0; j < n - width; j++)
            printf(" ");
        for (j = 0; j < 2 * width - 1; j++)
            printf("*");
        printf("\n");
    }
    return 0;
}
''', "5")
