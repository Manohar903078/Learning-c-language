# programs 901-1000  : id -> (stdin, code)
P = {}
def add(i, code, stdin=""): P[i] = (stdin, code.strip("\n"))

add(901, r'''
#include <stdio.h>

struct Student
{
    int roll;
    char name[30];
    float marks;
};

int main(void)
{
    struct Student s = {101, "Anita Rao", 87.5f};

    printf("Student details\n");
    printf("Roll no : %d\n", s.roll);
    printf("Name    : %s\n", s.name);
    printf("Marks   : %.1f\n", s.marks);
    return 0;
}
''')
add(902, r'''
#include <stdio.h>

#define MAX 20

struct Student
{
    int roll;
    char name[30];
    float marks;
};

int main(void)
{
    struct Student st[MAX];
    int n, i;

    printf("Enter number of students (1-%d): ", MAX);
    if (scanf("%d", &n) != 1 || n < 1 || n > MAX)
    {
        printf("Invalid count.\n");
        return 0;
    }
    for (i = 0; i < n; i++)
    {
        printf("Student %d - enter roll, name, marks: ", i + 1);
        scanf("%d %29s %f", &st[i].roll, st[i].name, &st[i].marks);
    }
    printf("\n%-6s %-15s %s\n", "Roll", "Name", "Marks");
    for (i = 0; i < n; i++)
        printf("%-6d %-15s %.1f\n", st[i].roll, st[i].name, st[i].marks);
    return 0;
}
''', "3\n1 Asha 78.5\n2 Ben 66\n3 Chitra 91.25\n")
add(903, r'''
#include <stdio.h>

struct Student
{
    char name[30];
    int marks[5];
    int total;
    float average;
};

int main(void)
{
    struct Student s = {"Rohan", {78, 85, 69, 92, 74}, 0, 0.0f};
    int i;

    for (i = 0; i < 5; i++)
        s.total += s.marks[i];
    s.average = s.total / 5.0f;

    printf("Student : %s\n", s.name);
    printf("Marks   :");
    for (i = 0; i < 5; i++)
        printf(" %d", s.marks[i]);
    printf("\nTotal   = %d\n", s.total);
    printf("Average = %.2f\n", s.average);
    return 0;
}
''')
add(904, r'''
#include <stdio.h>

struct Student
{
    char name[20];
    int marks;
};

int main(void)
{
    struct Student st[5] = {{"Asha", 72}, {"Bala", 88}, {"Chen", 95}, {"Divya", 81}, {"Esha", 64}};
    int i, best = 0;

    for (i = 1; i < 5; i++)
        if (st[i].marks > st[best].marks)
            best = i;

    printf("All students:\n");
    for (i = 0; i < 5; i++)
        printf("  %-6s %d\n", st[i].name, st[i].marks);
    printf("Highest marks: %s with %d\n", st[best].name, st[best].marks);
    return 0;
}
''')
add(905, r'''
#include <stdio.h>

struct Student
{
    int roll;
    char name[20];
};

int main(void)
{
    struct Student st[5] = {{104, "Dev"}, {101, "Asha"}, {105, "Esha"}, {102, "Bala"}, {103, "Chen"}};
    struct Student temp;
    int i, j;

    for (i = 0; i < 4; i++)
        for (j = 0; j < 4 - i; j++)
            if (st[j].roll > st[j + 1].roll)
            {
                temp = st[j];
                st[j] = st[j + 1];
                st[j + 1] = temp;
            }

    printf("Records sorted by roll number:\n");
    for (i = 0; i < 5; i++)
        printf("%d  %s\n", st[i].roll, st[i].name);
    return 0;
}
''')
add(906, r'''
#include <stdio.h>
#include <string.h>

struct Student
{
    int roll;
    char name[20];
    float marks;
};

int main(void)
{
    struct Student st[4] = {{1, "Asha", 78.5f}, {2, "Bala", 66.0f}, {3, "Chen", 91.0f}, {4, "Divya", 55.5f}};
    const char *keys[2] = {"Chen", "Zara"};
    int k, i, found;

    for (k = 0; k < 2; k++)
    {
        found = 0;
        for (i = 0; i < 4; i++)
            if (strcmp(st[i].name, keys[k]) == 0)
            {
                printf("Found %s: roll %d, marks %.1f\n", st[i].name, st[i].roll, st[i].marks);
                found = 1;
            }
        if (!found)
            printf("Student '%s' not found.\n", keys[k]);
    }
    return 0;
}
''')
add(907, r'''
#include <stdio.h>

struct Date
{
    int day;
    int month;
    int year;
};

int main(void)
{
    struct Date d = {15, 8, 1947};

    printf("Date (dd/mm/yyyy): %02d/%02d/%04d\n", d.day, d.month, d.year);
    return 0;
}
''')
add(908, r'''
#include <stdio.h>

struct Date
{
    int day, month, year;
};

/* returns -1 if a is earlier, 0 if equal, 1 if a is later */
int compareDates(struct Date a, struct Date b)
{
    if (a.year != b.year)
        return a.year < b.year ? -1 : 1;
    if (a.month != b.month)
        return a.month < b.month ? -1 : 1;
    if (a.day != b.day)
        return a.day < b.day ? -1 : 1;
    return 0;
}

int main(void)
{
    struct Date d1 = {12, 3, 2024}, d2 = {25, 12, 2023};
    int r = compareDates(d1, d2);

    printf("Date 1: %02d/%02d/%d\n", d1.day, d1.month, d1.year);
    printf("Date 2: %02d/%02d/%d\n", d2.day, d2.month, d2.year);
    if (r == 0)
        printf("Both dates are equal.\n");
    else if (r < 0)
        printf("Date 1 is earlier.\n");
    else
        printf("Date 1 is later.\n");
    return 0;
}
''')
add(909, r'''
#include <stdio.h>

struct Complex
{
    float real;
    float imag;
};

int main(void)
{
    struct Complex a = {3.5f, 2.0f}, b = {1.5f, -4.0f}, sum;

    sum.real = a.real + b.real;
    sum.imag = a.imag + b.imag;

    printf("First  : %.1f %+.1fi\n", a.real, a.imag);
    printf("Second : %.1f %+.1fi\n", b.real, b.imag);
    printf("Sum    : %.1f %+.1fi\n", sum.real, sum.imag);
    return 0;
}
''')
add(910, r'''
#include <stdio.h>

struct Complex
{
    double real;
    double imag;
};

int main(void)
{
    struct Complex a = {2, 3}, b = {4, -1}, p;

    /* (a+bi)(c+di) = (ac - bd) + (ad + bc)i */
    p.real = a.real * b.real - a.imag * b.imag;
    p.imag = a.real * b.imag + a.imag * b.real;

    printf("(%.0f %+.0fi) x (%.0f %+.0fi)\n", a.real, a.imag, b.real, b.imag);
    printf("Product = %.0f %+.0fi\n", p.real, p.imag);
    return 0;
}
''')
add(911, r'''
#include <stdio.h>

struct Book
{
    int id;
    char title[30];
    char author[20];
    float price;
};

int main(void)
{
    struct Book lib[4] = {
        {1, "The C Programming", "Kernighan", 450.0f},
        {2, "Let Us C", "Kanetkar", 380.5f},
        {3, "Data Structures", "Lipschutz", 520.0f},
        {4, "Algorithms", "Cormen", 899.99f}};
    int i;

    printf("%-4s %-20s %-12s %8s\n", "ID", "Title", "Author", "Price");
    for (i = 0; i < 4; i++)
        printf("%-4d %-20s %-12s %8.2f\n", lib[i].id, lib[i].title, lib[i].author, lib[i].price);
    return 0;
}
''')
add(912, r'''
#include <stdio.h>

struct Employee
{
    int id;
    char name[25];
    double monthlySalary;
    double annualSalary;
};

int main(void)
{
    struct Employee e = {501, "Meera Nair", 42500.0, 0.0};

    e.annualSalary = e.monthlySalary * 12;
    printf("Employee ID    : %d\n", e.id);
    printf("Name           : %s\n", e.name);
    printf("Monthly salary : %.2f\n", e.monthlySalary);
    printf("Annual salary  : %.2f\n", e.annualSalary);
    return 0;
}
''')
add(913, r'''
#include <stdio.h>

struct Address
{
    char street[30];
    char city[20];
    int pin;
};

struct Person
{
    char name[20];
    struct Address addr;
};

int main(void)
{
    struct Person p = {"Karan Shah", {"12 MG Road", "Pune", 411001}};

    printf("Name   : %s\n", p.name);
    printf("Street : %s\n", p.addr.street);
    printf("City   : %s\n", p.addr.city);
    printf("PIN    : %d\n", p.addr.pin);
    return 0;
}
''')
add(914, r'''
#include <stdio.h>

struct Rect
{
    int length;
    int width;
};

/* receives a copy of the structure */
int area(struct Rect r)
{
    r.length = r.length + 100;   /* only changes the copy */
    return r.length * r.width;
}

int main(void)
{
    struct Rect r = {8, 5};
    int result;

    printf("Before call: length=%d width=%d\n", r.length, r.width);
    result = area(r);
    printf("Function returned (using modified copy): %d\n", result);
    printf("After call : length=%d width=%d (original unchanged)\n", r.length, r.width);
    return 0;
}
''')
add(915, r'''
#include <stdio.h>

struct Account
{
    int number;
    double balance;
};

void addInterest(struct Account *acc, double ratePercent)
{
    acc->balance += acc->balance * ratePercent / 100.0;
}

int main(void)
{
    struct Account a = {1001, 5000.0};

    printf("Before: account %d balance %.2f\n", a.number, a.balance);
    addInterest(&a, 6.0);
    printf("After 6%% interest: balance %.2f\n", a.balance);
    return 0;
}
''')
add(916, r'''
#include <stdio.h>

struct Point
{
    int x;
    int y;
};

struct Point makePoint(int x, int y)
{
    struct Point p;
    p.x = x;
    p.y = y;
    return p;
}

struct Point midpoint(struct Point a, struct Point b)
{
    return makePoint((a.x + b.x) / 2, (a.y + b.y) / 2);
}

int main(void)
{
    struct Point a = makePoint(2, 4), b = makePoint(10, 8);
    struct Point m = midpoint(a, b);

    printf("A = (%d, %d)\n", a.x, a.y);
    printf("B = (%d, %d)\n", b.x, b.y);
    printf("Midpoint = (%d, %d)\n", m.x, m.y);
    return 0;
}
''')
add(917, r'''
#include <stdio.h>
#include <stdlib.h>

struct Node
{
    int data;
    struct Node *next;   /* self-referential pointer */
};

int main(void)
{
    struct Node *head = NULL, *tail = NULL, *n, *cur;
    int values[4] = {10, 20, 30, 40};
    int i;

    for (i = 0; i < 4; i++)
    {
        n = (struct Node *)malloc(sizeof(struct Node));
        if (n == NULL)
        {
            printf("Memory allocation failed.\n");
            return 1;
        }
        n->data = values[i];
        n->next = NULL;
        if (head == NULL)
            head = n;
        else
            tail->next = n;
        tail = n;
    }

    printf("Linked list: ");
    for (cur = head; cur != NULL; cur = cur->next)
        printf("%d -> ", cur->data);
    printf("NULL\n");

    while (head != NULL)
    {
        cur = head;
        head = head->next;
        free(cur);
    }
    return 0;
}
''')
add(918, r'''
#include <stdio.h>

union Data
{
    int i;
    float f;
    char c;
};

int main(void)
{
    union Data d;

    d.i = 65;
    printf("Stored int   : %d\n", d.i);
    d.f = 3.5f;
    printf("Stored float : %.2f\n", d.f);
    d.c = 'Z';
    printf("Stored char  : %c\n", d.c);
    printf("(Only the most recently stored member is meaningful.)\n");
    return 0;
}
''')
add(919, r'''
#include <stdio.h>

struct S
{
    int i;
    double d;
    char c;
};

union U
{
    int i;
    double d;
    char c;
};

int main(void)
{
    printf("sizeof(int)    = %zu\n", sizeof(int));
    printf("sizeof(double) = %zu\n", sizeof(double));
    printf("sizeof(char)   = %zu\n", sizeof(char));
    printf("sizeof(struct S) = %zu (members stored separately, plus padding)\n", sizeof(struct S));
    printf("sizeof(union U)  = %zu (size of the largest member)\n", sizeof(union U));
    if (sizeof(struct S) > sizeof(union U))
        printf("The structure is larger than the union.\n");
    return 0;
}
''')
add(920, r'''
#include <stdio.h>

enum Day { MONDAY = 1, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY, SUNDAY };

int main(void)
{
    const char *names[] = {"", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"};
    enum Day d;

    for (d = MONDAY; d <= SUNDAY; d++)
        printf("Day %d = %s%s\n", d, names[d], (d == SATURDAY || d == SUNDAY) ? " (weekend)" : "");
    return 0;
}
''')
add(921, r'''
#include <stdio.h>

enum Light { RED, YELLOW, GREEN };

const char *action(enum Light l)
{
    switch (l)
    {
    case RED:
        return "STOP";
    case YELLOW:
        return "GET READY";
    case GREEN:
        return "GO";
    }
    return "UNKNOWN";
}

int main(void)
{
    enum Light cycle[4] = {RED, GREEN, YELLOW, RED};
    const char *names[] = {"RED", "YELLOW", "GREEN"};
    int i;

    for (i = 0; i < 4; i++)
        printf("Signal %-6s -> %s\n", names[cycle[i]], action(cycle[i]));
    return 0;
}
''')
add(922, r'''
#include <stdio.h>

typedef int Integer;
typedef float Real;
typedef unsigned char Byte;
typedef char *String;

int main(void)
{
    Integer count = 42;
    Real price = 99.75f;
    Byte level = 200;
    String msg = "typedef makes names clearer";

    printf("Integer : %d\n", count);
    printf("Real    : %.2f\n", price);
    printf("Byte    : %u\n", (unsigned)level);
    printf("String  : %s\n", msg);
    return 0;
}
''')
add(923, r'''
#include <stdio.h>

typedef struct
{
    int id;
    char name[20];
    float gpa;
} Student;

int main(void)
{
    Student a = {1, "Lata", 8.7f};
    Student b = {2, "Mohan", 7.9f};

    printf("%-3s %-8s %s\n", "ID", "Name", "GPA");
    printf("%-3d %-8s %.1f\n", a.id, a.name, a.gpa);
    printf("%-3d %-8s %.1f\n", b.id, b.name, b.gpa);
    return 0;
}
''')
add(924, r'''
#include <stdio.h>

typedef struct
{
    int code;
    char name[20];
    double price;
} Product;

int main(void)
{
    Product p[5] = {{1, "Notebook", 45.5}, {2, "Pen", 10.0}, {3, "Bag", 650.0}, {4, "Eraser", 5.25}, {5, "Compass", 120.0}};
    Product t;
    int i, j;

    for (i = 0; i < 4; i++)
        for (j = i + 1; j < 5; j++)
            if (p[i].price > p[j].price)
            {
                t = p[i];
                p[i] = p[j];
                p[j] = t;
            }

    printf("Products sorted by price (low to high):\n");
    for (i = 0; i < 5; i++)
        printf("%-10s Rs %8.2f (code %d)\n", p[i].name, p[i].price, p[i].code);
    return 0;
}
''')
add(925, r'''
#include <stdio.h>

typedef struct
{
    char name[20];
    int matches;
    int runs;
    int outs;
    double average;
} Player;

int main(void)
{
    Player team[3] = {{"Virat", 254, 12169, 230, 0}, {"Rohit", 262, 10709, 244, 0}, {"Dhoni", 350, 10773, 297, 0}};
    int i;

    printf("%-8s %7s %7s %8s\n", "Player", "Matches", "Runs", "Average");
    for (i = 0; i < 3; i++)
    {
        team[i].average = (double)team[i].runs / team[i].outs;
        printf("%-8s %7d %7d %8.2f\n", team[i].name, team[i].matches, team[i].runs, team[i].average);
    }
    return 0;
}
''')
