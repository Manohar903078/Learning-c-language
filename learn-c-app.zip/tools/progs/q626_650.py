# programs q626-q650 : id -> (stdin, code)
P = {}
def add(i, code, stdin=""): P[i] = (stdin, code.strip("\n"))

add(626, r'''
#include <stdio.h>

int main(void)
{
    int m[3][3] = {{9, 2, 7}, {4, 8, 1}, {6, 3, 5}};
    int i, j, k, t;

    for (j = 0; j < 3; j++)                 /* sort every column separately (bubble sort) */
        for (i = 0; i < 2; i++)
            for (k = 0; k < 2 - i; k++)
                if (m[k][j] > m[k + 1][j]) {
                    t = m[k][j]; m[k][j] = m[k + 1][j]; m[k + 1][j] = t;
                }
    printf("Matrix after sorting each column:\n");
    for (i = 0; i < 3; i++) {
        for (j = 0; j < 3; j++) printf("%4d", m[i][j]);
        printf("\n");
    }
    return 0;
}
''')
add(627, r'''
#include <stdio.h>

int main(void)
{
    int m[3][3] = {{5, 8, 9}, {2, 4, 6}, {7, 3, 10}};
    int i, j, k, found = 0;

    for (i = 0; i < 3; i++) {
        int min = m[i][0], col = 0;         /* minimum of row i */
        for (j = 1; j < 3; j++)
            if (m[i][j] < min) { min = m[i][j]; col = j; }
        int ismax = 1;                      /* is it the maximum of its column? */
        for (k = 0; k < 3; k++)
            if (m[k][col] > min) ismax = 0;
        if (ismax) {
            printf("Saddle point = %d at row %d, column %d\n", min, i, col);
            found = 1;
        }
    }
    if (!found) printf("No saddle point exists\n");
    return 0;
}
''')
add(628, r'''
#include <stdio.h>

int main(void)
{
    int m[4][4] = {{1, 2, 3, 4}, {5, 6, 7, 8}, {9, 10, 11, 12}, {13, 14, 15, 16}};
    int i, j, sum = 0;

    for (i = 0; i < 4; i++)
        for (j = 0; j < 4; j++)
            if (i == 0 || j == 0 || i == 3 || j == 3)   /* first/last row or column */
                sum += m[i][j];
    printf("Sum of boundary elements = %d\n", sum);
    return 0;
}
''')
add(629, r'''
#include <stdio.h>

int main(void)
{
    int m[3][3] = {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}};
    int i, j, t, r1 = 0, r2 = 2;

    for (j = 0; j < 3; j++) { t = m[r1][j]; m[r1][j] = m[r2][j]; m[r2][j] = t; }
    printf("After exchanging row %d and row %d:\n", r1, r2);
    for (i = 0; i < 3; i++) {
        for (j = 0; j < 3; j++) printf("%3d", m[i][j]);
        printf("\n");
    }
    return 0;
}
''')
add(630, r'''
#include <stdio.h>

int main(void)
{
    int m[3][3] = {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}};
    int i, j, t, c1 = 0, c2 = 2;

    for (i = 0; i < 3; i++) { t = m[i][c1]; m[i][c1] = m[i][c2]; m[i][c2] = t; }
    printf("After exchanging column %d and column %d:\n", c1, c2);
    for (i = 0; i < 3; i++) {
        for (j = 0; j < 3; j++) printf("%3d", m[i][j]);
        printf("\n");
    }
    return 0;
}
''')
add(631, r'''
#include <stdio.h>

int main(void)
{
    int m[3][3] = {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}};
    int i, j, sum = 0;

    for (i = 0; i < 3; i++)
        for (j = i + 1; j < 3; j++)        /* column index greater than row index */
            sum += m[i][j];
    printf("Sum of elements above the main diagonal = %d\n", sum);
    return 0;
}
''')
add(632, r'''
#include <stdio.h>

int main(void)
{
    int m[3][3] = {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}};
    int i, j, sum = 0;

    for (i = 1; i < 3; i++)
        for (j = 0; j < i; j++)            /* column index smaller than row index */
            sum += m[i][j];
    printf("Sum of elements below the main diagonal = %d\n", sum);
    return 0;
}
''')
add(633, r'''
#include <stdio.h>

int main(void)
{
    int m[2][2] = {{0, 1}, {-1, 0}};          /* a rotation matrix */
    int i, j, k, orthogonal = 1;

    for (i = 0; i < 2; i++)                   /* A x A-transpose must be the identity */
        for (j = 0; j < 2; j++) {
            int s = 0;
            for (k = 0; k < 2; k++) s += m[i][k] * m[j][k];
            if (s != (i == j ? 1 : 0)) orthogonal = 0;
        }
    printf("The matrix is %sorthogonal\n", orthogonal ? "" : "not ");
    return 0;
}
''')
add(634, r'''
#include <stdio.h>

int main(void)
{
    int m[3][3] = {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}};
    int d, i, j;

    printf("Diagonal order:\n");
    for (d = 0; d <= 4; d++) {                /* i + j is constant on each diagonal */
        for (i = 0; i < 3; i++) {
            j = d - i;
            if (j >= 0 && j < 3) printf("%d ", m[i][j]);
        }
        printf("\n");
    }
    return 0;
}
''')
add(635, r'''
#include <stdio.h>

int main(void)
{
    int m[2][3] = {{1, 2, 3}, {4, 5, 6}};
    int k = 4, i, j;

    for (i = 0; i < 2; i++)
        for (j = 0; j < 3; j++) m[i][j] *= k;
    printf("Matrix multiplied by %d:\n", k);
    for (i = 0; i < 2; i++) {
        for (j = 0; j < 3; j++) printf("%4d", m[i][j]);
        printf("\n");
    }
    return 0;
}
''')
add(636, r'''
#include <stdio.h>

int main(void)
{
    int r, c, i, j, m[10][10];

    printf("Enter rows and columns: ");
    scanf("%d %d", &r, &c);
    printf("Enter %d elements:\n", r * c);
    for (i = 0; i < r; i++)
        for (j = 0; j < c; j++) scanf("%d", &m[i][j]);
    printf("The matrix is:\n");
    for (i = 0; i < r; i++) {
        for (j = 0; j < c; j++) printf("%4d", m[i][j]);
        printf("\n");
    }
    return 0;
}
''', "2 3\n1 2 3\n4 5 6")
add(637, r'''
#include <stdio.h>

void add(int a[2][2], int b[2][2], int s[2][2])      /* separate user-defined function */
{
    for (int i = 0; i < 2; i++)
        for (int j = 0; j < 2; j++) s[i][j] = a[i][j] + b[i][j];
}

int main(void)
{
    int a[2][2], b[2][2], s[2][2], i, j;

    printf("Enter first matrix (4 values): ");
    for (i = 0; i < 2; i++) for (j = 0; j < 2; j++) scanf("%d", &a[i][j]);
    printf("Enter second matrix (4 values): ");
    for (i = 0; i < 2; i++) for (j = 0; j < 2; j++) scanf("%d", &b[i][j]);
    add(a, b, s);
    printf("Sum:\n");
    for (i = 0; i < 2; i++) printf("%4d%4d\n", s[i][0], s[i][1]);
    return 0;
}
''', "1 2 3 4\n5 6 7 8")
add(638, r'''
#include <stdio.h>

int main(void)
{
    int r1, c1, r2, c2, i, j;
    int a[5][5], b[5][5];

    printf("Enter rows and columns of matrix A: ");
    if (scanf("%d %d", &r1, &c1) != 2 || r1 < 1 || r1 > 5 || c1 < 1 || c1 > 5) { printf("Error: size must be 1 to 5\n"); return 1; }
    printf("Enter rows and columns of matrix B: ");
    if (scanf("%d %d", &r2, &c2) != 2) { printf("Error: invalid input\n"); return 1; }
    if (r1 != r2 || c1 != c2) { printf("Error: subtraction needs matrices of the same size\n"); return 1; }
    printf("Enter A: ");
    for (i = 0; i < r1; i++) for (j = 0; j < c1; j++) scanf("%d", &a[i][j]);
    printf("Enter B: ");
    for (i = 0; i < r1; i++) for (j = 0; j < c1; j++) scanf("%d", &b[i][j]);
    printf("A - B:\n");
    for (i = 0; i < r1; i++) {
        for (j = 0; j < c1; j++) printf("%4d", a[i][j] - b[i][j]);
        printf("\n");
    }
    return 0;
}
''', "2 2\n2 2\n9 8 7 6\n1 2 3 4")
add(639, r'''
#include <stdio.h>

static void multiply(int a[2][2], int b[2][2])
{
    int i, j, k;
    for (i = 0; i < 2; i++) {
        for (j = 0; j < 2; j++) {
            int s = 0;
            for (k = 0; k < 2; k++) s += a[i][k] * b[k][j];
            printf("%5d", s);
        }
        printf("\n");
    }
}

int main(void)
{
    int a1[2][2] = {{1, 2}, {3, 4}}, b1[2][2] = {{5, 6}, {7, 8}};
    int a2[2][2] = {{1, 0}, {0, 1}}, b2[2][2] = {{9, 8}, {7, 6}};          /* identity matrix */
    int a3[2][2] = {{2, -1}, {0, 3}}, b3[2][2] = {{1, 1}, {1, 1}};

    printf("Test 1:\n"); multiply(a1, b1);
    printf("Test 2 (identity):\n"); multiply(a2, b2);
    printf("Test 3 (negative values):\n"); multiply(a3, b3);
    return 0;
}
''')
add(640, r'''
#include <stdio.h>

int main(void)
{
    int a[2][3] = {{1, 2, 3}, {4, 5, 6}}, t[3][2];
    int i, j;

    /* element at row i, column j moves to row j, column i */
    for (i = 0; i < 2; i++)
        for (j = 0; j < 3; j++)
            t[j][i] = a[i][j];
    printf("Transpose:\n");
    for (i = 0; i < 3; i++) {
        for (j = 0; j < 2; j++) printf("%3d", t[i][j]);
        printf("\n");
    }
    return 0;
}
''')
add(641, r'''
#include <stdio.h>

int main(void)
{
    int r, c, i, j, m[10][10];

    printf("Enter rows and columns (1 to 10): ");
    if (scanf("%d %d", &r, &c) != 2 || r < 1 || c < 1 || r > 10 || c > 10) { printf("Invalid size\n"); return 1; }
    for (i = 0; i < r; i++) for (j = 0; j < c; j++) scanf("%d", &m[i][j]);
    for (i = 0; i < r; i++) {
        int s = 0;
        for (j = 0; j < c; j++) s += m[i][j];
        printf("Sum of row %d = %d\n", i + 1, s);
    }
    return 0;
}
''', "1 4\n3 -3 10 0")
add(642, r'''
#include <stdio.h>

int main(void)
{
    int m[3][3] = {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}};
    int choice, i, j, s;

    do {
        printf("\n1. Sum of each column\n2. Sum of each row\n3. Exit\nChoice: ");
        scanf("%d", &choice);
        if (choice == 1)
            for (j = 0; j < 3; j++) { for (s = 0, i = 0; i < 3; i++) s += m[i][j]; printf("Column %d sum = %d\n", j + 1, s); }
        else if (choice == 2)
            for (i = 0; i < 3; i++) { for (s = 0, j = 0; j < 3; j++) s += m[i][j]; printf("Row %d sum = %d\n", i + 1, s); }
    } while (choice != 3);
    return 0;
}
''', "1\n2\n3")
add(643, r'''
#include <stdio.h>

int main(void)
{
    int m[3][3] = {{4, 1, 2}, {3, 5, 6}, {7, 8, 9}};
    int i, sum = 0;

    for (i = 0; i < 3; i++) {
        printf("Add m[%d][%d] = %d\n", i, i, m[i][i]);
        sum += m[i][i];
        printf("  running sum = %d\n", sum);
    }
    printf("Main diagonal sum = %d\n", sum);
    return 0;
}
''')
add(644, r'''
#include <stdio.h>

int main(void)
{
    int m[3][3] = {{4, 1, 2}, {3, 5, 6}, {7, 8, 9}};
    int i, sum = 0;

    for (i = 0; i < 3; i++)
        sum += m[i][2 - i];                 /* column = (n - 1) - row */
    printf("Secondary diagonal sum = %d\n", sum);
    return 0;
}
''')
add(645, r'''
#include <stdio.h>

int main(void)
{
    int r, c, i, j, m[10][10];
    int *p;

    printf("Enter rows and columns: ");
    scanf("%d %d", &r, &c);
    p = &m[0][0];
    for (i = 0; i < r; i++)
        for (j = 0; j < c; j++) scanf("%d", p + i * 10 + j);   /* pointer used to fill the array */
    printf("The matrix is %ssquare\n", r == c ? "" : "not ");
    for (i = 0; i < r; i++) {
        for (j = 0; j < c; j++) printf("%3d", *(p + i * 10 + j));
        printf("\n");
    }
    return 0;
}
''', "2 3\n1 2 3\n4 5 6")
add(646, r'''
#include <stdio.h>

int main(void)
{
    int m[3][3] = {{1, 0, 0}, {0, 1, 0}, {0, 0, 1}};
    int i, j, identity = 1;

    for (i = 0; i < 3; i++)
        for (j = 0; j < 3; j++)
            if ((i == j && m[i][j] != 1) || (i != j && m[i][j] != 0))
                identity = 0;
    printf("The matrix is %san identity matrix\n", identity ? "" : "not ");
    return 0;
}
''')
add(647, r'''
#include <stdio.h>

struct Matrix { int rows, cols, data[5][5]; };

int main(void)
{
    struct Matrix m = {3, 3, {{5, 0, 0}, {0, 7, 0}, {0, 0, 9}}};
    int i, j, diagonal = 1;

    for (i = 0; i < m.rows; i++)
        for (j = 0; j < m.cols; j++)
            if (i != j && m.data[i][j] != 0) diagonal = 0;
    printf("The matrix is %sa diagonal matrix\n", diagonal ? "" : "not ");
    return 0;
}
''')
add(648, r'''
#include <stdio.h>

int main(void)
{
    int n, k, i, j, m[5][5];

    scanf("%d", &n);                         /* number of matrices to check */
    for (k = 1; k <= n; k++) {
        int upper = 1;
        for (i = 0; i < 3; i++) for (j = 0; j < 3; j++) scanf("%d", &m[i][j]);
        for (i = 1; i < 3; i++)
            for (j = 0; j < i; j++)
                if (m[i][j] != 0) upper = 0;
        printf("Matrix %d: %s\n", k, upper ? "upper triangular" : "not upper triangular");
    }
    return 0;
}
''', "2\n1 2 3\n0 4 5\n0 0 6\n1 2 3\n4 5 6\n0 0 7")
add(649, r'''
#include <stdio.h>

int main(void)
{
    int m[3][3] = {{1, 0, 0}, {2, 3, 0}, {4, 5, 6}};
    int i, j, lower = 1;

    for (i = 0; i < 3; i++)
        for (j = i + 1; j < 3; j++)
            if (m[i][j] != 0) lower = 0;
    printf("+---------------------------+\n");
    printf("| Lower triangular check    |\n");
    printf("+---------------------------+\n");
    printf("| Result: %-18s|\n", lower ? "YES" : "NO");
    printf("+---------------------------+\n");
    return 0;
}
''')
add(650, r'''
#include <stdio.h>

int main(void)
{
    int n, i, j, m[10][10], symmetric = 1;

    printf("Enter order of the square matrix (1-10): ");
    if (scanf("%d", &n) != 1 || n < 1 || n > 10) { printf("Invalid order\n"); return 1; }
    for (i = 0; i < n; i++)
        for (j = 0; j < n; j++)
            if (scanf("%d", &m[i][j]) != 1) { printf("Invalid element\n"); return 1; }
    for (i = 0; i < n; i++)
        for (j = 0; j < n; j++)
            if (m[i][j] != m[j][i]) symmetric = 0;
    printf("The matrix is %ssymmetric\n", symmetric ? "" : "not ");
    return 0;
}
''', "3\n1 7 3\n7 4 5\n3 5 9")
