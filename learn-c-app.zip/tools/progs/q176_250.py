# programs 176-200, 226-250 : id -> (stdin, code)
P = {}
def add(i, code, stdin=""): P[i] = (stdin, code.strip("\n"))

add(176, r'''
#include <stdio.h>

int main(void)
{
    double number;

    printf("Enter a number: ");
    if (scanf("%lf", &number) != 1) {
        printf("Invalid input.\n");
        return 1;
    }

    if (number > 0)
        printf("%g is positive.\n", number);
    else if (number < 0)
        printf("%g is negative.\n", number);
    else
        printf("The number is zero.\n");
    return 0;
}
''', "-7.5")

add(177, r'''
#include <stdio.h>

/* returns 1 if n is even, 0 otherwise */
int isEven(int n)
{
    return n % 2 == 0;
}

int main(void)
{
    int n;

    printf("Enter an integer: ");
    if (scanf("%d", &n) != 1) {
        printf("Invalid input.\n");
        return 1;
    }
    printf("%d is %s.\n", n, isEven(n) ? "even" : "odd");
    return 0;
}
''', "28")

add(178, r'''
#include <stdio.h>

int main(void)
{
    double a, b;

    printf("Enter two numbers: ");
    if (scanf("%lf %lf", &a, &b) != 2) {
        printf("Error: please enter two valid numbers.\n");
        return 1;
    }

    if (a == b)
        printf("Both numbers are equal (%g).\n", a);
    else
        printf("The larger number is %g.\n", a > b ? a : b);
    return 0;
}
''', "12.5 9")

add(179, r'''
#include <stdio.h>

int main(void)
{
    int a, b, c, largest, t;

    /* three different test cases are read one after another */
    for (t = 1; t <= 3; t++) {
        printf("Test %d - enter three numbers: ", t);
        if (scanf("%d %d %d", &a, &b, &c) != 3) {
            printf("Invalid input.\n");
            return 1;
        }
        largest = a;
        if (b > largest) largest = b;
        if (c > largest) largest = c;
        printf("  Largest of %d, %d, %d is %d\n", a, b, c, largest);
    }
    return 0;
}
''', "4 9 2\n-5 -1 -8\n7 7 3")

add(180, r'''
#include <stdio.h>

int main(void)
{
    int a, b, c, smallest;

    printf("Enter three integers: ");
    if (scanf("%d %d %d", &a, &b, &c) != 3) {
        printf("Invalid input.\n");
        return 1;
    }

    /* assume a is smallest, then replace it if b or c is smaller */
    smallest = a;
    if (b < smallest)
        smallest = b;
    if (c < smallest)
        smallest = c;

    printf("Smallest of %d, %d and %d is %d\n", a, b, c, smallest);
    return 0;
}
''', "15 8 23")

add(181, r'''
#include <stdio.h>

int main(void)
{
    int n, i, year;

    printf("How many years to check? ");
    if (scanf("%d", &n) != 1 || n < 1) {
        printf("Invalid count.\n");
        return 1;
    }
    for (i = 0; i < n; i++) {
        printf("Enter year: ");
        if (scanf("%d", &year) != 1 || year < 1) {
            printf("Invalid year.\n");
            return 1;
        }
        /* divisible by 400, or by 4 but not by 100 */
        if ((year % 400 == 0) || (year % 4 == 0 && year % 100 != 0))
            printf("%d is a leap year.\n", year);
        else
            printf("%d is not a leap year.\n", year);
    }
    return 0;
}
''', "6\n1900 2000 2024 2023 2100 1600")

add(182, r'''
#include <stdio.h>

int main(void)
{
    int choice, age;

    do {
        printf("\n1. Check voting eligibility\n2. Exit\nChoice: ");
        if (scanf("%d", &choice) != 1)
            return 1;
        switch (choice) {
        case 1:
            printf("Enter age: ");
            if (scanf("%d", &age) != 1 || age < 0) {
                printf("Invalid age.\n");
                return 1;
            }
            if (age >= 18)
                printf("Age %d: eligible to vote.\n", age);
            else
                printf("Age %d: not eligible, %d more year(s) to wait.\n", age, 18 - age);
            break;
        case 2:
            printf("Goodbye!\n");
            break;
        default:
            printf("Invalid choice.\n");
        }
    } while (choice != 2);
    return 0;
}
''', "1 17 1 18 2")

add(183, r'''
#include <stdio.h>

int main(void)
{
    char ch;

    printf("Enter a character: ");
    if (scanf(" %c", &ch) != 1)
        return 1;

    printf("Step 1: character = '%c', ASCII code = %d\n", ch, ch);
    printf("Step 2: is it between 'A' and 'Z'? %s\n", (ch >= 'A' && ch <= 'Z') ? "yes" : "no");
    printf("Step 3: is it between 'a' and 'z'? %s\n", (ch >= 'a' && ch <= 'z') ? "yes" : "no");

    if (ch >= 'A' && ch <= 'Z')
        printf("Result: '%c' is an uppercase letter.\n", ch);
    else if (ch >= 'a' && ch <= 'z')
        printf("Result: '%c' is a lowercase letter.\n", ch);
    else
        printf("Result: '%c' is not a letter.\n", ch);
    return 0;
}
''', "g")

add(184, r'''
#include <stdio.h>

int main(void)
{
    char ch;
    int i;

    /* a loop checks five characters with the same code */
    for (i = 1; i <= 5; i++) {
        printf("Enter character %d: ", i);
        if (scanf(" %c", &ch) != 1)
            return 1;
        if (ch >= '0' && ch <= '9')
            printf("  '%c' is a digit.\n", ch);
        else
            printf("  '%c' is a non-digit.\n", ch);
    }
    return 0;
}
''', "a 7 # 0 Z")

add(185, r'''
#include <stdio.h>

/* returns 1 for a vowel; the character is read through a pointer */
int isVowel(const char *p)
{
    char c = *p;
    if (c >= 'A' && c <= 'Z')
        c = c - 'A' + 'a';        /* convert to lowercase */
    return c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u';
}

int main(void)
{
    char ch;
    char *ptr = &ch;

    printf("Enter an alphabet: ");
    if (scanf(" %c", ptr) != 1)
        return 1;
    if (!((*ptr >= 'a' && *ptr <= 'z') || (*ptr >= 'A' && *ptr <= 'Z'))) {
        printf("'%c' is not an alphabet.\n", *ptr);
        return 0;
    }
    printf("'%c' is a %s.\n", *ptr, isVowel(ptr) ? "vowel" : "consonant");
    return 0;
}
''', "E")

add(186, r'''
#include <stdio.h>

int main(void)
{
    double side[3];
    int i;

    for (i = 0; i < 3; i++) {
        printf("Enter side %d: ", i + 1);
        if (scanf("%lf", &side[i]) != 1 || side[i] <= 0) {
            printf("Sides must be positive numbers.\n");
            return 1;
        }
    }

    /* sum of any two sides must exceed the third */
    if (side[0] + side[1] > side[2] &&
        side[1] + side[2] > side[0] &&
        side[0] + side[2] > side[1])
        printf("Sides %g, %g, %g can form a triangle.\n", side[0], side[1], side[2]);
    else
        printf("Sides %g, %g, %g cannot form a triangle.\n", side[0], side[1], side[2]);
    return 0;
}
''', "7 10 5\n")

add(187, r'''
#include <stdio.h>

struct Triangle {
    double a, b, c;
};

int main(void)
{
    struct Triangle t;

    printf("Enter three sides: ");
    if (scanf("%lf %lf %lf", &t.a, &t.b, &t.c) != 3 || t.a <= 0 || t.b <= 0 || t.c <= 0) {
        printf("Invalid sides.\n");
        return 1;
    }
    if (t.a + t.b <= t.c || t.b + t.c <= t.a || t.a + t.c <= t.b) {
        printf("These sides do not form a triangle.\n");
        return 0;
    }

    if (t.a == t.b && t.b == t.c)
        printf("Equilateral triangle (all sides equal).\n");
    else if (t.a == t.b || t.b == t.c || t.a == t.c)
        printf("Isosceles triangle (two sides equal).\n");
    else
        printf("Scalene triangle (all sides different).\n");
    return 0;
}
''', "5 5 8")

add(188, r'''
#include <stdio.h>

int main(void)
{
    int n, i, a, b, c, tmp;

    printf("Number of triangles: ");
    if (scanf("%d", &n) != 1 || n < 1) {
        printf("Invalid count.\n");
        return 1;
    }
    for (i = 1; i <= n; i++) {
        if (scanf("%d %d %d", &a, &b, &c) != 3) {
            printf("Invalid sides.\n");
            return 1;
        }
        /* make c the largest side (the possible hypotenuse) */
        if (a > c) { tmp = a; a = c; c = tmp; }
        if (b > c) { tmp = b; b = c; c = tmp; }
        printf("Triangle %d (%d, %d, %d): %s\n", i, a, b, c,
               (a * a + b * b == c * c) ? "right-angled" : "not right-angled");
    }
    return 0;
}
''', "3\n3 4 5\n13 5 12\n6 7 8")

add(189, r'''
#include <stdio.h>

int main(void)
{
    int marks;
    char grade;

    printf("Grading scale: 90-100 A, 80-89 B, 70-79 C, 60-69 D, 40-59 E, below 40 F\n");
    printf("Enter marks (0-100): ");
    if (scanf("%d", &marks) != 1 || marks < 0 || marks > 100) {
        printf("Marks must be between 0 and 100.\n");
        return 1;
    }

    if (marks >= 90) grade = 'A';
    else if (marks >= 80) grade = 'B';
    else if (marks >= 70) grade = 'C';
    else if (marks >= 60) grade = 'D';
    else if (marks >= 40) grade = 'E';
    else grade = 'F';

    printf("\n+-----------+-------+\n");
    printf("| Marks     | %5d |\n", marks);
    printf("| Grade     | %5c |\n", grade);
    printf("| Result    | %5s |\n", grade == 'F' ? "FAIL" : "PASS");
    printf("+-----------+-------+\n");
    return 0;
}
''', "78")

add(190, r'''
#include <stdio.h>

int main(void)
{
    int units;
    double bill;

    /* slabs: first 100 units Rs5, next 100 units Rs7, above 200 units Rs10 */
    printf("Enter units consumed: ");
    if (scanf("%d", &units) != 1 || units < 0) {
        printf("Error: units must be a non-negative integer.\n");
        return 1;
    }

    if (units <= 100)
        bill = units * 5.0;
    else if (units <= 200)
        bill = 100 * 5.0 + (units - 100) * 7.0;
    else
        bill = 100 * 5.0 + 100 * 7.0 + (units - 200) * 10.0;

    bill += 50;                       /* fixed meter charge */
    printf("Units: %d\nBill (with Rs50 fixed charge): Rs%.2f\n", units, bill);
    return 0;
}
''', "250")

add(191, r'''
#include <stdio.h>

/* slabs: up to 2.5L nil, 2.5-5L 5%, 5-10L 20%, above 10L 30% */
double calcTax(double income)
{
    double tax = 0;
    if (income > 1000000) { tax += (income - 1000000) * 0.30; income = 1000000; }
    if (income > 500000)  { tax += (income - 500000) * 0.20;  income = 500000; }
    if (income > 250000)  { tax += (income - 250000) * 0.05; }
    return tax;
}

int readIncome(double *income)
{
    printf("Enter annual income: ");
    return scanf("%lf", income) == 1 && *income >= 0;
}

int main(void)
{
    double income;

    if (!readIncome(&income)) {
        printf("Invalid income.\n");
        return 1;
    }
    printf("Income : %.2f\nTax    : %.2f\n", income, calcTax(income));
    return 0;
}
''', "750000")

add(192, r'''
#include <stdio.h>

int main(void)
{
    long long n, result;

    printf("Enter an integer: ");
    if (scanf("%lld", &n) != 1) {
        printf("Invalid input.\n");
        return 1;
    }
    /* one comparison and at most one negation: O(1) time, O(1) space */
    result = (n < 0) ? -n : n;
    printf("Absolute value of %lld is %lld\n", n, result);
    return 0;
}
''', "-42")

add(193, r'''
#include <stdio.h>
#include <limits.h>

int main(void)
{
    /* normal, zero, minimum and maximum int values */
    long long tests[] = {55, 110, 25, 0, 1, INT_MIN, INT_MAX};
    int count = (int)(sizeof tests / sizeof tests[0]);
    int i;

    for (i = 0; i < count; i++) {
        long long n = tests[i];
        if (n % 5 == 0 && n % 11 == 0)
            printf("%11lld : divisible by both 5 and 11\n", n);
        else
            printf("%11lld : NOT divisible by both\n", n);
    }
    return 0;
}
''')

add(194, r'''
#include <stdio.h>

/* returns number of digits of n (sign ignored) */
int countDigits(long n)
{
    int d = 1;
    if (n < 0) n = -n;
    while (n >= 10) {
        n /= 10;
        d++;
    }
    return d;
}

int main(void)
{
    long n;
    int d;

    printf("Enter an integer: ");
    if (scanf("%ld", &n) != 1) {
        printf("Invalid input.\n");
        return 1;
    }
    d = countDigits(n);
    if (d == 2)
        printf("%ld is a two-digit number.\n", n);
    else if (d == 3)
        printf("%ld is a three-digit number.\n", n);
    else
        printf("%ld has %d digit(s): neither two nor three.\n", n, d);
    return 0;
}
''', "-345")

add(195, r'''
#include <stdio.h>

int main(void)
{
    int a, b, c, middle;

    printf("Enter three distinct integers: ");
    if (scanf("%d %d %d", &a, &b, &c) != 3) {
        printf("Error: three integers are required.\n");
        return 1;
    }
    if (a == b || b == c || a == c) {
        printf("Error: the numbers must be distinct.\n");
        return 1;
    }

    if ((a > b && a < c) || (a < b && a > c))
        middle = a;
    else if ((b > a && b < c) || (b < a && b > c))
        middle = b;
    else
        middle = c;
    printf("Middle value of %d, %d, %d is %d\n", a, b, c, middle);
    return 0;
}
''', "30 10 20")

add(196, r'''
#include <stdio.h>

int main(void)
{
    int age;

    printf("Enter your age: ");
    if (scanf("%d", &age) != 1 || age < 0 || age > 150) {
        printf("Invalid age.\n");
        return 1;
    }
    /* Time: one comparison, O(1). Space: one int variable, O(1). */
    if (age >= 18)
        printf("You are eligible to vote.\n");
    else
        printf("You are not eligible to vote yet.\n");
    return 0;
}
''', "21")

add(197, r'''
#include <stdio.h>

int main(void)
{
    char ch;

    printf("Enter a single character: ");
    if (scanf(" %c", &ch) != 1) {
        printf("No input.\n");
        return 1;
    }
    if (ch >= '0' && ch <= '9')
        printf("'%c' is a digit (value %d).\n", ch, ch - '0');
    else
        printf("'%c' is a non-digit.\n", ch);
    return 0;
}
''', "x")

add(198, r'''
#include <stdio.h>

int main(void)
{
    double a, b, c;

    printf("Enter three side lengths: ");
    if (scanf("%lf %lf %lf", &a, &b, &c) != 3) {
        printf("Invalid input.\n");
        return 1;
    }

    /* Triangle inequality: every pair of sides must be longer than the third.
       Zero or negative lengths are rejected first. */
    if (a <= 0 || b <= 0 || c <= 0)
        printf("Sides must be positive.\n");
    else if (a + b > c && a + c > b && b + c > a)
        printf("Valid triangle.\n");
    else
        printf("Not a valid triangle: %g + %g = %g is not greater than %g.\n",
               a < b ? a : b, a < b ? b : a, a + b, c);
    return 0;
}
''', "5 7 15")

add(199, r'''
#include <stdio.h>

int main(void)
{
    double s[3], largest, sumSquares = 0;
    int i, big = 0;

    for (i = 0; i < 3; i++) {
        printf("Enter side %d: ", i + 1);
        if (scanf("%lf", &s[i]) != 1 || s[i] <= 0) {
            printf("Invalid side.\n");
            return 1;
        }
    }
    /* loop finds the longest side and adds squares of the other two */
    largest = s[0];
    for (i = 1; i < 3; i++)
        if (s[i] > largest) { largest = s[i]; big = i; }
    for (i = 0; i < 3; i++)
        if (i != big) sumSquares += s[i] * s[i];

    printf("%g^2 = %g, other squares sum = %g\n", largest, largest * largest, sumSquares);
    printf("%s\n", sumSquares == largest * largest ? "Right-angled triangle." : "Not right-angled.");
    return 0;
}
''', "8 15 17")

add(200, r'''
#include <stdio.h>

int main(void)
{
    int n, i, units;
    double bill;

    /* rates: first 100 units Rs4, next 100 units Rs6, rest Rs9 */
    printf("Number of customers: ");
    if (scanf("%d", &n) != 1 || n < 1) {
        printf("Invalid count.\n");
        return 1;
    }
    printf("%-10s %-8s %-10s\n", "Customer", "Units", "Bill(Rs)");
    for (i = 1; i <= n; i++) {
        if (scanf("%d", &units) != 1 || units < 0) {
            printf("Invalid units.\n");
            return 1;
        }
        if (units <= 100) bill = units * 4.0;
        else if (units <= 200) bill = 400 + (units - 100) * 6.0;
        else bill = 400 + 600 + (units - 200) * 9.0;
        printf("%-10d %-8d %-10.2f\n", i, units, bill);
    }
    return 0;
}
''', "3\n80 150 320")

add(226, r'''
#include <stdio.h>

int main(void)
{
    double a, b;
    char op;

    printf("Enter expression (e.g. 12 * 4): ");
    if (scanf("%lf %c %lf", &a, &op, &b) != 3) {
        printf("Invalid expression.\n");
        return 1;
    }
    switch (op) {
    case '+': printf("%g + %g = %g\n", a, b, a + b); break;
    case '-': printf("%g - %g = %g\n", a, b, a - b); break;
    case '*': printf("%g * %g = %g\n", a, b, a * b); break;
    case '/':
        if (b == 0)
            printf("Error: division by zero.\n");
        else
            printf("%g / %g = %g\n", a, b, a / b);
        break;
    default:
        printf("Unknown operator '%c'.\n", op);
    }
    return 0;
}
''', "20 / 8")

add(227, r'''
#include <stdio.h>

const char *dayName(int d)
{
    switch (d) {
    case 1: return "Monday";
    case 2: return "Tuesday";
    case 3: return "Wednesday";
    case 4: return "Thursday";
    case 5: return "Friday";
    case 6: return "Saturday";
    case 7: return "Sunday";
    default: return "Invalid day";
    }
}

int main(void)
{
    int d;

    printf("Enter a number (1-7): ");
    if (scanf("%d", &d) != 1)
        return 1;
    printf("Day %d is %s\n", d, dayName(d));
    return 0;
}
''', "6")

add(228, r'''
#include <stdio.h>

int main(void)
{
    static const char *months[] = {"January", "February", "March", "April", "May", "June",
        "July", "August", "September", "October", "November", "December"};
    int m, r;

    for (;;) {
        printf("Enter month number (1-12): ");
        r = scanf("%d", &m);
        if (r != 1) {
            printf("Error: input must be a number.\n");
            return 1;
        }
        if (m >= 1 && m <= 12)
            break;
        printf("Error: %d is out of range, try again.\n", m);
    }
    printf("Month %d is %s.\n", m, months[m - 1]);
    return 0;
}
''', "13 0 9")

add(229, r'''
#include <stdio.h>

int main(void)
{
    int digit, i;

    for (i = 1; i <= 3; i++) {
        printf("Sample %d - enter a digit (0-9): ", i);
        if (scanf("%d", &digit) != 1)
            return 1;
        switch (digit) {
        case 0: printf("Zero\n"); break;
        case 1: printf("One\n"); break;
        case 2: printf("Two\n"); break;
        case 3: printf("Three\n"); break;
        case 4: printf("Four\n"); break;
        case 5: printf("Five\n"); break;
        case 6: printf("Six\n"); break;
        case 7: printf("Seven\n"); break;
        case 8: printf("Eight\n"); break;
        case 9: printf("Nine\n"); break;
        default: printf("%d is not a single digit\n", digit);
        }
    }
    return 0;
}
''', "7 0 12")

add(230, r'''
#include <stdio.h>

#define PI 3.14159265

int main(void)
{
    int choice;
    double x, y;

    do {
        printf("\n1. Circle  2. Rectangle  3. Triangle  4. Exit\nChoice: ");
        if (scanf("%d", &choice) != 1)
            return 1;
        switch (choice) {
        case 1:                               /* area = pi * r^2 */
            scanf("%lf", &x);
            printf("Area of circle (r=%g) = %.2f\n", x, PI * x * x);
            break;
        case 2:                               /* area = length * width */
            scanf("%lf %lf", &x, &y);
            printf("Area of rectangle (%g x %g) = %.2f\n", x, y, x * y);
            break;
        case 3:                               /* area = 0.5 * base * height */
            scanf("%lf %lf", &x, &y);
            printf("Area of triangle (b=%g, h=%g) = %.2f\n", x, y, 0.5 * x * y);
            break;
        case 4:
            printf("Bye!\n");
            break;
        default:
            printf("Invalid choice.\n");
        }
    } while (choice != 4);
    return 0;
}
''', "1 3.5 2 6 4 3 8 5 4")

add(231, r'''
#include <stdio.h>

int main(void)
{
    int choice;
    double t;

    do {
        printf("\n1. Celsius to Fahrenheit\n2. Fahrenheit to Celsius\n3. Exit\nChoice: ");
        if (scanf("%d", &choice) != 1)
            return 1;
        if (choice == 1 || choice == 2) {
            printf("Enter temperature: ");
            if (scanf("%lf", &t) != 1)
                return 1;
        }
        switch (choice) {
        case 1:
            if (t < -273.15)
                printf("Below absolute zero (-273.15 C)!\n");
            else
                printf("%.2f C = %.2f F\n", t, t * 9 / 5 + 32);
            break;
        case 2:
            if (t < -459.67)
                printf("Below absolute zero (-459.67 F)!\n");
            else
                printf("%.2f F = %.2f C\n", t, (t - 32) * 5 / 9);
            break;
        case 3:
            printf("Done.\n");
            break;
        default:
            printf("Invalid choice.\n");
        }
    } while (choice != 3);
    return 0;
}
''', "1 100 2 -500 1 -273.15 2 32 3")

add(232, r'''
#include <stdio.h>

int main(void)
{
    int choice;
    double a, b;

    do {
        printf("\n1.Add 2.Subtract 3.Multiply 4.Divide 5.Exit\nChoice: ");
        if (scanf("%d", &choice) != 1)
            return 1;
        if (choice >= 1 && choice <= 4) {
            printf("Enter two numbers: ");
            if (scanf("%lf %lf", &a, &b) != 2)
                return 1;
        }
        switch (choice) {
        case 1: printf("Result = %g\n", a + b); break;
        case 2: printf("Result = %g\n", a - b); break;
        case 3: printf("Result = %g\n", a * b); break;
        case 4:
            if (b == 0) printf("Cannot divide by zero.\n");
            else printf("Result = %g\n", a / b);
            break;
        case 5: printf("Exiting.\n"); break;
        default: printf("Invalid choice.\n");
        }
    } while (choice != 5);
    return 0;
}
''', "1 8 2\n4 20 0\n3 6 7\n4 9 2\n5")

add(233, r'''
#include <stdio.h>

int main(void)
{
    int choice;
    double v;

    do {
        printf("\n1. km to m  2. m to cm  3. cm to m  4. m to km  5. Exit\nChoice: ");
        if (scanf("%d", &choice) != 1)
            return 1;
        if (choice >= 1 && choice <= 4) {
            printf("Enter value: ");
            if (scanf("%lf", &v) != 1)
                return 1;
        }
        switch (choice) {
        case 1:
            printf("Step: %g km x 1000 = %g m\n", v, v * 1000);
            break;
        case 2:
            printf("Step: %g m x 100 = %g cm\n", v, v * 100);
            break;
        case 3:
            printf("Step: %g cm / 100 = %g m\n", v, v / 100);
            break;
        case 4:
            printf("Step: %g m / 1000 = %g km\n", v, v / 1000);
            break;
        case 5:
            printf("Goodbye.\n");
            break;
        default:
            printf("Invalid choice.\n");
        }
    } while (choice != 5);
    return 0;
}
''', "1 2.5 2 130 3 4500 4 750 5")

add(234, r'''
#include <stdio.h>

int main(void)
{
    int year, month, days, leap;

    printf("Enter a year: ");
    if (scanf("%d", &year) != 1 || year < 1) {
        printf("Invalid year.\n");
        return 1;
    }
    leap = (year % 400 == 0) || (year % 4 == 0 && year % 100 != 0);

    printf("Days in each month of %d:\n", year);
    for (month = 1; month <= 12; month++) {
        switch (month) {
        case 4: case 6: case 9: case 11:
            days = 30;
            break;
        case 2:
            days = leap ? 29 : 28;
            break;
        default:
            days = 31;
        }
        printf("  Month %2d : %d days\n", month, days);
    }
    return 0;
}
''', "2024")

add(235, r'''
#include <stdio.h>
#include <math.h>

/* results are returned through pointers */
void interest(double p, double r, double t, double *si, double *ci)
{
    *si = p * r * t / 100.0;
    *ci = p * pow(1 + r / 100.0, t) - p;
}

int main(void)
{
    int choice;
    double p, r, t, si, ci;

    printf("1. Simple interest\n2. Compound interest\nChoice: ");
    if (scanf("%d", &choice) != 1)
        return 1;
    if (choice != 1 && choice != 2) {
        printf("Invalid choice.\n");
        return 0;
    }
    printf("Enter principal, rate(%%) and time(years): ");
    if (scanf("%lf %lf %lf", &p, &r, &t) != 3)
        return 1;

    interest(p, r, t, &si, &ci);
    if (choice == 1)
        printf("Simple interest   = %.2f\n", si);
    else
        printf("Compound interest = %.2f (amount %.2f)\n", ci, p + ci);
    return 0;
}
''', "2 5000 8 3")

add(236, r'''
#include <stdio.h>

int main(void)
{
    char word[50];
    int count[5] = {0, 0, 0, 0, 0};       /* a e i o u */
    int i, others = 0;

    printf("Enter a word: ");
    if (scanf("%49s", word) != 1)
        return 1;

    for (i = 0; word[i] != '\0'; i++) {
        switch (word[i]) {
        case 'a': case 'A': count[0]++; break;
        case 'e': case 'E': count[1]++; break;
        case 'i': case 'I': count[2]++; break;
        case 'o': case 'O': count[3]++; break;
        case 'u': case 'U': count[4]++; break;
        default: others++;
        }
    }
    printf("a:%d e:%d i:%d o:%d u:%d other characters:%d\n",
           count[0], count[1], count[2], count[3], count[4], others);
    return 0;
}
''', "Programming")

add(237, r'''
#include <stdio.h>
#include <math.h>

struct Result {
    char name[20];
    double value;
};

int main(void)
{
    int choice;
    double n;
    struct Result res;

    printf("1. Square\n2. Cube\n3. Square root\nChoice: ");
    if (scanf("%d", &choice) != 1)
        return 1;
    printf("Enter a number: ");
    if (scanf("%lf", &n) != 1)
        return 1;

    switch (choice) {
    case 1: snprintf(res.name, sizeof res.name, "Square"); res.value = n * n; break;
    case 2: snprintf(res.name, sizeof res.name, "Cube"); res.value = n * n * n; break;
    case 3:
        if (n < 0) {
            printf("Square root of a negative number is not real.\n");
            return 0;
        }
        snprintf(res.name, sizeof res.name, "Square root");
        res.value = sqrt(n);
        break;
    default:
        printf("Invalid choice.\n");
        return 0;
    }
    printf("%s of %g = %g\n", res.name, n, res.value);
    return 0;
}
''', "3 49")

add(238, r'''
#include <stdio.h>

int main(void)
{
    int n, i, choice;
    unsigned int num;
    const char *hex = "0123456789ABCDEF";

    printf("How many conversions? ");
    if (scanf("%d", &n) != 1 || n < 1)
        return 1;
    for (i = 0; i < n; i++) {
        printf("Enter option (1=binary 2=octal 3=hex) and a decimal number: ");
        if (scanf("%d %u", &choice, &num) != 2)
            return 1;
        switch (choice) {
        case 1: {
            char bits[33];
            int len = 0;
            unsigned int x = num;
            do { bits[len++] = (char)('0' + x % 2); x /= 2; } while (x > 0);
            printf("%u in binary = ", num);
            while (len > 0) putchar(bits[--len]);
            putchar('\n');
            break;
        }
        case 2: printf("%u in octal = %o\n", num, num); break;
        case 3: printf("%u in hex = %c%c\n", num, hex[(num >> 4) & 15], hex[num & 15]); break;
        default: printf("Invalid option.\n");
        }
    }
    return 0;
}
''', "3\n1 10\n2 64\n3 255")

add(239, r'''
#include <stdio.h>

#define PI 3.14159265

int main(void)
{
    int choice;
    double a, b, c, p;

    printf("Perimeter menu\n 1. Circle\n 2. Rectangle\n 3. Square\n 4. Triangle\nChoice: ");
    if (scanf("%d", &choice) != 1)
        return 1;

    printf("\n%-12s %-20s %s\n", "Shape", "Formula", "Perimeter");
    switch (choice) {
    case 1:
        scanf("%lf", &a);
        p = 2 * PI * a;
        printf("%-12s %-20s %.2f\n", "Circle", "2*pi*r", p);
        break;
    case 2:
        scanf("%lf %lf", &a, &b);
        p = 2 * (a + b);
        printf("%-12s %-20s %.2f\n", "Rectangle", "2*(l+w)", p);
        break;
    case 3:
        scanf("%lf", &a);
        p = 4 * a;
        printf("%-12s %-20s %.2f\n", "Square", "4*side", p);
        break;
    case 4:
        scanf("%lf %lf %lf", &a, &b, &c);
        p = a + b + c;
        printf("%-12s %-20s %.2f\n", "Triangle", "a+b+c", p);
        break;
    default:
        printf("Invalid choice.\n");
    }
    return 0;
}
''', "2 4.5 3")

add(240, r'''
#include <stdio.h>

char gradeOf(int m)
{
    if (m >= 75) return 'A';
    if (m >= 60) return 'B';
    if (m >= 45) return 'C';
    if (m >= 33) return 'D';
    return 'F';
}

int main(void)
{
    int choice, marks;

    do {
        printf("\n1. Enter marks  2. Show grade scale  3. Exit\nChoice: ");
        if (scanf("%d", &choice) != 1)
            return 1;
        switch (choice) {
        case 1:
            printf("Marks (0-100): ");
            if (scanf("%d", &marks) != 1)
                return 1;
            if (marks < 0 || marks > 100)
                printf("Error: %d is not valid marks.\n", marks);
            else
                printf("Marks %d -> Grade %c\n", marks, gradeOf(marks));
            break;
        case 2:
            printf("A:75+  B:60-74  C:45-59  D:33-44  F:below 33\n");
            break;
        case 3:
            printf("Bye.\n");
            break;
        default:
            printf("Invalid choice.\n");
        }
    } while (choice != 3);
    return 0;
}
''', "2 1 85 1 140 1 52 3")

add(241, r'''
#include <stdio.h>

void trafficLight(char c)
{
    switch (c) {
    case 'R': case 'r': printf("%c -> RED: Stop\n", c); break;
    case 'Y': case 'y': printf("%c -> YELLOW: Get ready\n", c); break;
    case 'G': case 'g': printf("%c -> GREEN: Go\n", c); break;
    default: printf("%c -> Unknown signal\n", c);
    }
}

int main(void)
{
    char c;
    int i;

    for (i = 0; i < 4; i++) {
        printf("Enter signal letter (R/Y/G): ");
        if (scanf(" %c", &c) != 1)
            return 1;
        trafficLight(c);
    }
    return 0;
}
''', "g R y x")

add(242, r'''
#include <stdio.h>

int main(void)
{
    char op;

    printf("Enter an operator: ");
    if (scanf(" %c", &op) != 1)
        return 1;

    /* A switch jumps straight to the matching case: O(1) time, O(1) space. */
    switch (op) {
    case '+': printf("'+' is the addition operator.\n"); break;
    case '-': printf("'-' is the subtraction operator.\n"); break;
    case '*': printf("'*' is the multiplication operator.\n"); break;
    case '/': printf("'/' is the division operator.\n"); break;
    case '%': printf("'%%' is the modulus (remainder) operator.\n"); break;
    default: printf("'%c' is not a basic arithmetic operator.\n", op);
    }
    return 0;
}
''', "%")

add(243, r'''
#include <stdio.h>

int isPrime(long long n)
{
    long long i;
    if (n < 2) return 0;
    for (i = 2; i * i <= n; i++)
        if (n % i == 0) return 0;
    return 1;
}

int main(void)
{
    int choice;
    long long n;

    do {
        printf("\n1. Even/Odd  2. Positive/Negative  3. Prime  4. Exit\nChoice: ");
        if (scanf("%d", &choice) != 1)
            return 1;
        if (choice >= 1 && choice <= 3) {
            printf("Enter number: ");
            if (scanf("%lld", &n) != 1)
                return 1;
        }
        switch (choice) {
        case 1: printf("%lld is %s.\n", n, n % 2 == 0 ? "even" : "odd"); break;
        case 2: printf("%lld is %s.\n", n, n > 0 ? "positive" : n < 0 ? "negative" : "zero"); break;
        case 3: printf("%lld is %s.\n", n, isPrime(n) ? "prime" : "not prime"); break;
        case 4: printf("Exit.\n"); break;
        default: printf("Invalid choice.\n");
        }
    } while (choice != 4);
    return 0;
}
''', "1 7 2 -3 3 97 3 1 3 2147483647 1 -2147483648 2 0 4")

add(244, r'''
#include <stdio.h>

double cToF(double c) { return c * 9.0 / 5.0 + 32; }
double fToC(double f) { return (f - 32) * 5.0 / 9.0; }
double cToK(double c) { return c + 273.15; }
double kToC(double k) { return k - 273.15; }

int main(void)
{
    int choice;
    double v;

    do {
        printf("\n1.C->F 2.F->C 3.C->K 4.K->C 5.Exit\nChoice: ");
        if (scanf("%d", &choice) != 1)
            return 1;
        if (choice >= 1 && choice <= 4) {
            printf("Enter value: ");
            if (scanf("%lf", &v) != 1)
                return 1;
        }
        switch (choice) {
        case 1: printf("%.2f C = %.2f F\n", v, cToF(v)); break;
        case 2: printf("%.2f F = %.2f C\n", v, fToC(v)); break;
        case 3: printf("%.2f C = %.2f K\n", v, cToK(v)); break;
        case 4: printf("%.2f K = %.2f C\n", v, kToC(v)); break;
        case 5: printf("Done.\n"); break;
        default: printf("Invalid choice.\n");
        }
    } while (choice != 5);
    return 0;
}
''', "1 37 3 100 4 0 2 212 5")

add(245, r'''
#include <stdio.h>

int main(void)
{
    int choice = 0, c;

    while (choice != 3) {
        printf("\n1. Greeting\n2. Tip\n3. Exit\nChoice: ");
        if (scanf("%d", &choice) != 1) {
            /* non-numeric input: report, then discard the rest of the line */
            printf("That is not a number. Try again.\n");
            while ((c = getchar()) != '\n' && c != EOF)
                ;
            if (c == EOF)
                return 1;
            choice = 0;
            continue;
        }
        switch (choice) {
        case 1: printf("Hello, learner!\n"); break;
        case 2: printf("Tip: always check what scanf returns.\n"); break;
        case 3: printf("Goodbye!\n"); break;
        default: printf("Invalid choice %d: please pick 1, 2 or 3.\n", choice);
        }
    }
    return 0;
}
''', "9\n-1\nabc\n1\n2\n3\n")

add(246, r'''
#include <stdio.h>

int main(void)
{
    int choice, a, b;

    printf("1.Add 2.Subtract 3.Multiply 4.Divide 5.Remainder\nChoice: ");
    if (scanf("%d", &choice) != 1)
        return 1;
    printf("Enter two integers: ");
    if (scanf("%d %d", &a, &b) != 2)
        return 1;

    /* One switch, one operation: O(1) time and O(1) extra space. */
    switch (choice) {
    case 1: printf("%d + %d = %d\n", a, b, a + b); break;
    case 2: printf("%d - %d = %d\n", a, b, a - b); break;
    case 3: printf("%d * %d = %d\n", a, b, a * b); break;
    case 4:
    case 5:
        if (b == 0) printf("Division by zero is not allowed.\n");
        else if (choice == 4) printf("%d / %d = %d\n", a, b, a / b);
        else printf("%d %% %d = %d\n", a, b, a % b);
        break;
    default: printf("Invalid choice.\n");
    }
    return 0;
}
''', "5\n17 5")

add(247, r'''
#include <stdio.h>

int main(void)
{
    int month, year, days;

    printf("Enter month (1-12) and year: ");
    if (scanf("%d %d", &month, &year) != 2 || year < 1) {
        printf("Invalid input.\n");
        return 1;
    }
    switch (month) {
    case 1: case 3: case 5: case 7: case 8: case 10: case 12:
        days = 31;
        break;
    case 4: case 6: case 9: case 11:
        days = 30;
        break;
    case 2:
        days = ((year % 4 == 0 && year % 100 != 0) || year % 400 == 0) ? 29 : 28;
        break;
    default:
        printf("Month must be 1 to 12.\n");
        return 1;
    }
    printf("Month %d of year %d has %d days.\n", month, year, days);
    return 0;
}
''', "2 2100")

add(248, r'''
#include <stdio.h>

int main(void)
{
    char ch;

    printf("Enter a character: ");
    if (scanf(" %c", &ch) != 1)
        return 1;

    /* Case labels for all vowels fall through to one shared message. */
    switch (ch) {
    case 'a': case 'e': case 'i': case 'o': case 'u':
    case 'A': case 'E': case 'I': case 'O': case 'U':
        printf("'%c' is a vowel.\n", ch);
        break;
    default:
        /* anything else: letter (consonant), digit or special symbol */
        if ((ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z'))
            printf("'%c' is a consonant.\n", ch);
        else
            printf("'%c' is not a letter.\n", ch);
    }
    return 0;
}
''', "O")

add(249, r'''
#include <stdio.h>

/* writes digits of n in the given base into buf, returns the text */
char *toBase(unsigned int n, int base, char *buf)
{
    const char *digits = "0123456789ABCDEF";
    char tmp[40];
    int len = 0, i = 0;

    do {
        tmp[len++] = digits[n % (unsigned)base];
        n /= (unsigned)base;
    } while (n > 0);
    while (len > 0)
        buf[i++] = tmp[--len];
    buf[i] = '\0';
    return buf;
}

int main(void)
{
    int choice;
    unsigned int n;
    char out[40];

    do {
        printf("\n1.Binary 2.Octal 3.Hexadecimal 0.Exit\nChoice: ");
        if (scanf("%d", &choice) != 1)
            return 1;
        if (choice >= 1 && choice <= 3) {
            printf("Enter decimal number: ");
            if (scanf("%u", &n) != 1)
                return 1;
            printf("%u = %s\n", n, toBase(n, choice == 1 ? 2 : choice == 2 ? 8 : 16, out));
        } else if (choice != 0) {
            printf("Invalid choice.\n");
        }
    } while (choice != 0);
    return 0;
}
''', "1 45 2 45 3 255 7 0")

add(250, r'''
#include <stdio.h>

char gradeOf(int m)
{
    switch (m / 10) {
    case 10: case 9: return 'A';
    case 8: return 'B';
    case 7: return 'C';
    case 6: return 'D';
    default: return 'F';
    }
}

int main(void)
{
    int n, i, marks, total = 0;

    printf("How many students? ");
    if (scanf("%d", &n) != 1 || n < 1)
        return 1;
    printf("%-8s %-6s %s\n", "Student", "Marks", "Grade");
    for (i = 1; i <= n; i++) {
        if (scanf("%d", &marks) != 1 || marks < 0 || marks > 100) {
            printf("Invalid marks for student %d.\n", i);
            return 1;
        }
        total += marks;
        printf("%-8d %-6d %c\n", i, marks, gradeOf(marks));
    }
    printf("Class average: %.2f\n", (double)total / n);
    return 0;
}
''', "4\n92 67 45 81")
