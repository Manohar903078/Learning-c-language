# programs 951-1000 : id -> (stdin, code)
P = {}
def add(i, code, stdin=""): P[i] = (stdin, code.strip("\n"))

add(951, r'''
#include <stdio.h>

int main(void)
{
    FILE *fp = fopen("note951.txt", "w");   /* "w" creates the file */
    if (fp == NULL)
    {
        printf("Error: cannot create file.\n");
        return 1;
    }
    fprintf(fp, "Learning C file handling is fun.\n");   /* write one line */
    fclose(fp);
    printf("File 'note951.txt' created and one line written.\n");
    remove("note951.txt");                  /* clean up */
    return 0;
}
''')

add(952, r'''
#include <stdio.h>

int main(void)
{
    char line[100];
    FILE *fp = fopen("data952.txt", "w");
    if (fp == NULL) return 1;
    fputs("C is powerful.\nFiles store data permanently.\nThis is line three.\n", fp);
    fclose(fp);

    fp = fopen("data952.txt", "r");
    if (fp == NULL)
    {
        printf("Cannot open file.\n");
        return 1;
    }
    printf("Contents of data952.txt:\n");
    while (fgets(line, sizeof line, fp) != NULL)
        printf("%s", line);
    fclose(fp);
    remove("data952.txt");
    return 0;
}
''')

add(953, r'''
#include <stdio.h>

int main(void)
{
    char line[100];
    FILE *fp = fopen("app953.txt", "w");
    if (fp == NULL) return 1;
    fputs("First line.\n", fp);
    fclose(fp);

    fp = fopen("app953.txt", "a");          /* "a" appends at the end */
    if (fp == NULL) return 1;
    fputs("Second line appended.\n", fp);
    fclose(fp);

    fp = fopen("app953.txt", "r");
    if (fp == NULL) return 1;
    printf("File after appending:\n");
    while (fgets(line, sizeof line, fp) != NULL)
        printf("%s", line);
    fclose(fp);
    remove("app953.txt");
    return 0;
}
''')

add(954, r'''
#include <stdio.h>

int main(void)
{
    int ch, count = 0;
    FILE *fp = fopen("chars954.txt", "w");
    if (fp == NULL) return 1;
    fputs("Hello World\nC programming\n", fp);
    fclose(fp);

    fp = fopen("chars954.txt", "r");
    if (fp == NULL) return 1;
    while ((ch = fgetc(fp)) != EOF)         /* read one character at a time */
        count++;
    fclose(fp);

    printf("Total characters in file (including newlines): %d\n", count);
    remove("chars954.txt");
    return 0;
}
''')

add(955, r'''
#include <stdio.h>
#include <ctype.h>

int main(void)
{
    int ch, words = 0, inWord = 0;
    FILE *fp = fopen("words955.txt", "w");
    if (fp == NULL) return 1;
    fputs("The quick brown fox\njumps over   the lazy dog.\n", fp);
    fclose(fp);

    fp = fopen("words955.txt", "r");
    if (fp == NULL) return 1;
    while ((ch = fgetc(fp)) != EOF)
    {
        if (isspace(ch))
            inWord = 0;                     /* a space ends a word */
        else if (!inWord)
        {
            inWord = 1;                     /* start of a new word */
            words++;
        }
    }
    fclose(fp);

    printf("Number of words: %d\n", words);
    remove("words955.txt");
    return 0;
}
''')

add(956, r'''
#include <stdio.h>

int main(void)
{
    char line[100];
    int lines = 0;
    FILE *fp = fopen("lines956.txt", "w");
    if (fp == NULL) return 1;
    fputs("alpha\nbeta\ngamma\ndelta\nepsilon\n", fp);
    fclose(fp);

    fp = fopen("lines956.txt", "r");
    if (fp == NULL) return 1;
    while (fgets(line, sizeof line, fp) != NULL)
        lines++;                            /* one fgets = one line */
    fclose(fp);

    printf("Number of lines: %d\n", lines);
    remove("lines956.txt");
    return 0;
}
''')

add(957, r'''
#include <stdio.h>

int main(void)
{
    int ch;
    FILE *src = fopen("source957.txt", "w");
    if (src == NULL) return 1;
    fputs("This text will be copied.\nSecond line of text.\n", src);
    fclose(src);

    src = fopen("source957.txt", "r");
    FILE *dst = fopen("copy957.txt", "w");
    if (src == NULL || dst == NULL)
    {
        printf("File error.\n");
        return 1;
    }
    while ((ch = fgetc(src)) != EOF)
        fputc(ch, dst);
    fclose(src);
    fclose(dst);
    printf("File copied successfully. Contents of copy957.txt:\n");

    dst = fopen("copy957.txt", "r");
    if (dst == NULL) return 1;
    while ((ch = fgetc(dst)) != EOF)
        putchar(ch);
    fclose(dst);
    remove("source957.txt");
    remove("copy957.txt");
    return 0;
}
''')

add(958, r'''
#include <stdio.h>

int main(void)
{
    int ch;
    FILE *f1 = fopen("a958.txt", "w");
    FILE *f2 = fopen("b958.txt", "w");
    if (f1 == NULL || f2 == NULL) return 1;
    fputs("Contents of file one.\n", f1);
    fputs("Contents of file two.\n", f2);
    fclose(f1);
    fclose(f2);

    f1 = fopen("a958.txt", "r");
    f2 = fopen("b958.txt", "r");
    FILE *out = fopen("merged958.txt", "w");
    if (f1 == NULL || f2 == NULL || out == NULL) return 1;
    while ((ch = fgetc(f1)) != EOF) fputc(ch, out);   /* first file */
    while ((ch = fgetc(f2)) != EOF) fputc(ch, out);   /* then second */
    fclose(f1);
    fclose(f2);
    fclose(out);

    out = fopen("merged958.txt", "r");
    if (out == NULL) return 1;
    printf("Merged file contents:\n");
    while ((ch = fgetc(out)) != EOF) putchar(ch);
    fclose(out);
    remove("a958.txt");
    remove("b958.txt");
    remove("merged958.txt");
    return 0;
}
''')

add(959, r'''
#include <stdio.h>
#include <ctype.h>

int main(void)
{
    int ch;
    FILE *in = fopen("in959.txt", "w");
    if (in == NULL) return 1;
    fputs("Mixed Case text, 123!\nconvert me to UPPER.\n", in);
    fclose(in);

    in = fopen("in959.txt", "r");
    FILE *out = fopen("out959.txt", "w");
    if (in == NULL || out == NULL) return 1;
    while ((ch = fgetc(in)) != EOF)
        fputc(toupper(ch), out);            /* convert while copying */
    fclose(in);
    fclose(out);

    out = fopen("out959.txt", "r");
    if (out == NULL) return 1;
    printf("Uppercase copy:\n");
    while ((ch = fgetc(out)) != EOF) putchar(ch);
    fclose(out);
    remove("in959.txt");
    remove("out959.txt");
    return 0;
}
''')

add(960, r'''
#include <stdio.h>
#include <ctype.h>

int main(void)
{
    int ch, vowels = 0, consonants = 0;
    FILE *fp = fopen("vc960.txt", "w");
    if (fp == NULL) return 1;
    fputs("Programming in C is great.\n", fp);
    fclose(fp);

    fp = fopen("vc960.txt", "r");
    if (fp == NULL) return 1;
    while ((ch = fgetc(fp)) != EOF)
    {
        if (isalpha(ch))
        {
            ch = tolower(ch);
            if (ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u')
                vowels++;
            else
                consonants++;
        }
    }
    fclose(fp);

    printf("Vowels     : %d\n", vowels);
    printf("Consonants : %d\n", consonants);
    remove("vc960.txt");
    return 0;
}
''')

add(961, r'''
#include <stdio.h>
#include <string.h>

int main(void)
{
    char word[30], line[100];
    int lineNo = 0, found = 0;
    FILE *fp = fopen("find961.txt", "w");
    if (fp == NULL) return 1;
    fputs("The sun rises in the east.\nBirds sing at dawn.\nThe moon follows the sun.\n", fp);
    fclose(fp);

    printf("Enter word to search: ");
    if (scanf("%29s", word) != 1) return 1;

    fp = fopen("find961.txt", "r");
    if (fp == NULL) return 1;
    while (fgets(line, sizeof line, fp) != NULL)
    {
        lineNo++;
        if (strstr(line, word) != NULL)     /* word found in this line */
        {
            printf("Found '%s' in line %d: %s", word, lineNo, line);
            found++;
        }
    }
    fclose(fp);
    if (found == 0)
        printf("Word '%s' not found.\n", word);
    remove("find961.txt");
    return 0;
}
''', "sun")

add(962, r'''
#include <stdio.h>
#include <string.h>

int main(void)
{
    char oldw[30], neww[30], line[200];
    FILE *fp = fopen("orig962.txt", "w");
    if (fp == NULL) return 1;
    fputs("I have a cat. The cat is black.\nMy cat likes milk.\n", fp);
    fclose(fp);

    printf("Word to replace and new word: ");
    if (scanf("%29s %29s", oldw, neww) != 2) return 1;

    fp = fopen("orig962.txt", "r");
    FILE *tmp = fopen("temp962.txt", "w");
    if (fp == NULL || tmp == NULL) return 1;
    while (fgets(line, sizeof line, fp) != NULL)
    {
        char *p = line, *f;
        while ((f = strstr(p, oldw)) != NULL)
        {
            fprintf(tmp, "%.*s%s", (int)(f - p), p, neww);
            p = f + strlen(oldw);
        }
        fputs(p, tmp);
    }
    fclose(fp);
    fclose(tmp);

    remove("orig962.txt");                  /* replace original with temp */
    rename("temp962.txt", "orig962.txt");

    fp = fopen("orig962.txt", "r");
    if (fp == NULL) return 1;
    printf("File after replacement:\n");
    while (fgets(line, sizeof line, fp) != NULL)
        printf("%s", line);
    fclose(fp);
    remove("orig962.txt");
    return 0;
}
''', "cat dog")

add(963, r'''
#include <stdio.h>

int main(void)
{
    FILE *fp = fopen("students963.txt", "w");
    if (fp == NULL)
    {
        printf("Cannot open file.\n");
        return 1;
    }
    /* write three student records: roll name marks */
    fprintf(fp, "%d %s %.1f\n", 101, "Asha", 86.5);
    fprintf(fp, "%d %s %.1f\n", 102, "Ravi", 72.0);
    fprintf(fp, "%d %s %.1f\n", 103, "Meena", 91.25);
    fclose(fp);
    printf("3 student records stored in students963.txt\n");
    remove("students963.txt");
    return 0;
}
''')

add(964, r'''
#include <stdio.h>

int main(void)
{
    int roll;
    char name[30];
    float marks;
    FILE *fp = fopen("students964.txt", "w");
    if (fp == NULL) return 1;
    fprintf(fp, "101 Asha 86.5\n102 Ravi 72.0\n103 Meena 91.25\n");
    fclose(fp);

    fp = fopen("students964.txt", "r");
    if (fp == NULL) return 1;
    printf("Roll  Name     Marks\n");
    while (fscanf(fp, "%d %29s %f", &roll, name, &marks) == 3)
        printf("%-5d %-8s %.2f\n", roll, name, marks);
    fclose(fp);
    remove("students964.txt");
    return 0;
}
''')

add(965, r'''
#include <stdio.h>

struct Student
{
    int id;
    char name[20];
    float marks;
};

int main(void)
{
    struct Student list[3] = {
        {1, "Asha", 88.5f},
        {2, "Ravi", 74.0f},
        {3, "Meena", 93.0f}
    };
    FILE *fp = fopen("stud965.dat", "wb");  /* "wb" = write binary */
    if (fp == NULL) return 1;
    size_t written = fwrite(list, sizeof(struct Student), 3, fp);
    fclose(fp);

    printf("Records written: %zu\n", written);
    printf("Size of one record: %zu bytes\n", sizeof(struct Student));
    remove("stud965.dat");
    return 0;
}
''')

add(966, r'''
#include <stdio.h>

struct Student
{
    int id;
    char name[20];
    float marks;
};

int main(void)
{
    struct Student list[3] = {{1, "Asha", 88.5f}, {2, "Ravi", 74.0f}, {3, "Meena", 93.0f}};
    struct Student s;
    FILE *fp = fopen("stud966.dat", "wb");
    if (fp == NULL) return 1;
    fwrite(list, sizeof(struct Student), 3, fp);
    fclose(fp);

    fp = fopen("stud966.dat", "rb");        /* read the records back */
    if (fp == NULL) return 1;
    printf("ID  Name     Marks\n");
    while (fread(&s, sizeof(struct Student), 1, fp) == 1)
        printf("%-3d %-8s %.1f\n", s.id, s.name, s.marks);
    fclose(fp);
    remove("stud966.dat");
    return 0;
}
''')

add(967, r'''
#include <stdio.h>

struct Student
{
    int id;
    char name[20];
    float marks;
};

int main(void)
{
    struct Student s = {1, "Asha", 88.5f};
    struct Student extra;
    FILE *fp = fopen("stud967.dat", "wb");
    if (fp == NULL) return 1;
    fwrite(&s, sizeof s, 1, fp);
    fclose(fp);

    printf("Enter id, name and marks of new record: ");
    if (scanf("%d %19s %f", &extra.id, extra.name, &extra.marks) != 3)
    {
        printf("Invalid input.\n");
        return 1;
    }
    fp = fopen("stud967.dat", "ab");        /* "ab" = append binary */
    if (fp == NULL) return 1;
    fwrite(&extra, sizeof extra, 1, fp);
    fclose(fp);

    fp = fopen("stud967.dat", "rb");
    if (fp == NULL) return 1;
    printf("\nRecords in file:\n");
    while (fread(&s, sizeof s, 1, fp) == 1)
        printf("%d %s %.1f\n", s.id, s.name, s.marks);
    fclose(fp);
    remove("stud967.dat");
    return 0;
}
''', "2 Ravi 76.5")

add(968, r'''
#include <stdio.h>

struct Student
{
    int id;
    char name[20];
    float marks;
};

int main(void)
{
    struct Student list[4] = {{11, "Asha", 88.5f}, {12, "Ravi", 74.0f},
                              {13, "Meena", 93.0f}, {14, "Kiran", 61.5f}};
    struct Student s;
    int searchId, found = 0;
    FILE *fp = fopen("stud968.dat", "wb");
    if (fp == NULL) return 1;
    fwrite(list, sizeof(struct Student), 4, fp);
    fclose(fp);

    printf("Enter ID to search: ");
    if (scanf("%d", &searchId) != 1) return 1;

    fp = fopen("stud968.dat", "rb");
    if (fp == NULL) return 1;
    while (fread(&s, sizeof s, 1, fp) == 1)
    {
        if (s.id == searchId)
        {
            printf("Record found: %d %s %.1f\n", s.id, s.name, s.marks);
            found = 1;
            break;
        }
    }
    fclose(fp);
    if (!found)
        printf("No record with ID %d.\n", searchId);
    remove("stud968.dat");
    return 0;
}
''', "13")

add(969, r'''
#include <stdio.h>

struct Student
{
    int id;
    char name[20];
    float marks;
};

int main(void)
{
    struct Student list[3] = {{1, "Asha", 88.5f}, {2, "Ravi", 74.0f}, {3, "Meena", 93.0f}};
    struct Student s;
    int id;
    float newMarks;
    FILE *fp = fopen("stud969.dat", "wb");
    if (fp == NULL) return 1;
    fwrite(list, sizeof s, 3, fp);
    fclose(fp);

    printf("Enter ID and new marks: ");
    if (scanf("%d %f", &id, &newMarks) != 2) return 1;

    fp = fopen("stud969.dat", "rb+");       /* read and write */
    if (fp == NULL) return 1;
    while (fread(&s, sizeof s, 1, fp) == 1)
    {
        if (s.id == id)
        {
            s.marks = newMarks;
            fseek(fp, -(long)sizeof s, SEEK_CUR);   /* step back one record */
            fwrite(&s, sizeof s, 1, fp);
            printf("Record %d updated.\n", id);
            break;
        }
    }
    rewind(fp);
    printf("\nAll records now:\n");
    while (fread(&s, sizeof s, 1, fp) == 1)
        printf("%d %-6s %.1f\n", s.id, s.name, s.marks);
    fclose(fp);
    remove("stud969.dat");
    return 0;
}
''', "2 81.5")

add(970, r'''
#include <stdio.h>

struct Student
{
    int id;
    char name[20];
    int active;                             /* 1 = valid, 0 = deleted */
};

int main(void)
{
    struct Student list[3] = {{1, "Asha", 1}, {2, "Ravi", 1}, {3, "Meena", 1}};
    struct Student s;
    int delId;
    FILE *fp = fopen("stud970.dat", "wb");
    if (fp == NULL) return 1;
    fwrite(list, sizeof s, 3, fp);
    fclose(fp);

    printf("Enter ID to delete: ");
    if (scanf("%d", &delId) != 1) return 1;

    fp = fopen("stud970.dat", "rb+");
    if (fp == NULL) return 1;
    while (fread(&s, sizeof s, 1, fp) == 1)
    {
        if (s.id == delId && s.active)
        {
            s.active = 0;                   /* logical delete: only mark it */
            fseek(fp, -(long)sizeof s, SEEK_CUR);
            fwrite(&s, sizeof s, 1, fp);
            printf("Record %d marked as deleted.\n", delId);
            break;
        }
    }
    rewind(fp);
    printf("Active records:\n");
    while (fread(&s, sizeof s, 1, fp) == 1)
        if (s.active)
            printf("%d %s\n", s.id, s.name);
    fclose(fp);
    remove("stud970.dat");
    return 0;
}
''', "2")

add(971, r'''
#include <stdio.h>

int main(void)
{
    int ch;
    FILE *fp = fopen("pos971.txt", "w+");
    if (fp == NULL) return 1;
    fputs("ABCDEFGHIJ", fp);

    printf("Position after writing (ftell): %ld\n", ftell(fp));

    fseek(fp, 4, SEEK_SET);                 /* jump to 5th character */
    ch = fgetc(fp);
    printf("After fseek(4): char = %c, ftell = %ld\n", ch, ftell(fp));

    fseek(fp, -2, SEEK_END);                /* 2 bytes before the end */
    ch = fgetc(fp);
    printf("After fseek(-2, END): char = %c\n", ch);

    rewind(fp);                             /* back to the beginning */
    ch = fgetc(fp);
    printf("After rewind(): char = %c, ftell = %ld\n", ch, ftell(fp));
    fclose(fp);
    remove("pos971.txt");
    return 0;
}
''')

add(972, r'''
#include <stdio.h>

int main(void)
{
    unsigned char data[8] = {10, 20, 30, 40, 250, 251, 252, 255};
    int ch, i, bytes = 0;
    FILE *fp = fopen("src972.bin", "wb");
    if (fp == NULL) return 1;
    fwrite(data, 1, 8, fp);
    fclose(fp);

    FILE *in = fopen("src972.bin", "rb");
    FILE *out = fopen("dst972.bin", "wb");
    if (in == NULL || out == NULL) return 1;
    while ((ch = fgetc(in)) != EOF)         /* copy byte by byte */
    {
        fputc(ch, out);
        bytes++;
    }
    fclose(in);
    fclose(out);
    printf("Bytes copied: %d\n", bytes);

    in = fopen("dst972.bin", "rb");
    if (in == NULL) return 1;
    printf("Bytes in copy:");
    for (i = 0; (ch = fgetc(in)) != EOF; i++)
        printf(" %d", ch);
    printf("\n");
    fclose(in);
    remove("src972.bin");
    remove("dst972.bin");
    return 0;
}
''')

add(973, r'''
#include <stdio.h>

int main(void)
{
    int c1, c2, pos = 1, line = 1, same = 1;
    FILE *f1 = fopen("cmp1_973.txt", "w");
    FILE *f2 = fopen("cmp2_973.txt", "w");
    if (f1 == NULL || f2 == NULL) return 1;
    fputs("Hello World\nSame line\nEnd of file\n", f1);
    fputs("Hello World\nSame lime\nEnd of file\n", f2);
    fclose(f1);
    fclose(f2);

    f1 = fopen("cmp1_973.txt", "r");
    f2 = fopen("cmp2_973.txt", "r");
    if (f1 == NULL || f2 == NULL) return 1;
    while (1)
    {
        c1 = fgetc(f1);
        c2 = fgetc(f2);
        if (c1 != c2)
        {
            same = 0;
            break;
        }
        if (c1 == EOF) break;
        if (c1 == '\n') { line++; pos = 1; }
        else pos++;
    }
    if (same)
        printf("Files are identical.\n");
    else
        printf("Files differ at line %d, column %d.\n", line, pos);
    fclose(f1);
    fclose(f2);
    remove("cmp1_973.txt");
    remove("cmp2_973.txt");
    return 0;
}
''')

add(974, r'''
#include <stdio.h>

int main(void)
{
    int freq[256] = {0};
    int ch, i;
    FILE *fp = fopen("freq974.txt", "w");
    if (fp == NULL) return 1;
    fputs("hello world\nbanana\n", fp);
    fclose(fp);

    fp = fopen("freq974.txt", "r");
    if (fp == NULL) return 1;
    while ((ch = fgetc(fp)) != EOF)
        freq[ch]++;                         /* the character is the index */
    fclose(fp);

    printf("Character frequencies:\n");
    for (i = 0; i < 256; i++)
    {
        if (freq[i] > 0 && i != '\n')
        {
            if (i == ' ')
                printf("'space' : %d\n", freq[i]);
            else
                printf("'%c'     : %d\n", i, freq[i]);
        }
    }
    remove("freq974.txt");
    return 0;
}
''')

add(975, r'''
#include <stdio.h>

int main(void)
{
    int num, count = 0, sum = 0;
    FILE *fp = fopen("nums975.txt", "w");
    if (fp == NULL) return 1;
    fprintf(fp, "12 45 7\n30 18 66\n");
    fclose(fp);

    fp = fopen("nums975.txt", "r");
    if (fp == NULL) return 1;
    while (fscanf(fp, "%d", &num) == 1)
    {
        sum += num;
        count++;
    }
    fclose(fp);

    printf("Numbers read : %d\n", count);
    printf("Sum          : %d\n", sum);
    if (count > 0)
        printf("Average      : %.2f\n", (double)sum / count);
    remove("nums975.txt");
    return 0;
}
''')

add(976, r'''
#include <stdio.h>

int main(void)
{
    char line[100], name[30];
    int perFile, lineNo = 0, part = 0, ch;
    FILE *fp = fopen("big976.txt", "w");
    FILE *out = NULL;
    if (fp == NULL) return 1;
    fprintf(fp, "line 1\nline 2\nline 3\nline 4\nline 5\n");
    fclose(fp);

    printf("Lines per small file: ");
    if (scanf("%d", &perFile) != 1 || perFile < 1)
    {
        printf("Invalid number.\n");
        return 1;
    }

    fp = fopen("big976.txt", "r");
    if (fp == NULL) return 1;
    while (fgets(line, sizeof line, fp) != NULL)
    {
        if (lineNo % perFile == 0)          /* start a new part file */
        {
            if (out != NULL) fclose(out);
            part++;
            snprintf(name, sizeof name, "part976_%d.txt", part);
            out = fopen(name, "w");
            if (out == NULL) return 1;
        }
        fputs(line, out);
        lineNo++;
    }
    if (out != NULL) fclose(out);
    fclose(fp);

    for (int i = 1; i <= part; i++)
    {
        snprintf(name, sizeof name, "part976_%d.txt", i);
        printf("--- %s ---\n", name);
        fp = fopen(name, "r");
        if (fp == NULL) return 1;
        while ((ch = fgetc(fp)) != EOF) putchar(ch);
        fclose(fp);
        remove(name);
    }
    remove("big976.txt");
    return 0;
}
''', "2")

add(977, r'''
#include <stdio.h>

int main(void)
{
    const char *names[3] = {"c1_977.txt", "c2_977.txt", "c3_977.txt"};
    const char *texts[3] = {"Apple\n", "Banana\n", "Cherry\n"};
    int i, ch;
    FILE *fp, *out;

    for (i = 0; i < 3; i++)                 /* create the input files */
    {
        fp = fopen(names[i], "w");
        if (fp == NULL) return 1;
        fputs(texts[i], fp);
        fclose(fp);
    }

    out = fopen("all977.txt", "w");
    if (out == NULL) return 1;
    for (i = 0; i < 3; i++)                 /* append each file to output */
    {
        fp = fopen(names[i], "r");
        if (fp == NULL) return 1;
        while ((ch = fgetc(fp)) != EOF) fputc(ch, out);
        fclose(fp);
        printf("Added %s\n", names[i]);
    }
    fclose(out);

    printf("\nCombined file:\n");
    out = fopen("all977.txt", "r");
    if (out == NULL) return 1;
    while ((ch = fgetc(out)) != EOF) putchar(ch);
    fclose(out);
    for (i = 0; i < 3; i++) remove(names[i]);
    remove("all977.txt");
    return 0;
}
''')

add(978, r'''
#include <stdio.h>

/* returns 1 if the file can be opened for reading */
int fileExists(const char *name)
{
    FILE *fp = fopen(name, "r");
    if (fp == NULL) return 0;
    fclose(fp);
    return 1;
}

int main(void)
{
    FILE *fp = fopen("exists978.txt", "w");
    if (fp == NULL) return 1;
    fputs("I exist.\n", fp);
    fclose(fp);

    printf("exists978.txt : %s\n", fileExists("exists978.txt") ? "exists" : "does not exist");
    printf("missing978.txt: %s\n", fileExists("missing978.txt") ? "exists" : "does not exist");

    fp = fopen("missing978.txt", "r");
    if (fp == NULL)                         /* handle fopen() failure */
    {
        printf("Error: could not open 'missing978.txt'. Please check the file name.\n");
        remove("exists978.txt");
        return 0;
    }
    fclose(fp);
    return 0;
}
''')

add(979, r'''
#include <stdio.h>

/* write one log entry with a text timestamp */
void logError(FILE *log, const char *stamp, int code, const char *msg)
{
    fprintf(log, "[%s] ERROR %d: %s\n", stamp, code, msg);
}

int main(void)
{
    char line[120];
    FILE *log = fopen("error979.log", "w");
    if (log == NULL) return 1;
    logError(log, "2025-03-10 09:15:02", 101, "File not found");
    logError(log, "2025-03-10 09:15:40", 205, "Invalid input value");
    logError(log, "2025-03-10 09:16:11", 310, "Disk almost full");
    fclose(log);

    log = fopen("error979.log", "r");
    if (log == NULL) return 1;
    printf("Contents of error979.log:\n");
    while (fgets(line, sizeof line, log) != NULL)
        printf("%s", line);
    fclose(log);
    remove("error979.log");
    return 0;
}
''')

add(980, r'''
#include <stdio.h>

#define FILE_NAME "mgmt980.txt"

void addRecord(void)
{
    int roll;
    char name[30];
    float marks;
    printf("Enter roll, name, marks: ");
    if (scanf("%d %29s %f", &roll, name, &marks) != 3)
    {
        printf("Invalid input.\n");
        return;
    }
    FILE *fp = fopen(FILE_NAME, "a");
    if (fp == NULL) return;
    fprintf(fp, "%d %s %.1f\n", roll, name, marks);
    fclose(fp);
    printf("Record added.\n");
}

void showRecords(void)
{
    int roll;
    char name[30];
    float marks;
    FILE *fp = fopen(FILE_NAME, "r");
    if (fp == NULL) { printf("No records yet.\n"); return; }
    printf("Roll  Name       Marks\n");
    while (fscanf(fp, "%d %29s %f", &roll, name, &marks) == 3)
        printf("%-5d %-10s %.1f\n", roll, name, marks);
    fclose(fp);
}

void searchRecord(void)
{
    int roll, key, found = 0;
    char name[30];
    float marks;
    printf("Enter roll to search: ");
    if (scanf("%d", &key) != 1) return;
    FILE *fp = fopen(FILE_NAME, "r");
    if (fp == NULL) { printf("No records yet.\n"); return; }
    while (fscanf(fp, "%d %29s %f", &roll, name, &marks) == 3)
        if (roll == key)
        {
            printf("Found: %d %s %.1f\n", roll, name, marks);
            found = 1;
        }
    fclose(fp);
    if (!found) printf("Roll %d not found.\n", key);
}

int main(void)
{
    int choice;
    do
    {
        printf("\n1.Add 2.Display 3.Search 4.Exit\nChoice: ");
        if (scanf("%d", &choice) != 1) break;
        if (choice == 1) addRecord();
        else if (choice == 2) showRecords();
        else if (choice == 3) searchRecord();
        else if (choice != 4) printf("Invalid choice.\n");
    } while (choice != 4);
    remove(FILE_NAME);
    printf("Goodbye.\n");
    return 0;
}
''', "1 101 Asha 88.5\n1 102 Ravi 72\n2\n3 102\n3 999\n4\n")

add(981, r'''
#include <stdio.h>
#include <string.h>

int main(void)
{
    char line[200], longest[200] = "";
    FILE *fp = fopen("long981.txt", "w");
    if (fp == NULL) return 1;
    fputs("short line\nthis one is a bit longer\nthe longest line in this small file is here\nend\n", fp);
    fclose(fp);

    fp = fopen("long981.txt", "r");
    if (fp == NULL) return 1;
    while (fgets(line, sizeof line, fp) != NULL)
    {
        line[strcspn(line, "\n")] = '\0';   /* strip the newline */
        if (strlen(line) > strlen(longest))
            strcpy(longest, line);
    }
    fclose(fp);

    printf("Longest line (%zu characters):\n%s\n", strlen(longest), longest);
    remove("long981.txt");
    return 0;
}
''')

add(982, r'''
#include <stdio.h>

int main(void)
{
    char line[100];
    int blank = 0, total = 0;
    FILE *fp = fopen("blank982.txt", "w");
    if (fp == NULL) return 1;
    fputs("Title\n\nParagraph one.\n\n\nParagraph two.\n", fp);
    fclose(fp);

    fp = fopen("blank982.txt", "r");
    if (fp == NULL) return 1;
    while (fgets(line, sizeof line, fp) != NULL)
    {
        total++;
        if (line[0] == '\n')                /* nothing but newline */
            blank++;
    }
    fclose(fp);

    printf("Total lines : %d\n", total);
    printf("Blank lines : %d\n", blank);
    remove("blank982.txt");
    return 0;
}
''')

add(983, r'''
#include <stdio.h>

int main(void)
{
    char line[100];
    FILE *in = fopen("in983.txt", "w");
    if (in == NULL) return 1;
    fputs("First\n\nSecond\n\n\nThird\n", in);
    fclose(in);

    in = fopen("in983.txt", "r");
    FILE *out = fopen("out983.txt", "w");
    if (in == NULL || out == NULL) return 1;
    while (fgets(line, sizeof line, in) != NULL)
        if (line[0] != '\n')                /* copy only non-blank lines */
            fputs(line, out);
    fclose(in);
    fclose(out);

    out = fopen("out983.txt", "r");
    if (out == NULL) return 1;
    printf("File without blank lines:\n");
    while (fgets(line, sizeof line, out) != NULL)
        printf("%s", line);
    fclose(out);
    remove("in983.txt");
    remove("out983.txt");
    return 0;
}
''')

add(984, r'''
#include <stdio.h>

int main(void)
{
    char line[100];
    int n = 0;
    FILE *fp = fopen("num984.txt", "w");
    if (fp == NULL) return 1;
    fputs("int main(void)\n{\n    return 0;\n}\n", fp);
    fclose(fp);

    fp = fopen("num984.txt", "r");
    if (fp == NULL) return 1;
    while (fgets(line, sizeof line, fp) != NULL)
    {
        n++;
        printf("%3d: %s", n, line);
    }
    fclose(fp);
    remove("num984.txt");
    return 0;
}
''')

add(985, r'''
#include <stdio.h>
#include <string.h>

#define MAX 10

int main(void)
{
    char lines[MAX][50], temp[50], buf[50];
    int n = 0, i, j;
    FILE *fp = fopen("sort985.txt", "w");
    if (fp == NULL) return 1;
    fputs("pear\napple\nmango\nbanana\ncherry\n", fp);
    fclose(fp);

    fp = fopen("sort985.txt", "r");
    if (fp == NULL) return 1;
    while (n < MAX && fgets(buf, sizeof buf, fp) != NULL)
    {
        buf[strcspn(buf, "\n")] = '\0';
        strcpy(lines[n++], buf);
    }
    fclose(fp);

    for (i = 0; i < n - 1; i++)             /* bubble sort on strings */
        for (j = 0; j < n - 1 - i; j++)
            if (strcmp(lines[j], lines[j + 1]) > 0)
            {
                strcpy(temp, lines[j]);
                strcpy(lines[j], lines[j + 1]);
                strcpy(lines[j + 1], temp);
            }

    printf("Lines in alphabetical order:\n");
    for (i = 0; i < n; i++)
        printf("%s\n", lines[i]);
    remove("sort985.txt");
    return 0;
}
''')

add(986, r'''
#include <stdio.h>

int main(void)
{
    char text[100];
    printf("Enter a line to store in the file: ");
    if (fgets(text, sizeof text, stdin) == NULL)
    {
        printf("No input received.\n");
        return 1;
    }

    FILE *fp = fopen("user986.txt", "w");
    if (fp == NULL)
    {
        printf("Cannot create file.\n");
        return 1;
    }
    fputs(text, fp);
    fclose(fp);
    printf("Your line was written to user986.txt\n");

    fp = fopen("user986.txt", "r");         /* read back to confirm */
    if (fp == NULL) return 1;
    if (fgets(text, sizeof text, fp) != NULL)
        printf("File contains: %s", text);
    fclose(fp);
    remove("user986.txt");
    return 0;
}
''', "C files are easy to learn\n")

add(987, r'''
#include <stdio.h>

/* displays the whole file; returns number of lines shown, -1 on error */
int displayFile(const char *name)
{
    char line[100];
    int count = 0;
    FILE *fp = fopen(name, "r");
    if (fp == NULL) return -1;
    while (fgets(line, sizeof line, fp) != NULL)
    {
        printf("%s", line);
        count++;
    }
    fclose(fp);
    return count;
}

int main(void)
{
    FILE *fp = fopen("show987.txt", "w");
    if (fp == NULL) return 1;
    fputs("Functions make code reusable.\nThis file is shown by displayFile().\n", fp);
    fclose(fp);

    int n = displayFile("show987.txt");
    if (n < 0)
        printf("Could not open file.\n");
    else
        printf("(%d lines displayed)\n", n);
    remove("show987.txt");
    return 0;
}
''')

add(988, r'''
#include <stdio.h>
#include <string.h>

int main(void)
{
    char text[100], line[120];
    FILE *fp = fopen("log988.txt", "w");
    if (fp == NULL)
    {
        printf("Error: cannot create file.\n");
        return 1;
    }
    fputs("Existing line.\n", fp);
    fclose(fp);

    printf("Enter text to append: ");
    if (fgets(text, sizeof text, stdin) == NULL)
    {
        printf("Error: no input received.\n");
        return 1;
    }
    text[strcspn(text, "\n")] = '\0';
    if (strlen(text) == 0)                  /* validate: empty text */
    {
        printf("Error: empty text cannot be appended.\n");
        remove("log988.txt");
        return 1;
    }

    fp = fopen("log988.txt", "a");
    if (fp == NULL)
    {
        printf("Error: cannot open file for appending.\n");
        return 1;
    }
    fprintf(fp, "%s\n", text);
    fclose(fp);
    printf("Text appended successfully.\n\n");

    fp = fopen("log988.txt", "r");
    if (fp == NULL) return 1;
    while (fgets(line, sizeof line, fp) != NULL)
        printf("%s", line);
    fclose(fp);
    remove("log988.txt");
    return 0;
}
''', "Appended by the user\n")

add(989, r'''
#include <stdio.h>

/* writes text to a file and counts its characters */
int countChars(const char *text)
{
    int ch, count = 0;
    FILE *fp = fopen("test989.txt", "w");
    if (fp == NULL) return -1;
    fputs(text, fp);
    fclose(fp);

    fp = fopen("test989.txt", "r");
    if (fp == NULL) return -1;
    while ((ch = fgetc(fp)) != EOF)
        count++;
    fclose(fp);
    return count;
}

int main(void)
{
    const char *samples[3] = {"Hello", "C programming is fun", "a b\tc 123"};
    int i;
    for (i = 0; i < 3; i++)                 /* three different tests */
        printf("Test %d: \"%s\" -> %d characters\n", i + 1, samples[i], countChars(samples[i]));
    remove("test989.txt");
    return 0;
}
''')

add(990, r'''
#include <stdio.h>
#include <ctype.h>

int main(void)
{
    int ch, words = 0;
    int inWord = 0;                         /* 1 while we are inside a word */
    FILE *fp = fopen("words990.txt", "w");
    if (fp == NULL) return 1;
    fputs("Counting words:   spaces,\ntabs\tand newlines separate words.\n", fp);
    fclose(fp);

    fp = fopen("words990.txt", "r");
    if (fp == NULL) return 1;
    while ((ch = fgetc(fp)) != EOF)
    {
        /* whitespace means we are between words */
        if (ch == ' ' || ch == '\n' || ch == '\t')
            inWord = 0;
        /* first non-space character after whitespace starts a new word */
        else if (inWord == 0)
        {
            inWord = 1;
            words++;
        }
    }
    fclose(fp);

    printf("The file contains %d words.\n", words);
    remove("words990.txt");
    return 0;
}
''')

add(991, r'''
#include <stdio.h>
#include <string.h>

/* count lines of text; a last line without '\n' still counts */
int countLines(const char *content)
{
    FILE *fp = fopen("edge991.txt", "w");
    int ch, last = '\n', lines = 0;
    if (fp == NULL) return -1;
    fputs(content, fp);
    fclose(fp);

    fp = fopen("edge991.txt", "r");
    if (fp == NULL) return -1;
    while ((ch = fgetc(fp)) != EOF)
    {
        if (ch == '\n') lines++;
        last = ch;
    }
    if (last != '\n') lines++;              /* unfinished last line */
    fclose(fp);
    return lines;
}

int main(void)
{
    printf("Empty file                : %d\n", countLines(""));
    printf("One line, no newline      : %d\n", countLines("single"));
    printf("One line with newline     : %d\n", countLines("single\n"));
    printf("Only blank lines (3)      : %d\n", countLines("\n\n\n"));
    printf("Three lines, no last '\\n' : %d\n", countLines("a\nb\nc"));
    remove("edge991.txt");
    return 0;
}
''')

add(992, r'''
#include <stdio.h>

void copyFile(const char *from, const char *to)
{
    int ch;
    FILE *in = fopen(from, "r");
    FILE *out = fopen(to, "w");
    if (in == NULL || out == NULL)
    {
        printf("Copy failed.\n");
        if (in) fclose(in);
        if (out) fclose(out);
        return;
    }
    while ((ch = fgetc(in)) != EOF) fputc(ch, out);
    fclose(in);
    fclose(out);
    printf("File copied.\n");
}

void showFile(const char *name)
{
    char line[100];
    FILE *fp = fopen(name, "r");
    if (fp == NULL) { printf("%s does not exist yet.\n", name); return; }
    while (fgets(line, sizeof line, fp) != NULL) printf("  %s", line);
    fclose(fp);
}

int main(void)
{
    int choice;
    FILE *fp = fopen("src992.txt", "w");
    if (fp == NULL) return 1;
    fputs("Menu driven copy.\nSecond line.\n", fp);
    fclose(fp);

    do
    {
        printf("\n1. Copy file\n2. Show source\n3. Show copy\n4. Exit\nChoice: ");
        if (scanf("%d", &choice) != 1) break;
        switch (choice)
        {
            case 1: copyFile("src992.txt", "dst992.txt"); break;
            case 2: showFile("src992.txt"); break;
            case 3: showFile("dst992.txt"); break;
            case 4: printf("Exiting.\n"); break;
            default: printf("Invalid choice.\n");
        }
    } while (choice != 4);
    remove("src992.txt");
    remove("dst992.txt");
    return 0;
}
''', "3 1 3 2 7 4")

add(993, r'''
#include <stdio.h>

int main(void)
{
    int ch, count;
    FILE *f1 = fopen("x993.txt", "w");
    FILE *f2 = fopen("y993.txt", "w");
    if (f1 == NULL || f2 == NULL) return 1;
    fputs("Red\nGreen\n", f1);
    fputs("Blue\nYellow\n", f2);
    fclose(f1);
    fclose(f2);
    printf("Step 1: created x993.txt and y993.txt\n");

    f1 = fopen("x993.txt", "r");
    f2 = fopen("y993.txt", "r");
    FILE *out = fopen("z993.txt", "w");
    if (f1 == NULL || f2 == NULL || out == NULL) return 1;

    count = 0;
    while ((ch = fgetc(f1)) != EOF) { fputc(ch, out); count++; }
    printf("Step 2: copied %d characters from x993.txt\n", count);

    count = 0;
    while ((ch = fgetc(f2)) != EOF) { fputc(ch, out); count++; }
    printf("Step 3: copied %d characters from y993.txt\n", count);
    fclose(f1);
    fclose(f2);
    fclose(out);

    out = fopen("z993.txt", "r");
    if (out == NULL) return 1;
    printf("Step 4: merged file z993.txt contains:\n");
    while ((ch = fgetc(out)) != EOF) putchar(ch);
    fclose(out);
    remove("x993.txt");
    remove("y993.txt");
    remove("z993.txt");
    return 0;
}
''')

add(994, r'''
#include <stdio.h>
#include <ctype.h>

int main(void)
{
    int ch;
    FILE *in = fopen("low994.txt", "w");
    if (in == NULL) return 1;
    fputs("loops save typing.\nvery useful, really!\n", in);
    fclose(in);

    in = fopen("low994.txt", "r");
    FILE *out = fopen("up994.txt", "w");
    if (in == NULL || out == NULL) return 1;
    while ((ch = fgetc(in)) != EOF)         /* one loop handles every character */
        fputc(toupper(ch), out);
    fclose(in);
    fclose(out);

    out = fopen("up994.txt", "r");
    if (out == NULL) return 1;
    printf("Converted file:\n");
    while ((ch = fgetc(out)) != EOF)
        putchar(ch);
    fclose(out);
    remove("low994.txt");
    remove("up994.txt");
    return 0;
}
''')

add(995, r'''
#include <stdio.h>
#include <ctype.h>

int main(void)
{
    char line[100];
    char *p;
    int vowels = 0, consonants = 0;
    FILE *fp = fopen("vc995.txt", "w");
    if (fp == NULL) return 1;
    fputs("Pointers walk through strings.\nEvery character is checked.\n", fp);
    fclose(fp);

    fp = fopen("vc995.txt", "r");
    if (fp == NULL) return 1;
    while (fgets(line, sizeof line, fp) != NULL)
    {
        for (p = line; *p != '\0'; p++)     /* move pointer along the line */
        {
            if (isalpha((unsigned char)*p))
            {
                switch (tolower((unsigned char)*p))
                {
                    case 'a': case 'e': case 'i': case 'o': case 'u':
                        vowels++;
                        break;
                    default:
                        consonants++;
                }
            }
        }
    }
    fclose(fp);

    printf("Vowels: %d, Consonants: %d\n", vowels, consonants);
    remove("vc995.txt");
    return 0;
}
''')

add(996, r'''
#include <stdio.h>
#include <string.h>

#define MAX_LINES 20

int main(void)
{
    char lines[MAX_LINES][80];              /* array holding the file lines */
    char word[30], buf[80];
    int n = 0, i, matches = 0;
    FILE *fp = fopen("search996.txt", "w");
    if (fp == NULL) return 1;
    fputs("Arrays store many values.\nStrings are arrays of char.\nFiles keep data safe.\n", fp);
    fclose(fp);

    printf("Enter word to search: ");
    if (scanf("%29s", word) != 1) return 1;

    fp = fopen("search996.txt", "r");
    if (fp == NULL) return 1;
    while (n < MAX_LINES && fgets(buf, sizeof buf, fp) != NULL)
    {
        buf[strcspn(buf, "\n")] = '\0';
        strcpy(lines[n++], buf);
    }
    fclose(fp);

    for (i = 0; i < n; i++)
        if (strstr(lines[i], word) != NULL)
        {
            printf("Line %d: %s\n", i + 1, lines[i]);
            matches++;
        }
    printf("Lines containing \"%s\": %d\n", word, matches);
    remove("search996.txt");
    return 0;
}
''', "arrays")

add(997, r'''
#include <stdio.h>
#include <string.h>

/* structure bundling the replacement request */
struct Replacement
{
    char oldWord[20];
    char newWord[20];
    int count;
};

int main(void)
{
    struct Replacement r = {"is", "was", 0};
    char line[200];
    FILE *fp = fopen("doc997.txt", "w");
    if (fp == NULL) return 1;
    fputs("This is a test. It is simple.\nWhat is next?\n", fp);
    fclose(fp);

    fp = fopen("doc997.txt", "r");
    FILE *tmp = fopen("tmp997.txt", "w");
    if (fp == NULL || tmp == NULL) return 1;
    while (fgets(line, sizeof line, fp) != NULL)
    {
        char *p = line, *f;
        while ((f = strstr(p, r.oldWord)) != NULL)
        {
            fprintf(tmp, "%.*s%s", (int)(f - p), p, r.newWord);
            p = f + strlen(r.oldWord);
            r.count++;
        }
        fputs(p, tmp);
    }
    fclose(fp);
    fclose(tmp);
    remove("doc997.txt");
    rename("tmp997.txt", "doc997.txt");

    printf("Replaced \"%s\" with \"%s\" %d times.\n", r.oldWord, r.newWord, r.count);
    fp = fopen("doc997.txt", "r");
    if (fp == NULL) return 1;
    while (fgets(line, sizeof line, fp) != NULL)
        printf("%s", line);
    fclose(fp);
    remove("doc997.txt");
    return 0;
}
''')

add(998, r'''
#include <stdio.h>

struct Student
{
    int roll;
    char name[30];
    float marks;
};

int main(void)
{
    int n, i;
    struct Student s;
    printf("How many students? ");
    if (scanf("%d", &n) != 1 || n < 1)
    {
        printf("Invalid count.\n");
        return 1;
    }

    FILE *fp = fopen("stud998.txt", "w");
    if (fp == NULL) return 1;
    for (i = 1; i <= n; i++)                /* process many records in a loop */
    {
        printf("Student %d (roll name marks): ", i);
        if (scanf("%d %29s %f", &s.roll, s.name, &s.marks) != 3)
        {
            printf("Bad record, stopping.\n");
            break;
        }
        fprintf(fp, "%d %s %.1f\n", s.roll, s.name, s.marks);
    }
    fclose(fp);

    fp = fopen("stud998.txt", "r");
    if (fp == NULL) return 1;
    int saved = 0;
    printf("\nStored records:\n");
    while (fscanf(fp, "%d %29s %f", &s.roll, s.name, &s.marks) == 3)
    {
        printf("%d %s %.1f\n", s.roll, s.name, s.marks);
        saved++;
    }
    fclose(fp);
    printf("Total saved: %d\n", saved);
    remove("stud998.txt");
    return 0;
}
''', "3\n1 Asha 88.5\n2 Ravi 74\n3 Meena 93.25\n")

add(999, r'''
#include <stdio.h>

struct Student
{
    int roll;
    char name[30];
    float marks;
};

int main(void)
{
    struct Student s;
    int count = 0;
    float total = 0;
    FILE *fp = fopen("stud999.txt", "w");
    if (fp == NULL) return 1;
    fprintf(fp, "101 Asha 88.5\n102 Ravi 74.0\n103 Meena 93.25\n104 Kiran 61.5\n");
    fclose(fp);

    fp = fopen("stud999.txt", "r");
    if (fp == NULL)
    {
        printf("Cannot open file.\n");
        return 1;
    }
    printf("+------+------------+--------+\n");
    printf("| Roll | Name       | Marks  |\n");
    printf("+------+------------+--------+\n");
    while (fscanf(fp, "%d %29s %f", &s.roll, s.name, &s.marks) == 3)
    {
        printf("| %4d | %-10s | %6.2f |\n", s.roll, s.name, s.marks);
        total += s.marks;
        count++;
    }
    printf("+------+------------+--------+\n");
    fclose(fp);
    printf("Students: %d   Average marks: %.2f\n", count, count ? total / count : 0.0);
    remove("stud999.txt");
    return 0;
}
''')

add(1000, r'''
#include <stdio.h>

struct Student
{
    int id;
    char name[20];
    float marks;
};

int main(void)
{
    int n, i, saved = 0;
    struct Student s;
    printf("How many records (1-5)? ");
    if (scanf("%d", &n) != 1 || n < 1 || n > 5)
    {
        printf("Error: count must be a number from 1 to 5.\n");
        return 1;
    }

    FILE *fp = fopen("stud1000.dat", "wb");
    if (fp == NULL) return 1;
    for (i = 1; i <= n; i++)
    {
        printf("Record %d (id name marks): ", i);
        if (scanf("%d %19s %f", &s.id, s.name, &s.marks) != 3)
        {
            printf("Error: wrong input format. Stopping.\n");
            break;
        }
        if (s.id <= 0 || s.marks < 0 || s.marks > 100)   /* validate before writing */
        {
            printf("Error: invalid id or marks, record skipped.\n");
            continue;
        }
        fwrite(&s, sizeof s, 1, fp);
        saved++;
    }
    fclose(fp);
    printf("\n%d record(s) written to binary file.\n", saved);

    fp = fopen("stud1000.dat", "rb");
    if (fp == NULL) return 1;
    while (fread(&s, sizeof s, 1, fp) == 1)
        printf("%d %s %.1f\n", s.id, s.name, s.marks);
    fclose(fp);
    remove("stud1000.dat");
    return 0;
}
''', "4\n1 Asha 90\n2 Bob 150\n-3 Cara 80\n4 Dev 67.5\n")
