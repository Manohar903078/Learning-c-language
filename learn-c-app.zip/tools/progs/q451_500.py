# programs 451-500 : id -> (stdin, code)
P = {}
def add(i, code, stdin=""): P[i] = (stdin, code.strip("\n"))

add(451, r'''
#include <stdio.h>
#define MAX 100

int main(void)
{
    int a[MAX], n, i;

    printf("How many integers (1-%d)? ", MAX);
    if (scanf("%d", &n) != 1 || n < 1 || n > MAX) {
        printf("Invalid size.\n");
        return 1;
    }
    printf("Enter %d integers: ", n);
    for (i = 0; i < n; i++)
        scanf("%d", &a[i]);

    printf("You entered:");
    for (i = 0; i < n; i++)
        printf(" %d", a[i]);
    printf("\n");
    return 0;
}
''', "6\n12 7 -3 25 0 9")

add(452, r'''
#include <stdio.h>
#define MAX 100

int main(void)
{
    int a[MAX], n, i, sum = 0;

    printf("Enter number of elements: ");
    if (scanf("%d", &n) != 1 || n < 1 || n > MAX) {
        printf("Invalid size.\n");
        return 1;
    }
    printf("Enter %d elements: ", n);
    for (i = 0; i < n; i++) {
        scanf("%d", &a[i]);
        sum += a[i];            /* add each element to the running total */
    }
    printf("Sum of the elements = %d\n", sum);
    return 0;
}
''', "5\n14 22 -6 40 9")

add(453, r'''
#include <stdio.h>
#define MAX 100

int main(void)
{
    int a[MAX], n, i, sum = 0;

    printf("Enter number of elements: ");
    if (scanf("%d", &n) != 1 || n < 1 || n > MAX) {
        printf("Invalid size.\n");
        return 1;
    }
    printf("Enter %d elements: ", n);
    for (i = 0; i < n; i++) {
        scanf("%d", &a[i]);
        sum += a[i];
    }
    printf("Sum     = %d\n", sum);
    printf("Average = %.2f\n", (double)sum / n);
    return 0;
}
''', "6\n8 15 22 9 31 4")

add(454, r'''
#include <stdio.h>
#define MAX 100

int main(void)
{
    int a[MAX], n, i, largest;

    printf("Enter number of elements: ");
    if (scanf("%d", &n) != 1 || n < 1 || n > MAX) {
        printf("Invalid size.\n");
        return 1;
    }
    printf("Enter %d elements: ", n);
    for (i = 0; i < n; i++)
        scanf("%d", &a[i]);

    largest = a[0];
    for (i = 1; i < n; i++)
        if (a[i] > largest)
            largest = a[i];
    printf("Largest element = %d\n", largest);
    return 0;
}
''', "7\n34 -8 91 17 62 91 5")

add(455, r'''
#include <stdio.h>
#define MAX 100

int main(void)
{
    int a[MAX], n, i, smallest, pos = 0;

    printf("Enter number of elements: ");
    if (scanf("%d", &n) != 1 || n < 1 || n > MAX) {
        printf("Invalid size.\n");
        return 1;
    }
    printf("Enter %d elements: ", n);
    for (i = 0; i < n; i++)
        scanf("%d", &a[i]);

    smallest = a[0];
    for (i = 1; i < n; i++)
        if (a[i] < smallest) {
            smallest = a[i];
            pos = i;
        }
    printf("Smallest element = %d (at index %d)\n", smallest, pos);
    return 0;
}
''', "6\n45 19 -12 33 70 8")

add(456, r'''
#include <stdio.h>
#define MAX 100

int main(void)
{
    int a[MAX], n, i, first, second, found = 0;

    printf("Enter number of elements: ");
    if (scanf("%d", &n) != 1 || n < 1 || n > MAX) {
        printf("Invalid size.\n");
        return 1;
    }
    printf("Enter %d elements: ", n);
    for (i = 0; i < n; i++)
        scanf("%d", &a[i]);

    first = a[0];                       /* find the largest */
    for (i = 1; i < n; i++)
        if (a[i] > first)
            first = a[i];

    second = 0;                         /* largest among values below first */
    for (i = 0; i < n; i++)
        if (a[i] < first && (!found || a[i] > second)) {
            second = a[i];
            found = 1;
        }

    if (found)
        printf("Largest = %d, second-largest distinct = %d\n", first, second);
    else
        printf("No second-largest distinct element exists.\n");
    return 0;
}
''', "7\n20 45 45 12 38 45 7")

add(457, r'''
#include <stdio.h>
#define MAX 100

int main(void)
{
    int a[MAX], n, i, first, second, found = 0;

    printf("Enter number of elements: ");
    if (scanf("%d", &n) != 1 || n < 1 || n > MAX) {
        printf("Invalid size.\n");
        return 1;
    }
    printf("Enter %d elements: ", n);
    for (i = 0; i < n; i++)
        scanf("%d", &a[i]);

    first = a[0];                       /* find the smallest */
    for (i = 1; i < n; i++)
        if (a[i] < first)
            first = a[i];

    second = 0;                         /* smallest among values above first */
    for (i = 0; i < n; i++)
        if (a[i] > first && (!found || a[i] < second)) {
            second = a[i];
            found = 1;
        }

    if (found)
        printf("Smallest = %d, second-smallest distinct = %d\n", first, second);
    else
        printf("No second-smallest distinct element exists.\n");
    return 0;
}
''', "7\n9 3 3 15 6 3 21")

add(458, r'''
#include <stdio.h>
#define MAX 100

int main(void)
{
    int a[MAX], n, i, even = 0, odd = 0;

    printf("Enter number of elements: ");
    if (scanf("%d", &n) != 1 || n < 1 || n > MAX) {
        printf("Invalid size.\n");
        return 1;
    }
    printf("Enter %d elements: ", n);
    for (i = 0; i < n; i++) {
        scanf("%d", &a[i]);
        if (a[i] % 2 == 0)
            even++;
        else
            odd++;
    }
    printf("Even elements: %d\n", even);
    printf("Odd elements : %d\n", odd);
    return 0;
}
''', "8\n12 7 -4 9 20 33 5 0")

add(459, r'''
#include <stdio.h>
#define MAX 100

int main(void)
{
    int a[MAX], n, i, pos = 0, neg = 0, zero = 0;

    printf("Enter number of elements: ");
    if (scanf("%d", &n) != 1 || n < 1 || n > MAX) {
        printf("Invalid size.\n");
        return 1;
    }
    printf("Enter %d elements: ", n);
    for (i = 0; i < n; i++) {
        scanf("%d", &a[i]);
        if (a[i] > 0)
            pos++;
        else if (a[i] < 0)
            neg++;
        else
            zero++;
    }
    printf("Positive: %d\nNegative: %d\nZero    : %d\n", pos, neg, zero);
    return 0;
}
''', "9\n5 -3 0 8 -1 0 -7 12 4")

add(460, r'''
#include <stdio.h>
#define MAX 100

int main(void)
{
    int a[MAX], n, i, key, found = -1;

    printf("Enter number of elements: ");
    if (scanf("%d", &n) != 1 || n < 1 || n > MAX) {
        printf("Invalid size.\n");
        return 1;
    }
    printf("Enter %d elements: ", n);
    for (i = 0; i < n; i++)
        scanf("%d", &a[i]);
    printf("Enter value to search: ");
    scanf("%d", &key);

    for (i = 0; i < n; i++)             /* check elements one by one */
        if (a[i] == key) {
            found = i;
            break;
        }

    if (found >= 0)
        printf("%d found at index %d (position %d)\n", key, found, found + 1);
    else
        printf("%d not found in the array\n", key);
    return 0;
}
''', "6\n14 27 3 56 41 9\n56")

add(461, r'''
#include <stdio.h>
#define MAX 100

int main(void)
{
    int a[MAX], n, i, key, count = 0;

    printf("Enter number of elements: ");
    if (scanf("%d", &n) != 1 || n < 1 || n > MAX) {
        printf("Invalid size.\n");
        return 1;
    }
    printf("Enter %d elements: ", n);
    for (i = 0; i < n; i++)
        scanf("%d", &a[i]);
    printf("Enter value to count: ");
    scanf("%d", &key);

    for (i = 0; i < n; i++)
        if (a[i] == key)
            count++;
    printf("%d occurs %d time(s)\n", key, count);
    return 0;
}
''', "9\n4 7 4 2 4 9 7 4 1\n4")

add(462, r'''
#include <stdio.h>
#define MAX 100

int main(void)
{
    int a[MAX], counted[MAX] = {0}, n, i, j, freq;

    printf("Enter number of elements: ");
    if (scanf("%d", &n) != 1 || n < 1 || n > MAX) {
        printf("Invalid size.\n");
        return 1;
    }
    printf("Enter %d elements: ", n);
    for (i = 0; i < n; i++)
        scanf("%d", &a[i]);

    printf("Element  Frequency\n");
    for (i = 0; i < n; i++) {
        if (counted[i])
            continue;                   /* already counted earlier */
        freq = 1;
        for (j = i + 1; j < n; j++)
            if (a[j] == a[i]) {
                freq++;
                counted[j] = 1;
            }
        printf("%7d  %9d\n", a[i], freq);
    }
    return 0;
}
''', "10\n3 5 3 8 5 3 1 8 9 5")

add(463, r'''
#include <stdio.h>
#define MAX 100

int main(void)
{
    int a[MAX], n, i, temp;

    printf("Enter number of elements: ");
    if (scanf("%d", &n) != 1 || n < 1 || n > MAX) {
        printf("Invalid size.\n");
        return 1;
    }
    printf("Enter %d elements: ", n);
    for (i = 0; i < n; i++)
        scanf("%d", &a[i]);

    for (i = 0; i < n / 2; i++) {       /* swap first with last, and so on */
        temp = a[i];
        a[i] = a[n - 1 - i];
        a[n - 1 - i] = temp;
    }

    printf("Reversed array:");
    for (i = 0; i < n; i++)
        printf(" %d", a[i]);
    printf("\n");
    return 0;
}
''', "7\n1 2 3 4 5 6 7")

add(464, r'''
#include <stdio.h>
#define MAX 100

int main(void)
{
    int src[MAX], dst[MAX], n, i;

    printf("Enter number of elements: ");
    if (scanf("%d", &n) != 1 || n < 1 || n > MAX) {
        printf("Invalid size.\n");
        return 1;
    }
    printf("Enter %d elements: ", n);
    for (i = 0; i < n; i++)
        scanf("%d", &src[i]);

    for (i = 0; i < n; i++)
        dst[i] = src[i];                /* copy element by element */

    printf("Source     :");
    for (i = 0; i < n; i++)
        printf(" %d", src[i]);
    printf("\nDestination:");
    for (i = 0; i < n; i++)
        printf(" %d", dst[i]);
    printf("\n");
    return 0;
}
''', "5\n11 22 33 44 55")

add(465, r'''
#include <stdio.h>
#define MAX 50

int main(void)
{
    int a[MAX], b[MAX], c[2 * MAX], n, m, i, k = 0;

    printf("Size of first array: ");
    if (scanf("%d", &n) != 1 || n < 1 || n > MAX) {
        printf("Invalid size.\n");
        return 1;
    }
    printf("Enter %d elements: ", n);
    for (i = 0; i < n; i++)
        scanf("%d", &a[i]);

    printf("Size of second array: ");
    if (scanf("%d", &m) != 1 || m < 1 || m > MAX) {
        printf("Invalid size.\n");
        return 1;
    }
    printf("Enter %d elements: ", m);
    for (i = 0; i < m; i++)
        scanf("%d", &b[i]);

    for (i = 0; i < n; i++)
        c[k++] = a[i];                  /* first array, then second */
    for (i = 0; i < m; i++)
        c[k++] = b[i];

    printf("Merged array:");
    for (i = 0; i < k; i++)
        printf(" %d", c[i]);
    printf("\n");
    return 0;
}
''', "4\n10 20 30 40\n3\n5 15 25")

add(466, r'''
#include <stdio.h>
#define MAX 50

int main(void)
{
    int a[MAX], b[MAX], c[2 * MAX], n, m, i = 0, j = 0, k = 0;

    printf("Size of first sorted array: ");
    if (scanf("%d", &n) != 1 || n < 1 || n > MAX) {
        printf("Invalid size.\n");
        return 1;
    }
    printf("Enter %d sorted elements: ", n);
    for (i = 0; i < n; i++)
        scanf("%d", &a[i]);

    printf("Size of second sorted array: ");
    if (scanf("%d", &m) != 1 || m < 1 || m > MAX) {
        printf("Invalid size.\n");
        return 1;
    }
    printf("Enter %d sorted elements: ", m);
    for (i = 0; i < m; i++)
        scanf("%d", &b[i]);

    i = 0;
    while (i < n && j < m) {            /* take the smaller front element */
        if (a[i] <= b[j])
            c[k++] = a[i++];
        else
            c[k++] = b[j++];
    }
    while (i < n)
        c[k++] = a[i++];
    while (j < m)
        c[k++] = b[j++];

    printf("Merged sorted array:");
    for (i = 0; i < k; i++)
        printf(" %d", c[i]);
    printf("\n");
    return 0;
}
''', "5\n1 4 9 12 20\n4\n2 4 10 25")

add(467, r'''
#include <stdio.h>
#define MAX 100

int main(void)
{
    int a[MAX], u[MAX], n, i, j, k = 0, dup;

    printf("Enter number of elements: ");
    if (scanf("%d", &n) != 1 || n < 1 || n > MAX) {
        printf("Invalid size.\n");
        return 1;
    }
    printf("Enter %d elements: ", n);
    for (i = 0; i < n; i++)
        scanf("%d", &a[i]);

    for (i = 0; i < n; i++) {
        dup = 0;
        for (j = 0; j < k; j++)         /* already kept? */
            if (u[j] == a[i]) {
                dup = 1;
                break;
            }
        if (!dup)
            u[k++] = a[i];
    }

    printf("After removing duplicates:");
    for (i = 0; i < k; i++)
        printf(" %d", u[i]);
    printf("\n");
    return 0;
}
''', "10\n4 7 4 1 9 7 2 1 9 5")

add(468, r'''
#include <stdio.h>
#define MAX 100

int main(void)
{
    int a[MAX], n, i, pos, value;

    printf("Enter number of elements (max %d): ", MAX - 1);
    if (scanf("%d", &n) != 1 || n < 1 || n > MAX - 1) {
        printf("Invalid size.\n");
        return 1;
    }
    printf("Enter %d elements: ", n);
    for (i = 0; i < n; i++)
        scanf("%d", &a[i]);
    printf("Enter position (1 to %d) and value: ", n + 1);
    if (scanf("%d %d", &pos, &value) != 2 || pos < 1 || pos > n + 1) {
        printf("Invalid position.\n");
        return 1;
    }

    for (i = n; i >= pos; i--)          /* shift right to make room */
        a[i] = a[i - 1];
    a[pos - 1] = value;
    n++;

    printf("Array after insertion:");
    for (i = 0; i < n; i++)
        printf(" %d", a[i]);
    printf("\n");
    return 0;
}
''', "5\n10 20 30 40 50\n3 25")

add(469, r'''
#include <stdio.h>
#define MAX 100

int main(void)
{
    int a[MAX], n, i, pos;

    printf("Enter number of elements: ");
    if (scanf("%d", &n) != 1 || n < 1 || n > MAX) {
        printf("Invalid size.\n");
        return 1;
    }
    printf("Enter %d elements: ", n);
    for (i = 0; i < n; i++)
        scanf("%d", &a[i]);
    printf("Enter position to delete (1 to %d): ", n);
    if (scanf("%d", &pos) != 1 || pos < 1 || pos > n) {
        printf("Invalid position.\n");
        return 1;
    }

    for (i = pos - 1; i < n - 1; i++)   /* shift left over the deleted slot */
        a[i] = a[i + 1];
    n--;

    printf("Array after deletion:");
    for (i = 0; i < n; i++)
        printf(" %d", a[i]);
    printf("\n");
    return 0;
}
''', "6\n5 15 25 35 45 55\n4")

add(470, r'''
#include <stdio.h>
#define MAX 100

int main(void)
{
    int a[MAX], n, i, first;

    printf("Enter number of elements: ");
    if (scanf("%d", &n) != 1 || n < 1 || n > MAX) {
        printf("Invalid size.\n");
        return 1;
    }
    printf("Enter %d elements: ", n);
    for (i = 0; i < n; i++)
        scanf("%d", &a[i]);

    first = a[0];                       /* remember the first element */
    for (i = 0; i < n - 1; i++)
        a[i] = a[i + 1];
    a[n - 1] = first;                   /* place it at the end */

    printf("Rotated left by 1:");
    for (i = 0; i < n; i++)
        printf(" %d", a[i]);
    printf("\n");
    return 0;
}
''', "6\n1 2 3 4 5 6")

add(471, r'''
#include <stdio.h>
#define MAX 100

int main(void)
{
    int a[MAX], n, i, last;

    printf("Enter number of elements: ");
    if (scanf("%d", &n) != 1 || n < 1 || n > MAX) {
        printf("Invalid size.\n");
        return 1;
    }
    printf("Enter %d elements: ", n);
    for (i = 0; i < n; i++)
        scanf("%d", &a[i]);

    last = a[n - 1];                    /* remember the last element */
    for (i = n - 1; i > 0; i--)
        a[i] = a[i - 1];
    a[0] = last;                        /* place it at the front */

    printf("Rotated right by 1:");
    for (i = 0; i < n; i++)
        printf(" %d", a[i]);
    printf("\n");
    return 0;
}
''', "6\n1 2 3 4 5 6")

add(472, r'''
#include <stdio.h>
#define MAX 100

/* reverse a[from..to] */
void reverse(int a[], int from, int to)
{
    int t;
    while (from < to) {
        t = a[from];
        a[from] = a[to];
        a[to] = t;
        from++;
        to--;
    }
}

int main(void)
{
    int a[MAX], n, k, i;

    printf("Enter number of elements: ");
    if (scanf("%d", &n) != 1 || n < 1 || n > MAX) {
        printf("Invalid size.\n");
        return 1;
    }
    printf("Enter %d elements: ", n);
    for (i = 0; i < n; i++)
        scanf("%d", &a[i]);
    printf("Enter K: ");
    if (scanf("%d", &k) != 1 || k < 0) {
        printf("Invalid K.\n");
        return 1;
    }
    k %= n;

    reverse(a, 0, k - 1);               /* reversal algorithm */
    reverse(a, k, n - 1);
    reverse(a, 0, n - 1);

    printf("Rotated left by %d:", k);
    for (i = 0; i < n; i++)
        printf(" %d", a[i]);
    printf("\n");
    return 0;
}
''', "7\n1 2 3 4 5 6 7\n3")

add(473, r'''
#include <stdio.h>
#define MAX 100

int main(void)
{
    int a[MAX], b[MAX], n, k, i;

    printf("Enter number of elements: ");
    if (scanf("%d", &n) != 1 || n < 1 || n > MAX) {
        printf("Invalid size.\n");
        return 1;
    }
    printf("Enter %d elements: ", n);
    for (i = 0; i < n; i++)
        scanf("%d", &a[i]);
    printf("Enter K: ");
    if (scanf("%d", &k) != 1 || k < 0) {
        printf("Invalid K.\n");
        return 1;
    }
    k %= n;

    for (i = 0; i < n; i++)             /* element i moves to (i+k) mod n */
        b[(i + k) % n] = a[i];

    printf("Rotated right by %d:", k);
    for (i = 0; i < n; i++)
        printf(" %d", b[i]);
    printf("\n");
    return 0;
}
''', "8\n10 20 30 40 50 60 70 80\n3")

add(474, r'''
#include <stdio.h>
#define MAX 100

int main(void)
{
    int a[MAX], n, i, pos = 0;

    printf("Enter number of elements: ");
    if (scanf("%d", &n) != 1 || n < 1 || n > MAX) {
        printf("Invalid size.\n");
        return 1;
    }
    printf("Enter %d elements: ", n);
    for (i = 0; i < n; i++)
        scanf("%d", &a[i]);

    for (i = 0; i < n; i++)             /* compact non-zero values */
        if (a[i] != 0)
            a[pos++] = a[i];
    while (pos < n)                     /* fill the rest with zeros */
        a[pos++] = 0;

    printf("Zeros moved to end:");
    for (i = 0; i < n; i++)
        printf(" %d", a[i]);
    printf("\n");
    return 0;
}
''', "9\n0 4 0 7 9 0 0 3 5")

add(475, r'''
#include <stdio.h>
#define MAX 100

int main(void)
{
    int a[MAX], b[MAX], n, i, k = 0;

    printf("Enter number of elements: ");
    if (scanf("%d", &n) != 1 || n < 1 || n > MAX) {
        printf("Invalid size.\n");
        return 1;
    }
    printf("Enter %d elements: ", n);
    for (i = 0; i < n; i++)
        scanf("%d", &a[i]);

    for (i = 0; i < n; i++)             /* negatives first */
        if (a[i] < 0)
            b[k++] = a[i];
    for (i = 0; i < n; i++)             /* then the others */
        if (a[i] >= 0)
            b[k++] = a[i];

    printf("Negatives first:");
    for (i = 0; i < n; i++)
        printf(" %d", b[i]);
    printf("\n");
    return 0;
}
''', "9\n6 -2 8 -9 0 3 -4 7 -1")

add(476, r'''
#include <stdio.h>
#define MAX 100

int main(void)
{
    int a[MAX], even[MAX], odd[MAX], n, i, ne = 0, no = 0;

    printf("Enter number of elements: ");
    if (scanf("%d", &n) != 1 || n < 1 || n > MAX) {
        printf("Invalid size.\n");
        return 1;
    }
    printf("Enter %d elements: ", n);
    for (i = 0; i < n; i++)
        scanf("%d", &a[i]);

    for (i = 0; i < n; i++) {
        if (a[i] % 2 == 0)
            even[ne++] = a[i];
        else
            odd[no++] = a[i];
    }

    printf("Even array:");
    for (i = 0; i < ne; i++)
        printf(" %d", even[i]);
    printf("\nOdd array :");
    for (i = 0; i < no; i++)
        printf(" %d", odd[i]);
    printf("\n");
    return 0;
}
''', "10\n11 24 5 38 17 6 90 3 8 21")

add(477, r'''
#include <stdio.h>
#define MAX 100

int main(void)
{
    int a[MAX], n, i, j, target, found = 0;

    printf("Enter number of elements: ");
    if (scanf("%d", &n) != 1 || n < 1 || n > MAX) {
        printf("Invalid size.\n");
        return 1;
    }
    printf("Enter %d elements: ", n);
    for (i = 0; i < n; i++)
        scanf("%d", &a[i]);
    printf("Enter target sum: ");
    scanf("%d", &target);

    printf("Pairs with sum %d:\n", target);
    for (i = 0; i < n; i++)
        for (j = i + 1; j < n; j++)
            if (a[i] + a[j] == target) {
                printf("  (%d, %d) at indices %d and %d\n", a[i], a[j], i, j);
                found = 1;
            }
    if (!found)
        printf("  No such pair found.\n");
    return 0;
}
''', "8\n2 7 4 5 9 1 6 3\n9")

add(478, r'''
#include <stdio.h>
#define MAX 100

int main(void)
{
    int a[MAX], n, i, sum = 0, expected;

    printf("Enter N (numbers are from 1 to N, one missing): ");
    if (scanf("%d", &n) != 1 || n < 2 || n > MAX) {
        printf("Invalid N.\n");
        return 1;
    }
    printf("Enter the %d given numbers: ", n - 1);
    for (i = 0; i < n - 1; i++) {
        scanf("%d", &a[i]);
        sum += a[i];
    }

    expected = n * (n + 1) / 2;         /* sum of 1..N */
    printf("Missing number = %d\n", expected - sum);
    return 0;
}
''', "10\n3 7 1 2 8 4 5 10 9")

add(479, r'''
#include <stdio.h>
#define MAX 100

int main(void)
{
    int a[MAX], n, i, j, dup = 0, found = 0;

    printf("Enter number of elements: ");
    if (scanf("%d", &n) != 1 || n < 1 || n > MAX) {
        printf("Invalid size.\n");
        return 1;
    }
    printf("Enter %d elements: ", n);
    for (i = 0; i < n; i++)
        scanf("%d", &a[i]);

    for (i = 0; i < n && !found; i++)
        for (j = i + 1; j < n; j++)
            if (a[i] == a[j]) {
                dup = a[i];
                found = 1;
                break;
            }

    if (found)
        printf("Duplicate value found: %d\n", dup);
    else
        printf("No duplicate values.\n");
    return 0;
}
''', "8\n6 3 9 1 4 9 2 8")

add(480, r'''
#include <stdio.h>
#define MAX 50

/* return 1 if value is already in arr[0..size-1] */
int contains(const int arr[], int size, int value)
{
    int i;
    for (i = 0; i < size; i++)
        if (arr[i] == value)
            return 1;
    return 0;
}

int main(void)
{
    int a[MAX], b[MAX], u[2 * MAX], n, m, i, k = 0;

    printf("Size of first array: ");
    if (scanf("%d", &n) != 1 || n < 1 || n > MAX) {
        printf("Invalid size.\n");
        return 1;
    }
    printf("Enter %d elements: ", n);
    for (i = 0; i < n; i++)
        scanf("%d", &a[i]);
    printf("Size of second array: ");
    if (scanf("%d", &m) != 1 || m < 1 || m > MAX) {
        printf("Invalid size.\n");
        return 1;
    }
    printf("Enter %d elements: ", m);
    for (i = 0; i < m; i++)
        scanf("%d", &b[i]);

    for (i = 0; i < n; i++)
        if (!contains(u, k, a[i]))
            u[k++] = a[i];
    for (i = 0; i < m; i++)
        if (!contains(u, k, b[i]))
            u[k++] = b[i];

    printf("Union:");
    for (i = 0; i < k; i++)
        printf(" %d", u[i]);
    printf("\n");
    return 0;
}
''', "5\n1 3 5 7 3\n5\n3 4 5 6 8")

add(481, r'''
#include <stdio.h>
#define MAX 50

int contains(const int arr[], int size, int value)
{
    int i;
    for (i = 0; i < size; i++)
        if (arr[i] == value)
            return 1;
    return 0;
}

int main(void)
{
    int a[MAX], b[MAX], r[MAX], n, m, i, k = 0;

    printf("Size of first array: ");
    if (scanf("%d", &n) != 1 || n < 1 || n > MAX) {
        printf("Invalid size.\n");
        return 1;
    }
    printf("Enter %d elements: ", n);
    for (i = 0; i < n; i++)
        scanf("%d", &a[i]);
    printf("Size of second array: ");
    if (scanf("%d", &m) != 1 || m < 1 || m > MAX) {
        printf("Invalid size.\n");
        return 1;
    }
    printf("Enter %d elements: ", m);
    for (i = 0; i < m; i++)
        scanf("%d", &b[i]);

    for (i = 0; i < n; i++)             /* in A, in B, not yet listed */
        if (contains(b, m, a[i]) && !contains(r, k, a[i]))
            r[k++] = a[i];

    printf("Intersection:");
    if (k == 0)
        printf(" (empty)");
    for (i = 0; i < k; i++)
        printf(" %d", r[i]);
    printf("\n");
    return 0;
}
''', "6\n2 4 6 8 4 10\n5\n4 8 12 2 14")

add(482, r'''
#include <stdio.h>
#define MAX 50

int contains(const int arr[], int size, int value)
{
    int i;
    for (i = 0; i < size; i++)
        if (arr[i] == value)
            return 1;
    return 0;
}

int main(void)
{
    int a[MAX], b[MAX], r[MAX], n, m, i, k = 0;

    printf("Size of first array: ");
    if (scanf("%d", &n) != 1 || n < 1 || n > MAX) {
        printf("Invalid size.\n");
        return 1;
    }
    printf("Enter %d elements: ", n);
    for (i = 0; i < n; i++)
        scanf("%d", &a[i]);
    printf("Size of second array: ");
    if (scanf("%d", &m) != 1 || m < 1 || m > MAX) {
        printf("Invalid size.\n");
        return 1;
    }
    printf("Enter %d elements: ", m);
    for (i = 0; i < m; i++)
        scanf("%d", &b[i]);

    for (i = 0; i < n; i++)             /* in A but not in B */
        if (!contains(b, m, a[i]) && !contains(r, k, a[i]))
            r[k++] = a[i];

    printf("A - B:");
    if (k == 0)
        printf(" (empty)");
    for (i = 0; i < k; i++)
        printf(" %d", r[i]);
    printf("\n");
    return 0;
}
''', "6\n1 2 3 4 5 2\n4\n2 4 6 8")

add(483, r'''
#include <stdio.h>
#define MAX 100

int main(void)
{
    int a[MAX], n, i, asc = 1, desc = 1;

    printf("Enter number of elements: ");
    if (scanf("%d", &n) != 1 || n < 1 || n > MAX) {
        printf("Invalid size.\n");
        return 1;
    }
    printf("Enter %d elements: ", n);
    for (i = 0; i < n; i++)
        scanf("%d", &a[i]);

    for (i = 0; i < n - 1; i++) {
        if (a[i] > a[i + 1])
            asc = 0;
        if (a[i] < a[i + 1])
            desc = 0;
    }

    if (asc)
        printf("The array is sorted in ascending order.\n");
    else if (desc)
        printf("The array is sorted in descending order.\n");
    else
        printf("The array is not sorted.\n");
    return 0;
}
''', "6\n3 8 8 12 20 31")

add(484, r'''
#include <stdio.h>
#define MAX 100

int main(void)
{
    int a[MAX], n, i, minVal, maxDiff;

    printf("Enter number of elements (at least 2): ");
    if (scanf("%d", &n) != 1 || n < 2 || n > MAX) {
        printf("Invalid size.\n");
        return 1;
    }
    printf("Enter %d elements: ", n);
    for (i = 0; i < n; i++)
        scanf("%d", &a[i]);

    minVal = a[0];
    maxDiff = a[1] - a[0];
    for (i = 1; i < n; i++) {
        if (a[i] - minVal > maxDiff)    /* best gap using smallest earlier value */
            maxDiff = a[i] - minVal;
        if (a[i] < minVal)
            minVal = a[i];
    }
    printf("Maximum difference a[j] - a[i] with i < j = %d\n", maxDiff);
    return 0;
}
''', "7\n7 9 5 6 3 2 11")

add(485, r'''
#include <stdio.h>
#define MAX 100

int main(void)
{
    int a[MAX], n, i, current, best;

    printf("Enter number of elements: ");
    if (scanf("%d", &n) != 1 || n < 1 || n > MAX) {
        printf("Invalid size.\n");
        return 1;
    }
    printf("Enter %d elements: ", n);
    for (i = 0; i < n; i++)
        scanf("%d", &a[i]);

    current = best = a[0];              /* Kadane's algorithm */
    for (i = 1; i < n; i++) {
        current = (current > 0) ? current + a[i] : a[i];
        if (current > best)
            best = current;
    }
    printf("Maximum subarray sum = %d\n", best);
    return 0;
}
''', "9\n-2 1 -3 4 -1 2 1 -5 4")

add(486, r'''
#include <stdio.h>
#define MAX 100

int main(void)
{
    int a[MAX], n, i, total = 0, left = 0, found = 0;

    printf("Enter number of elements: ");
    if (scanf("%d", &n) != 1 || n < 1 || n > MAX) {
        printf("Invalid size.\n");
        return 1;
    }
    printf("Enter %d elements: ", n);
    for (i = 0; i < n; i++) {
        scanf("%d", &a[i]);
        total += a[i];
    }

    for (i = 0; i < n; i++) {
        /* right sum = total - left - a[i] */
        if (left == total - left - a[i]) {
            printf("Equilibrium index: %d\n", i);
            found = 1;
        }
        left += a[i];
    }
    if (!found)
        printf("No equilibrium index exists.\n");
    return 0;
}
''', "7\n-7 1 5 2 -4 3 0")

add(487, r'''
#include <stdio.h>
#define MAX 100

int main(void)
{
    int a[MAX], leaders[MAX], n, i, k = 0, maxRight;

    printf("Enter number of elements: ");
    if (scanf("%d", &n) != 1 || n < 1 || n > MAX) {
        printf("Invalid size.\n");
        return 1;
    }
    printf("Enter %d elements: ", n);
    for (i = 0; i < n; i++)
        scanf("%d", &a[i]);

    maxRight = a[n - 1];                /* last element is always a leader */
    leaders[k++] = maxRight;
    for (i = n - 2; i >= 0; i--)
        if (a[i] > maxRight) {
            maxRight = a[i];
            leaders[k++] = a[i];
        }

    printf("Leaders:");
    for (i = k - 1; i >= 0; i--)        /* print in original order */
        printf(" %d", leaders[i]);
    printf("\n");
    return 0;
}
''', "7\n16 17 4 3 5 2 1")

add(488, r'''
#include <stdio.h>
#define MAX 100

int main(void)
{
    int a[MAX], n, i, j, count, majority = 0, found = 0;

    printf("Enter number of elements: ");
    if (scanf("%d", &n) != 1 || n < 1 || n > MAX) {
        printf("Invalid size.\n");
        return 1;
    }
    printf("Enter %d elements: ", n);
    for (i = 0; i < n; i++)
        scanf("%d", &a[i]);

    for (i = 0; i < n && !found; i++) {
        count = 0;
        for (j = 0; j < n; j++)
            if (a[j] == a[i])
                count++;
        if (count > n / 2) {            /* appears more than n/2 times */
            majority = a[i];
            found = 1;
        }
    }

    if (found)
        printf("Majority element: %d\n", majority);
    else
        printf("No majority element exists.\n");
    return 0;
}
''', "9\n3 3 4 2 3 3 1 3 5")

add(489, r'''
#include <stdio.h>
#define MAX 100

int main(void)
{
    int a[MAX], n, i, len = 1, best = 1, start = 0, bestStart = 0;

    printf("Enter number of elements: ");
    if (scanf("%d", &n) != 1 || n < 1 || n > MAX) {
        printf("Invalid size.\n");
        return 1;
    }
    printf("Enter %d elements: ", n);
    for (i = 0; i < n; i++)
        scanf("%d", &a[i]);

    for (i = 1; i < n; i++) {
        if (a[i] > a[i - 1])
            len++;                      /* run continues */
        else {
            len = 1;                    /* run restarts here */
            start = i;
        }
        if (len > best) {
            best = len;
            bestStart = start;
        }
    }

    printf("Longest increasing run has length %d:", best);
    for (i = bestStart; i < bestStart + best; i++)
        printf(" %d", a[i]);
    printf("\n");
    return 0;
}
''', "10\n5 1 2 3 2 4 6 8 9 3")

add(490, r'''
#include <stdio.h>
#define MAX 100

int main(void)
{
    int a[MAX], prefix[MAX], n, i;

    printf("Enter number of elements: ");
    if (scanf("%d", &n) != 1 || n < 1 || n > MAX) {
        printf("Invalid size.\n");
        return 1;
    }
    printf("Enter %d elements: ", n);
    for (i = 0; i < n; i++)
        scanf("%d", &a[i]);

    prefix[0] = a[0];
    for (i = 1; i < n; i++)
        prefix[i] = prefix[i - 1] + a[i];

    printf("Original  :");
    for (i = 0; i < n; i++)
        printf(" %d", a[i]);
    printf("\nPrefix sum:");
    for (i = 0; i < n; i++)
        printf(" %d", prefix[i]);
    printf("\n");
    return 0;
}
''', "6\n3 1 4 1 5 9")

add(491, r'''
#include <stdio.h>
#define MAX 100

int main(void)
{
    int a[MAX], n, i, bestSum, bestIdx = 0;

    printf("Enter number of elements (at least 2): ");
    if (scanf("%d", &n) != 1 || n < 2 || n > MAX) {
        printf("Invalid size.\n");
        return 1;
    }
    printf("Enter %d elements: ", n);
    for (i = 0; i < n; i++)
        scanf("%d", &a[i]);

    bestSum = a[0] + a[1];
    for (i = 1; i < n - 1; i++)
        if (a[i] + a[i + 1] > bestSum) {
            bestSum = a[i] + a[i + 1];
            bestIdx = i;
        }

    printf("Largest adjacent pair: (%d, %d) with sum %d\n",
           a[bestIdx], a[bestIdx + 1], bestSum);
    return 0;
}
''', "8\n4 -2 9 3 7 -5 6 1")

add(492, r'''
#include <stdio.h>
#define MAX 100

int main(void)
{
    int a[MAX], n, i, run = 1, best = 1, value;

    printf("Enter number of elements: ");
    if (scanf("%d", &n) != 1 || n < 1 || n > MAX) {
        printf("Invalid size.\n");
        return 1;
    }
    printf("Enter %d elements: ", n);
    for (i = 0; i < n; i++)
        scanf("%d", &a[i]);

    value = a[0];
    for (i = 1; i < n; i++) {
        if (a[i] == a[i - 1])
            run++;
        else
            run = 1;
        if (run > best) {
            best = run;
            value = a[i];
        }
    }
    printf("Longest run: value %d repeated %d time(s)\n", value, best);
    return 0;
}
''', "12\n1 1 2 2 2 3 3 1 1 1 1 4")

add(493, r'''
#include <stdio.h>
#define MAX 100

int main(void)
{
    int a[MAX], n, i, nonZero = 0;
    long long product = 1;

    printf("Enter number of elements: ");
    if (scanf("%d", &n) != 1 || n < 1 || n > MAX) {
        printf("Invalid size.\n");
        return 1;
    }
    printf("Enter %d elements: ", n);
    for (i = 0; i < n; i++) {
        scanf("%d", &a[i]);
        if (a[i] != 0) {                /* skip zeros */
            product *= a[i];
            nonZero++;
        }
    }

    if (nonZero == 0)
        printf("All elements are zero; no non-zero product.\n");
    else
        printf("Product of %d non-zero elements = %lld\n", nonZero, product);
    return 0;
}
''', "8\n2 0 -3 4 0 5 1 0")

add(494, r'''
#include <stdio.h>
#define MAX 50

int main(void)
{
    int a[MAX], b[MAX], c[2 * MAX], n, m, i = 0, j = 0, k = 0;

    printf("Size of first array: ");
    if (scanf("%d", &n) != 1 || n < 1 || n > MAX) {
        printf("Invalid size.\n");
        return 1;
    }
    printf("Enter %d elements: ", n);
    for (i = 0; i < n; i++)
        scanf("%d", &a[i]);
    printf("Size of second array: ");
    if (scanf("%d", &m) != 1 || m < 1 || m > MAX) {
        printf("Invalid size.\n");
        return 1;
    }
    printf("Enter %d elements: ", m);
    for (i = 0; i < m; i++)
        scanf("%d", &b[i]);

    i = 0;
    while (i < n && j < m) {            /* alternate a, b, a, b ... */
        c[k++] = a[i++];
        c[k++] = b[j++];
    }
    while (i < n)                       /* leftovers of the longer array */
        c[k++] = a[i++];
    while (j < m)
        c[k++] = b[j++];

    printf("Interleaved array:");
    for (i = 0; i < k; i++)
        printf(" %d", c[i]);
    printf("\n");
    return 0;
}
''', "4\n1 3 5 7\n6\n2 4 6 8 10 12")

add(495, r'''
#include <stdio.h>
#define MAX 100

int main(void)
{
    int a[MAX], n, i, j, t;
    double median;

    printf("Enter number of elements: ");
    if (scanf("%d", &n) != 1 || n < 1 || n > MAX) {
        printf("Invalid size.\n");
        return 1;
    }
    printf("Enter %d elements: ", n);
    for (i = 0; i < n; i++)
        scanf("%d", &a[i]);

    for (i = 0; i < n - 1; i++)         /* bubble sort */
        for (j = 0; j < n - 1 - i; j++)
            if (a[j] > a[j + 1]) {
                t = a[j];
                a[j] = a[j + 1];
                a[j + 1] = t;
            }

    if (n % 2 == 1)
        median = a[n / 2];
    else
        median = (a[n / 2 - 1] + a[n / 2]) / 2.0;

    printf("Sorted:");
    for (i = 0; i < n; i++)
        printf(" %d", a[i]);
    printf("\nMedian = %.2f\n", median);
    return 0;
}
''', "8\n40 12 7 25 33 18 9 50")

add(496, r'''
#include <stdio.h>
#define MAX 20

int main(void)
{
    int numbers[MAX], count, i;

    printf("=== Array Input and Display ===\n");
    printf("How many integers do you want to enter (1-%d)? ", MAX);
    if (scanf("%d", &count) != 1 || count < 1 || count > MAX) {
        printf("Error: please enter a number between 1 and %d.\n", MAX);
        return 1;
    }
    for (i = 0; i < count; i++) {
        printf("Enter integer %d: ", i + 1);
        scanf("%d", &numbers[i]);
    }

    printf("\nThe array contains:\n");
    for (i = 0; i < count; i++)
        printf("numbers[%d] = %d\n", i, numbers[i]);
    return 0;
}
''', "4\n31\n-7\n0\n256")

add(497, r'''
#include <stdio.h>
#define MAX 100

/* return the sum of the first n elements of arr */
int arraySum(const int arr[], int n)
{
    int i, sum = 0;
    for (i = 0; i < n; i++)
        sum += arr[i];
    return sum;
}

int main(void)
{
    int a[MAX], n, i;

    printf("Enter number of elements: ");
    if (scanf("%d", &n) != 1 || n < 1 || n > MAX) {
        printf("Invalid size.\n");
        return 1;
    }
    printf("Enter %d elements: ", n);
    for (i = 0; i < n; i++)
        scanf("%d", &a[i]);

    printf("Sum of array elements = %d\n", arraySum(a, n));
    return 0;
}
''', "6\n17 -4 9 30 12 8")

add(498, r'''
#include <stdio.h>
#define MAX 100

int main(void)
{
    int a[MAX], n, i, sum = 0;

    printf("Enter number of elements (1-%d): ", MAX);
    if (scanf("%d", &n) != 1) {
        printf("Error: that is not a valid integer.\n");
        return 1;
    }
    if (n < 1 || n > MAX) {
        printf("Error: count must be between 1 and %d.\n", MAX);
        return 1;
    }
    for (i = 0; i < n; i++) {
        printf("Element %d: ", i + 1);
        if (scanf("%d", &a[i]) != 1) {  /* reject non-numeric input */
            printf("Error: element %d is not a valid integer.\n", i + 1);
            return 1;
        }
        sum += a[i];
    }
    printf("Average = %.2f\n", (double)sum / n);
    return 0;
}
''', "5\n12\n18\n25\n7\n30")

add(499, r'''
#include <stdio.h>
#define MAX 100

/* return the largest of the first n elements */
int findLargest(const int arr[], int n)
{
    int i, largest = arr[0];
    for (i = 1; i < n; i++)
        if (arr[i] > largest)
            largest = arr[i];
    return largest;
}

int main(void)
{
    int tests, t, n, i, a[MAX];

    printf("Number of test cases: ");
    if (scanf("%d", &tests) != 1 || tests < 1) {
        printf("Invalid input.\n");
        return 1;
    }
    for (t = 1; t <= tests; t++) {      /* run several sample inputs */
        if (scanf("%d", &n) != 1 || n < 1 || n > MAX) {
            printf("Test %d: invalid size.\n", t);
            return 1;
        }
        printf("Test %d input:", t);
        for (i = 0; i < n; i++) {
            scanf("%d", &a[i]);
            printf(" %d", a[i]);
        }
        printf("\n  -> largest = %d\n", findLargest(a, n));
    }
    return 0;
}
''', "3\n5 4 18 7 2 11\n4 -9 -3 -20 -5\n1 42")

add(500, r'''
#include <stdio.h>
#define MAX 100

int main(void)
{
    int a[MAX], n, i, smallest;

    printf("Enter number of elements: ");
    if (scanf("%d", &n) != 1 || n < 1 || n > MAX) {
        printf("Invalid size.\n");
        return 1;
    }
    printf("Enter %d elements: ", n);
    for (i = 0; i < n; i++)
        scanf("%d", &a[i]);

    /* Assume the first element is the smallest so far. */
    smallest = a[0];

    /* Compare every other element with the current smallest;
       whenever a smaller value appears, remember it. */
    for (i = 1; i < n; i++)
        if (a[i] < smallest)
            smallest = a[i];

    printf("Smallest element = %d\n", smallest);
    return 0;
}
''', "7\n23 9 41 -6 15 -6 30")
