# programs 826-875 : id -> (stdin, code)
P = {}
def add(i, code, stdin=""): P[i] = (stdin, code.strip("\n"))

add(826, r'''
#include <stdio.h>

int main(void)
{
    const char *text = "Pointers in C";
    const char *p = text;       /* walker pointer */

    while (*p != '\0')          /* move until the terminator */
        p++;

    printf("String : %s\n", text);
    printf("Length : %ld\n", (long)(p - text));   /* pointer difference */
    return 0;
}
''')
add(827, r'''
#include <stdio.h>

int main(void)
{
    int src[6] = {4, 8, 15, 16, 23, 42};
    int dst[6];
    const int *s = src;
    int *d = dst;

    for (int i = 0; i < 6; i++)
        *d++ = *s++;            /* copy element, advance both pointers */

    printf("Source     :");
    for (int i = 0; i < 6; i++) printf(" %d", src[i]);
    printf("\nDestination:");
    for (int i = 0; i < 6; i++) printf(" %d", dst[i]);
    printf("\n");
    return 0;
}
''')
add(828, r'''
#include <stdio.h>

/* Bubble sort using only pointer parameters */
void sort(int *start, int *end)
{
    for (int *i = start; i < end - 1; i++)
        for (int *j = start; j < end - 1 - (i - start); j++)
            if (*j > *(j + 1)) {
                int t = *j;
                *j = *(j + 1);
                *(j + 1) = t;
            }
}

int main(void)
{
    int a[] = {29, 5, 17, 3, 41, 12, 8};
    int n = sizeof(a) / sizeof(a[0]);

    printf("Before:");
    for (int *p = a; p < a + n; p++) printf(" %d", *p);
    sort(a, a + n);
    printf("\nAfter :");
    for (int *p = a; p < a + n; p++) printf(" %d", *p);
    printf("\n");
    return 0;
}
''')
add(829, r'''
#include <stdio.h>

#define COLS 3

/* The column count must be given in the parameter */
void show(int m[][COLS], int rows)
{
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < COLS; j++)
            printf("%4d", m[i][j]);
        printf("\n");
    }
}

int main(void)
{
    int grid[2][COLS] = {{1, 2, 3}, {4, 5, 6}};

    printf("2D array passed to a function:\n");
    show(grid, 2);
    return 0;
}
''')
add(830, r'''
#include <stdio.h>
#include <stddef.h>

/* Returns 1 on success, 0 if the pointer is NULL */
int print_value(const int *p, const char *name)
{
    if (p == NULL) {
        printf("%s is NULL - cannot dereference\n", name);
        return 0;
    }
    printf("%s points to %d\n", name, *p);
    return 1;
}

int main(void)
{
    int x = 99;
    int *good = &x;
    int *bad = NULL;

    print_value(good, "good");
    print_value(bad, "bad");
    return 0;
}
''')
add(831, r'''
#include <stdio.h>

int main(void)
{
    int a[] = {14, 72, 33, 91, 5, 60};
    int n = 6;
    int *p = a;
    int *max = a;

    for (; p < a + n; p++)
        if (*p > *max)
            max = p;            /* remember the position of the largest */

    printf("Maximum = %d at index %ld\n", *max, (long)(max - a));
    return 0;
}
''')
add(832, r'''
#include <stdio.h>

/* Copy n bytes from src to dst */
void copy_bytes(void *dst, const void *src, size_t n)
{
    unsigned char *d = dst;
    const unsigned char *s = src;
    while (n--)
        *d++ = *s++;
}

int main(void)
{
    int src[4] = {10, 20, 30, 40};
    int dst[4] = {0};

    copy_bytes(dst, src, sizeof(src));
    printf("Copied %zu bytes\n", sizeof(src));
    for (int i = 0; i < 4; i++)
        printf("dst[%d] = %d\n", i, dst[i]);
    return 0;
}
''')
add(833, r'''
#include <stdio.h>

/* const int * : function may read but not modify the data */
int sum(const int *arr, int n)
{
    int total = 0;
    for (int i = 0; i < n; i++)
        total += arr[i];        /* arr[i] = 0; would not compile */
    return total;
}

/* int *const : the pointer itself cannot be changed */
void set_first(int *const arr, int value)
{
    arr[0] = value;
}

int main(void)
{
    int data[4] = {3, 6, 9, 12};

    printf("Sum = %d\n", sum(data, 4));
    set_first(data, 100);
    printf("Sum after set_first = %d\n", sum(data, 4));
    return 0;
}
''')
add(834, r'''
#include <stdio.h>

struct Point {
    int x;
    int y;
};

void move(struct Point *p, int dx, int dy)
{
    p->x += dx;                 /* arrow operator through the pointer */
    p->y += dy;
}

void show(const struct Point *p)
{
    printf("Point(%d, %d)\n", p->x, p->y);
}

int main(void)
{
    struct Point pt = {2, 3};

    show(&pt);
    move(&pt, 5, -1);
    show(&pt);
    return 0;
}
''')
add(835, r'''
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(void)
{
    const char *src = "Dynamic string";
    char *copy = malloc(strlen(src) + 1);   /* +1 for '\0' */

    if (copy == NULL) {
        printf("Allocation failed\n");
        return 1;
    }
    strcpy(copy, src);
    printf("Allocated string: %s\n", copy);
    free(copy);                              /* release memory */
    copy = NULL;
    printf("Memory released\n");
    return 0;
}
''')
add(836, r'''
#include <stdio.h>

int main(void)
{
    int num;
    int *ptr = &num;

    printf("Enter an integer: ");
    if (scanf("%d", &num) != 1) {
        printf("Invalid input\n");
        return 1;
    }
    printf("Value of num      : %d\n", num);
    printf("Value via *ptr    : %d\n", *ptr);
    printf("ptr holds &num    : %s\n", ptr == &num ? "yes" : "no");
    printf("Address is %zu bytes wide\n", sizeof(ptr));
    return 0;
}
''', "57")
add(837, r'''
#include <stdio.h>

/* Initialise the target through a pointer and print it */
void init_and_show(int *p, int value)
{
    *p = value;                 /* dereference to store */
    printf("Stored %d, read back %d\n", value, *p);
}

int main(void)
{
    int x = 0;
    int *p = &x;                /* initialised before use */

    printf("Before: x = %d\n", x);
    init_and_show(p, 123);
    printf("After : x = %d\n", x);
    return 0;
}
''')
add(838, r'''
#include <stdio.h>

void swap(int *a, int *b)
{
    int t = *a;
    *a = *b;
    *b = t;
}

int main(void)
{
    int x, y;

    printf("Enter two integers: ");
    if (scanf("%d %d", &x, &y) != 2) {
        printf("Error: please enter two valid integers.\n");
        return 1;
    }
    printf("Before swap: x = %d, y = %d\n", x, y);
    swap(&x, &y);
    printf("After swap : x = %d, y = %d\n", x, y);
    return 0;
}
''', "15 -7")
add(839, r'''
#include <stdio.h>

int *larger(int *a, int *b)
{
    return (*a >= *b) ? a : b;
}

int main(void)
{
    int tests[3][2] = {{10, 20}, {-5, -9}, {7, 7}};

    for (int i = 0; i < 3; i++) {
        int *big = larger(&tests[i][0], &tests[i][1]);
        printf("Test %d: %d and %d -> larger is %d\n",
               i + 1, tests[i][0], tests[i][1], *big);
    }
    return 0;
}
''')
add(840, r'''
#include <stdio.h>

int main(void)
{
    int a[5] = {11, 22, 33, 44, 55};
    int *p = a;                 /* points to a[0] */

    /* p + i moves i elements forward, not i bytes */
    for (int i = 0; i < 5; i++)
        printf("*(p + %d) = %d\n", i, *(p + i));

    /* the same traversal by incrementing the pointer */
    printf("Using p++ :");
    for (p = a; p < a + 5; p++)
        printf(" %d", *p);
    printf("\n");
    return 0;
}
''')
add(841, r'''
#include <stdio.h>

long sum(const int *p, int n)
{
    long total = 0;
    if (p == NULL || n <= 0)    /* boundary cases */
        return 0;
    while (n--)
        total += *p++;
    return total;
}

int main(void)
{
    int a[] = {5, 10, 15, 20};
    int one[] = {42};

    printf("Normal array  : %ld\n", sum(a, 4));
    printf("Single element: %ld\n", sum(one, 1));
    printf("Empty (n = 0) : %ld\n", sum(a, 0));
    printf("NULL pointer  : %ld\n", sum(NULL, 3));
    return 0;
}
''')
add(842, r'''
#include <stdio.h>

void copy_str(char *dst, const char *src)
{
    while ((*dst++ = *src++) != '\0')
        ;
}

int main(void)
{
    char src[100], dst[100];
    int choice;

    printf("1. Copy a string\n2. Exit\n");
    while (printf("Choice: "), scanf("%d", &choice) == 1 && choice != 2) {
        if (choice == 1) {
            if (scanf("%99s", src) != 1) break;
            copy_str(dst, src);
            printf("Source: %s\nCopy  : %s\n", src, dst);
        } else {
            printf("Invalid choice\n");
        }
    }
    printf("Goodbye\n");
    return 0;
}
''', "1 hello 1 pointers 7 2")
add(843, r'''
#include <stdio.h>
#include <string.h>

int main(void)
{
    char s[] = "pointer";
    char *left = s;
    char *right = s + strlen(s) - 1;

    printf("Original: %s\n", s);
    while (left < right) {
        char t = *left;
        *left = *right;
        *right = t;
        left++;
        right--;
        printf("  swapped -> %s\n", s);   /* intermediate step */
    }
    printf("Reversed: %s\n", s);
    return 0;
}
''')
add(844, r'''
#include <stdio.h>

int main(void)
{
    char a[50], b[50];

    printf("Enter two words: ");
    if (scanf("%49s %49s", a, b) != 2) {
        printf("Invalid input\n");
        return 1;
    }
    const char *p = a, *q = b;
    while (*p != '\0' && *p == *q) {    /* stop at first difference */
        p++;
        q++;
    }
    if (*p == *q)
        printf("\"%s\" and \"%s\" are equal\n", a, b);
    else
        printf("\"%s\" and \"%s\" differ at position %ld\n", a, b, (long)(p - a) + 1);
    return 0;
}
''', "apple apply")
add(845, r'''
#include <stdio.h>

int main(void)
{
    char line[100];
    int letters = 0, digits = 0, spaces = 0, others = 0;

    printf("Enter a line: ");
    if (fgets(line, sizeof line, stdin) == NULL) return 1;

    for (const char *p = line; *p != '\0' && *p != '\n'; p++) {
        if ((*p >= 'a' && *p <= 'z') || (*p >= 'A' && *p <= 'Z')) letters++;
        else if (*p >= '0' && *p <= '9') digits++;
        else if (*p == ' ') spaces++;
        else others++;
    }
    printf("Letters: %d\nDigits : %d\nSpaces : %d\nOthers : %d\n",
           letters, digits, spaces, others);
    return 0;
}
''', "Call 555-1234 now!\n")
add(846, r'''
#include <stdio.h>

/* Doubles every element through the pointer */
void double_all(int *arr, int n)
{
    for (int i = 0; i < n; i++)
        arr[i] *= 2;
}

void increment(int *p)
{
    (*p)++;
}

int main(void)
{
    int a[5] = {1, 2, 3, 4, 5};
    int counter = 10;

    increment(&counter);
    printf("counter = %d\n", counter);
    double_all(a, 5);
    printf("Array after doubling:");
    for (int i = 0; i < 5; i++) printf(" %d", a[i]);
    printf("\n");
    return 0;
}
''')
add(847, r'''
#include <stdio.h>

struct Item {
    int id;
    int qty;
};

int main(void)
{
    struct Item item = {101, 25};
    int *p = &item.qty;         /* pointer to a member */
    int **pp = &p;              /* pointer to pointer */

    printf("Item id = %d\n", item.id);
    printf("qty directly      : %d\n", item.qty);
    printf("qty via *p        : %d\n", *p);
    printf("qty via **pp      : %d\n", **pp);
    **pp = 30;
    printf("qty after **pp=30 : %d\n", item.qty);
    return 0;
}
''')
add(848, r'''
#include <stdio.h>

int main(void)
{
    const char *days[] = {"Monday", "Tuesday", "Wednesday", "Thursday", "Friday"};
    int n = sizeof(days) / sizeof(days[0]);

    printf("Array of %d string pointers:\n", n);
    for (int i = 0; i < n; i++) {
        int len = 0;
        for (const char *p = days[i]; *p; p++) len++;
        printf("%d. %-10s (%d chars, first letter '%c')\n", i + 1, days[i], len, *days[i]);
    }
    return 0;
}
''')
add(849, r'''
#include <stdio.h>

int main(void)
{
    int a[4] = {10, 20, 30, 40};
    int (*pa)[4] = &a;          /* pointer to an array of 4 ints */

    printf("=== Pointer to array ===\n");
    printf("%-14s: %zu bytes\n", "sizeof(a)", sizeof(a));
    printf("%-14s: %zu bytes\n", "sizeof(*pa)", sizeof(*pa));
    for (int i = 0; i < 4; i++)
        printf("(*pa)[%d]       = %d\n", i, (*pa)[i]);
    return 0;
}
''')
add(850, r'''
#include <stdio.h>

double add(double a, double b) { return a + b; }
double sub(double a, double b) { return a - b; }
double mul(double a, double b) { return a * b; }
double divide(double a, double b) { return a / b; }

int main(void)
{
    double x, y;
    char op;
    double (*fn)(double, double) = NULL;

    printf("Enter: number number operator(+ - * /): ");
    if (scanf("%lf %lf %c", &x, &y, &op) != 3) {
        printf("Error: invalid input\n");
        return 1;
    }
    switch (op) {
        case '+': fn = add; break;
        case '-': fn = sub; break;
        case '*': fn = mul; break;
        case '/':
            if (y == 0) { printf("Error: division by zero\n"); return 1; }
            fn = divide;
            break;
        default:
            printf("Error: unknown operator '%c'\n", op);
            return 1;
    }
    printf("%.2f %c %.2f = %.2f\n", x, op, y, fn(x, y));
    return 0;
}
''', "12.5 4 /")
add(851, r'''
#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int *p = malloc(sizeof(int));

    if (p == NULL) {
        printf("Out of memory\n");
        return 1;
    }
    *p = 2026;
    printf("Value in allocated memory: %d\n", *p);
    free(p);
    return 0;
}
''')
add(852, r'''
#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int n;

    printf("How many integers? ");
    if (scanf("%d", &n) != 1 || n <= 0) {
        printf("Invalid count\n");
        return 1;
    }
    int *a = malloc(n * sizeof(int));
    if (a == NULL) return 1;

    printf("Enter %d integers: ", n);
    for (int i = 0; i < n; i++)
        if (scanf("%d", &a[i]) != 1) { free(a); return 1; }

    printf("You entered:");
    for (int i = 0; i < n; i++) printf(" %d", a[i]);
    printf("\n");
    free(a);
    return 0;
}
''', "5\n10 20 30 40 50")
add(853, r'''
#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int n;

    printf("Size of array: ");
    if (scanf("%d", &n) != 1 || n <= 0) return 1;
    int *a = malloc(n * sizeof *a);
    if (a == NULL) return 1;

    printf("Enter %d values: ", n);
    for (int i = 0; i < n; i++)
        if (scanf("%d", &a[i]) != 1) { free(a); return 1; }

    int max = a[0];
    for (int i = 1; i < n; i++)
        if (a[i] > max) max = a[i];
    printf("Maximum = %d\n", max);
    free(a);
    return 0;
}
''', "6\n23 87 5 64 91 12")
add(854, r'''
#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int n = 6;
    int *a = calloc(n, sizeof(int));    /* every element starts at 0 */

    if (a == NULL) return 1;
    printf("After calloc  :");
    for (int i = 0; i < n; i++) printf(" %d", a[i]);

    for (int i = 0; i < n; i++) a[i] = (i + 1) * 5;
    printf("\nAfter filling :");
    for (int i = 0; i < n; i++) printf(" %d", a[i]);
    printf("\n");
    free(a);
    return 0;
}
''')
add(855, r'''
#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int *a = malloc(3 * sizeof(int));
    if (a == NULL) return 1;
    for (int i = 0; i < 3; i++) a[i] = i + 1;

    int *bigger = realloc(a, 6 * sizeof(int));   /* grow to 6 */
    if (bigger == NULL) { free(a); return 1; }
    a = bigger;
    for (int i = 3; i < 6; i++) a[i] = (i + 1) * 10;

    printf("Resized array:");
    for (int i = 0; i < 6; i++) printf(" %d", a[i]);
    printf("\n");
    free(a);
    return 0;
}
''')
add(856, r'''
#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int cap = 2, count = 0, v;
    int *a = malloc(cap * sizeof(int));
    if (a == NULL) return 1;

    printf("Enter numbers (0 to stop): ");
    while (scanf("%d", &v) == 1 && v != 0) {
        if (count == cap) {                 /* full: double capacity */
            cap *= 2;
            int *t = realloc(a, cap * sizeof(int));
            if (t == NULL) { free(a); return 1; }
            a = t;
            printf("[array grown to %d]\n", cap);
        }
        a[count++] = v;
    }
    printf("Stored %d values:", count);
    for (int i = 0; i < count; i++) printf(" %d", a[i]);
    printf("\n");
    free(a);
    return 0;
}
''', "3 6 9 12 15 0")
add(857, r'''
#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int cap;
    int c;

    printf("Buffer capacity: ");
    if (scanf("%d", &cap) != 1 || cap < 2) { printf("Invalid capacity\n"); return 1; }
    while ((c = getchar()) != '\n' && c != EOF) ;   /* skip rest of line */

    char *buf = malloc(cap);
    if (buf == NULL) return 1;
    printf("Enter text: ");
    if (fgets(buf, cap, stdin) == NULL) { free(buf); return 1; }
    printf("Stored (max %d chars): \"%s\"\n", cap - 1, buf);
    free(buf);
    return 0;
}
''', "12\nHello, dynamic world\n")
add(858, r'''
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(void)
{
    char *line = malloc(100);

    if (line == NULL) return 1;
    printf("Type a sentence: ");
    if (fgets(line, 100, stdin) == NULL) { free(line); return 1; }
    line[strcspn(line, "\n")] = '\0';       /* remove newline */
    printf("Line read : %s\n", line);
    printf("Length    : %zu\n", strlen(line));
    free(line);
    return 0;
}
''', "Memory on the heap\n")
add(859, r'''
#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int r = 3, c = 4;
    int **m = malloc(r * sizeof(int *));
    if (m == NULL) return 1;

    for (int i = 0; i < r; i++) {
        m[i] = malloc(c * sizeof(int));
        if (m[i] == NULL) return 1;
        for (int j = 0; j < c; j++)
            m[i][j] = i * c + j + 1;
    }
    printf("Matrix %dx%d:\n", r, c);
    for (int i = 0; i < r; i++) {
        for (int j = 0; j < c; j++) printf("%4d", m[i][j]);
        printf("\n");
    }
    for (int i = 0; i < r; i++) free(m[i]);
    free(m);
    return 0;
}
''')
add(860, r'''
#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int rows = 4;
    int len[4] = {1, 2, 3, 4};
    int *jag[4];

    for (int i = 0; i < rows; i++) {
        jag[i] = malloc(len[i] * sizeof(int));
        if (jag[i] == NULL) return 1;
        for (int j = 0; j < len[i]; j++)
            jag[i][j] = (i + 1) * (j + 1);
    }
    for (int i = 0; i < rows; i++) {
        printf("Row %d (%d items):", i, len[i]);
        for (int j = 0; j < len[i]; j++) printf(" %d", jag[i][j]);
        printf("\n");
    }
    for (int i = 0; i < rows; i++) free(jag[i]);
    return 0;
}
''')
add(861, r'''
#include <stdio.h>
#include <stdlib.h>

struct Student {
    int roll;
    char name[20];
    float marks;
};

int main(void)
{
    int n;

    printf("Number of students: ");
    if (scanf("%d", &n) != 1 || n <= 0) return 1;
    struct Student *s = malloc(n * sizeof(struct Student));
    if (s == NULL) return 1;

    for (int i = 0; i < n; i++) {
        printf("Roll, name, marks: ");
        if (scanf("%d %19s %f", &s[i].roll, s[i].name, &s[i].marks) != 3) {
            free(s);
            return 1;
        }
    }
    printf("\n%-6s %-10s %6s\n", "Roll", "Name", "Marks");
    for (int i = 0; i < n; i++)
        printf("%-6d %-10s %6.1f\n", s[i].roll, s[i].name, s[i].marks);
    free(s);
    return 0;
}
''', "3\n1 Asha 88.5\n2 Ravi 72\n3 Meena 91.25")
add(862, r'''
#include <stdio.h>
#include <stdlib.h>

struct Node {
    int data;
    struct Node *next;
};

int main(void)
{
    struct Node *head = NULL;

    for (int i = 3; i >= 1; i--) {          /* insert at front */
        struct Node *n = malloc(sizeof *n);
        if (n == NULL) return 1;
        n->data = i * 10;
        n->next = head;
        head = n;
    }
    printf("List:");
    for (struct Node *p = head; p != NULL; p = p->next)
        printf(" %d ->", p->data);
    printf(" NULL\n");

    int freed = 0;
    while (head != NULL) {
        struct Node *t = head;
        head = head->next;
        free(t);
        freed++;
    }
    printf("Freed %d nodes\n", freed);
    return 0;
}
''')
add(863, r'''
#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    /* an absurdly large request is likely to fail */
    size_t huge = (size_t)-1 / 2;
    int *p = malloc(huge);

    if (p == NULL) {
        printf("malloc failed: not enough memory, handled gracefully\n");
    } else {
        printf("Allocation succeeded\n");
        free(p);
    }

    int *q = malloc(5 * sizeof(int));
    if (q == NULL) {
        printf("Small allocation failed\n");
        return 1;
    }
    printf("Small allocation of 5 ints succeeded\n");
    free(q);
    return 0;
}
''')
add(864, r'''
#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int *a = malloc(4 * sizeof(int));
    char *s = malloc(16);
    double *d = malloc(sizeof(double));

    if (a == NULL || s == NULL || d == NULL) {
        free(a); free(s); free(d);          /* free(NULL) is safe */
        return 1;
    }
    for (int i = 0; i < 4; i++) a[i] = i * i;
    snprintf(s, 16, "memory");
    *d = 3.14;
    printf("a[3]=%d s=%s d=%.2f\n", a[3], s, *d);

    free(a);
    free(s);
    free(d);
    printf("All three blocks freed before exit\n");
    return 0;
}
''')
add(865, r'''
#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int n = 5;
    int *m = malloc(n * sizeof(int));
    int *c = calloc(n, sizeof(int));

    if (m == NULL || c == NULL) { free(m); free(c); return 1; }

    /* malloc memory is uninitialised, so set it before printing */
    for (int i = 0; i < n; i++) m[i] = -1;
    printf("calloc block (zeroed) :");
    for (int i = 0; i < n; i++) printf(" %d", c[i]);
    printf("\nmalloc block (we set) :");
    for (int i = 0; i < n; i++) printf(" %d", m[i]);
    printf("\nmalloc(n*size) takes 1 argument; calloc(n, size) takes 2 and zeroes memory\n");
    free(m);
    free(c);
    return 0;
}
''')
add(866, r'''
#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int *p = malloc(sizeof(int));
    if (p == NULL) return 1;
    *p = 77;
    printf("Before free: *p = %d\n", *p);
    free(p);

    /* UNSAFE: p is now a dangling pointer; *p here would be undefined behaviour */
    printf("p is dangling now - do not use it.\n");

    p = NULL;                               /* safe alternative */
    if (p == NULL)
        printf("Safe: p set to NULL, check before use\n");
    else
        printf("Value = %d\n", *p);
    return 0;
}
''')
add(867, r'''
#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int *a = malloc(2 * sizeof(int));
    if (a == NULL) return 1;
    a[0] = 8; a[1] = 9;

    /* never write a = realloc(a, ...): on failure the old block leaks */
    int *tmp = realloc(a, 5 * sizeof(int));
    if (tmp == NULL) {
        printf("realloc failed, old data still valid\n");
        free(a);
        return 1;
    }
    a = tmp;
    a[2] = 10; a[3] = 11; a[4] = 12;
    printf("Array:");
    for (int i = 0; i < 5; i++) printf(" %d", a[i]);
    printf("\n");
    free(a);
    return 0;
}
''')
add(868, r'''
#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int n;
    float sum = 0;

    printf("Number of students: ");
    if (scanf("%d", &n) != 1 || n <= 0) { printf("Invalid count\n"); return 1; }
    float *marks = malloc(n * sizeof(float));
    if (marks == NULL) return 1;

    for (int i = 0; i < n; i++) {
        printf("Marks of student %d: ", i + 1);
        if (scanf("%f", &marks[i]) != 1) { free(marks); return 1; }
        sum += marks[i];
    }
    float high = marks[0];
    for (int i = 1; i < n; i++)
        if (marks[i] > high) high = marks[i];
    printf("Total = %.1f, Average = %.2f, Highest = %.1f\n", sum, sum / n, high);
    free(marks);
    return 0;
}
''', "4\n78.5 92 64 85.5")
add(869, r'''
#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    size_t cap = 4, len = 0;
    char *buf = malloc(cap);
    int c;

    if (buf == NULL) return 1;
    printf("Type characters (end with '.'): ");
    while ((c = getchar()) != EOF && c != '.') {
        if (len + 1 >= cap) {                /* keep room for '\0' */
            cap *= 2;
            char *t = realloc(buf, cap);
            if (t == NULL) { free(buf); return 1; }
            buf = t;
            printf("[buffer expanded to %zu]\n", cap);
        }
        buf[len++] = (char)c;
    }
    buf[len] = '\0';
    printf("Collected %zu chars: %s\n", len, buf);
    free(buf);
    return 0;
}
''', "dynamic buffers grow.")
add(870, r'''
#include <stdio.h>
#include <stdlib.h>

/* Returns 0 on success, -1 on error; never leaks memory */
int process(int n)
{
    int *a = NULL, *b = NULL;
    int status = -1;

    a = malloc(n * sizeof(int));
    if (a == NULL) goto cleanup;
    b = malloc(n * sizeof(int));
    if (b == NULL) goto cleanup;

    for (int i = 0; i < n; i++) { a[i] = i; b[i] = a[i] * 2; }
    printf("b[%d] = %d\n", n - 1, b[n - 1]);
    status = 0;

cleanup:                                    /* single exit frees everything */
    free(a);
    free(b);
    return status;
}

int main(void)
{
    int n;

    printf("Enter n: ");
    if (scanf("%d", &n) != 1 || n <= 0) {
        printf("Invalid input, nothing allocated\n");
        return 1;
    }
    if (process(n) != 0) printf("Processing failed, memory released\n");
    else printf("Done, memory released\n");
    return 0;
}
''', "8")
add(871, r'''
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(void)
{
    int n;
    char word[50];

    printf("How many words? ");
    if (scanf("%d", &n) != 1 || n <= 0) return 1;
    char **list = malloc(n * sizeof(char *));
    if (list == NULL) return 1;

    for (int i = 0; i < n; i++) {
        if (scanf("%49s", word) != 1) n = i;
        list[i] = malloc(strlen(word) + 1);
        if (list[i] == NULL) return 1;
        strcpy(list[i], word);
    }
    for (int i = 0; i < n; i++)
        printf("%d: %s\n", i + 1, list[i]);
    for (int i = 0; i < n; i++) free(list[i]);   /* each string first */
    free(list);                                  /* then the array */
    printf("All strings freed\n");
    return 0;
}
''', "4\nred green blue yellow")
add(872, r'''
#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int rows = 4;
    int len[] = {2, 5, 3, 4};
    int **a = malloc(rows * sizeof(int *));
    if (a == NULL) return 1;

    for (int i = 0; i < rows; i++) {
        a[i] = malloc(len[i] * sizeof(int));
        if (a[i] == NULL) return 1;
        for (int j = 0; j < len[i]; j++) a[i][j] = i + j + 1;
    }
    for (int i = 0; i < rows; i++) {
        int sum = 0;
        printf("Row %d:", i);
        for (int j = 0; j < len[i]; j++) {
            printf(" %d", a[i][j]);
            sum += a[i][j];
        }
        printf("  | sum = %d\n", sum);
    }
    for (int i = 0; i < rows; i++) free(a[i]);
    free(a);
    return 0;
}
''')
add(873, r'''
#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int cap = 2, n = 0, v;
    int *a = malloc(cap * sizeof(int));
    if (a == NULL) return 1;

    printf("Enter numbers, -1 to stop: ");
    while (scanf("%d", &v) == 1 && v != -1) {
        if (n == cap) {
            cap *= 2;
            int *t = realloc(a, cap * sizeof(int));
            if (t == NULL) { free(a); return 1; }
            a = t;
        }
        a[n++] = v;
    }
    long sum = 0;
    for (int i = 0; i < n; i++) sum += a[i];
    printf("Read %d numbers, capacity %d, sum = %ld\n", n, cap, sum);
    free(a);
    return 0;
}
''', "4 8 15 16 23 42 -1")
add(874, r'''
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Reads a whole line of any length; caller must free the result */
char *read_line(void)
{
    size_t cap = 8, len = 0;
    char *buf = malloc(cap);
    if (buf == NULL) return NULL;
    buf[0] = '\0';

    while (fgets(buf + len, (int)(cap - len), stdin) != NULL) {
        len += strlen(buf + len);
        if (len > 0 && buf[len - 1] == '\n') {
            buf[len - 1] = '\0';
            return buf;
        }
        cap *= 2;
        char *t = realloc(buf, cap);
        if (t == NULL) { free(buf); return NULL; }
        buf = t;
    }
    return buf;
}

int main(void)
{
    printf("Enter a long line: ");
    char *line = read_line();
    if (line == NULL) return 1;
    printf("You typed %zu characters:\n%s\n", strlen(line), line);
    free(line);
    return 0;
}
''', "This line is much longer than the starting buffer of eight bytes.\n")
add(875, r'''
#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int r = 2, c = 3;
    int **m = malloc(r * sizeof(int *));
    int **t = malloc(c * sizeof(int *));
    if (m == NULL || t == NULL) return 1;

    for (int i = 0; i < r; i++) {
        m[i] = malloc(c * sizeof(int));
        if (m[i] == NULL) return 1;
        for (int j = 0; j < c; j++) m[i][j] = i * c + j + 1;
    }
    for (int j = 0; j < c; j++) {
        t[j] = malloc(r * sizeof(int));
        if (t[j] == NULL) return 1;
        for (int i = 0; i < r; i++) t[j][i] = m[i][j];
    }
    printf("Original (%dx%d):\n", r, c);
    for (int i = 0; i < r; i++) {
        for (int j = 0; j < c; j++) printf("%3d", m[i][j]);
        printf("\n");
    }
    printf("Transpose (%dx%d):\n", c, r);
    for (int j = 0; j < c; j++) {
        for (int i = 0; i < r; i++) printf("%3d", t[j][i]);
        printf("\n");
    }
    for (int i = 0; i < r; i++) free(m[i]);
    for (int j = 0; j < c; j++) free(t[j]);
    free(m);
    free(t);
    return 0;
}
''')
