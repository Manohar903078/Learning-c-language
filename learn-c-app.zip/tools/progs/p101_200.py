# programs 101-200
P = {}
def add(i, code, stdin=""): P[i] = (stdin, code.strip("\n"))

add(101, r'''
#include <stdio.h>

int main(void)
{
    int a = 17, b = 5;
    printf("a = %d, b = %d\n", a, b);
    printf("Addition       : %d + %d = %d\n", a, b, a + b);
    printf("Subtraction    : %d - %d = %d\n", a, b, a - b);
    printf("Multiplication : %d * %d = %d\n", a, b, a * b);
    printf("Division       : %d / %d = %d\n", a, b, a / b);
    printf("Modulus        : %d %% %d = %d\n", a, b, a % b);
    return 0;
}
''')
add(102, r'''
#include <stdio.h>

int main(void)
{
    int x = 5, y;
    y = ++x;    /* x is incremented first, then used */
    printf("Pre-increment : y = ++x -> x = %d, y = %d\n", x, y);
    x = 5;
    y = x++;    /* x is used first, then incremented */
    printf("Post-increment: y = x++ -> x = %d, y = %d\n", x, y);
    return 0;
}
''')
add(103, r'''
#include <stdio.h>

int main(void)
{
    int x = 10, y;
    y = --x;    /* decrement first, then use */
    printf("Pre-decrement : y = --x -> x = %d, y = %d\n", x, y);
    x = 10;
    y = x--;    /* use first, then decrement */
    printf("Post-decrement: y = x-- -> x = %d, y = %d\n", x, y);
    return 0;
}
''')
add(104, r'''
#include <stdio.h>

int main(void)
{
    int a = 10, b = 4, c = 3;
    int result = a + b * c - a / b % c;
    /* * / % are evaluated before + - (left to right) */
    printf("a = %d, b = %d, c = %d\n", a, b, c);
    printf("a + b * c - a / b %% c = %d\n", result);
    printf("(a + b) * c = %d\n", (a + b) * c);
    return 0;
}
''')
add(105, r'''
#include <stdio.h>

int main(void)
{
    int a = 12, b = 20;
    printf("a = %d, b = %d\n", a, b);
    printf("a == b : %d\n", a == b);
    printf("a != b : %d\n", a != b);
    printf("a >  b : %d\n", a > b);
    printf("a <  b : %d\n", a < b);
    printf("a >= b : %d\n", a >= b);
    printf("a <= b : %d\n", a <= b);
    return 0;
}
''')
add(106, r'''
#include <stdio.h>

int main(void)
{
    int age = 25, hasId = 0;
    printf("age = %d, hasId = %d\n", age, hasId);
    printf("(age > 18) && hasId : %d\n", (age > 18) && hasId);
    printf("(age > 18) || hasId : %d\n", (age > 18) || hasId);
    printf("!hasId              : %d\n", !hasId);
    printf("!(age > 18)         : %d\n", !(age > 18));
    return 0;
}
''')
add(107, r'''
#include <stdio.h>

int main(void)
{
    int x = 20;
    printf("Start    : x = %d\n", x);
    x += 5;  printf("x += 5   : x = %d\n", x);
    x -= 3;  printf("x -= 3   : x = %d\n", x);
    x *= 2;  printf("x *= 2   : x = %d\n", x);
    x /= 4;  printf("x /= 4   : x = %d\n", x);
    x %= 4;  printf("x %%= 4   : x = %d\n", x);
    return 0;
}
''')
add(108, r'''
#include <stdio.h>

int main(void)
{
    int a = 35, b = 48;
    int larger = (a > b) ? a : b;
    printf("a = %d, b = %d\n", a, b);
    printf("Larger number = %d\n", larger);
    return 0;
}
''')
add(109, r'''
#include <stdio.h>

int main(void)
{
    int a = 42, b = 17, c = 29;
    int smaller = (a < b) ? ((a < c) ? a : c) : ((b < c) ? b : c);
    printf("Numbers: %d %d %d\n", a, b, c);
    printf("Smallest = %d\n", smaller);
    return 0;
}
''')
add(110, r'''
#include <stdio.h>

int main(void)
{
    int n = 28;
    if (n % 2 == 0)
    {
        printf("%d is even\n", n);
    }
    else
    {
        printf("%d is not even (it is odd)\n", n);
    }
    return 0;
}
''')
add(111, r'''
#include <stdio.h>

int main(void)
{
    char ch = 'k';
    if ((ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z'))
    {
        printf("'%c' is an alphabet\n", ch);
    }
    else
    {
        printf("'%c' is not an alphabet\n", ch);
    }
    return 0;
}
''')
add(112, r'''
#include <stdio.h>

int main(void)
{
    int a = 12, b = 10;   /* 1100 and 1010 in binary */
    printf("a = %d, b = %d\n", a, b);
    printf("a & b = %d\n", a & b);
    printf("a | b = %d\n", a | b);
    printf("a ^ b = %d\n", a ^ b);
    return 0;
}
''')
add(113, r'''
#include <stdio.h>

int main(void)
{
    int n = 6;
    printf("n = %d\n", n);
    printf("n << 1 = %d (multiplies by 2)\n", n << 1);
    printf("n << 3 = %d (multiplies by 8)\n", n << 3);
    printf("n >> 1 = %d (divides by 2)\n", n >> 1);
    printf("n >> 2 = %d (divides by 4)\n", n >> 2);
    return 0;
}
''')
add(114, r'''
#include <stdio.h>

int main(void)
{
    unsigned int num = 20;   /* 10100 */
    int pos = 1;             /* bit position, counted from 0 */
    unsigned int result = num | (1u << pos);
    printf("Original number = %u\n", num);
    printf("Setting bit %d -> %u\n", pos, result);
    return 0;
}
''')
add(115, r'''
#include <stdio.h>

int main(void)
{
    unsigned int num = 29;   /* 11101 */
    int pos = 2;
    unsigned int result = num & ~(1u << pos);
    printf("Original number = %u\n", num);
    printf("Clearing bit %d -> %u\n", pos, result);
    return 0;
}
''')
add(116, r'''
#include <stdio.h>

int main(void)
{
    unsigned int num = 10;   /* 1010 */
    int pos = 0;
    unsigned int result = num ^ (1u << pos);
    printf("Original number = %u\n", num);
    printf("Toggling bit %d -> %u\n", pos, result);
    result = result ^ (1u << pos);
    printf("Toggling it again -> %u\n", result);
    return 0;
}
''')
add(117, r'''
#include <stdio.h>

int main(void)
{
    int n = 37;
    /* the last bit is 1 for odd numbers and 0 for even numbers */
    if (n & 1)
    {
        printf("%d is odd\n", n);
    }
    else
    {
        printf("%d is even\n", n);
    }
    return 0;
}
''')
add(118, r'''
#include <stdio.h>

int main(void)
{
    int a = 8, b = 3, c = 5;
    float f = 2.5f;
    int step1 = a / b;
    int step2 = step1 * c;
    float step3 = step2 + f;
    float step4 = step3 / 2;
    printf("a = %d, b = %d, c = %d, f = %.1f\n", a, b, c, f);
    printf("Step 1: a / b         = %d\n", step1);
    printf("Step 2: step1 * c     = %d\n", step2);
    printf("Step 3: step2 + f     = %.2f\n", step3);
    printf("Step 4: step3 / 2     = %.3f\n", step4);
    return 0;
}
''')
add(119, r'''
#include <stdio.h>

int main(void)
{
    int a = 47, b = 6;
    int quotient = a / b;
    int remainder = a - quotient * b;   /* a = q*b + r */
    printf("%d divided by %d: quotient = %d\n", a, b, quotient);
    printf("Remainder = %d\n", remainder);
    return 0;
}
''')
add(120, r'''
#include <stdio.h>

int main(void)
{
    int a, b, c;
    a = (b = 1, c = 2, b + c + 10);   /* value is the last expression */
    printf("a = (b = 1, c = 2, b + c + 10) -> a = %d\n", a);
    b = (a++, a + 10);    /* a++ first, then a + 10 */
    printf("b = (a++, a + 10) -> a = %d, b = %d\n", a, b);
    for (c = 0, a = 10; c < 3; c++, a--)
    {
        printf("Loop: c = %d, a = %d\n", c, a);
    }
    return 0;
}
''')
add(121, r'''
#include <stdio.h>

int main(void)
{
    int n = 0;
    printf("%d is %s\n", n, (n == 0) ? "zero" : "not zero");
    n = 9;
    printf("%d is %s\n", n, (n == 0) ? "zero" : "not zero");
    return 0;
}
''')
add(122, r'''
#include <stdio.h>

int main(void)
{
    printf("Integer division truncates towards zero:\n");
    printf(" 7 /  2 = %d\n", 7 / 2);
    printf("-7 /  2 = %d\n", -7 / 2);
    printf(" 7 / -2 = %d\n", 7 / -2);
    printf("-7 / -2 = %d\n", -7 / -2);
    printf("Remainder takes the sign of the dividend:\n");
    printf(" 7 %%  2 = %d\n", 7 % 2);
    printf("-7 %%  2 = %d\n", -7 % 2);
    printf(" 7 %% -2 = %d\n", 7 % -2);
    return 0;
}
''')
add(123, r'''
#include <stdio.h>

int main(void)
{
    int values[2] = {0, 1};   /* 0 = false, 1 = true */
    int i, j;
    printf("A B | A&&B A||B !A\n");
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 2; j++)
        {
            printf("%d %d |  %d    %d    %d\n", values[i], values[j],
                   values[i] && values[j], values[i] || values[j], !values[i]);
        }
    }
    return 0;
}
''')
add(124, r'''
#include <stdio.h>

#define FLAG_READ  1   /* 001 */
#define FLAG_WRITE 2   /* 010 */
#define FLAG_EXEC  4   /* 100 */

int main(void)
{
    int perms = FLAG_READ | FLAG_EXEC;
    printf("READ | EXEC = %d\n", perms);
    perms = perms | FLAG_WRITE;
    printf("After adding WRITE = %d\n", perms);
    return 0;
}
''')
add(125, r'''
#include <stdio.h>

int main(void)
{
    int values[3] = {8, 7, 24};
    int mask = 1 << 3;    /* fourth bit (bit 3) = 8 */
    int i;
    for (i = 0; i < 3; i++)
    {
        if (values[i] & mask)
        {
            printf("%d : fourth bit is SET\n", values[i]);
        }
        else
        {
            printf("%d : fourth bit is NOT set\n", values[i]);
        }
    }
    return 0;
}
''')
add(126, r'''
#include <stdio.h>

int main(void)
{
    int a, b;
    printf("Enter first integer: ");
    scanf("%d", &a);
    printf("Enter second integer: ");
    scanf("%d", &b);
    printf("Sum        = %d\n", a + b);
    printf("Difference = %d\n", a - b);
    printf("Product    = %d\n", a * b);
    if (b != 0)
    {
        printf("Quotient   = %d\n", a / b);
        printf("Remainder  = %d\n", a % b);
    }
    else
    {
        printf("Division and modulus are not possible (second number is zero)\n");
    }
    return 0;
}
''', "29\n6\n")
add(127, r'''
#include <stdio.h>

/* demonstrates pre- and post-increment on a local copy of value */
void showIncrement(int value)
{
    int x = value;
    int pre = ++x;
    printf("Pre-increment : ++x gives %d, x is now %d\n", pre, x);
    x = value;
    int post = x++;
    printf("Post-increment: x++ gives %d, x is now %d\n", post, x);
}

int main(void)
{
    showIncrement(10);
    showIncrement(-3);
    return 0;
}
''')
add(128, r'''
#include <stdio.h>

int main(void)
{
    int n;
    printf("Enter an integer between -1000 and 1000: ");
    if (scanf("%d", &n) != 1)
    {
        printf("Error: input is not a valid integer.\n");
        return 0;
    }
    if (n < -1000 || n > 1000)
    {
        printf("Error: %d is outside the allowed range.\n", n);
        return 0;
    }
    int x = n;
    printf("Start: n = %d\n", n);
    int shown = --x;
    printf("--x gives %d, x is now %d\n", shown, x);
    x = n;
    printf("x-- gives %d, ", x--);
    printf("x is now %d\n", x);
    return 0;
}
''', "50\n")
add(129, r'''
#include <stdio.h>

int main(void)
{
    int tests[3][3] = {{2, 3, 4}, {10, 5, 2}, {7, 0, 9}};
    int i;
    for (i = 0; i < 3; i++)
    {
        int a = tests[i][0], b = tests[i][1], c = tests[i][2];
        /* precedence: * / before + - */
        printf("Test %d: a=%d b=%d c=%d -> a + b * c - a / 2 = %d\n",
               i + 1, a, b, c, a + b * c - a / 2);
    }
    return 0;
}
''')
add(130, r'''
#include <stdio.h>

int main(void)
{
    int a, b;
    printf("Enter two integers: ");
    scanf("%d %d", &a, &b);
    /* each relational expression yields 1 (true) or 0 (false) */
    if (a == b)
    {
        printf("%d is equal to %d\n", a, b);
    }
    if (a != b)
    {
        printf("%d is not equal to %d\n", a, b);
    }
    if (a > b)
    {
        printf("%d is greater than %d\n", a, b);
    }
    if (a < b)
    {
        printf("%d is less than %d\n", a, b);
    }
    if (a >= b)
    {
        printf("%d >= %d is true\n", a, b);
    }
    if (a <= b)
    {
        printf("%d <= %d is true\n", a, b);
    }
    return 0;
}
''', "15 9\n")
add(131, r'''
#include <stdio.h>

int main(void)
{
    /* boundary cases: 0, 1, negative and a large value as truth values */
    int tests[4] = {0, 1, -1, 2147483647};
    int i;
    for (i = 0; i < 4; i++)
    {
        int a = tests[i];
        printf("a = %11d : !a = %d, a && 1 = %d, a || 0 = %d\n",
               a, !a, a && 1, a || 0);
    }
    return 0;
}
''')
add(132, r'''
#include <stdio.h>

int main(void)
{
    int x = 40;
    int choice;
    printf("Value of x = %d\n", x);
    printf("1. x += 10\n2. x -= 10\n3. x *= 3\n4. x /= 4\n5. x %%= 7\n");
    printf("Enter your choice (1-5): ");
    if (scanf("%d", &choice) != 1)
    {
        printf("Invalid input\n");
        return 0;
    }
    switch (choice)
    {
        case 1: x += 10; break;
        case 2: x -= 10; break;
        case 3: x *= 3;  break;
        case 4: x /= 4;  break;
        case 5: x %= 7;  break;
        default: printf("Invalid choice\n"); return 0;
    }
    printf("New value of x = %d\n", x);
    return 0;
}
''', "3\n")
add(133, r'''
#include <stdio.h>

int main(void)
{
    int a = 64, b = 81;
    printf("Comparing a = %d and b = %d\n", a, b);
    printf("Step 1: is a > b ? %s\n", (a > b) ? "yes" : "no");
    int larger = (a > b) ? a : b;
    printf("Step 2: the conditional operator picked %d\n", larger);
    printf("Larger number = %d\n", larger);
    return 0;
}
''')
add(134, r'''
#include <stdio.h>

int main(void)
{
    int nums[5] = {45, 12, 78, 9, 33};
    int smallest = nums[0];
    int i;
    for (i = 1; i < 5; i++)
    {
        /* conditional operator keeps the smaller value */
        smallest = (nums[i] < smallest) ? nums[i] : smallest;
    }
    printf("Smallest of the numbers = %d\n", smallest);
    int three[3] = {21, 8, 15};
    smallest = three[0];
    for (i = 1; i < 3; i++)
    {
        smallest = (three[i] < smallest) ? three[i] : smallest;
    }
    printf("Smallest of 21, 8, 15 = %d\n", smallest);
    return 0;
}
''')
add(135, r'''
#include <stdio.h>

int main(void)
{
    int n = 54;
    int *p = &n;
    if (*p % 2 == 0)
    {
        printf("%d (read through a pointer) is even\n", *p);
    }
    else
    {
        printf("%d (read through a pointer) is odd\n", *p);
    }
    return 0;
}
''')
add(136, r'''
#include <stdio.h>

int main(void)
{
    char text[] = {'a', 'Z', '5', '#', 'm', ' '};
    int i;
    for (i = 0; i < 6; i++)
    {
        char ch = text[i];
        if ((ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z'))
        {
            printf("'%c' is an alphabet\n", ch);
        }
        else
        {
            printf("'%c' is not an alphabet\n", ch);
        }
    }
    return 0;
}
''')
add(137, r'''
#include <stdio.h>

struct Pair
{
    int first;
    int second;
};

int main(void)
{
    struct Pair p = {25, 14};
    printf("first = %d, second = %d\n", p.first, p.second);
    printf("first & second = %d\n", p.first & p.second);
    printf("first | second = %d\n", p.first | p.second);
    printf("first ^ second = %d\n", p.first ^ p.second);
    return 0;
}
''')
add(138, r'''
#include <stdio.h>

int main(void)
{
    int values[4] = {1, 5, 12, 100};
    int i;
    printf("Value  Left shift by 2  Right shift by 1\n");
    for (i = 0; i < 4; i++)
    {
        printf("%5d  %15d  %16d\n", values[i], values[i] << 2, values[i] >> 1);
    }
    return 0;
}
''')
add(139, r'''
#include <stdio.h>

int main(void)
{
    unsigned int num = 33;   /* 100001 */
    int pos = 3;
    unsigned int result = num | (1u << pos);
    printf("+----------------------+-------+\n");
    printf("| Original number      | %5u |\n", num);
    printf("| Bit position to set  | %5d |\n", pos);
    printf("| Result               | %5u |\n", result);
    printf("+----------------------+-------+\n");
    return 0;
}
''')
add(140, r'''
#include <stdio.h>

int main(void)
{
    unsigned int num;
    int pos;
    printf("Enter a non-negative number: ");
    if (scanf("%u", &num) != 1)
    {
        printf("Error: invalid number.\n");
        return 0;
    }
    printf("Enter bit position to clear (0-31): ");
    if (scanf("%d", &pos) != 1 || pos < 0 || pos > 31)
    {
        printf("Error: bit position must be between 0 and 31.\n");
        return 0;
    }
    printf("Result after clearing bit %d = %u\n", pos, num & ~(1u << pos));
    return 0;
}
''', "255\n4\n")
add(141, r'''
#include <stdio.h>

unsigned int toggleBit(unsigned int num, int pos)
{
    return num ^ (1u << pos);
}

void show(unsigned int num, int pos)
{
    printf("Toggle bit %d of %u -> %u\n", pos, num, toggleBit(num, pos));
}

int main(void)
{
    unsigned int num;
    int pos;
    printf("Enter a number and a bit position: ");
    scanf("%u %d", &num, &pos);
    show(num, pos);
    show(toggleBit(num, pos), pos);
    return 0;
}
''', "40 3\n")
add(142, r'''
#include <stdio.h>

/* Time cost: O(1), one AND operation.  Space cost: O(1), no extra memory. */
int isOdd(int n)
{
    return n & 1;
}

int main(void)
{
    int n;
    printf("Enter an integer: ");
    scanf("%d", &n);
    if (isOdd(n))
    {
        printf("%d is odd\n", n);
    }
    else
    {
        printf("%d is even\n", n);
    }
    return 0;
}
''', "-7\n")
add(143, r'''
#include <stdio.h>

int main(void)
{
    /* test cases: normal, minimum and maximum inputs */
    long tests[3] = {5, 0, 1000};
    const char *names[3] = {"normal", "minimum", "maximum"};
    int i;
    for (i = 0; i < 3; i++)
    {
        long n = tests[i];
        long t1 = n * 2;
        long t2 = t1 + 10;
        long t3 = t2 / 3;
        printf("%-8s n=%4ld: n*2=%ld, +10=%ld, /3=%ld\n", names[i], n, t1, t2, t3);
    }
    return 0;
}
''')
add(144, r'''
#include <stdio.h>

/* returns a mod b using repeated subtraction; no global variables */
int remainderOf(int a, int b)
{
    while (a >= b)
    {
        a -= b;
    }
    return a;
}

int main(void)
{
    int a = 100, b = 7;
    printf("%d mod %d = %d\n", a, b, remainderOf(a, b));
    a = 5; b = 9;
    printf("%d mod %d = %d\n", a, b, remainderOf(a, b));
    return 0;
}
''')
add(145, r'''
#include <stdio.h>

int main(void)
{
    int a, b, total;
    FILE *fp = fopen("data.txt", "r");   /* file does not exist: failure case */
    if (fp == NULL)
    {
        printf("Could not open data.txt, using default values.\n");
    }
    else
    {
        fclose(fp);
    }
    total = (a = 4, b = 6, a * b);       /* comma operator */
    printf("total = (a = 4, b = 6, a * b) = %d\n", total);
    for (a = 0, b = 5; a < b; a++, b--)
    {
        printf("a = %d, b = %d\n", a, b);
    }
    return 0;
}
''')
add(146, r'''
#include <stdio.h>

int main(void)
{
    /* Time cost: O(1) - each compound assignment is one operation.
       Space cost: O(1) - only one variable is used. */
    int x = 100;
    x += 20;  printf("x += 20 -> %d\n", x);
    x -= 45;  printf("x -= 45 -> %d\n", x);
    x *= 2;   printf("x *= 2  -> %d\n", x);
    x /= 3;   printf("x /= 3  -> %d\n", x);
    x %= 9;   printf("x %%= 9  -> %d\n", x);
    x <<= 2;  printf("x <<= 2 -> %d\n", x);
    return 0;
}
''')
add(147, r'''
#include <stdio.h>

int main(void)
{
    int a, b, c;
    printf("Enter three integers: ");
    scanf("%d %d %d", &a, &b, &c);
    int smallest = (a < b && a < c) ? a : (b < c) ? b : c;
    printf("Smallest = %d\n", smallest);
    return 0;
}
''', "34 -8 21\n")
add(148, r'''
#include <stdio.h>

int main(void)
{
    char ch = 'Q';
    /* upper-case letters lie between 'A' and 'Z' in ASCII */
    int isUpper = (ch >= 'A' && ch <= 'Z');
    /* lower-case letters lie between 'a' and 'z' */
    int isLower = (ch >= 'a' && ch <= 'z');
    if (isUpper || isLower)
    {
        printf("'%c' is an alphabet (%s case)\n", ch, isUpper ? "upper" : "lower");
    }
    else
    {
        printf("'%c' is not an alphabet\n", ch);
    }
    return 0;
}
''')
add(149, r'''
#include <stdio.h>

int main(void)
{
    int n = 3;
    int i;
    for (i = 1; i <= 4; i++)
    {
        printf("%d << %d = %3d    %d >> %d = %d\n", n * 10, i, (n * 10) << i,
               n * 10, i, (n * 10) >> i);
    }
    return 0;
}
''')
add(150, r'''
#include <stdio.h>

int main(void)
{
    unsigned int nums[4] = {255, 170, 64, 15};
    int positions[4] = {0, 1, 6, 3};
    int i;
    for (i = 0; i < 4; i++)
    {
        unsigned int result = nums[i] & ~(1u << positions[i]);
        printf("Clear bit %d of %3u -> %3u\n", positions[i], nums[i], result);
    }
    return 0;
}
''')
add(151, r'''
#include <stdio.h>

int main(void)
{
    int n = -12;
    if (n > 0)
    {
        printf("%d is positive\n", n);
    }
    else if (n < 0)
    {
        printf("%d is negative\n", n);
    }
    else
    {
        printf("The number is zero\n");
    }
    return 0;
}
''')
add(152, r'''
#include <stdio.h>

int main(void)
{
    int n = 73;
    if (n % 2 == 0)
    {
        printf("%d is even\n", n);
    }
    else
    {
        printf("%d is odd\n", n);
    }
    return 0;
}
''')
add(153, r'''
#include <stdio.h>

int main(void)
{
    int a = 58, b = 91;
    if (a > b)
    {
        printf("%d is larger than %d\n", a, b);
    }
    else if (b > a)
    {
        printf("%d is larger than %d\n", b, a);
    }
    else
    {
        printf("Both numbers are equal (%d)\n", a);
    }
    return 0;
}
''')
add(154, r'''
#include <stdio.h>

int main(void)
{
    int a = 23, b = 67, c = 45;
    int largest = a;
    if (b > largest)
    {
        largest = b;
    }
    if (c > largest)
    {
        largest = c;
    }
    printf("Numbers: %d, %d, %d\n", a, b, c);
    printf("Largest = %d\n", largest);
    return 0;
}
''')
add(155, r'''
#include <stdio.h>

int main(void)
{
    int a = 23, b = 67, c = 5;
    int smallest;
    if (a <= b && a <= c)
    {
        smallest = a;
    }
    else if (b <= a && b <= c)
    {
        smallest = b;
    }
    else
    {
        smallest = c;
    }
    printf("Numbers: %d, %d, %d\n", a, b, c);
    printf("Smallest = %d\n", smallest);
    return 0;
}
''')
add(156, r'''
#include <stdio.h>

int main(void)
{
    int year = 2024;
    if ((year % 4 == 0 && year % 100 != 0) || year % 400 == 0)
    {
        printf("%d is a leap year\n", year);
    }
    else
    {
        printf("%d is not a leap year\n", year);
    }
    return 0;
}
''')
add(157, r'''
#include <stdio.h>

int main(void)
{
    int age = 17;
    if (age >= 18)
    {
        printf("Age %d: eligible to vote\n", age);
    }
    else
    {
        printf("Age %d: not eligible to vote (%d more year(s) to wait)\n", age, 18 - age);
    }
    return 0;
}
''')
add(158, r'''
#include <stdio.h>

int main(void)
{
    char ch = 'g';
    if (ch >= 'A' && ch <= 'Z')
    {
        printf("'%c' is an uppercase letter\n", ch);
    }
    else if (ch >= 'a' && ch <= 'z')
    {
        printf("'%c' is a lowercase letter\n", ch);
    }
    else
    {
        printf("'%c' is not a letter\n", ch);
    }
    return 0;
}
''')
add(159, r'''
#include <stdio.h>

int main(void)
{
    char ch = '7';
    if (ch >= '0' && ch <= '9')
    {
        printf("'%c' is a digit\n", ch);
    }
    else
    {
        printf("'%c' is a non-digit\n", ch);
    }
    return 0;
}
''')
add(160, r'''
#include <stdio.h>

int main(void)
{
    char ch = 'E';
    char lower = ch;
    if (ch >= 'A' && ch <= 'Z')
    {
        lower = ch + ('a' - 'A');   /* convert to lowercase */
    }
    if (lower >= 'a' && lower <= 'z')
    {
        if (lower == 'a' || lower == 'e' || lower == 'i' || lower == 'o' || lower == 'u')
        {
            printf("'%c' is a vowel\n", ch);
        }
        else
        {
            printf("'%c' is a consonant\n", ch);
        }
    }
    else
    {
        printf("'%c' is not an alphabet\n", ch);
    }
    return 0;
}
''')
add(161, r'''
#include <stdio.h>

int main(void)
{
    int a = 7, b = 10, c = 5;
    /* sum of any two sides must be greater than the third */
    if (a + b > c && a + c > b && b + c > a)
    {
        printf("Sides %d, %d, %d can form a triangle\n", a, b, c);
    }
    else
    {
        printf("Sides %d, %d, %d cannot form a triangle\n", a, b, c);
    }
    return 0;
}
''')
add(162, r'''
#include <stdio.h>

int main(void)
{
    int a = 6, b = 6, c = 9;
    if (a == b && b == c)
    {
        printf("Equilateral triangle\n");
    }
    else if (a == b || b == c || a == c)
    {
        printf("Isosceles triangle\n");
    }
    else
    {
        printf("Scalene triangle\n");
    }
    return 0;
}
''')
add(163, r'''
#include <stdio.h>

int main(void)
{
    int a = 5, b = 12, c = 13;
    if (a * a + b * b == c * c || a * a + c * c == b * b || b * b + c * c == a * a)
    {
        printf("%d, %d, %d form a right-angled triangle\n", a, b, c);
    }
    else
    {
        printf("%d, %d, %d do not form a right-angled triangle\n", a, b, c);
    }
    return 0;
}
''')
add(164, r'''
#include <stdio.h>

int main(void)
{
    /* Grading scale: 90+ A, 80-89 B, 70-79 C, 60-69 D, 50-59 E, below 50 F */
    int marks = 76;
    char grade;
    if (marks >= 90)
    {
        grade = 'A';
    }
    else if (marks >= 80)
    {
        grade = 'B';
    }
    else if (marks >= 70)
    {
        grade = 'C';
    }
    else if (marks >= 60)
    {
        grade = 'D';
    }
    else if (marks >= 50)
    {
        grade = 'E';
    }
    else
    {
        grade = 'F';
    }
    printf("Marks = %d, Grade = %c\n", marks, grade);
    return 0;
}
''')
add(165, r'''
#include <stdio.h>

int main(void)
{
    /* Slabs: first 100 units Rs 3, next 100 units Rs 5, above 200 units Rs 8 */
    int units = 260;
    double bill;
    if (units <= 100)
    {
        bill = units * 3.0;
    }
    else if (units <= 200)
    {
        bill = 100 * 3.0 + (units - 100) * 5.0;
    }
    else
    {
        bill = 100 * 3.0 + 100 * 5.0 + (units - 200) * 8.0;
    }
    printf("Units consumed = %d\n", units);
    printf("Electricity bill = Rs %.2f\n", bill);
    return 0;
}
''')
add(166, r'''
#include <stdio.h>

int main(void)
{
    /* Slabs: up to 3,00,000 nil; next 3,00,000 at 5%; next 4,00,000 at 10%; above 10,00,000 at 20% */
    double income = 1200000.0;
    double tax = 0.0;
    if (income > 1000000.0)
    {
        tax = 300000 * 0.05 + 400000 * 0.10 + (income - 1000000.0) * 0.20;
    }
    else if (income > 600000.0)
    {
        tax = 300000 * 0.05 + (income - 600000.0) * 0.10;
    }
    else if (income > 300000.0)
    {
        tax = (income - 300000.0) * 0.05;
    }
    printf("Income = Rs %.2f\n", income);
    printf("Tax    = Rs %.2f\n", tax);
    return 0;
}
''')
add(167, r'''
#include <stdio.h>

int main(void)
{
    int n = -45;
    int absolute = n;
    if (n < 0)
    {
        absolute = -n;
    }
    printf("Absolute value of %d is %d\n", n, absolute);
    return 0;
}
''')
add(168, r'''
#include <stdio.h>

int main(void)
{
    int n = 110;
    if (n % 5 == 0 && n % 11 == 0)
    {
        printf("%d is divisible by both 5 and 11\n", n);
    }
    else
    {
        printf("%d is not divisible by both 5 and 11\n", n);
    }
    return 0;
}
''')
add(169, r'''
#include <stdio.h>

int main(void)
{
    int n = 482;
    int a = n < 0 ? -n : n;   /* ignore the sign */
    if (a >= 10 && a <= 99)
    {
        printf("%d is a two-digit number\n", n);
    }
    else if (a >= 100 && a <= 999)
    {
        printf("%d is a three-digit number\n", n);
    }
    else
    {
        printf("%d is neither two-digit nor three-digit\n", n);
    }
    return 0;
}
''')
add(170, r'''
#include <stdio.h>

int main(void)
{
    int a = 14, b = 3, c = 9;
    int middle;
    if ((a > b && a < c) || (a < b && a > c))
    {
        middle = a;
    }
    else if ((b > a && b < c) || (b < a && b > c))
    {
        middle = b;
    }
    else
    {
        middle = c;
    }
    printf("Numbers: %d, %d, %d\n", a, b, c);
    printf("Middle value = %d\n", middle);
    return 0;
}
''')
add(171, r'''
#include <stdio.h>

int main(void)
{
    int day = 29, month = 2, year = 2023;
    int maxDays;
    int leap = (year % 4 == 0 && year % 100 != 0) || year % 400 == 0;
    if (month < 1 || month > 12)
    {
        printf("Invalid month %d\n", month);
        return 0;
    }
    if (month == 2)
    {
        maxDays = leap ? 29 : 28;
    }
    else if (month == 4 || month == 6 || month == 9 || month == 11)
    {
        maxDays = 30;
    }
    else
    {
        maxDays = 31;
    }
    if (day >= 1 && day <= maxDays)
    {
        printf("%02d/%02d/%d is a valid date\n", day, month, year);
    }
    else
    {
        printf("%02d/%02d/%d is NOT a valid date (month has %d days)\n", day, month, year, maxDays);
    }
    return 0;
}
''')
add(172, r'''
#include <stdio.h>

int main(void)
{
    double a = 1, b = 4, c = 4;
    double d = b * b - 4 * a * c;   /* discriminant */
    printf("Equation: %.0fx^2 + %.0fx + %.0f = 0, discriminant = %.2f\n", a, b, c, d);
    if (d > 0)
    {
        printf("Roots are real and distinct\n");
    }
    else if (d == 0)
    {
        printf("Roots are real and equal\n");
    }
    else
    {
        printf("Roots are complex (no real roots)\n");
    }
    return 0;
}
''')
add(173, r'''
#include <stdio.h>

int main(void)
{
    char ch = '~';
    /* printable ASCII characters are 32 (space) to 126 (~) */
    if (ch >= 32 && ch <= 126)
    {
        printf("Character '%c' (code %d) is printable ASCII\n", ch, ch);
    }
    else
    {
        printf("Character with code %d is not printable ASCII\n", ch);
    }
    return 0;
}
''')
add(174, r'''
#include <stdio.h>

int main(void)
{
    int a = 18, b = 42, c = 7, d = 30;
    int max = a, second;
    /* find the largest, then the largest among the remaining ones */
    if (b > max) max = b;
    if (c > max) max = c;
    if (d > max) max = d;
    second = -2147483647 - 1;
    if (a != max && a > second) second = a;
    if (b != max && b > second) second = b;
    if (c != max && c > second) second = c;
    if (d != max && d > second) second = d;
    printf("Numbers: %d %d %d %d\n", a, b, c, d);
    printf("Largest = %d, second largest = %d\n", max, second);
    return 0;
}
''')
add(175, r'''
#include <stdio.h>

int main(void)
{
    int n = 25;
    int by3 = (n % 3 == 0), by5 = (n % 5 == 0);
    if (by3 != by5)    /* exactly one of the two */
    {
        printf("%d is divisible by 3 or 5 but not both\n", n);
    }
    else
    {
        printf("%d does not satisfy the condition\n", n);
    }
    return 0;
}
''')
