# programs 501-600 : sorting and searching
P = {}
def add(i, code, stdin=""): P[i] = (stdin, code.strip("\n"))

add(501, r'''
#include <stdio.h>

int main(void)
{
    int a[] = {64, 34, 25, 12, 22, 11, 90};
    int n = sizeof(a) / sizeof(a[0]);
    int i, j, temp;

    printf("Before sorting: ");
    for (i = 0; i < n; i++)
        printf("%d ", a[i]);
    printf("\n");

    for (i = 0; i < n - 1; i++)
    {
        for (j = 0; j < n - 1 - i; j++)
        {
            if (a[j] > a[j + 1])
            {
                temp = a[j];
                a[j] = a[j + 1];
                a[j + 1] = temp;
            }
        }
    }

    printf("After sorting (ascending): ");
    for (i = 0; i < n; i++)
        printf("%d ", a[i]);
    printf("\n");
    return 0;
}
''')
add(502, r'''
#include <stdio.h>

int main(void)
{
    int a[] = {5, 91, 17, 42, 8, 63, 30, 25};
    int n = sizeof(a) / sizeof(a[0]);
    int i, j, temp;

    printf("Original array  : ");
    for (i = 0; i < n; i++)
        printf("%d ", a[i]);
    printf("\n");

    for (i = 0; i < n - 1; i++)
    {
        for (j = 0; j < n - 1 - i; j++)
        {
            if (a[j] < a[j + 1])   /* smaller value moves right */
            {
                temp = a[j];
                a[j] = a[j + 1];
                a[j + 1] = temp;
            }
        }
    }

    printf("Descending order: ");
    for (i = 0; i < n; i++)
        printf("%d ", a[i]);
    printf("\n");
    return 0;
}
''')
add(503, r'''
#include <stdio.h>

int main(void)
{
    int a[] = {29, 10, 14, 37, 13, 5};
    int n = sizeof(a) / sizeof(a[0]);
    int i, j, min, temp;

    printf("Before: ");
    for (i = 0; i < n; i++)
        printf("%d ", a[i]);
    printf("\n");

    for (i = 0; i < n - 1; i++)
    {
        min = i;
        for (j = i + 1; j < n; j++)
        {
            if (a[j] < a[min])
                min = j;
        }
        temp = a[i];
        a[i] = a[min];
        a[min] = temp;
    }

    printf("After : ");
    for (i = 0; i < n; i++)
        printf("%d ", a[i]);
    printf("\n");
    return 0;
}
''')
add(504, r'''
#include <stdio.h>

int main(void)
{
    int a[] = {7, 19, 3, 88, 45, 21, 60};
    int n = sizeof(a) / sizeof(a[0]);
    int i, j, max, temp;

    printf("Before: ");
    for (i = 0; i < n; i++)
        printf("%d ", a[i]);
    printf("\n");

    for (i = 0; i < n - 1; i++)
    {
        max = i;
        for (j = i + 1; j < n; j++)
        {
            if (a[j] > a[max])
                max = j;
        }
        temp = a[i];
        a[i] = a[max];
        a[max] = temp;
    }

    printf("After (descending): ");
    for (i = 0; i < n; i++)
        printf("%d ", a[i]);
    printf("\n");
    return 0;
}
''')
add(505, r'''
#include <stdio.h>

int main(void)
{
    int a[] = {12, 11, 13, 5, 6, 9};
    int n = sizeof(a) / sizeof(a[0]);
    int i, j, key;

    printf("Before: ");
    for (i = 0; i < n; i++)
        printf("%d ", a[i]);
    printf("\n");

    for (i = 1; i < n; i++)
    {
        key = a[i];
        j = i - 1;
        while (j >= 0 && a[j] > key)
        {
            a[j + 1] = a[j];
            j--;
        }
        a[j + 1] = key;
    }

    printf("After : ");
    for (i = 0; i < n; i++)
        printf("%d ", a[i]);
    printf("\n");
    return 0;
}
''')
add(506, r'''
#include <stdio.h>

int main(void)
{
    int a[] = {4, 27, 15, 8, 33, 21};
    int n = sizeof(a) / sizeof(a[0]);
    int i, j, key;

    printf("Before: ");
    for (i = 0; i < n; i++)
        printf("%d ", a[i]);
    printf("\n");

    for (i = 1; i < n; i++)
    {
        key = a[i];
        j = i - 1;
        while (j >= 0 && a[j] < key)   /* shift smaller items right */
        {
            a[j + 1] = a[j];
            j--;
        }
        a[j + 1] = key;
    }

    printf("After (descending): ");
    for (i = 0; i < n; i++)
        printf("%d ", a[i]);
    printf("\n");
    return 0;
}
''')
add(507, r'''
#include <stdio.h>

void merge(int a[], int low, int mid, int high)
{
    int temp[50];
    int i = low, j = mid + 1, k = 0;

    while (i <= mid && j <= high)
    {
        if (a[i] <= a[j])
            temp[k++] = a[i++];
        else
            temp[k++] = a[j++];
    }
    while (i <= mid)
        temp[k++] = a[i++];
    while (j <= high)
        temp[k++] = a[j++];
    for (i = 0; i < k; i++)
        a[low + i] = temp[i];
}

void mergeSort(int a[], int low, int high)
{
    if (low < high)
    {
        int mid = (low + high) / 2;
        mergeSort(a, low, mid);
        mergeSort(a, mid + 1, high);
        merge(a, low, mid, high);
    }
}

int main(void)
{
    int a[] = {38, 27, 43, 3, 9, 82, 10};
    int n = sizeof(a) / sizeof(a[0]);
    int i;

    printf("Before: ");
    for (i = 0; i < n; i++)
        printf("%d ", a[i]);
    printf("\n");

    mergeSort(a, 0, n - 1);

    printf("After : ");
    for (i = 0; i < n; i++)
        printf("%d ", a[i]);
    printf("\n");
    return 0;
}
''')
add(508, r'''
#include <stdio.h>

int partition(int a[], int low, int high)
{
    int pivot = a[high];
    int i = low - 1, j, temp;

    for (j = low; j < high; j++)
    {
        if (a[j] < pivot)
        {
            i++;
            temp = a[i]; a[i] = a[j]; a[j] = temp;
        }
    }
    temp = a[i + 1]; a[i + 1] = a[high]; a[high] = temp;
    return i + 1;
}

void quickSort(int a[], int low, int high)
{
    if (low < high)
    {
        int p = partition(a, low, high);
        quickSort(a, low, p - 1);
        quickSort(a, p + 1, high);
    }
}

int main(void)
{
    int a[] = {10, 80, 30, 90, 40, 50, 70};
    int n = sizeof(a) / sizeof(a[0]);
    int i;

    printf("Before: ");
    for (i = 0; i < n; i++)
        printf("%d ", a[i]);
    printf("\n");

    quickSort(a, 0, n - 1);

    printf("After : ");
    for (i = 0; i < n; i++)
        printf("%d ", a[i]);
    printf("\n");
    return 0;
}
''')
add(509, r'''
#include <stdio.h>

void heapify(int a[], int n, int root)
{
    int largest = root;
    int left = 2 * root + 1;
    int right = 2 * root + 2;
    int temp;

    if (left < n && a[left] > a[largest])
        largest = left;
    if (right < n && a[right] > a[largest])
        largest = right;
    if (largest != root)
    {
        temp = a[root]; a[root] = a[largest]; a[largest] = temp;
        heapify(a, n, largest);
    }
}

void heapSort(int a[], int n)
{
    int i, temp;
    for (i = n / 2 - 1; i >= 0; i--)     /* build max heap */
        heapify(a, n, i);
    for (i = n - 1; i > 0; i--)          /* move max to the end */
    {
        temp = a[0]; a[0] = a[i]; a[i] = temp;
        heapify(a, i, 0);
    }
}

int main(void)
{
    int a[] = {12, 11, 13, 5, 6, 7, 1};
    int n = sizeof(a) / sizeof(a[0]);
    int i;

    printf("Before: ");
    for (i = 0; i < n; i++)
        printf("%d ", a[i]);
    printf("\n");

    heapSort(a, n);

    printf("After : ");
    for (i = 0; i < n; i++)
        printf("%d ", a[i]);
    printf("\n");
    return 0;
}
''')
add(510, r'''
#include <stdio.h>

int main(void)
{
    int a[] = {4, 2, 2, 8, 3, 3, 1, 7};
    int n = sizeof(a) / sizeof(a[0]);
    int count[10] = {0};     /* values are in the range 0..9 */
    int i, k = 0, v;

    printf("Before: ");
    for (i = 0; i < n; i++)
        printf("%d ", a[i]);
    printf("\n");

    for (i = 0; i < n; i++)          /* count each value */
        count[a[i]]++;
    for (v = 0; v < 10; v++)         /* write values back in order */
    {
        while (count[v] > 0)
        {
            a[k++] = v;
            count[v]--;
        }
    }

    printf("After : ");
    for (i = 0; i < n; i++)
        printf("%d ", a[i]);
    printf("\n");
    return 0;
}
''')
add(511, r'''
#include <stdio.h>

/* stable counting sort on the digit given by exp (1, 10, 100...) */
void countByDigit(int a[], int n, int exp)
{
    int output[20], count[10] = {0};
    int i;

    for (i = 0; i < n; i++)
        count[(a[i] / exp) % 10]++;
    for (i = 1; i < 10; i++)
        count[i] += count[i - 1];
    for (i = n - 1; i >= 0; i--)
    {
        output[count[(a[i] / exp) % 10] - 1] = a[i];
        count[(a[i] / exp) % 10]--;
    }
    for (i = 0; i < n; i++)
        a[i] = output[i];
}

int main(void)
{
    int a[] = {170, 45, 75, 90, 802, 24, 2, 66};
    int n = sizeof(a) / sizeof(a[0]);
    int i, max = a[0], exp;

    printf("Before: ");
    for (i = 0; i < n; i++)
        printf("%d ", a[i]);
    printf("\n");

    for (i = 1; i < n; i++)
        if (a[i] > max)
            max = a[i];
    for (exp = 1; max / exp > 0; exp *= 10)
        countByDigit(a, n, exp);

    printf("After : ");
    for (i = 0; i < n; i++)
        printf("%d ", a[i]);
    printf("\n");
    return 0;
}
''')
add(512, r'''
#include <stdio.h>

int main(void)
{
    int a[] = {23, 12, 1, 8, 34, 54, 2, 3};
    int n = sizeof(a) / sizeof(a[0]);
    int gap, i, j, temp;

    printf("Before: ");
    for (i = 0; i < n; i++)
        printf("%d ", a[i]);
    printf("\n");

    for (gap = n / 2; gap > 0; gap /= 2)
    {
        for (i = gap; i < n; i++)
        {
            temp = a[i];
            for (j = i; j >= gap && a[j - gap] > temp; j -= gap)
                a[j] = a[j - gap];
            a[j] = temp;
        }
    }

    printf("After : ");
    for (i = 0; i < n; i++)
        printf("%d ", a[i]);
    printf("\n");
    return 0;
}
''')
add(513, r'''
#include <stdio.h>

int main(void)
{
    int a[] = {5, 1, 4, 2, 8, 0, 2};
    int n = sizeof(a) / sizeof(a[0]);
    int start = 0, end = n - 1, swapped = 1, i, temp;

    printf("Before: ");
    for (i = 0; i < n; i++)
        printf("%d ", a[i]);
    printf("\n");

    while (swapped)
    {
        swapped = 0;
        for (i = start; i < end; i++)          /* forward pass */
        {
            if (a[i] > a[i + 1])
            {
                temp = a[i]; a[i] = a[i + 1]; a[i + 1] = temp;
                swapped = 1;
            }
        }
        end--;
        for (i = end - 1; i >= start; i--)     /* backward pass */
        {
            if (a[i] > a[i + 1])
            {
                temp = a[i]; a[i] = a[i + 1]; a[i + 1] = temp;
                swapped = 1;
            }
        }
        start++;
    }

    printf("After : ");
    for (i = 0; i < n; i++)
        printf("%d ", a[i]);
    printf("\n");
    return 0;
}
''')
add(514, r'''
#include <stdio.h>

int main(void)
{
    int a[] = {8, 4, 1, 56, 3, -44, 23, -6, 28, 0};
    int n = sizeof(a) / sizeof(a[0]);
    int gap = n, swapped = 1, i, temp;

    printf("Before: ");
    for (i = 0; i < n; i++)
        printf("%d ", a[i]);
    printf("\n");

    while (gap > 1 || swapped)
    {
        gap = gap * 10 / 13;          /* shrink factor about 1.3 */
        if (gap < 1)
            gap = 1;
        swapped = 0;
        for (i = 0; i + gap < n; i++)
        {
            if (a[i] > a[i + gap])
            {
                temp = a[i]; a[i] = a[i + gap]; a[i + gap] = temp;
                swapped = 1;
            }
        }
    }

    printf("After : ");
    for (i = 0; i < n; i++)
        printf("%d ", a[i]);
    printf("\n");
    return 0;
}
''')
add(515, r'''
#include <stdio.h>
#include <string.h>

int main(void)
{
    char names[6][20] = {"mango", "apple", "cherry", "banana", "grape", "kiwi"};
    int n = 6, i, j;
    char temp[20];

    printf("Before sorting:\n");
    for (i = 0; i < n; i++)
        printf("  %s\n", names[i]);

    for (i = 0; i < n - 1; i++)
    {
        for (j = 0; j < n - 1 - i; j++)
        {
            if (strcmp(names[j], names[j + 1]) > 0)
            {
                strcpy(temp, names[j]);
                strcpy(names[j], names[j + 1]);
                strcpy(names[j + 1], temp);
            }
        }
    }

    printf("After sorting (alphabetical):\n");
    for (i = 0; i < n; i++)
        printf("  %s\n", names[i]);
    return 0;
}
''')
add(516, r'''
#include <stdio.h>

struct Student
{
    char name[20];
    int marks;
};

int main(void)
{
    struct Student s[5] = {{"Asha", 78}, {"Ravi", 92}, {"Meena", 65}, {"John", 85}, {"Kiran", 70}};
    int n = 5, i, j;
    struct Student temp;

    for (i = 0; i < n - 1; i++)
    {
        for (j = 0; j < n - 1 - i; j++)
        {
            if (s[j].marks < s[j + 1].marks)    /* highest marks first */
            {
                temp = s[j];
                s[j] = s[j + 1];
                s[j + 1] = temp;
            }
        }
    }

    printf("Rank  Name     Marks\n");
    for (i = 0; i < n; i++)
        printf("%-5d %-8s %d\n", i + 1, s[i].name, s[i].marks);
    return 0;
}
''')
add(517, r'''
#include <stdio.h>

struct Student
{
    int id;
    char name[20];
    float cgpa;
};

int main(void)
{
    struct Student s[5] = {{104, "Divya", 8.2f}, {101, "Arun", 7.5f}, {105, "Eshan", 9.1f},
                           {102, "Bala", 6.8f}, {103, "Chitra", 8.8f}};
    int n = 5, i, j, min;
    struct Student temp;

    for (i = 0; i < n - 1; i++)      /* selection sort on id */
    {
        min = i;
        for (j = i + 1; j < n; j++)
            if (s[j].id < s[min].id)
                min = j;
        temp = s[i];
        s[i] = s[min];
        s[min] = temp;
    }

    printf("ID    Name     CGPA\n");
    for (i = 0; i < n; i++)
        printf("%-5d %-8s %.1f\n", s[i].id, s[i].name, s[i].cgpa);
    return 0;
}
''')
add(518, r'''
#include <stdio.h>

int main(void)
{
    int a[] = {4, 6, 2, 4, 6, 4, 9, 2};
    int n = sizeof(a) / sizeof(a[0]);
    int value[10], freq[10], m = 0;
    int i, j, found, t;

    /* build table of distinct values with their counts */
    for (i = 0; i < n; i++)
    {
        found = 0;
        for (j = 0; j < m; j++)
        {
            if (value[j] == a[i])
            {
                freq[j]++;
                found = 1;
                break;
            }
        }
        if (!found)
        {
            value[m] = a[i];
            freq[m] = 1;
            m++;
        }
    }

    /* sort table by frequency (high first); equal frequency keeps first-seen order */
    for (i = 1; i < m; i++)
    {
        int v = value[i], f = freq[i];
        j = i - 1;
        while (j >= 0 && freq[j] < f)
        {
            value[j + 1] = value[j];
            freq[j + 1] = freq[j];
            j--;
        }
        value[j + 1] = v;
        freq[j + 1] = f;
    }

    printf("Original: ");
    for (i = 0; i < n; i++)
        printf("%d ", a[i]);
    printf("\nSorted by frequency: ");
    for (i = 0; i < m; i++)
        for (t = 0; t < freq[i]; t++)
            printf("%d ", value[i]);
    printf("\n");
    return 0;
}
''')
add(519, r'''
#include <stdio.h>

int main(void)
{
    int a[] = {7, 12, 3, 8, 5, 10, 1, 4};
    int n = sizeof(a) / sizeof(a[0]);
    int result[8], k = 0, i;

    printf("Original: ");
    for (i = 0; i < n; i++)
        printf("%d ", a[i]);
    printf("\n");

    for (i = 0; i < n; i++)      /* first copy the even numbers */
        if (a[i] % 2 == 0)
            result[k++] = a[i];
    for (i = 0; i < n; i++)      /* then the odd numbers */
        if (a[i] % 2 != 0)
            result[k++] = a[i];

    printf("Even first, then odd: ");
    for (i = 0; i < n; i++)
        printf("%d ", result[i]);
    printf("\n");
    return 0;
}
''')
add(520, r'''
#include <stdio.h>

struct Item
{
    int key;
    char tag;
};

int main(void)
{
    struct Item a[] = {{3, 'a'}, {1, 'b'}, {3, 'c'}, {2, 'd'}, {1, 'e'}, {3, 'f'}};
    int n = sizeof(a) / sizeof(a[0]);
    int i, j;
    struct Item temp;

    printf("Before: ");
    for (i = 0; i < n; i++)
        printf("%d%c ", a[i].key, a[i].tag);
    printf("\n");

    /* insertion sort is stable: strictly greater keys are shifted only */
    for (i = 1; i < n; i++)
    {
        temp = a[i];
        j = i - 1;
        while (j >= 0 && a[j].key > temp.key)
        {
            a[j + 1] = a[j];
            j--;
        }
        a[j + 1] = temp;
    }

    printf("After : ");
    for (i = 0; i < n; i++)
        printf("%d%c ", a[i].key, a[i].tag);
    printf("\n(equal keys keep their original order: 1b before 1e, 3a 3c 3f)\n");
    return 0;
}
''')
add(521, r'''
#include <stdio.h>

int main(void)
{
    int base[] = {9, 4, 7, 1, 8, 2, 6};
    int n = sizeof(base) / sizeof(base[0]);
    int a[7], i, j, min, temp;
    int bubbleCmp = 0, selCmp = 0;

    /* bubble sort on a copy */
    for (i = 0; i < n; i++)
        a[i] = base[i];
    for (i = 0; i < n - 1; i++)
    {
        for (j = 0; j < n - 1 - i; j++)
        {
            bubbleCmp++;
            if (a[j] > a[j + 1])
            {
                temp = a[j]; a[j] = a[j + 1]; a[j + 1] = temp;
            }
        }
    }

    /* selection sort on a fresh copy */
    for (i = 0; i < n; i++)
        a[i] = base[i];
    for (i = 0; i < n - 1; i++)
    {
        min = i;
        for (j = i + 1; j < n; j++)
        {
            selCmp++;
            if (a[j] < a[min])
                min = j;
        }
        temp = a[i]; a[i] = a[min]; a[min] = temp;
    }

    printf("Array size          : %d\n", n);
    printf("Bubble sort compares: %d\n", bubbleCmp);
    printf("Selection sort compares: %d\n", selCmp);
    printf("Both need n(n-1)/2 = %d comparisons here.\n", n * (n - 1) / 2);
    return 0;
}
''')
add(522, r'''
#include <stdio.h>

int main(void)
{
    int a[] = {5, 3, 8, 4, 2, 9, 1};
    int n = sizeof(a) / sizeof(a[0]);
    int i, j, temp, swaps = 0;

    printf("Before: ");
    for (i = 0; i < n; i++)
        printf("%d ", a[i]);
    printf("\n");

    for (i = 0; i < n - 1; i++)
    {
        for (j = 0; j < n - 1 - i; j++)
        {
            if (a[j] > a[j + 1])
            {
                temp = a[j]; a[j] = a[j + 1]; a[j + 1] = temp;
                swaps++;
            }
        }
    }

    printf("After : ");
    for (i = 0; i < n; i++)
        printf("%d ", a[i]);
    printf("\nTotal swaps = %d\n", swaps);
    return 0;
}
''')
add(523, r'''
#include <stdio.h>

int main(void)
{
    int a[] = {6, 3, 9, 1, 5};
    int n = sizeof(a) / sizeof(a[0]);
    int i, j, k, temp;

    printf("Initial : ");
    for (k = 0; k < n; k++)
        printf("%d ", a[k]);
    printf("\n");

    for (i = 0; i < n - 1; i++)
    {
        for (j = 0; j < n - 1 - i; j++)
        {
            if (a[j] > a[j + 1])
            {
                temp = a[j]; a[j] = a[j + 1]; a[j + 1] = temp;
            }
        }
        printf("Pass %d  : ", i + 1);
        for (k = 0; k < n; k++)
            printf("%d ", a[k]);
        printf("\n");
    }
    return 0;
}
''')
add(524, r'''
#include <stdio.h>

int main(void)
{
    int a[] = {1, 2, 4, 3, 5, 6, 8, 7, 9, 10};
    int n = sizeof(a) / sizeof(a[0]);
    int i, j, key, shifts = 0;

    printf("Nearly sorted input: ");
    for (i = 0; i < n; i++)
        printf("%d ", a[i]);
    printf("\n");

    for (i = 1; i < n; i++)
    {
        key = a[i];
        j = i - 1;
        while (j >= 0 && a[j] > key)
        {
            a[j + 1] = a[j];
            shifts++;
            j--;
        }
        a[j + 1] = key;
    }

    printf("Sorted output      : ");
    for (i = 0; i < n; i++)
        printf("%d ", a[i]);
    printf("\nOnly %d shifts were needed (close to n = %d).\n", shifts, n);
    return 0;
}
''')
add(525, r'''
#include <stdio.h>

int main(void)
{
    int a[] = {2, 0, 2, 1, 1, 0, 1, 2, 0};
    int n = sizeof(a) / sizeof(a[0]);
    int low = 0, mid = 0, high = n - 1, temp, i;

    printf("Before: ");
    for (i = 0; i < n; i++)
        printf("%d ", a[i]);
    printf("\n");

    /* Dutch national flag: 0s go left, 2s go right */
    while (mid <= high)
    {
        if (a[mid] == 0)
        {
            temp = a[low]; a[low] = a[mid]; a[mid] = temp;
            low++;
            mid++;
        }
        else if (a[mid] == 1)
        {
            mid++;
        }
        else
        {
            temp = a[mid]; a[mid] = a[high]; a[high] = temp;
            high--;
        }
    }

    printf("After : ");
    for (i = 0; i < n; i++)
        printf("%d ", a[i]);
    printf("\n");
    return 0;
}
''')
