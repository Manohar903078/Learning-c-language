# programs 876-950 : id -> (stdin, code)
P = {}
def add(i, code, stdin=""): P[i] = (stdin, code.strip("\n"))

add(876, r'''
#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int *p = malloc(sizeof(int));      /* memory for ONE int */
    if (p == NULL) {
        printf("Memory allocation failed\n");
        return 1;
    }
    printf("Enter an integer: ");
    if (scanf("%d", p) != 1) {
        printf("Invalid input\n");
        free(p);
        return 1;
    }
    printf("Stored value : %d\n", *p);
    printf("Address holds %zu bytes\n", sizeof(*p));
    free(p);
    return 0;
}
''', "42")

add(877, r'''
#include <stdio.h>
#include <stdlib.h>

/* Print n integers stored in arr */
void display(const int *arr, int n)
{
    for (int i = 0; i < n; i++)
        printf("arr[%d] = %d\n", i, arr[i]);
}

int main(void)
{
    int n;
    printf("How many integers? ");
    if (scanf("%d", &n) != 1 || n <= 0) {
        printf("Invalid count\n");
        return 1;
    }
    int *arr = malloc(n * sizeof(int));
    if (arr == NULL) {
        printf("Out of memory\n");
        return 1;
    }
    for (int i = 0; i < n; i++)
        scanf("%d", &arr[i]);
    printf("\nThe numbers are:\n");
    display(arr, n);
    free(arr);
    return 0;
}
''', "5\n12 7 30 -4 99")

add(878, r'''
#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int n;
    printf("Enter number of elements (1-100): ");
    if (scanf("%d", &n) != 1) {
        printf("Error: input is not a number.\n");
        return 1;
    }
    if (n < 1 || n > 100) {
        printf("Error: count must be between 1 and 100.\n");
        return 1;
    }
    int *a = malloc(n * sizeof *a);
    if (a == NULL) {
        printf("Error: memory allocation failed.\n");
        return 1;
    }
    for (int i = 0; i < n; i++) {
        if (scanf("%d", &a[i]) != 1) {
            printf("Error: element %d is invalid.\n", i + 1);
            free(a);
            return 1;
        }
    }
    int max = a[0];
    for (int i = 1; i < n; i++)
        if (a[i] > max)
            max = a[i];
    printf("Maximum = %d\n", max);
    free(a);
    return 0;
}
''', "6\n14 -3 88 25 88 7")

add(879, r'''
#include <stdio.h>
#include <stdlib.h>

/* Run one test: calloc n ints, show initial zeros, fill, show sum */
void run_test(int test, int n)
{
    int *a = calloc(n, sizeof(int));     /* all elements start at 0 */
    if (a == NULL) {
        printf("Test %d: allocation failed\n", test);
        return;
    }
    printf("Test %d (n=%d) after calloc:", test, n);
    for (int i = 0; i < n; i++)
        printf(" %d", a[i]);
    int sum = 0;
    for (int i = 0; i < n; i++) {
        scanf("%d", &a[i]);
        sum += a[i];
    }
    printf("\n         after input sum = %d\n", sum);
    free(a);
}

int main(void)
{
    for (int t = 1; t <= 3; t++) {
        int n;
        if (scanf("%d", &n) != 1 || n <= 0) {
            printf("Test %d: invalid size\n", t);
            return 1;
        }
        run_test(t, n);
    }
    return 0;
}
''', "3\n1 2 3\n1\n50\n5\n10 20 30 40 50")

add(880, r'''
#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int n = 3;
    int *a = malloc(n * sizeof(int));     /* start with room for 3 */
    if (a == NULL)
        return 1;
    for (int i = 0; i < n; i++)
        a[i] = (i + 1) * 10;

    printf("Initial size %d:", n);
    for (int i = 0; i < n; i++)
        printf(" %d", a[i]);

    int newSize;
    printf("\nEnter new size: ");
    if (scanf("%d", &newSize) != 1 || newSize <= 0) {
        printf("Invalid size\n");
        free(a);
        return 1;
    }
    /* realloc keeps old data and may move the block */
    int *tmp = realloc(a, newSize * sizeof(int));
    if (tmp == NULL) {
        printf("realloc failed, keeping old array\n");
        free(a);
        return 1;
    }
    a = tmp;
    for (int i = n; i < newSize; i++)     /* fill only the new part */
        a[i] = (i + 1) * 10;
    n = newSize;

    printf("Resized to %d:", n);
    for (int i = 0; i < n; i++)
        printf(" %d", a[i]);
    printf("\n");
    free(a);
    return 0;
}
''', "6")

add(881, r'''
#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int capacity = 2, count = 0, value;
    int *data = malloc(capacity * sizeof(int));
    if (data == NULL)
        return 1;
    printf("Enter numbers (0 to stop):\n");
    while (scanf("%d", &value) == 1 && value != 0) {
        if (count == capacity) {            /* array is full: double it */
            capacity *= 2;
            int *tmp = realloc(data, capacity * sizeof(int));
            if (tmp == NULL) {
                free(data);
                return 1;
            }
            data = tmp;
            printf("[array grown to %d]\n", capacity);
        }
        data[count++] = value;
    }
    if (count == 0) {                       /* boundary: nothing entered */
        printf("No numbers were entered.\n");
    } else {
        printf("Stored %d numbers:", count);
        for (int i = 0; i < count; i++)
            printf(" %d", data[i]);
        printf("\n");
    }
    free(data);
    return 0;
}
''', "4 8 15 16 23 42 0")

add(882, r'''
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(void)
{
    char *text = NULL;
    int capacity = 0, choice;
    do {
        printf("\n1. Set capacity\n2. Store a word\n3. Show string\n4. Exit\nChoice: ");
        if (scanf("%d", &choice) != 1)
            break;
        if (choice == 1) {
            int c;
            scanf("%d", &c);
            if (c < 2) {
                printf("Capacity must be at least 2\n");
                continue;
            }
            free(text);
            text = calloc(c, 1);
            if (text == NULL) { printf("Out of memory\n"); return 1; }
            capacity = c;
            printf("Allocated %d bytes\n", capacity);
        } else if (choice == 2) {
            char temp[100];
            scanf("%99s", temp);
            if (text == NULL) {
                printf("Set capacity first\n");
                continue;
            }
            strncpy(text, temp, capacity - 1);   /* never overflow */
            text[capacity - 1] = '\0';
            printf("Stored (max %d chars)\n", capacity - 1);
        } else if (choice == 3) {
            printf("String = \"%s\"\n", text ? text : "(none)");
        }
    } while (choice != 4);
    free(text);
    printf("Goodbye\n");
    return 0;
}
''', "3\n2 hello\n1 8\n2 programming\n3\n1 20\n2 programming\n3\n4")

add(883, r'''
#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    size_t cap = 4, len = 0;
    char *buf = malloc(cap);
    int ch;
    if (buf == NULL)
        return 1;
    printf("Type a line: ");
    while ((ch = getchar()) != '\n' && ch != EOF) {
        if (len + 1 >= cap) {                 /* keep room for '\0' */
            cap *= 2;
            char *tmp = realloc(buf, cap);
            if (tmp == NULL) { free(buf); return 1; }
            buf = tmp;
            printf("  [buffer grown to %zu bytes at length %zu]\n", cap, len);
        }
        buf[len++] = (char)ch;
    }
    buf[len] = '\0';
    printf("Line read   : \"%s\"\n", buf);
    printf("Length      : %zu\n", len);
    printf("Buffer size : %zu\n", cap);
    free(buf);
    return 0;
}
''', "dynamic memory is fun\n")

add(884, r'''
#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int rows = 3, cols = 4;
    int **m = malloc(rows * sizeof(int *));    /* array of row pointers */
    if (m == NULL)
        return 1;
    for (int i = 0; i < rows; i++) {           /* one loop allocates all rows */
        m[i] = malloc(cols * sizeof(int));
        if (m[i] == NULL)
            return 1;
        for (int j = 0; j < cols; j++)
            m[i][j] = (i + 1) * (j + 1);       /* multiplication table */
    }
    printf("%d x %d matrix:\n", rows, cols);
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++)
            printf("%4d", m[i][j]);
        printf("\n");
    }
    for (int i = 0; i < rows; i++)
        free(m[i]);
    free(m);
    return 0;
}
''')

add(885, r'''
#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int rows = 4;
    int *lens = malloc(rows * sizeof(int));
    int **jag = malloc(rows * sizeof(int *));
    if (lens == NULL || jag == NULL)
        return 1;
    for (int i = 0; i < rows; i++) {
        lens[i] = i + 1;                        /* row i has i+1 items */
        jag[i] = malloc(lens[i] * sizeof(int));
        if (jag[i] == NULL)
            return 1;
        for (int *p = jag[i]; p < jag[i] + lens[i]; p++)
            *p = (int)(p - jag[i]) + 1 + i * 10;
    }
    printf("Jagged array:\n");
    for (int i = 0; i < rows; i++) {
        printf("Row %d (length %d):", i, lens[i]);
        for (int j = 0; j < lens[i]; j++)
            printf(" %d", *(*(jag + i) + j));
        printf("\n");
    }
    for (int i = 0; i < rows; i++)
        free(jag[i]);
    free(jag);
    free(lens);
    return 0;
}
''')

add(886, r'''
#include <stdio.h>
#include <stdlib.h>

struct Item {
    char name[20];
    int qty;
    float price;
};

int main(void)
{
    int n;
    printf("How many items? ");
    if (scanf("%d", &n) != 1 || n <= 0)
        return 1;
    struct Item *items = malloc(n * sizeof(struct Item));
    if (items == NULL)
        return 1;
    for (int i = 0; i < n; i++)
        scanf("%19s %d %f", items[i].name, &items[i].qty, &items[i].price);

    printf("\n%-12s %5s %8s\n", "Name", "Qty", "Price");
    float total = 0;
    for (int i = 0; i < n; i++) {
        printf("%-12s %5d %8.2f\n", items[i].name, items[i].qty, items[i].price);
        total += items[i].qty * items[i].price;
    }
    printf("Total value = %.2f\n", total);
    free(items);
    return 0;
}
''', "3\nPen 10 1.50\nNotebook 4 3.25\nBag 1 24.99")

add(887, r'''
#include <stdio.h>
#include <stdlib.h>

struct Node {
    int data;
    struct Node *next;
};

int main(void)
{
    struct Node *head = NULL, *tail = NULL;
    for (int i = 1; i <= 5; i++) {              /* create 5 nodes */
        struct Node *n = malloc(sizeof(struct Node));
        if (n == NULL)
            return 1;
        n->data = i * i;
        n->next = NULL;
        if (head == NULL)
            head = tail = n;
        else {
            tail->next = n;
            tail = n;
        }
    }
    printf("List: ");
    for (struct Node *p = head; p != NULL; p = p->next)
        printf("%d -> ", p->data);
    printf("NULL\n");

    int freed = 0;
    while (head != NULL) {                      /* free every node */
        struct Node *next = head->next;
        free(head);
        head = next;
        freed++;
    }
    printf("Freed %d nodes\n", freed);
    return 0;
}
''')

add(888, r'''
#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    /* requested sizes in bytes; the last one is far too big */
    size_t sizes[4] = {100, 4096, 1000000, (size_t)-1};
    for (int i = 0; i < 4; i++) {
        char *p = malloc(sizes[i]);
        if (p == NULL) {
            printf("Request %d (%zu bytes): FAILED, malloc returned NULL\n", i + 1, sizes[i]);
            continue;                           /* never use a NULL pointer */
        }
        p[0] = 'A';
        printf("Request %d (%zu bytes): OK, first byte = %c\n", i + 1, sizes[i], p[0]);
        free(p);
    }
    return 0;
}
''')

add(889, r'''
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(void)
{
    const char *words[3] = {"alpha", "beta", "gamma"};
    char **list = malloc(3 * sizeof(char *));
    int *lengths = malloc(3 * sizeof(int));
    if (list == NULL || lengths == NULL)
        return 1;
    for (int i = 0; i < 3; i++) {
        list[i] = malloc(strlen(words[i]) + 1);
        if (list[i] == NULL)
            return 1;
        strcpy(list[i], words[i]);
        lengths[i] = (int)strlen(list[i]);
    }
    printf("%-6s %-10s %s\n", "Index", "Word", "Length");
    printf("---------------------------\n");
    for (int i = 0; i < 3; i++)
        printf("%-6d %-10s %d\n", i, list[i], lengths[i]);

    for (int i = 0; i < 3; i++)
        free(list[i]);                          /* free each string */
    free(list);                                 /* then the pointer array */
    free(lengths);
    printf("All memory freed.\n");
    return 0;
}
''')

add(890, r'''
#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int n;
    printf("Enter block size (1-10): ");
    if (scanf("%d", &n) != 1 || n < 1 || n > 10) {
        printf("Invalid size, must be 1 to 10\n");
        return 1;
    }
    int *m = malloc(n * sizeof(int));      /* contents NOT initialised */
    int *c = calloc(n, sizeof(int));       /* contents set to zero */
    if (m == NULL || c == NULL) {
        free(m);
        free(c);
        return 1;
    }
    for (int i = 0; i < n; i++)            /* we must set malloc memory ourselves */
        m[i] = i * 2;
    printf("calloc block :");
    for (int i = 0; i < n; i++)
        printf(" %d", c[i]);
    printf("   (already zero)\n");
    printf("malloc block :");
    for (int i = 0; i < n; i++)
        printf(" %d", m[i]);
    printf("   (set by our loop)\n");
    printf("malloc(n*4) takes one argument, calloc(n,4) takes two and clears.\n");
    free(m);
    free(c);
    return 0;
}
''', "5")

add(891, r'''
#include <stdio.h>
#include <stdlib.h>

/* Safe helper: free and set pointer to NULL */
void safe_free(int **p)
{
    free(*p);
    *p = NULL;
}

int main(void)
{
    int *p = malloc(sizeof(int));
    if (p == NULL)
        return 1;
    *p = 77;
    printf("Before free: *p = %d\n", *p);
    free(p);
    /* UNSAFE: p is now dangling. Reading *p here is undefined behaviour,
       so we do NOT do it. */
    printf("After free : p is dangling, must not be used\n");

    int *q = malloc(sizeof(int));
    if (q == NULL)
        return 1;
    *q = 88;
    safe_free(&q);
    if (q == NULL)
        printf("Safe way   : q set to NULL, check before use -> not used\n");
    safe_free(&q);                       /* freeing NULL is harmless */
    printf("Freeing NULL again is harmless.\n");
    return 0;
}
''')

add(892, r'''
#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int cap = 2, n = 0, v;
    int *a = malloc(cap * sizeof *a);
    if (a == NULL)
        return 1;
    while (scanf("%d", &v) == 1) {
        if (n == cap) {
            /* Doubling makes appends O(1) on average: copying costs O(n)
               only occasionally. Space used is at most 2x the data. */
            int *tmp = realloc(a, 2 * cap * sizeof *a);
            if (tmp == NULL) {          /* a is still valid, so no leak */
                printf("realloc failed\n");
                free(a);
                return 1;
            }
            a = tmp;
            cap *= 2;
        }
        a[n++] = v;
    }
    printf("Read %d values, capacity %d\n", n, cap);
    for (int i = 0; i < n; i++)
        printf("%d ", a[i]);
    printf("\n");
    free(a);
    return 0;
}
''', "3 1 4 1 5 9 2 6 5")

add(893, r'''
#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int n;
    printf("Number of students: ");
    if (scanf("%d", &n) != 1 || n <= 0) {
        printf("Invalid count\n");
        return 1;
    }
    int *marks = malloc(n * sizeof(int));
    if (marks == NULL)
        return 1;
    for (int i = 0; i < n; i++) {
        scanf("%d", &marks[i]);
        if (marks[i] < 0 || marks[i] > 100) {
            printf("Mark %d is out of range 0-100\n", marks[i]);
            free(marks);
            return 1;
        }
    }
    int min = marks[0], max = marks[0], sum = 0;
    for (int i = 0; i < n; i++) {
        if (marks[i] < min) min = marks[i];
        if (marks[i] > max) max = marks[i];
        sum += marks[i];
    }
    printf("Minimum = %d\nMaximum = %d\nAverage = %.2f\n", min, max, (double)sum / n);
    free(marks);
    return 0;
}
''', "6\n72 0 100 45 88 100")

add(894, r'''
#include <stdio.h>
#include <stdlib.h>

struct Buffer {
    char *data;
    size_t len, cap;
};

/* Append one character, doubling the capacity when full */
int append(struct Buffer *b, char c)
{
    if (b->len + 1 >= b->cap) {
        size_t newCap = b->cap * 2;
        char *tmp = realloc(b->data, newCap);
        if (tmp == NULL)
            return 0;
        b->data = tmp;
        b->cap = newCap;
    }
    b->data[b->len++] = c;
    b->data[b->len] = '\0';
    return 1;
}

int main(void)
{
    struct Buffer buf = {malloc(4), 0, 4};     /* no global variables */
    if (buf.data == NULL)
        return 1;
    buf.data[0] = '\0';
    const char *msg = "Expanding buffers are useful!";
    for (const char *p = msg; *p; p++)
        if (!append(&buf, *p)) {
            free(buf.data);
            return 1;
        }
    printf("Text     : %s\n", buf.data);
    printf("Length   : %zu\n", buf.len);
    printf("Capacity : %zu\n", buf.cap);
    free(buf.data);
    return 0;
}
''')

add(895, r'''
#include <stdio.h>
#include <stdlib.h>

/* Allocate two blocks; if the second "fails", release the first. */
int build(int n, int simulateFail)
{
    int *a = malloc(n * sizeof(int));
    if (a == NULL)
        return -1;
    int *b = simulateFail ? NULL : malloc(n * sizeof(int));
    if (b == NULL) {
        printf("  second allocation failed, freeing first block\n");
        free(a);                      /* avoids a leak on the error path */
        return -1;
    }
    for (int i = 0; i < n; i++) {
        a[i] = i;
        b[i] = i * i;
    }
    int sum = 0;
    for (int i = 0; i < n; i++)
        sum += a[i] + b[i];
    free(b);
    free(a);
    return sum;
}

int main(void)
{
    int n;
    printf("Enter n: ");
    if (scanf("%d", &n) != 1 || n <= 0) {
        printf("Invalid n\n");
        return 1;
    }
    for (int fail = 0; fail <= 1; fail++) {
        printf("Run %d (simulate failure = %d)\n", fail + 1, fail);
        int r = build(n, fail);
        if (r < 0)
            printf("  build() reported an error\n");
        else
            printf("  build() result = %d\n", r);
    }
    return 0;
}
''', "5")

add(896, r'''
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(void)
{
    int cap;
    printf("Enter capacity of the string: ");
    if (scanf("%d", &cap) != 1 || cap < 2) {
        printf("Capacity must be a number >= 2\n");
        return 1;
    }
    /* Space cost: exactly cap bytes on the heap, chosen at run time.
       Time cost: malloc is fast; copying text is O(length). */
    char *s = malloc(cap);
    if (s == NULL)
        return 1;
    char word[200];
    printf("Enter a word: ");
    scanf("%199s", word);
    strncpy(s, word, cap - 1);
    s[cap - 1] = '\0';                 /* guarantee termination */
    printf("Capacity %d -> stored \"%s\" (%zu chars)\n", cap, s, strlen(s));
    free(s);
    return 0;
}
''', "10\ncomputerscience")

add(897, r'''
#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int r, c;
    printf("Enter rows and columns: ");
    if (scanf("%d %d", &r, &c) != 2 || r <= 0 || c <= 0)
        return 1;
    int **m = malloc(r * sizeof(int *));
    if (m == NULL)
        return 1;
    for (int i = 0; i < r; i++) {
        m[i] = malloc(c * sizeof(int));
        if (m[i] == NULL)
            return 1;
        for (int j = 0; j < c; j++)
            scanf("%d", &m[i][j]);
    }
    printf("\nMatrix:\n");
    for (int i = 0; i < r; i++) {
        for (int j = 0; j < c; j++)
            printf("%4d", m[i][j]);
        printf("\n");
    }
    printf("\nTranspose:\n");
    for (int j = 0; j < c; j++) {
        for (int i = 0; i < r; i++)
            printf("%4d", m[i][j]);
        printf("\n");
    }
    for (int i = 0; i < r; i++)
        free(m[i]);
    free(m);
    return 0;
}
''', "2 3\n1 2 3\n4 5 6")

add(898, r'''
#include <stdio.h>
#include <stdlib.h>

struct Employee {
    int id;
    char name[20];
    double salary;
};

int main(void)
{
    int n = 3;
    /* One block big enough for n structures */
    struct Employee *emp = malloc(n * sizeof(struct Employee));
    if (emp == NULL)
        return 1;

    const char *names[3] = {"Asha", "Ravi", "Meena"};
    for (int i = 0; i < n; i++) {
        emp[i].id = 101 + i;                       /* fill each record */
        snprintf(emp[i].name, sizeof emp[i].name, "%s", names[i]);
        emp[i].salary = 30000.0 + 2500.5 * i;
    }

    printf("%-5s %-10s %10s\n", "ID", "Name", "Salary");
    for (int i = 0; i < n; i++)                    /* print each record */
        printf("%-5d %-10s %10.2f\n", emp[i].id, emp[i].name, emp[i].salary);

    free(emp);
    return 0;
}
''')

add(899, r'''
#include <stdio.h>
#include <stdlib.h>

#define LIMIT 100000            /* pretend the system has only 100000 bytes */

/* Wrapper that returns NULL when the request exceeds LIMIT */
void *limited_alloc(size_t size)
{
    if (size > LIMIT)
        return NULL;
    return malloc(size);
}

int main(void)
{
    size_t size = 1000;
    for (int step = 1; step <= 6; step++) {      /* loop: grow request x10 */
        char *p = limited_alloc(size);
        if (p == NULL) {
            printf("Step %d: %zu bytes -> allocation FAILED, stopping\n", step, size);
            break;
        }
        p[0] = 'x';
        printf("Step %d: %zu bytes -> allocated\n", step, size);
        free(p);
        size *= 10;
    }
    return 0;
}
''')

add(900, r'''
#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int sizes[3] = {3, 5, 8};            /* several records to process */
    printf("%-6s %-22s %-22s\n", "Size", "calloc contents", "malloc (after filling)");
    for (int k = 0; k < 3; k++) {
        int n = sizes[k];
        int *c = calloc(n, sizeof(int));
        int *m = malloc(n * sizeof(int));
        if (c == NULL || m == NULL) {
            free(c);
            free(m);
            return 1;
        }
        int csum = 0, msum = 0;
        for (int i = 0; i < n; i++) {
            m[i] = i + 1;                /* malloc memory must be set first */
            csum += c[i];
            msum += m[i];
        }
        printf("%-6d sum of zeros = %-8d sum 1..n = %d\n", n, csum, msum);
        free(c);
        free(m);
    }
    return 0;
}
''')

# ---------------- Topic 19: structures ----------------

add(926, r'''
#include <stdio.h>

struct Contact {
    char name[30];
    char phone[15];
    char email[40];
};

int main(void)
{
    struct Contact c = {"Priya Sharma", "9876543210", "priya@example.com"};
    printf("----- Contact Card -----\n");
    printf("Name  : %s\n", c.name);
    printf("Phone : %s\n", c.phone);
    printf("Email : %s\n", c.email);
    return 0;
}
''')

add(927, r'''
#include <stdio.h>

struct Time {
    int hours, minutes, seconds;
};

int to_seconds(struct Time t)
{
    return t.hours * 3600 + t.minutes * 60 + t.seconds;
}

int main(void)
{
    struct Time t1, t2;
    printf("Enter start time (h m s): ");
    scanf("%d %d %d", &t1.hours, &t1.minutes, &t1.seconds);
    printf("Enter end time (h m s): ");
    scanf("%d %d %d", &t2.hours, &t2.minutes, &t2.seconds);

    int diff = to_seconds(t2) - to_seconds(t1);
    if (diff < 0)
        diff += 24 * 3600;               /* end is on the next day */
    printf("Difference = %d h %d m %d s\n", diff / 3600, (diff % 3600) / 60, diff % 60);
    return 0;
}
''', "10 45 30\n14 20 15")

add(928, r'''
#include <stdio.h>

struct Account {
    int number;
    char holder[20];
    double balance;
};

int main(void)
{
    struct Account acc = {1001, "Kiran", 1000.0};
    char type;
    double amount;
    printf("Account %d (%s) opening balance: %.2f\n", acc.number, acc.holder, acc.balance);
    printf("Enter transactions (D amount / W amount / Q to quit)\n");
    while (scanf(" %c", &type) == 1 && type != 'Q') {
        if (scanf("%lf", &amount) != 1 || amount <= 0) {
            printf("Invalid amount\n");
            break;
        }
        if (type == 'D') {
            acc.balance += amount;
            printf("Deposited %.2f  -> balance %.2f\n", amount, acc.balance);
        } else if (type == 'W') {
            if (amount > acc.balance)
                printf("Withdraw %.2f refused: insufficient funds\n", amount);
            else {
                acc.balance -= amount;
                printf("Withdrew  %.2f  -> balance %.2f\n", amount, acc.balance);
            }
        } else {
            printf("Unknown transaction '%c'\n", type);
        }
    }
    printf("Final balance: %.2f\n", acc.balance);
    return 0;
}
''', "D 500\nW 200\nW 5000\nD 75.50\nQ")

add(929, r'''
#include <stdio.h>

struct Student {
    int roll;
    char name[20];
    float marks;
};

int main(void)
{
    struct Student list[4] = {
        {1, "Arun", 78.5f},
        {2, "Bela", 91.0f},
        {3, "Chitra", 66.25f},
        {4, "Dev", 84.75f}
    };
    printf("%-6s %-10s %7s\n", "Roll", "Name", "Marks");
    printf("-----------------------------\n");
    for (int i = 0; i < 4; i++)
        printf("%-6d %-10s %7.2f\n", list[i].roll, list[i].name, list[i].marks);
    return 0;
}
''')

add(930, r'''
#include <stdio.h>
#include <string.h>

struct Point3 {
    int x, y, z;
    char label[10];
};

int main(void)
{
    struct Point3 a = {1, 2, 3, "origin"};
    struct Point3 b, c;

    b = a;                               /* whole-structure assignment */

    c.x = a.x;                           /* field by field copy */
    c.y = a.y;
    c.z = a.z;
    strcpy(c.label, a.label);            /* arrays need strcpy here */

    b.x = 99;                            /* copies are independent */
    printf("a: %d %d %d %s\n", a.x, a.y, a.z, a.label);
    printf("b: %d %d %d %s (changed x)\n", b.x, b.y, b.z, b.label);
    printf("c: %d %d %d %s\n", c.x, c.y, c.z, c.label);
    printf("a and c equal? %s\n", memcmp(&a.x, &c.x, 3 * sizeof(int)) == 0 ? "yes" : "no");
    return 0;
}
''')

add(931, r'''
#include <stdio.h>

#define SUBJECTS 4

struct Student {
    char name[20];
    char subject[SUBJECTS][12];
    int marks[SUBJECTS];
    int total;
    double percent;
};

int main(void)
{
    struct Student s = {"Nisha", {"Maths", "Physics", "Chemistry", "English"}, {0}, 0, 0};
    printf("Enter marks for %s\n", s.name);
    for (int i = 0; i < SUBJECTS; i++) {
        printf("  %-10s: ", s.subject[i]);
        scanf("%d", &s.marks[i]);
        s.total += s.marks[i];
    }
    s.percent = s.total * 100.0 / (SUBJECTS * 100);
    printf("\nTotal      : %d / %d\n", s.total, SUBJECTS * 100);
    printf("Percentage : %.2f%%\n", s.percent);
    printf("Result     : %s\n", s.percent >= 40 ? "Pass" : "Fail");
    return 0;
}
''', "88 76 91 69")

add(932, r'''
#include <stdio.h>

enum Kind { INT_VALUE, FLOAT_VALUE, CHAR_VALUE };

struct Tagged {
    enum Kind kind;                      /* tag says which member is valid */
    union {
        int i;
        float f;
        char c;
    } u;
};

void show(struct Tagged t)
{
    switch (t.kind) {
    case INT_VALUE:   printf("int   : %d\n", t.u.i); break;
    case FLOAT_VALUE: printf("float : %.2f\n", t.u.f); break;
    case CHAR_VALUE:  printf("char  : %c\n", t.u.c); break;
    }
}

int main(void)
{
    struct Tagged v[3];
    v[0].kind = INT_VALUE;   v[0].u.i = 42;
    v[1].kind = FLOAT_VALUE; v[1].u.f = 3.14f;
    v[2].kind = CHAR_VALUE;  v[2].u.c = 'Z';
    for (int i = 0; i < 3; i++)
        show(v[i]);
    printf("sizeof(union) = %zu (size of its largest member)\n", sizeof v[0].u);
    return 0;
}
''')

add(933, r'''
#include <stdio.h>

enum Option { EXIT, ADD, SUBTRACT, MULTIPLY };

int main(void)
{
    int choice, a, b;
    do {
        printf("\n%d. Add\n%d. Subtract\n%d. Multiply\n%d. Exit\nChoice: ",
               ADD, SUBTRACT, MULTIPLY, EXIT);
        if (scanf("%d", &choice) != 1)
            break;
        switch ((enum Option)choice) {
        case ADD:
            scanf("%d %d", &a, &b);
            printf("%d + %d = %d\n", a, b, a + b);
            break;
        case SUBTRACT:
            scanf("%d %d", &a, &b);
            printf("%d - %d = %d\n", a, b, a - b);
            break;
        case MULTIPLY:
            scanf("%d %d", &a, &b);
            printf("%d * %d = %d\n", a, b, a * b);
            break;
        case EXIT:
            printf("Bye\n");
            break;
        default:
            printf("Invalid choice\n");
        }
    } while (choice != EXIT);
    return 0;
}
''', "1\n8 5\n2\n8 5\n3\n8 5\n7\n0")

add(934, r'''
#include <stdio.h>

struct Student {
    int roll;
    char name[15];
    char city[15];
    int marks;
};

int main(void)
{
    struct Student s[5] = {
        {1, "Anil", "Pune", 72},
        {2, "Bhavna", "Delhi", 91},
        {3, "Chetan", "Pune", 58},
        {4, "Divya", "Mumbai", 84},
        {5, "Esha", "Pune", 96}
    };
    int limit;
    printf("Show students from Pune with marks at least: ");
    scanf("%d", &limit);
    printf("%-5s %-10s %-8s %5s\n", "Roll", "Name", "City", "Marks");
    int found = 0;
    for (int i = 0; i < 5; i++) {
        if (s[i].marks >= limit && s[i].city[0] == 'P') {
            printf("%-5d %-10s %-8s %5d\n", s[i].roll, s[i].name, s[i].city, s[i].marks);
            found++;
        }
    }
    printf("%d record(s) matched\n", found);
    return 0;
}
''', "70")

add(935, r'''
#include <stdio.h>

struct Date {
    int day, month, year;
};

struct Address {
    char street[30];
    char city[20];
    int pin;
};

struct Person {
    char name[20];
    struct Date dob;                     /* nested structure */
    struct Address addr;                 /* nested structure */
};

int main(void)
{
    struct Person p = {"Rahul Verma", {14, 8, 1999}, {"12 MG Road", "Bengaluru", 560001}};
    printf("Name    : %s\n", p.name);
    printf("DOB     : %02d/%02d/%d\n", p.dob.day, p.dob.month, p.dob.year);
    printf("Address : %s, %s - %d\n", p.addr.street, p.addr.city, p.addr.pin);
    return 0;
}
''')

add(936, r'''
#include <stdio.h>

struct Student {
    int roll;
    char name[30];
    float marks;
};

int main(void)
{
    struct Student s;
    printf("Enter roll number: ");
    scanf("%d", &s.roll);
    printf("Enter first name: ");
    scanf("%29s", s.name);
    printf("Enter marks: ");
    scanf("%f", &s.marks);

    printf("\n--- Student Details ---\n");
    printf("Roll  : %d\n", s.roll);
    printf("Name  : %s\n", s.name);
    printf("Marks : %.1f\n", s.marks);
    return 0;
}
''', "17\nSneha\n86.5")

add(937, r'''
#include <stdio.h>

#define MAX 20

struct Student {
    int roll;
    char name[20];
    float marks;
};

void read_students(struct Student s[], int n)
{
    for (int i = 0; i < n; i++) {
        printf("Student %d (roll name marks): ", i + 1);
        scanf("%d %19s %f", &s[i].roll, s[i].name, &s[i].marks);
    }
}

void print_students(const struct Student s[], int n)
{
    printf("\n%-6s %-12s %6s\n", "Roll", "Name", "Marks");
    for (int i = 0; i < n; i++)
        printf("%-6d %-12s %6.1f\n", s[i].roll, s[i].name, s[i].marks);
}

int main(void)
{
    struct Student s[MAX];
    int n;
    printf("How many students (1-%d)? ", MAX);
    if (scanf("%d", &n) != 1 || n < 1 || n > MAX) {
        printf("Invalid number\n");
        return 1;
    }
    read_students(s, n);
    print_students(s, n);
    return 0;
}
''', "3\n1 Amit 78\n2 Bina 92.5\n3 Carl 64")

add(938, r'''
#include <stdio.h>

struct Student {
    char name[20];
    int marks[3];
    int total;
    float average;
};

int main(void)
{
    struct Student s;
    printf("Enter name: ");
    if (scanf("%19s", s.name) != 1) {
        printf("Error: name not read.\n");
        return 1;
    }
    s.total = 0;
    for (int i = 0; i < 3; i++) {
        printf("Enter marks of subject %d (0-100): ", i + 1);
        if (scanf("%d", &s.marks[i]) != 1) {
            printf("Error: marks must be a number.\n");
            return 1;
        }
        if (s.marks[i] < 0 || s.marks[i] > 100) {
            printf("Error: %d is outside the range 0-100.\n", s.marks[i]);
            return 1;
        }
        s.total += s.marks[i];
    }
    s.average = s.total / 3.0f;
    printf("\nStudent : %s\nTotal   : %d\nAverage : %.2f\n", s.name, s.total, s.average);
    return 0;
}
''', "Tanvi\n81\n67\n94")

add(939, r'''
#include <stdio.h>

struct Student {
    char name[20];
    int marks;
};

/* Handle one test case: read n records and report the topper */
void find_top(int test)
{
    int n;
    scanf("%d", &n);
    struct Student best = {"", -1};
    for (int i = 0; i < n; i++) {
        struct Student s;
        scanf("%19s %d", s.name, &s.marks);
        if (s.marks > best.marks)
            best = s;
    }
    printf("Test %d: highest is %s with %d marks\n", test, best.name, best.marks);
}

int main(void)
{
    for (int t = 1; t <= 3; t++)
        find_top(t);
    return 0;
}
''', "4\nAsha 67 Binod 88 Cyrus 74 Dolly 59\n1\nEkta 45\n3\nFarid 90 Gita 90 Hari 12")

add(940, r'''
#include <stdio.h>

struct Student {
    int roll;
    char name[15];
};

int main(void)
{
    struct Student s[5] = {
        {42, "Kavya"}, {7, "Omar"}, {19, "Lena"}, {3, "Ivan"}, {25, "Zara"}
    };
    int n = 5;

    printf("Before sorting:\n");
    for (int i = 0; i < n; i++)
        printf("  %2d %s\n", s[i].roll, s[i].name);

    /* Bubble sort: repeatedly swap neighbours that are out of order */
    for (int pass = 0; pass < n - 1; pass++) {
        for (int j = 0; j < n - 1 - pass; j++) {
            if (s[j].roll > s[j + 1].roll) {
                struct Student tmp = s[j];       /* swap whole records */
                s[j] = s[j + 1];
                s[j + 1] = tmp;
            }
        }
    }

    printf("After sorting by roll number:\n");
    for (int i = 0; i < n; i++)
        printf("  %2d %s\n", s[i].roll, s[i].name);
    return 0;
}
''')

add(941, r'''
#include <stdio.h>
#include <string.h>

struct Student {
    int roll;
    char name[20];
    int marks;
};

/* Return index of the student with this name, or -1 */
int find(const struct Student s[], int n, const char *name)
{
    for (int i = 0; i < n; i++)
        if (strcmp(s[i].name, name) == 0)
            return i;
    return -1;
}

int main(void)
{
    struct Student s[4] = {
        {1, "Alice", 80}, {2, "Bob", 65}, {3, "Charlie", 92}, {4, "Diana", 71}
    };
    char key[20];
    for (int q = 0; q < 4; q++) {
        if (scanf("%19s", key) != 1)
            break;
        int idx = find(s, 4, key);
        if (idx < 0)
            printf("'%s' not found\n", key);
        else
            printf("Found %s: roll %d, marks %d\n", s[idx].name, s[idx].roll, s[idx].marks);
    }
    return 0;
}
''', "Alice\nDiana\nbob\nEve")

add(942, r'''
#include <stdio.h>

struct Date {
    int day, month, year;
};

int main(void)
{
    const char *months[12] = {"January", "February", "March", "April", "May", "June",
                              "July", "August", "September", "October", "November", "December"};
    struct Date d;
    printf("Enter date (dd mm yyyy): ");
    if (scanf("%d %d %d", &d.day, &d.month, &d.year) != 3 ||
        d.month < 1 || d.month > 12 || d.day < 1 || d.day > 31) {
        printf("Invalid date\n");
        return 1;
    }
    int choice;
    do {
        printf("\n1. dd/mm/yyyy\n2. Long format\n3. yyyy-mm-dd\n4. Exit\nChoice: ");
        if (scanf("%d", &choice) != 1)
            break;
        if (choice == 1)
            printf("%02d/%02d/%04d\n", d.day, d.month, d.year);
        else if (choice == 2)
            printf("%d %s %d\n", d.day, months[d.month - 1], d.year);
        else if (choice == 3)
            printf("%04d-%02d-%02d\n", d.year, d.month, d.day);
    } while (choice != 4);
    return 0;
}
''', "5 11 2024\n1\n2\n3\n4")

add(943, r'''
#include <stdio.h>

struct Date {
    int day, month, year;
};

/* Turn a date into a single comparable number */
long key(struct Date d)
{
    return d.year * 10000L + d.month * 100L + d.day;
}

int main(void)
{
    struct Date a, b;
    printf("Enter first date (d m y): ");
    scanf("%d %d %d", &a.day, &a.month, &a.year);
    printf("Enter second date (d m y): ");
    scanf("%d %d %d", &b.day, &b.month, &b.year);

    printf("Key of first date  = %ld\n", key(a));
    printf("Key of second date = %ld\n", key(b));
    if (key(a) == key(b))
        printf("Both dates are equal\n");
    else if (key(a) < key(b))
        printf("%02d/%02d/%d is earlier\n", a.day, a.month, a.year);
    else
        printf("%02d/%02d/%d is earlier\n", b.day, b.month, b.year);
    return 0;
}
''', "25 12 2023\n3 1 2024")

add(944, r'''
#include <stdio.h>

struct Complex {
    double re, im;
};

int main(void)
{
    int pairs;
    printf("Number of additions: ");
    if (scanf("%d", &pairs) != 1 || pairs <= 0)
        return 1;
    for (int i = 1; i <= pairs; i++) {
        struct Complex a, b, sum;
        printf("Pair %d (re1 im1 re2 im2): ", i);
        scanf("%lf %lf %lf %lf", &a.re, &a.im, &b.re, &b.im);
        sum.re = a.re + b.re;
        sum.im = a.im + b.im;
        printf("  (%.1f%+.1fi) + (%.1f%+.1fi) = %.1f%+.1fi\n",
               a.re, a.im, b.re, b.im, sum.re, sum.im);
    }
    return 0;
}
''', "3\n1 2 3 4\n-5 0.5 2 -2.5\n0 0 7 7")

add(945, r'''
#include <stdio.h>

struct Complex {
    double re, im;
};

/* (a+bi)(c+di) = (ac-bd) + (ad+bc)i, result stored through pointer */
void multiply(const struct Complex *x, const struct Complex *y, struct Complex *out)
{
    out->re = x->re * y->re - x->im * y->im;
    out->im = x->re * y->im + x->im * y->re;
}

int main(void)
{
    struct Complex a, b, prod;
    printf("Enter first complex number (re im): ");
    scanf("%lf %lf", &a.re, &a.im);
    printf("Enter second complex number (re im): ");
    scanf("%lf %lf", &b.re, &b.im);
    multiply(&a, &b, &prod);
    printf("(%.1f%+.1fi) * (%.1f%+.1fi) = %.1f%+.1fi\n",
           a.re, a.im, b.re, b.im, prod.re, prod.im);
    return 0;
}
''', "3 2\n1 -4")

add(946, r'''
#include <stdio.h>

struct Book {
    int id;
    char title[30];
    char author[20];
    float price;
    int available;
};

int main(void)
{
    struct Book lib[4] = {
        {1, "The C Programming Lang", "Kernighan", 45.50f, 1},
        {2, "Let Us C", "Kanetkar", 22.00f, 0},
        {3, "C Primer Plus", "Prata", 39.99f, 1},
        {4, "Expert C Programming", "van der Linden", 31.25f, 1}
    };
    printf("%-3s %-26s %-15s %7s %s\n", "ID", "Title", "Author", "Price", "Status");
    printf("--------------------------------------------------------------------\n");
    for (int i = 0; i < 4; i++)
        printf("%-3d %-26s %-15s %7.2f %s\n", lib[i].id, lib[i].title, lib[i].author,
               lib[i].price, lib[i].available ? "In" : "Issued");
    return 0;
}
''')

add(947, r'''
#include <stdio.h>

struct Employee {
    int id;
    char name[20];
    double monthly;
    double bonus;
    double annual;
};

int main(void)
{
    struct Employee e;
    printf("Enter id, name, monthly salary, yearly bonus: ");
    if (scanf("%d %19s %lf %lf", &e.id, e.name, &e.monthly, &e.bonus) != 4) {
        printf("Invalid input\n");
        return 1;
    }
    e.annual = e.monthly * 12 + e.bonus;
    printf("\nEmployee ID    : %d\n", e.id);
    printf("Name           : %s\n", e.name);
    printf("Monthly salary : %.2f\n", e.monthly);
    printf("Annual salary  : %.2f (incl. bonus %.2f)\n", e.annual, e.bonus);
    return 0;
}
''', "204 Rohan 42500 15000")

add(948, r'''
#include <stdio.h>

struct Address {
    char house[10];
    char city[15];
    int pin;
};

struct Customer {
    char name[20];
    struct Address addr;
};

int main(void)
{
    struct Customer c[3] = {
        {"Meera", {"A-12", "Jaipur", 302001}},
        {"Naveen", {"7/B", "Chennai", 600028}},
        {"Olivia", {"221", "Kolkata", 700019}}
    };
    printf("%-8s | %-6s | %-8s | %s\n", "Name", "House", "City", "PIN");
    printf("---------+--------+----------+-------\n");
    for (int i = 0; i < 3; i++)
        printf("%-8s | %-6s | %-8s | %d\n", c[i].name, c[i].addr.house, c[i].addr.city,
               c[i].addr.pin);
    return 0;
}
''')

add(949, r'''
#include <stdio.h>

struct Rectangle {
    double length, width;
};

/* Receives a COPY of the structure; changes do not affect the caller */
double area(struct Rectangle r)
{
    double a = r.length * r.width;
    r.length = 0;                        /* modifies only the copy */
    return a;
}

int main(void)
{
    struct Rectangle rect = {12.5, 4.0};
    printf("Before call : length = %.1f, width = %.1f\n", rect.length, rect.width);
    double a = area(rect);
    printf("Area        : %.2f\n", a);
    printf("After call  : length = %.1f, width = %.1f (unchanged)\n", rect.length, rect.width);
    return 0;
}
''')

add(950, r'''
#include <stdio.h>

struct Product {
    char name[20];
    int stock;
    double price;
};

/* Apply a percentage discount through a pointer; returns 0 if invalid */
int discount(struct Product *p, double percent)
{
    if (p == NULL || percent < 0 || percent > 100)
        return 0;
    p->price -= p->price * percent / 100.0;
    return 1;
}

int main(void)
{
    struct Product item = {"Headphones", 25, 1999.00};
    double pct;
    printf("%s: price %.2f, stock %d\n", item.name, item.price, item.stock);
    printf("Enter discount percent (0-100): ");
    if (scanf("%lf", &pct) != 1) {
        printf("Error: not a number\n");
        return 1;
    }
    if (!discount(&item, pct)) {
        printf("Error: discount must be between 0 and 100\n");
        return 1;
    }
    printf("New price after %.1f%% off: %.2f\n", pct, item.price);
    return 0;
}
''', "15")
