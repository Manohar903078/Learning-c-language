# programs 651-700 : id -> (stdin, code)
P = {}
def add(i, code, stdin=""): P[i] = (stdin, code.strip("\n"))

add(651, r'''
#include <stdio.h>

int main(void)
{
    char word[50];

    printf("Enter a word: ");
    if (scanf("%49s", word) != 1) {
        printf("No input received.\n");
        return 1;
    }
    printf("You entered: %s\n", word);
    return 0;
}
''', "Programming")

add(652, r'''
#include <stdio.h>

int main(void)
{
    char text[100];
    int length = 0;

    printf("Enter a line of text: ");
    if (fgets(text, sizeof text, stdin) == NULL)
        return 1;

    /* count characters until newline or end of string */
    while (text[length] != '\0' && text[length] != '\n')
        length++;

    printf("Length of the string = %d\n", length);
    return 0;
}
''', "Hello, World\n")

add(653, r'''
#include <stdio.h>

int main(void)
{
    char source[100], target[100];
    int i = 0;

    printf("Enter a string: ");
    if (fgets(source, sizeof source, stdin) == NULL)
        return 1;

    /* copy each character, stopping at newline */
    while (source[i] != '\0' && source[i] != '\n') {
        target[i] = source[i];
        i++;
    }
    target[i] = '\0';

    printf("Source: %s", source);
    printf("Copied: %s\n", target);
    return 0;
}
''', "Learning C is fun\n")

add(654, r'''
#include <stdio.h>

int main(void)
{
    char first[50], second[50], result[100];
    int i = 0, j = 0;

    printf("Enter first string : ");
    if (scanf("%49s", first) != 1) return 1;
    printf("Enter second string: ");
    if (scanf("%49s", second) != 1) return 1;

    while (first[i] != '\0') {       /* copy the first string */
        result[i] = first[i];
        i++;
    }
    while (second[j] != '\0') {      /* append the second string */
        result[i + j] = second[j];
        j++;
    }
    result[i + j] = '\0';

    printf("Concatenated string: %s\n", result);
    return 0;
}
''', "Good Morning")

add(655, r'''
#include <stdio.h>

int main(void)
{
    char a[50], b[50];
    int i = 0;

    printf("Enter first string : ");
    if (scanf("%49s", a) != 1) return 1;
    printf("Enter second string: ");
    if (scanf("%49s", b) != 1) return 1;

    /* move forward while characters match */
    while (a[i] != '\0' && a[i] == b[i])
        i++;

    if (a[i] == b[i])
        printf("The strings are equal.\n");
    else if (a[i] < b[i])
        printf("\"%s\" comes before \"%s\".\n", a, b);
    else
        printf("\"%s\" comes after \"%s\".\n", a, b);
    return 0;
}
''', "apple apricot")

add(656, r'''
#include <stdio.h>

int main(void)
{
    char text[100];
    int len = 0, i;

    printf("Enter a string: ");
    if (scanf("%99s", text) != 1) return 1;

    while (text[len] != '\0')
        len++;

    printf("Reversed string: ");
    for (i = len - 1; i >= 0; i--)
        putchar(text[i]);
    printf("\n");
    return 0;
}
''', "computer")

add(657, r'''
#include <stdio.h>

int main(void)
{
    char text[100];
    int len = 0, i, isPalindrome = 1;

    printf("Enter a string: ");
    if (scanf("%99s", text) != 1) return 1;

    while (text[len] != '\0')
        len++;

    /* compare characters from both ends */
    for (i = 0; i < len / 2; i++) {
        if (text[i] != text[len - 1 - i]) {
            isPalindrome = 0;
            break;
        }
    }

    if (isPalindrome)
        printf("\"%s\" is a palindrome.\n", text);
    else
        printf("\"%s\" is not a palindrome.\n", text);
    return 0;
}
''', "madam")

add(658, r'''
#include <stdio.h>
#include <ctype.h>

int main(void)
{
    char text[200];
    int vowels = 0, consonants = 0, i;

    printf("Enter a string: ");
    if (fgets(text, sizeof text, stdin) == NULL) return 1;

    for (i = 0; text[i] != '\0'; i++) {
        char ch = (char)tolower((unsigned char)text[i]);
        if (ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u')
            vowels++;
        else if (ch >= 'a' && ch <= 'z')
            consonants++;
    }

    printf("Vowels     : %d\n", vowels);
    printf("Consonants : %d\n", consonants);
    return 0;
}
''', "Programming in C is Fun\n")

add(659, r'''
#include <stdio.h>

int main(void)
{
    char text[200];
    int upper = 0, lower = 0, i;

    printf("Enter a string: ");
    if (fgets(text, sizeof text, stdin) == NULL) return 1;

    for (i = 0; text[i] != '\0'; i++) {
        if (text[i] >= 'A' && text[i] <= 'Z')
            upper++;
        else if (text[i] >= 'a' && text[i] <= 'z')
            lower++;
    }

    printf("Uppercase letters: %d\n", upper);
    printf("Lowercase letters: %d\n", lower);
    return 0;
}
''', "Welcome To The World Of C\n")

add(660, r'''
#include <stdio.h>
#include <ctype.h>

int main(void)
{
    char text[200];
    int letters = 0, digits = 0, spaces = 0, symbols = 0, i;

    printf("Enter a string: ");
    if (fgets(text, sizeof text, stdin) == NULL) return 1;

    for (i = 0; text[i] != '\0' && text[i] != '\n'; i++) {
        unsigned char ch = (unsigned char)text[i];
        if (isalpha(ch))      letters++;
        else if (isdigit(ch)) digits++;
        else if (ch == ' ')   spaces++;
        else                  symbols++;
    }

    printf("Letters : %d\n", letters);
    printf("Digits  : %d\n", digits);
    printf("Spaces  : %d\n", spaces);
    printf("Symbols : %d\n", symbols);
    return 0;
}
''', "Room 101 costs $45 #best!\n")

add(661, r'''
#include <stdio.h>

int main(void)
{
    char text[300];
    int words = 0, inWord = 0, i;

    printf("Enter a sentence: ");
    if (fgets(text, sizeof text, stdin) == NULL) return 1;

    for (i = 0; text[i] != '\0'; i++) {
        if (text[i] == ' ' || text[i] == '\t' || text[i] == '\n')
            inWord = 0;
        else if (!inWord) {      /* start of a new word */
            inWord = 1;
            words++;
        }
    }

    printf("Number of words = %d\n", words);
    return 0;
}
''', "  C is   a powerful programming language \n")

add(662, r'''
#include <stdio.h>
#include <string.h>

int main(void)
{
    char line[200];
    int count = 0;

    printf("Enter lines of text (type END to stop):\n");
    while (fgets(line, sizeof line, stdin) != NULL) {
        line[strcspn(line, "\n")] = '\0';
        if (strcmp(line, "END") == 0)   /* sentinel found */
            break;
        count++;
    }

    printf("Number of lines entered = %d\n", count);
    return 0;
}
''', "first line\nsecond line\n\nfourth line after a blank\nEND\nignored\n")

add(663, r'''
#include <stdio.h>

int main(void)
{
    char text[200];
    int i;

    printf("Enter a string: ");
    if (fgets(text, sizeof text, stdin) == NULL) return 1;

    for (i = 0; text[i] != '\0'; i++)
        if (text[i] >= 'a' && text[i] <= 'z')
            text[i] = text[i] - 'a' + 'A';   /* shift to uppercase */

    printf("Uppercase: %s", text);
    return 0;
}
''', "hello world 2024\n")

add(664, r'''
#include <stdio.h>

int main(void)
{
    char text[200];
    int i;

    printf("Enter a string: ");
    if (fgets(text, sizeof text, stdin) == NULL) return 1;

    for (i = 0; text[i] != '\0'; i++)
        if (text[i] >= 'A' && text[i] <= 'Z')
            text[i] = text[i] - 'A' + 'a';   /* shift to lowercase */

    printf("Lowercase: %s", text);
    return 0;
}
''', "THE QUICK Brown FOX\n")

add(665, r'''
#include <stdio.h>

int main(void)
{
    char text[200];
    int i;

    printf("Enter a string: ");
    if (fgets(text, sizeof text, stdin) == NULL) return 1;

    for (i = 0; text[i] != '\0'; i++) {
        if (text[i] >= 'a' && text[i] <= 'z')
            text[i] -= 32;
        else if (text[i] >= 'A' && text[i] <= 'Z')
            text[i] += 32;
    }

    printf("Toggled  : %s", text);
    return 0;
}
''', "Hello World ABC xyz\n")

add(666, r'''
#include <stdio.h>

int main(void)
{
    char text[200];
    int freq[256] = {0};
    int i;

    printf("Enter a string: ");
    if (fgets(text, sizeof text, stdin) == NULL) return 1;

    for (i = 0; text[i] != '\0' && text[i] != '\n'; i++)
        freq[(unsigned char)text[i]]++;

    printf("Character frequencies:\n");
    for (i = 0; i < 256; i++)
        if (freq[i] > 0)
            printf("'%c' : %d\n", i, freq[i]);
    return 0;
}
''', "banana\n")

add(667, r'''
#include <stdio.h>

int main(void)
{
    char text[100];
    int i, j, found = 0;

    printf("Enter a string: ");
    if (scanf("%99s", text) != 1) return 1;

    for (i = 0; text[i] != '\0'; i++) {
        int repeated = 0;
        for (j = 0; text[j] != '\0'; j++)
            if (i != j && text[i] == text[j]) {
                repeated = 1;
                break;
            }
        if (!repeated) {
            printf("First non-repeating character: %c\n", text[i]);
            found = 1;
            break;
        }
    }
    if (!found)
        printf("Every character repeats.\n");
    return 0;
}
''', "swiss")

add(668, r'''
#include <stdio.h>

int main(void)
{
    char text[100];
    int i, j, found = 0;

    printf("Enter a string: ");
    if (scanf("%99s", text) != 1) return 1;

    /* the first character that has appeared before */
    for (i = 1; text[i] != '\0' && !found; i++)
        for (j = 0; j < i; j++)
            if (text[i] == text[j]) {
                printf("First repeating character: %c\n", text[i]);
                found = 1;
                break;
            }
    if (!found)
        printf("No repeating character found.\n");
    return 0;
}
''', "programming")

add(669, r'''
#include <stdio.h>

int main(void)
{
    char text[200], result[200];
    int i, k = 0;

    printf("Enter a string: ");
    if (fgets(text, sizeof text, stdin) == NULL) return 1;

    for (i = 0; text[i] != '\0' && text[i] != '\n'; i++)
        if (text[i] != ' ')
            result[k++] = text[i];
    result[k] = '\0';

    printf("Without spaces: %s\n", result);
    return 0;
}
''', "C is a fun language\n")

add(670, r'''
#include <stdio.h>
#include <ctype.h>

int main(void)
{
    char text[200], result[200];
    int i, k = 0;

    printf("Enter a string: ");
    if (fgets(text, sizeof text, stdin) == NULL) return 1;

    for (i = 0; text[i] != '\0' && text[i] != '\n'; i++) {
        char ch = (char)tolower((unsigned char)text[i]);
        if (ch != 'a' && ch != 'e' && ch != 'i' && ch != 'o' && ch != 'u')
            result[k++] = text[i];
    }
    result[k] = '\0';

    printf("Without vowels: %s\n", result);
    return 0;
}
''', "Education is Important\n")

add(671, r'''
#include <stdio.h>

int main(void)
{
    char text[100], result[100];
    int i, j, k = 0;

    printf("Enter a string: ");
    if (scanf("%99s", text) != 1) return 1;

    for (i = 0; text[i] != '\0'; i++) {
        int seen = 0;
        for (j = 0; j < k; j++)
            if (result[j] == text[i]) {
                seen = 1;
                break;
            }
        if (!seen)
            result[k++] = text[i];   /* keep only the first occurrence */
    }
    result[k] = '\0';

    printf("After removing duplicates: %s\n", result);
    return 0;
}
''', "mississippi")

add(672, r'''
#include <stdio.h>

int main(void)
{
    char text[200];
    int i;

    printf("Enter a sentence: ");
    if (fgets(text, sizeof text, stdin) == NULL) return 1;

    for (i = 0; text[i] != '\0'; i++)
        if (text[i] == ' ')
            text[i] = '-';

    printf("Result: %s", text);
    return 0;
}
''', "learn C step by step\n")

add(673, r'''
#include <stdio.h>

int main(void)
{
    char text[200], oldCh, newCh;
    int i, count = 0;

    printf("Enter a string: ");
    if (fgets(text, sizeof text, stdin) == NULL) return 1;
    printf("Enter character to replace: ");
    if (scanf(" %c", &oldCh) != 1) return 1;
    printf("Enter new character: ");
    if (scanf(" %c", &newCh) != 1) return 1;

    for (i = 0; text[i] != '\0'; i++)
        if (text[i] == oldCh) {
            text[i] = newCh;
            count++;
        }

    printf("Replaced %d occurrence(s).\n", count);
    printf("New string: %s", text);
    return 0;
}
''', "banana bread\na\no\n")

add(674, r'''
#include <stdio.h>

int main(void)
{
    char text[200], sub[50];
    int i, j, pos = -1;

    printf("Enter the main string: ");
    if (fgets(text, sizeof text, stdin) == NULL) return 1;
    printf("Enter the substring  : ");
    if (scanf("%49s", sub) != 1) return 1;

    for (i = 0; text[i] != '\0' && pos < 0; i++) {
        for (j = 0; sub[j] != '\0' && text[i + j] == sub[j]; j++)
            ;
        if (sub[j] == '\0')       /* whole substring matched */
            pos = i;
    }

    if (pos >= 0)
        printf("Substring found at index %d.\n", pos);
    else
        printf("Substring not found.\n");
    return 0;
}
''', "the quick brown fox jumps\nbrown\n")

add(675, r'''
#include <stdio.h>

int main(void)
{
    char text[200], sub[50];
    int i, j, count = 0;

    printf("Enter the main string: ");
    if (fgets(text, sizeof text, stdin) == NULL) return 1;
    printf("Enter the substring  : ");
    if (scanf("%49s", sub) != 1) return 1;

    for (i = 0; text[i] != '\0'; i++) {
        for (j = 0; sub[j] != '\0' && text[i + j] == sub[j]; j++)
            ;
        if (sub[j] == '\0')
            count++;
    }

    printf("\"%s\" occurs %d time(s).\n", sub, count);
    return 0;
}
''', "abababa and ababa\naba\n")

add(676, r'''
#include <stdio.h>
#include <ctype.h>

int main(void)
{
    char a[100], b[100];
    int count[26] = {0};
    int i, anagram = 1;

    printf("Enter first string : ");
    if (scanf("%99s", a) != 1) return 1;
    printf("Enter second string: ");
    if (scanf("%99s", b) != 1) return 1;

    for (i = 0; a[i] != '\0'; i++)
        if (isalpha((unsigned char)a[i]))
            count[tolower((unsigned char)a[i]) - 'a']++;
    for (i = 0; b[i] != '\0'; i++)
        if (isalpha((unsigned char)b[i]))
            count[tolower((unsigned char)b[i]) - 'a']--;

    for (i = 0; i < 26; i++)
        if (count[i] != 0)
            anagram = 0;

    printf("\"%s\" and \"%s\" %s anagrams.\n", a, b, anagram ? "are" : "are not");
    return 0;
}
''', "Listen Silent")

add(677, r'''
#include <stdio.h>

int main(void)
{
    char a[100], b[100];
    int la = 0, lb = 0, shift, i, rotation = 0;

    printf("Enter first string : ");
    if (scanf("%99s", a) != 1) return 1;
    printf("Enter second string: ");
    if (scanf("%99s", b) != 1) return 1;

    while (a[la] != '\0') la++;
    while (b[lb] != '\0') lb++;

    if (la == lb) {
        /* try every rotation of a and compare with b */
        for (shift = 0; shift < la && !rotation; shift++) {
            rotation = 1;
            for (i = 0; i < la; i++)
                if (a[(i + shift) % la] != b[i]) {
                    rotation = 0;
                    break;
                }
        }
    }

    printf("The strings %s rotations of each other.\n", rotation ? "are" : "are not");
    return 0;
}
''', "waterbottle erbottlewat")

add(678, r'''
#include <stdio.h>

int main(void)
{
    char text[100], temp;
    int len = 0, i, j;

    printf("Enter a string: ");
    if (scanf("%99s", text) != 1) return 1;

    while (text[len] != '\0')
        len++;

    /* simple bubble sort on characters */
    for (i = 0; i < len - 1; i++)
        for (j = 0; j < len - 1 - i; j++)
            if (text[j] > text[j + 1]) {
                temp = text[j];
                text[j] = text[j + 1];
                text[j + 1] = temp;
            }

    printf("Sorted characters: %s\n", text);
    return 0;
}
''', "programming")

add(679, r'''
#include <stdio.h>
#include <string.h>

#define MAXW 20

int main(void)
{
    char words[MAXW][30], temp[30];
    int n = 0, i, j;

    printf("Enter a sentence: ");
    while (n < MAXW && scanf("%29s", words[n]) == 1) {
        n++;
        if (getchar() == '\n')   /* stop at end of the line */
            break;
    }

    for (i = 0; i < n - 1; i++)
        for (j = 0; j < n - 1 - i; j++)
            if (strcmp(words[j], words[j + 1]) > 0) {
                strcpy(temp, words[j]);
                strcpy(words[j], words[j + 1]);
                strcpy(words[j + 1], temp);
            }

    printf("Words in alphabetical order:\n");
    for (i = 0; i < n; i++)
        printf("%s ", words[i]);
    printf("\n");
    return 0;
}
''', "pear apple mango banana cherry\n")

add(680, r'''
#include <stdio.h>

int main(void)
{
    char text[300], longest[50] = "", current[50];
    int i, len = 0, maxLen = 0, k;

    printf("Enter a sentence: ");
    if (fgets(text, sizeof text, stdin) == NULL) return 1;

    for (i = 0; ; i++) {
        char ch = text[i];
        if (ch != ' ' && ch != '\n' && ch != '\0' && len < 49) {
            current[len++] = ch;
        } else {
            if (len > maxLen) {
                maxLen = len;
                for (k = 0; k < len; k++)
                    longest[k] = current[k];
                longest[len] = '\0';
            }
            len = 0;
            if (ch == '\0')
                break;
        }
    }

    printf("Longest word: %s (%d letters)\n", longest, maxLen);
    return 0;
}
''', "Programming makes learning computers exciting\n")

add(681, r'''
#include <stdio.h>

int main(void)
{
    char text[300], shortest[50] = "", current[50];
    int i, len = 0, minLen = 0, k;

    printf("Enter a sentence: ");
    if (fgets(text, sizeof text, stdin) == NULL) return 1;

    for (i = 0; ; i++) {
        char ch = text[i];
        if (ch != ' ' && ch != '\n' && ch != '\0' && len < 49) {
            current[len++] = ch;
        } else {
            if (len > 0 && (minLen == 0 || len < minLen)) {
                minLen = len;
                for (k = 0; k < len; k++)
                    shortest[k] = current[k];
                shortest[len] = '\0';
            }
            len = 0;
            if (ch == '\0')
                break;
        }
    }

    if (minLen == 0)
        printf("No words found.\n");
    else
        printf("Shortest word: %s (%d letters)\n", shortest, minLen);
    return 0;
}
''', "Learning C is a great skill\n")

add(682, r'''
#include <stdio.h>

int main(void)
{
    char text[300];
    int i, newWord = 1;

    printf("Enter a sentence: ");
    if (fgets(text, sizeof text, stdin) == NULL) return 1;

    for (i = 0; text[i] != '\0'; i++) {
        if (text[i] == ' ') {
            newWord = 1;
        } else {
            if (newWord && text[i] >= 'a' && text[i] <= 'z')
                text[i] -= 32;       /* make it uppercase */
            newWord = 0;
        }
    }

    printf("Capitalized: %s", text);
    return 0;
}
''', "the c programming language is fun\n")

add(683, r'''
#include <stdio.h>

int main(void)
{
    char text[200], result[200];
    int start = 0, end = 0, i, k = 0;

    printf("Enter a string: ");
    if (fgets(text, sizeof text, stdin) == NULL) return 1;

    while (text[end] != '\0' && text[end] != '\n')
        end++;                         /* end is now the string length */

    while (start < end && text[start] == ' ')
        start++;
    while (end > start && text[end - 1] == ' ')
        end--;

    for (i = start; i < end; i++)
        result[k++] = text[i];
    result[k] = '\0';

    printf("Trimmed: [%s]\n", result);
    return 0;
}
''', "     hello   world    \n")

add(684, r'''
#include <stdio.h>

int main(void)
{
    char text[100];
    int i = 0, count;

    printf("Enter a string: ");
    if (scanf("%99s", text) != 1) return 1;

    printf("Compressed: ");
    while (text[i] != '\0') {
        char ch = text[i];
        count = 0;
        while (text[i] == ch) {      /* count the run of ch */
            count++;
            i++;
        }
        printf("%c%d", ch, count);
    }
    printf("\n");
    return 0;
}
''', "aaabbccccd")

add(685, r'''
#include <stdio.h>
#include <ctype.h>

int main(void)
{
    char text[100];
    int i = 0, count, k;

    printf("Enter encoded string (like a3b2): ");
    if (scanf("%99s", text) != 1) return 1;

    printf("Expanded: ");
    while (text[i] != '\0') {
        char ch = text[i++];
        count = 0;
        while (isdigit((unsigned char)text[i]))
            count = count * 10 + (text[i++] - '0');
        if (count == 0)
            count = 1;               /* no number means one copy */
        for (k = 0; k < count; k++)
            putchar(ch);
    }
    printf("\n");
    return 0;
}
''', "a3b2c1d4")

add(686, r'''
#include <stdio.h>
#include <ctype.h>

int main(void)
{
    char text[100];
    int i, valid = 1;

    printf("Enter a string: ");
    if (scanf("%99s", text) != 1) {
        printf("Error: empty input.\n");
        return 1;
    }

    for (i = 0; text[i] != '\0'; i++)
        if (!isdigit((unsigned char)text[i])) {
            valid = 0;
            break;
        }

    if (valid)
        printf("\"%s\" contains only digits.\n", text);
    else
        printf("\"%s\" is not a digit-only string.\n", text);
    return 0;
}
''', "20241025")

add(687, r'''
#include <stdio.h>
#include <ctype.h>

int main(void)
{
    char name[100];
    int i, valid;

    printf("Enter an identifier: ");
    if (scanf("%99s", name) != 1) return 1;

    /* must start with a letter or underscore */
    valid = (isalpha((unsigned char)name[0]) || name[0] == '_');
    /* remaining characters: letters, digits or underscore */
    for (i = 1; valid && name[i] != '\0'; i++)
        if (!isalnum((unsigned char)name[i]) && name[i] != '_')
            valid = 0;

    printf("\"%s\" is %s identifier.\n", name, valid ? "a valid" : "not a valid");
    return 0;
}
''', "2total_marks")

add(688, r'''
#include <stdio.h>

int main(void)
{
    char text[200];
    int i, depth = 0, balanced = 1;

    printf("Enter an expression: ");
    if (fgets(text, sizeof text, stdin) == NULL) return 1;

    for (i = 0; text[i] != '\0'; i++) {
        if (text[i] == '(')
            depth++;
        else if (text[i] == ')') {
            depth--;
            if (depth < 0) {         /* closing without opening */
                balanced = 0;
                break;
            }
        }
    }
    if (depth != 0)
        balanced = 0;

    printf("Parentheses are %s.\n", balanced ? "balanced" : "not balanced");
    return 0;
}
''', "((a + b) * (c - d))\n")

add(689, r'''
#include <stdio.h>

int main(void)
{
    char text[100], sub[100];
    int len = 0, start, count, i, k = 0;

    printf("Enter a string: ");
    if (scanf("%99s", text) != 1) return 1;
    printf("Enter start index and length: ");
    if (scanf("%d %d", &start, &count) != 2) return 1;

    while (text[len] != '\0')
        len++;

    if (start < 0 || count < 0 || start >= len) {
        printf("Invalid start or length.\n");
        return 1;
    }

    for (i = start; i < start + count && i < len; i++)
        sub[k++] = text[i];
    sub[k] = '\0';

    printf("Substring: %s\n", sub);
    return 0;
}
''', "programming\n3 5\n")

add(690, r'''
#include <stdio.h>

int main(void)
{
    char text[200];
    int shift, i;

    printf("Enter text: ");
    if (fgets(text, sizeof text, stdin) == NULL) return 1;
    printf("Enter shift (0-25): ");
    if (scanf("%d", &shift) != 1 || shift < 0 || shift > 25) {
        printf("Invalid shift.\n");
        return 1;
    }

    for (i = 0; text[i] != '\0'; i++) {
        if (text[i] >= 'a' && text[i] <= 'z')
            text[i] = (char)('a' + (text[i] - 'a' + shift) % 26);
        else if (text[i] >= 'A' && text[i] <= 'Z')
            text[i] = (char)('A' + (text[i] - 'A' + shift) % 26);
    }

    printf("Encrypted: %s", text);
    return 0;
}
''', "Hello, World!\n3\n")

add(691, r'''
#include <stdio.h>
#include <ctype.h>

int main(void)
{
    char text[300], result[300];
    int i, k = 0;

    printf("Enter a sentence: ");
    if (fgets(text, sizeof text, stdin) == NULL) return 1;

    for (i = 0; text[i] != '\0' && text[i] != '\n'; i++)
        if (!ispunct((unsigned char)text[i]))
            result[k++] = text[i];
    result[k] = '\0';

    printf("Without punctuation: %s\n", result);
    return 0;
}
''', "Hello, world! It's a (great) day; isn't it?\n")

add(692, r'''
#include <stdio.h>

int main(void)
{
    char text[100];
    int len = 0, i, bestStart = 0, bestLen = 1, center;

    printf("Enter a short string: ");
    if (scanf("%99s", text) != 1) return 1;
    while (text[len] != '\0')
        len++;

    /* expand around every possible center (odd and even) */
    for (center = 0; center < 2 * len - 1; center++) {
        int left = center / 2;
        int right = left + center % 2;
        while (left >= 0 && right < len && text[left] == text[right]) {
            left--;
            right++;
        }
        if (right - left - 1 > bestLen) {
            bestLen = right - left - 1;
            bestStart = left + 1;
        }
    }

    printf("Longest palindromic substring: ");
    for (i = bestStart; i < bestStart + bestLen; i++)
        putchar(text[i]);
    printf(" (length %d)\n", bestLen);
    return 0;
}
''', "forgeeksskeegfor")

add(693, r'''
#include <stdio.h>

int main(void)
{
    char text[200], result[600];
    int i, k = 0;

    printf("Enter a string: ");
    if (fgets(text, sizeof text, stdin) == NULL) return 1;

    for (i = 0; text[i] != '\0' && text[i] != '\n'; i++) {
        if (text[i] == ' ') {
            result[k++] = '%';
            result[k++] = '2';
            result[k++] = '0';
        } else {
            result[k++] = text[i];
        }
    }
    result[k] = '\0';

    printf("URL form: %s\n", result);
    return 0;
}
''', "my first c program\n")

add(694, r'''
#include <stdio.h>
#include <ctype.h>

int main(void)
{
    char text[300];
    int seen[26] = {0};
    int i, pangram = 1;

    printf("Enter a sentence: ");
    if (fgets(text, sizeof text, stdin) == NULL) return 1;

    for (i = 0; text[i] != '\0'; i++)
        if (isalpha((unsigned char)text[i]))
            seen[tolower((unsigned char)text[i]) - 'a'] = 1;

    for (i = 0; i < 26; i++)
        if (!seen[i]) {
            printf("Missing letter: %c\n", 'a' + i);
            pangram = 0;
            break;
        }

    printf("The sentence %s a pangram.\n", pangram ? "is" : "is not");
    return 0;
}
''', "The quick brown fox jumps over the lazy dog\n")

add(695, r'''
#include <stdio.h>
#include <string.h>

#define MAXW 50

int main(void)
{
    char words[MAXW][30];
    int n = 0, i, j, best = 0, bestCount = 0;

    printf("Enter a sentence: ");
    while (n < MAXW && scanf("%29s", words[n]) == 1) {
        n++;
        if (getchar() == '\n')
            break;
    }

    for (i = 0; i < n; i++) {
        int count = 0;
        for (j = 0; j < n; j++)
            if (strcmp(words[i], words[j]) == 0)
                count++;
        if (count > bestCount) {
            bestCount = count;
            best = i;
        }
    }

    if (n == 0)
        printf("No words entered.\n");
    else
        printf("Most frequent word: \"%s\" (%d times)\n", words[best], bestCount);
    return 0;
}
''', "the cat and the dog and the bird\n")

add(696, r'''
#include <stdio.h>

int main(void)
{
    char line[100];

    printf("Please type a sentence and press Enter: ");
    if (fgets(line, sizeof line, stdin) == NULL) {
        printf("No input received.\n");
        return 1;
    }
    printf("You typed: %s", line);
    return 0;
}
''', "C makes strings easy to learn\n")

add(697, r'''
#include <stdio.h>

/* returns the number of characters before the terminating '\0' */
int stringLength(const char *s)
{
    int count = 0;
    while (s[count] != '\0' && s[count] != '\n')
        count++;
    return count;
}

int main(void)
{
    char text[100];

    printf("Enter a string: ");
    if (fgets(text, sizeof text, stdin) == NULL) return 1;
    printf("Length = %d\n", stringLength(text));
    return 0;
}
''', "function based length\n")

add(698, r'''
#include <stdio.h>

int main(void)
{
    char source[20], target[20];
    int i = 0, ch;

    printf("Enter a string (max 19 characters): ");
    if (fgets(source, sizeof source, stdin) == NULL) {
        printf("Error: no input received.\n");
        return 1;
    }
    /* if the line was too long, the newline is missing */
    {
        int len = 0;
        while (source[len] != '\0' && source[len] != '\n')
            len++;
        if (source[len] == '\0') {
            while ((ch = getchar()) != '\n' && ch != EOF)
                ;
            printf("Error: input is too long, only 19 characters allowed.\n");
            return 1;
        }
        source[len] = '\0';
    }
    if (source[0] == '\0') {
        printf("Error: the string is empty.\n");
        return 1;
    }

    for (i = 0; source[i] != '\0'; i++)
        target[i] = source[i];
    target[i] = '\0';

    printf("Copied string: %s\n", target);
    return 0;
}
''', "copy this text\n")

add(699, r'''
#include <stdio.h>

/* append src to the end of dest */
void joinStrings(char *dest, const char *src)
{
    int i = 0, j = 0;
    while (dest[i] != '\0')
        i++;
    while (src[j] != '\0')
        dest[i++] = src[j++];
    dest[i] = '\0';
}

int main(void)
{
    int t;
    const char *firsts[3]  = {"Hello, ", "Good", "C "};
    const char *seconds[3] = {"World!", "Night", "Programming"};

    for (t = 0; t < 3; t++) {
        char result[100] = "";
        joinStrings(result, firsts[t]);
        joinStrings(result, seconds[t]);
        printf("Test %d: \"%s\" + \"%s\" = \"%s\"\n",
               t + 1, firsts[t], seconds[t], result);
    }
    return 0;
}
''')

add(700, r'''
#include <stdio.h>

int main(void)
{
    char a[50], b[50];
    int i = 0;

    printf("Enter first string : ");
    if (scanf("%49s", a) != 1) return 1;
    printf("Enter second string: ");
    if (scanf("%49s", b) != 1) return 1;

    /* Walk through both strings together while the characters are the same
       and the first string has not ended. */
    while (a[i] != '\0' && a[i] == b[i])
        i++;

    /* The difference of the first unequal characters decides the result:
       0 means equal, negative means a < b, positive means a > b. */
    int diff = (unsigned char)a[i] - (unsigned char)b[i];

    if (diff == 0)
        printf("Strings are equal (result 0).\n");
    else
        printf("Strings are different (result %d).\n", diff);
    return 0;
}
''', "computer compute")
