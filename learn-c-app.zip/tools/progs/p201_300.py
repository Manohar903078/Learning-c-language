# programs 201-300
P = {}
def add(i, code, stdin=""): P[i] = (stdin, code.strip("\n"))

add(201, r'''
#include <stdio.h>

int main(void)
{
    double a, b;
    char op;
    printf("Enter expression (number operator number): ");
    scanf("%lf %c %lf", &a, &op, &b);
    switch (op)
    {
        case '+':
            printf("%.2f + %.2f = %.2f\n", a, b, a + b);
            break;
        case '-':
            printf("%.2f - %.2f = %.2f\n", a, b, a - b);
            break;
        case '*':
            printf("%.2f * %.2f = %.2f\n", a, b, a * b);
            break;
        case '/':
            if (b == 0)
                printf("Error: division by zero\n");
            else
                printf("%.2f / %.2f = %.2f\n", a, b, a / b);
            break;
        default:
            printf("Error: invalid operator '%c'\n", op);
    }
    return 0;
}
''', "12 * 5")
add(202, r'''
#include <stdio.h>

int main(void)
{
    int day;
    printf("Enter day number (1-7): ");
    scanf("%d", &day);
    switch (day)
    {
        case 1: printf("Monday\n"); break;
        case 2: printf("Tuesday\n"); break;
        case 3: printf("Wednesday\n"); break;
        case 4: printf("Thursday\n"); break;
        case 5: printf("Friday\n"); break;
        case 6: printf("Saturday\n"); break;
        case 7: printf("Sunday\n"); break;
        default: printf("Invalid day number\n");
    }
    return 0;
}
''', "3")
add(203, r'''
#include <stdio.h>

int main(void)
{
    int month;
    printf("Enter month number (1-12): ");
    scanf("%d", &month);
    switch (month)
    {
        case 1: printf("January\n"); break;
        case 2: printf("February\n"); break;
        case 3: printf("March\n"); break;
        case 4: printf("April\n"); break;
        case 5: printf("May\n"); break;
        case 6: printf("June\n"); break;
        case 7: printf("July\n"); break;
        case 8: printf("August\n"); break;
        case 9: printf("September\n"); break;
        case 10: printf("October\n"); break;
        case 11: printf("November\n"); break;
        case 12: printf("December\n"); break;
        default: printf("Invalid month number\n");
    }
    return 0;
}
''', "11")
add(204, r'''
#include <stdio.h>

int main(void)
{
    int digit;
    printf("Enter a digit (0-9): ");
    scanf("%d", &digit);
    switch (digit)
    {
        case 0: printf("Zero\n"); break;
        case 1: printf("One\n"); break;
        case 2: printf("Two\n"); break;
        case 3: printf("Three\n"); break;
        case 4: printf("Four\n"); break;
        case 5: printf("Five\n"); break;
        case 6: printf("Six\n"); break;
        case 7: printf("Seven\n"); break;
        case 8: printf("Eight\n"); break;
        case 9: printf("Nine\n"); break;
        default: printf("Not a single digit\n");
    }
    return 0;
}
''', "7")
add(205, r'''
#include <stdio.h>

int main(void)
{
    int choice;
    double r, l, w, base, height;
    do
    {
        printf("\n--- Area Menu ---\n");
        printf("1. Circle\n2. Rectangle\n3. Triangle\n4. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);
        switch (choice)
        {
            case 1:
                printf("Enter radius: ");
                scanf("%lf", &r);
                printf("Area of circle = %.2f\n", 3.14159 * r * r);
                break;
            case 2:
                printf("Enter length and width: ");
                scanf("%lf %lf", &l, &w);
                printf("Area of rectangle = %.2f\n", l * w);
                break;
            case 3:
                printf("Enter base and height: ");
                scanf("%lf %lf", &base, &height);
                printf("Area of triangle = %.2f\n", 0.5 * base * height);
                break;
            case 4:
                printf("Goodbye!\n");
                break;
            default:
                printf("Invalid choice, try again.\n");
        }
    } while (choice != 4);
    return 0;
}
''', "1\n3\n2\n4 5\n3\n6 2\n4\n")
add(206, r'''
#include <stdio.h>

int main(void)
{
    int choice;
    double temp;
    do
    {
        printf("\n1. Celsius to Fahrenheit\n2. Fahrenheit to Celsius\n3. Exit\n");
        printf("Enter choice: ");
        scanf("%d", &choice);
        switch (choice)
        {
            case 1:
                printf("Enter temperature in Celsius: ");
                scanf("%lf", &temp);
                printf("%.2f C = %.2f F\n", temp, temp * 9.0 / 5.0 + 32);
                break;
            case 2:
                printf("Enter temperature in Fahrenheit: ");
                scanf("%lf", &temp);
                printf("%.2f F = %.2f C\n", temp, (temp - 32) * 5.0 / 9.0);
                break;
            case 3:
                printf("Exiting...\n");
                break;
            default:
                printf("Invalid choice.\n");
        }
    } while (choice != 3);
    return 0;
}
''', "1\n100\n2\n98.6\n3\n")
add(207, r'''
#include <stdio.h>

int main(void)
{
    int choice;
    double a, b;
    while (1)
    {
        printf("\n1.Add 2.Subtract 3.Multiply 4.Divide 5.Exit\n");
        printf("Enter choice: ");
        scanf("%d", &choice);
        if (choice == 5)
        {
            printf("Bye!\n");
            break;
        }
        if (choice < 1 || choice > 5)
        {
            printf("Invalid choice.\n");
            continue;
        }
        printf("Enter two numbers: ");
        scanf("%lf %lf", &a, &b);
        switch (choice)
        {
            case 1: printf("Sum = %.2f\n", a + b); break;
            case 2: printf("Difference = %.2f\n", a - b); break;
            case 3: printf("Product = %.2f\n", a * b); break;
            case 4:
                if (b != 0)
                    printf("Quotient = %.2f\n", a / b);
                else
                    printf("Cannot divide by zero.\n");
                break;
        }
    }
    return 0;
}
''', "1\n8 4\n4\n9 0\n3\n6 7\n9\n5\n")
add(208, r'''
#include <stdio.h>

int main(void)
{
    int choice;
    double value;
    do
    {
        printf("\n--- Unit Converter ---\n");
        printf("1. km to m\n2. m to cm\n3. km to cm\n4. cm to m\n5. Exit\n");
        printf("Enter choice: ");
        scanf("%d", &choice);
        if (choice >= 1 && choice <= 4)
        {
            printf("Enter value: ");
            scanf("%lf", &value);
        }
        switch (choice)
        {
            case 1: printf("%.2f km = %.2f m\n", value, value * 1000); break;
            case 2: printf("%.2f m = %.2f cm\n", value, value * 100); break;
            case 3: printf("%.2f km = %.2f cm\n", value, value * 100000); break;
            case 4: printf("%.2f cm = %.2f m\n", value, value / 100); break;
            case 5: printf("Done.\n"); break;
            default: printf("Invalid choice.\n");
        }
    } while (choice != 5);
    return 0;
}
''', "1\n2.5\n2\n3.2\n4\n250\n7\n5\n")
add(209, r'''
#include <stdio.h>

int main(void)
{
    int year, month, days = 0;
    printf("Enter year: ");
    scanf("%d", &year);
    printf("Enter month (1-12): ");
    scanf("%d", &month);
    switch (month)
    {
        case 1: case 3: case 5: case 7: case 8: case 10: case 12:
            days = 31;
            break;
        case 4: case 6: case 9: case 11:
            days = 30;
            break;
        case 2:
            /* leap year: divisible by 4 and not 100, or divisible by 400 */
            if ((year % 4 == 0 && year % 100 != 0) || year % 400 == 0)
                days = 29;
            else
                days = 28;
            break;
        default:
            printf("Invalid month.\n");
            return 0;
    }
    printf("Month %d of year %d has %d days.\n", month, year, days);
    return 0;
}
''', "2024\n2")
add(210, r'''
#include <stdio.h>
#include <math.h>

int main(void)
{
    int choice;
    double p, rate, years, result;
    do
    {
        printf("\n1. Simple Interest\n2. Compound Interest\n3. Exit\n");
        printf("Enter choice: ");
        scanf("%d", &choice);
        if (choice == 1 || choice == 2)
        {
            printf("Enter principal, rate (%%) and time (years): ");
            scanf("%lf %lf %lf", &p, &rate, &years);
        }
        switch (choice)
        {
            case 1:
                result = p * rate * years / 100;
                printf("Simple Interest = %.2f\n", result);
                break;
            case 2:
                result = p * pow(1 + rate / 100, years) - p;
                printf("Compound Interest = %.2f\n", result);
                break;
            case 3:
                printf("Goodbye!\n");
                break;
            default:
                printf("Invalid choice.\n");
        }
    } while (choice != 3);
    return 0;
}
''', "1\n10000 5 2\n2\n10000 5 2\n3\n")
add(211, r'''
#include <stdio.h>

int main(void)
{
    char ch;
    printf("Enter a character: ");
    scanf(" %c", &ch);
    switch (ch)
    {
        case 'a': case 'e': case 'i': case 'o': case 'u':
        case 'A': case 'E': case 'I': case 'O': case 'U':
            printf("'%c' is a vowel.\n", ch);
            break;
        default:
            if ((ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z'))
                printf("'%c' is a consonant.\n", ch);
            else
                printf("'%c' is not an alphabet.\n", ch);
    }
    return 0;
}
''', "E")
add(212, r'''
#include <stdio.h>
#include <math.h>

int main(void)
{
    int choice;
    double x;
    do
    {
        printf("\n1. Square\n2. Cube\n3. Square root\n4. Exit\n");
        printf("Enter choice: ");
        scanf("%d", &choice);
        if (choice >= 1 && choice <= 3)
        {
            printf("Enter a number: ");
            scanf("%lf", &x);
        }
        switch (choice)
        {
            case 1: printf("Square of %.2f = %.2f\n", x, x * x); break;
            case 2: printf("Cube of %.2f = %.2f\n", x, x * x * x); break;
            case 3:
                if (x < 0)
                    printf("Square root of a negative number is not real.\n");
                else
                    printf("Square root of %.2f = %.2f\n", x, sqrt(x));
                break;
            case 4: printf("Exiting.\n"); break;
            default: printf("Invalid choice.\n");
        }
    } while (choice != 4);
    return 0;
}
''', "1\n7\n2\n3\n3\n144\n3\n-4\n4\n")
add(213, r'''
#include <stdio.h>

int main(void)
{
    int choice, n, i, k;
    int bits[32];
    do
    {
        printf("\n1. Decimal to Binary\n2. Decimal to Octal\n3. Decimal to Hexadecimal\n4. Exit\n");
        printf("Enter choice: ");
        scanf("%d", &choice);
        if (choice >= 1 && choice <= 3)
        {
            printf("Enter a positive decimal number: ");
            scanf("%d", &n);
        }
        switch (choice)
        {
            case 1:
                /* repeated division by 2, remainders read in reverse */
                k = 0;
                if (n == 0)
                    bits[k++] = 0;
                while (n > 0)
                {
                    bits[k++] = n % 2;
                    n /= 2;
                }
                printf("Binary = ");
                for (i = k - 1; i >= 0; i--)
                    printf("%d", bits[i]);
                printf("\n");
                break;
            case 2:
                printf("Octal = %o\n", n);
                break;
            case 3:
                printf("Hexadecimal = %X\n", n);
                break;
            case 4:
                printf("Bye!\n");
                break;
            default:
                printf("Invalid choice.\n");
        }
    } while (choice != 4);
    return 0;
}
''', "1\n10\n2\n64\n3\n255\n4\n")
add(214, r'''
#include <stdio.h>

int main(void)
{
    int choice;
    double a, b, c;
    do
    {
        printf("\n--- Perimeter Menu ---\n");
        printf("1. Square\n2. Rectangle\n3. Circle\n4. Triangle\n5. Exit\n");
        printf("Enter choice: ");
        scanf("%d", &choice);
        switch (choice)
        {
            case 1:
                printf("Enter side: ");
                scanf("%lf", &a);
                printf("Perimeter of square = %.2f\n", 4 * a);
                break;
            case 2:
                printf("Enter length and width: ");
                scanf("%lf %lf", &a, &b);
                printf("Perimeter of rectangle = %.2f\n", 2 * (a + b));
                break;
            case 3:
                printf("Enter radius: ");
                scanf("%lf", &a);
                printf("Circumference of circle = %.2f\n", 2 * 3.14159 * a);
                break;
            case 4:
                printf("Enter three sides: ");
                scanf("%lf %lf %lf", &a, &b, &c);
                printf("Perimeter of triangle = %.2f\n", a + b + c);
                break;
            case 5:
                printf("Goodbye!\n");
                break;
            default:
                printf("Invalid choice.\n");
        }
    } while (choice != 5);
    return 0;
}
''', "1\n5\n2\n4 6\n3\n7\n4\n3 4 5\n5\n")
add(215, r'''
#include <stdio.h>

int main(void)
{
    int choice, marks = -1;
    do
    {
        printf("\n1. Enter marks\n2. Show grade\n3. Exit\n");
        printf("Enter choice: ");
        scanf("%d", &choice);
        switch (choice)
        {
            case 1:
                printf("Enter marks (0-100): ");
                scanf("%d", &marks);
                if (marks < 0 || marks > 100)
                {
                    printf("Marks out of range.\n");
                    marks = -1;
                }
                break;
            case 2:
                if (marks < 0)
                    printf("No valid marks entered yet.\n");
                else
                {
                    char grade;
                    switch (marks / 10)
                    {
                        case 10: case 9: grade = 'A'; break;
                        case 8: grade = 'B'; break;
                        case 7: grade = 'C'; break;
                        case 6: grade = 'D'; break;
                        default: grade = 'F';
                    }
                    printf("Marks = %d, Grade = %c\n", marks, grade);
                }
                break;
            case 3:
                printf("Exiting.\n");
                break;
            default:
                printf("Invalid choice.\n");
        }
    } while (choice != 3);
    return 0;
}
''', "2\n1\n87\n2\n1\n150\n1\n55\n2\n3\n")
add(216, r'''
#include <stdio.h>

int main(void)
{
    char light;
    printf("Enter traffic light colour (R/Y/G): ");
    scanf(" %c", &light);
    switch (light)
    {
        case 'R': case 'r':
            printf("RED - Stop!\n");
            break;
        case 'Y': case 'y':
            printf("YELLOW - Get ready, slow down.\n");
            break;
        case 'G': case 'g':
            printf("GREEN - Go!\n");
            break;
        default:
            printf("Unknown signal '%c'.\n", light);
    }
    return 0;
}
''', "y")
add(217, r'''
#include <stdio.h>

int main(void)
{
    char op;
    printf("Enter an operator: ");
    scanf(" %c", &op);
    switch (op)
    {
        case '+': printf("'+' is the addition operator.\n"); break;
        case '-': printf("'-' is the subtraction operator.\n"); break;
        case '*': printf("'*' is the multiplication operator.\n"); break;
        case '/': printf("'/' is the division operator.\n"); break;
        case '%': printf("'%%' is the modulus operator.\n"); break;
        default: printf("'%c' is not a basic arithmetic operator.\n", op);
    }
    return 0;
}
''', "*")
add(218, r'''
#include <stdio.h>

int main(void)
{
    int choice, n, i, prime;
    do
    {
        printf("\n1. Even/Odd\n2. Positive/Negative\n3. Prime check\n4. Exit\n");
        printf("Enter choice: ");
        scanf("%d", &choice);
        if (choice >= 1 && choice <= 3)
        {
            printf("Enter an integer: ");
            scanf("%d", &n);
        }
        switch (choice)
        {
            case 1:
                printf("%d is %s.\n", n, n % 2 == 0 ? "even" : "odd");
                break;
            case 2:
                if (n > 0)
                    printf("%d is positive.\n", n);
                else if (n < 0)
                    printf("%d is negative.\n", n);
                else
                    printf("Zero is neither positive nor negative.\n");
                break;
            case 3:
                prime = (n >= 2);
                for (i = 2; i * i <= n && prime; i++)
                    if (n % i == 0)
                        prime = 0;
                printf("%d is %s.\n", n, prime ? "prime" : "not prime");
                break;
            case 4:
                printf("Bye!\n");
                break;
            default:
                printf("Invalid choice.\n");
        }
    } while (choice != 4);
    return 0;
}
''', "1\n17\n2\n-5\n3\n29\n3\n21\n4\n")
add(219, r'''
#include <stdio.h>

int main(void)
{
    int choice;
    double t;
    do
    {
        printf("\n1. Celsius -> Fahrenheit\n2. Fahrenheit -> Celsius\n");
        printf("3. Celsius -> Kelvin\n4. Kelvin -> Celsius\n5. Exit\n");
        printf("Enter choice: ");
        scanf("%d", &choice);
        if (choice >= 1 && choice <= 4)
        {
            printf("Enter temperature: ");
            scanf("%lf", &t);
        }
        switch (choice)
        {
            case 1: printf("%.2f C = %.2f F\n", t, t * 1.8 + 32); break;
            case 2: printf("%.2f F = %.2f C\n", t, (t - 32) / 1.8); break;
            case 3: printf("%.2f C = %.2f K\n", t, t + 273.15); break;
            case 4: printf("%.2f K = %.2f C\n", t, t - 273.15); break;
            case 5: printf("Exiting.\n"); break;
            default: printf("Invalid choice.\n");
        }
    } while (choice != 5);
    return 0;
}
''', "1\n37\n2\n212\n3\n0\n4\n300\n5\n")
add(220, r'''
#include <stdio.h>

int main(void)
{
    int choice;
    do
    {
        printf("\n1. Say Hello\n2. Show Date Note\n3. Exit\n");
        printf("Enter choice: ");
        if (scanf("%d", &choice) != 1)
        {
            printf("Input is not a number. Stopping.\n");
            break;
        }
        switch (choice)
        {
            case 1: printf("Hello, student!\n"); break;
            case 2: printf("Practice a little every day.\n"); break;
            case 3: printf("Goodbye!\n"); break;
            default:
                /* any other number is reported clearly */
                printf("Error: %d is not a valid option. Please choose 1, 2 or 3.\n", choice);
        }
    } while (choice != 3);
    return 0;
}
''', "1\n9\n-2\n2\n3\n")
add(221, r'''
#include <stdio.h>

int main(void)
{
    char shape;
    double a, b;
    printf("Select shape - C (circle), R (rectangle), S (square), T (triangle): ");
    scanf(" %c", &shape);
    switch (shape)
    {
        case 'C': case 'c':
            printf("Enter radius: ");
            scanf("%lf", &a);
            printf("Area of circle = %.2f\n", 3.14159 * a * a);
            break;
        case 'R': case 'r':
            printf("Enter length and width: ");
            scanf("%lf %lf", &a, &b);
            printf("Area of rectangle = %.2f\n", a * b);
            break;
        case 'S': case 's':
            printf("Enter side: ");
            scanf("%lf", &a);
            printf("Area of square = %.2f\n", a * a);
            break;
        case 'T': case 't':
            printf("Enter base and height: ");
            scanf("%lf %lf", &a, &b);
            printf("Area of triangle = %.2f\n", 0.5 * a * b);
            break;
        default:
            printf("Unknown shape.\n");
    }
    return 0;
}
''', "R\n8 3.5")
add(222, r'''
#include <stdio.h>
#define MAX 5

int main(void)
{
    int stack[MAX], top = -1, choice, value, i;
    do
    {
        printf("\n1. Push\n2. Pop\n3. Peek\n4. Display\n5. Exit\n");
        printf("Enter choice: ");
        scanf("%d", &choice);
        switch (choice)
        {
            case 1:
                if (top == MAX - 1)
                    printf("Stack overflow!\n");
                else
                {
                    printf("Enter value: ");
                    scanf("%d", &value);
                    stack[++top] = value;
                    printf("%d pushed.\n", value);
                }
                break;
            case 2:
                if (top == -1)
                    printf("Stack underflow!\n");
                else
                    printf("Popped %d\n", stack[top--]);
                break;
            case 3:
                if (top == -1)
                    printf("Stack is empty.\n");
                else
                    printf("Top element = %d\n", stack[top]);
                break;
            case 4:
                if (top == -1)
                    printf("Stack is empty.\n");
                else
                {
                    printf("Stack (top to bottom):");
                    for (i = top; i >= 0; i--)
                        printf(" %d", stack[i]);
                    printf("\n");
                }
                break;
            case 5:
                printf("Exiting.\n");
                break;
            default:
                printf("Invalid choice.\n");
        }
    } while (choice != 5);
    return 0;
}
''', "2\n1\n10\n1\n20\n1\n30\n3\n4\n2\n4\n5\n")
add(223, r'''
#include <stdio.h>

int main(void)
{
    int arr[6] = {12, 45, 7, 89, 23, 56};
    int n = 6, choice, i, sum, max;
    do
    {
        printf("\n1. Display\n2. Sum\n3. Largest\n4. Reverse display\n5. Exit\n");
        printf("Enter choice: ");
        scanf("%d", &choice);
        switch (choice)
        {
            case 1:
                printf("Array:");
                for (i = 0; i < n; i++)
                    printf(" %d", arr[i]);
                printf("\n");
                break;
            case 2:
                sum = 0;
                for (i = 0; i < n; i++)
                    sum += arr[i];
                printf("Sum = %d\n", sum);
                break;
            case 3:
                max = arr[0];
                for (i = 1; i < n; i++)
                    if (arr[i] > max)
                        max = arr[i];
                printf("Largest = %d\n", max);
                break;
            case 4:
                printf("Reversed:");
                for (i = n - 1; i >= 0; i--)
                    printf(" %d", arr[i]);
                printf("\n");
                break;
            case 5:
                printf("Exiting.\n");
                break;
            default:
                printf("Invalid choice.\n");
        }
    } while (choice != 5);
    return 0;
}
''', "1\n2\n3\n4\n8\n5\n")
add(224, r'''
#include <stdio.h>
#include <string.h>
#include <ctype.h>

int main(void)
{
    char text[50];
    int choice, i, len, count;
    printf("Enter a word: ");
    scanf("%49s", text);
    len = (int)strlen(text);
    do
    {
        printf("\n1. Length\n2. Reverse\n3. Uppercase\n4. Count vowels\n5. Exit\n");
        printf("Enter choice: ");
        scanf("%d", &choice);
        switch (choice)
        {
            case 1:
                printf("Length = %d\n", len);
                break;
            case 2:
                printf("Reverse = ");
                for (i = len - 1; i >= 0; i--)
                    putchar(text[i]);
                printf("\n");
                break;
            case 3:
                printf("Uppercase = ");
                for (i = 0; i < len; i++)
                    putchar(toupper((unsigned char)text[i]));
                printf("\n");
                break;
            case 4:
                count = 0;
                for (i = 0; i < len; i++)
                    if (strchr("aeiouAEIOU", text[i]) != NULL)
                        count++;
                printf("Vowels = %d\n", count);
                break;
            case 5:
                printf("Exiting.\n");
                break;
            default:
                printf("Invalid choice.\n");
        }
    } while (choice != 5);
    return 0;
}
''', "Programming\n1\n2\n3\n4\n5\n")
add(225, r'''
#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int choice, n, i, k;
    char bits[40], hex[20];
    do
    {
        printf("\n1. Decimal to Binary\n2. Binary to Decimal\n3. Decimal to Hex\n4. Hex to Decimal\n5. Exit\n");
        printf("Enter choice: ");
        scanf("%d", &choice);
        switch (choice)
        {
            case 1:
                printf("Enter decimal number: ");
                scanf("%d", &n);
                k = 0;
                do
                {
                    bits[k++] = (char)('0' + n % 2);
                    n /= 2;
                } while (n > 0 && k < 39);
                printf("Binary = ");
                for (i = k - 1; i >= 0; i--)
                    putchar(bits[i]);
                printf("\n");
                break;
            case 2:
                printf("Enter binary number: ");
                scanf("%39s", bits);
                printf("Decimal = %ld\n", strtol(bits, NULL, 2));
                break;
            case 3:
                printf("Enter decimal number: ");
                scanf("%d", &n);
                printf("Hex = %X\n", n);
                break;
            case 4:
                printf("Enter hex number: ");
                scanf("%19s", hex);
                printf("Decimal = %ld\n", strtol(hex, NULL, 16));
                break;
            case 5:
                printf("Exiting.\n");
                break;
            default:
                printf("Invalid choice.\n");
        }
    } while (choice != 5);
    return 0;
}
''', "1\n13\n2\n101101\n3\n255\n4\n1F\n5\n")
