# programs 501-600
P = {}
def add(i, code, stdin=""): P[i] = (stdin, code.strip("\n"))

add(501, r'''
#include <stdio.h>

int main(void)
{
    int a[] = {64, 25, 12, 22, 11, 90, 5};
    int n = (int)(sizeof a / sizeof a[0]);
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - 1 - i; j++) {
            if (a[j] > a[j + 1]) {
                int t = a[j];
                a[j] = a[j + 1];
                a[j + 1] = t;
            }
        }
    }
    printf("Ascending order:");
    for (int i = 0; i < n; i++) {
        printf(" %d", a[i]);
    }
    printf("\n");
    return 0;
}
''')
add(502, r'''
#include <stdio.h>

int main(void)
{
    int a[] = {40, 7, 19, 83, 56, 2, 31, 19};
    int n = (int)(sizeof a / sizeof a[0]);
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - 1 - i; j++) {
            if (a[j] < a[j + 1]) {   /* smaller goes right */
                int t = a[j];
                a[j] = a[j + 1];
                a[j + 1] = t;
            }
        }
    }
    printf("Descending order:");
    for (int i = 0; i < n; i++) {
        printf(" %d", a[i]);
    }
    printf("\n");
    return 0;
}
''')
add(503, r'''
#include <stdio.h>

int main(void)
{
    int a[] = {29, 10, 14, 37, 13, 8};
    int n = 6;
    for (int i = 0; i < n - 1; i++) {
        int min = i;
        for (int j = i + 1; j < n; j++) {
            if (a[j] < a[min]) {
                min = j;
            }
        }
        int t = a[i];
        a[i] = a[min];
        a[min] = t;
    }
    printf("Selection sort (ascending):");
    for (int i = 0; i < n; i++) {
        printf(" %d", a[i]);
    }
    printf("\n");
    return 0;
}
''')
add(504, r'''
#include <stdio.h>

int main(void)
{
    int a[] = {5, 61, 17, 44, 3, 28, 90};
    int n = 7;
    for (int i = 0; i < n - 1; i++) {
        int max = i;
        for (int j = i + 1; j < n; j++) {
            if (a[j] > a[max]) {
                max = j;
            }
        }
        int t = a[i];
        a[i] = a[max];
        a[max] = t;
    }
    printf("Selection sort (descending):");
    for (int i = 0; i < n; i++) {
        printf(" %d", a[i]);
    }
    printf("\n");
    return 0;
}
''')
add(505, r'''
#include <stdio.h>

int main(void)
{
    int a[] = {12, 11, 13, 5, 6, 1};
    int n = 6;
    for (int i = 1; i < n; i++) {
        int key = a[i];
        int j = i - 1;
        while (j >= 0 && a[j] > key) {
            a[j + 1] = a[j];
            j--;
        }
        a[j + 1] = key;
    }
    printf("Insertion sort (ascending):");
    for (int i = 0; i < n; i++) {
        printf(" %d", a[i]);
    }
    printf("\n");
    return 0;
}
''')
add(506, r'''
#include <stdio.h>

int main(void)
{
    int a[] = {9, 4, 15, 2, 20, 7};
    int n = 6;
    for (int i = 1; i < n; i++) {
        int key = a[i];
        int j = i - 1;
        while (j >= 0 && a[j] < key) {
            a[j + 1] = a[j];
            j--;
        }
        a[j + 1] = key;
    }
    printf("Insertion sort (descending):");
    for (int i = 0; i < n; i++) {
        printf(" %d", a[i]);
    }
    printf("\n");
    return 0;
}
''')
add(507, r'''
#include <stdio.h>

static void merge(int a[], int tmp[], int lo, int mid, int hi)
{
    int i = lo, j = mid + 1, k = lo;
    while (i <= mid && j <= hi) {
        tmp[k++] = (a[i] <= a[j]) ? a[i++] : a[j++];
    }
    while (i <= mid) {
        tmp[k++] = a[i++];
    }
    while (j <= hi) {
        tmp[k++] = a[j++];
    }
    for (k = lo; k <= hi; k++) {
        a[k] = tmp[k];
    }
}

static void merge_sort(int a[], int tmp[], int lo, int hi)
{
    if (lo >= hi) {
        return;
    }
    int mid = lo + (hi - lo) / 2;
    merge_sort(a, tmp, lo, mid);
    merge_sort(a, tmp, mid + 1, hi);
    merge(a, tmp, lo, mid, hi);
}

int main(void)
{
    int a[] = {38, 27, 43, 3, 9, 82, 10};
    int tmp[7];
    merge_sort(a, tmp, 0, 6);
    printf("Merge sorted:");
    for (int i = 0; i < 7; i++) {
        printf(" %d", a[i]);
    }
    printf("\n");
    return 0;
}
''')
add(508, r'''
#include <stdio.h>

static void quick_sort(int a[], int lo, int hi)
{
    if (lo >= hi) {
        return;
    }
    int pivot = a[hi];
    int i = lo - 1;
    for (int j = lo; j < hi; j++) {
        if (a[j] <= pivot) {
            i++;
            int t = a[i]; a[i] = a[j]; a[j] = t;
        }
    }
    int t = a[i + 1]; a[i + 1] = a[hi]; a[hi] = t;
    quick_sort(a, lo, i);
    quick_sort(a, i + 2, hi);
}

int main(void)
{
    int a[] = {10, 80, 30, 90, 40, 50, 70};
    quick_sort(a, 0, 6);
    printf("Quick sorted:");
    for (int i = 0; i < 7; i++) {
        printf(" %d", a[i]);
    }
    printf("\n");
    return 0;
}
''')
add(509, r'''
#include <stdio.h>

static void heapify(int a[], int n, int i)
{
    int largest = i, l = 2 * i + 1, r = 2 * i + 2;
    if (l < n && a[l] > a[largest]) {
        largest = l;
    }
    if (r < n && a[r] > a[largest]) {
        largest = r;
    }
    if (largest != i) {
        int t = a[i]; a[i] = a[largest]; a[largest] = t;
        heapify(a, n, largest);
    }
}

int main(void)
{
    int a[] = {12, 11, 13, 5, 6, 7, 25};
    int n = 7;
    for (int i = n / 2 - 1; i >= 0; i--) {
        heapify(a, n, i);          /* build max heap */
    }
    for (int end = n - 1; end > 0; end--) {
        int t = a[0]; a[0] = a[end]; a[end] = t;
        heapify(a, end, 0);
    }
    printf("Heap sorted:");
    for (int i = 0; i < n; i++) {
        printf(" %d", a[i]);
    }
    printf("\n");
    return 0;
}
''')
add(510, r'''
#include <stdio.h>

int main(void)
{
    int a[] = {4, 2, 2, 8, 3, 3, 1, 7};
    int n = 8, max = 8;
    int count[9] = {0};
    int out[8];
    for (int i = 0; i < n; i++) {
        count[a[i]]++;
    }
    for (int v = 1; v <= max; v++) {
        count[v] += count[v - 1];   /* prefix sums */
    }
    for (int i = n - 1; i >= 0; i--) {
        out[--count[a[i]]] = a[i];
    }
    printf("Counting sort:");
    for (int i = 0; i < n; i++) {
        printf(" %d", out[i]);
    }
    printf("\n");
    return 0;
}
''')
add(511, r'''
#include <stdio.h>

static void count_by_digit(int a[], int n, int exp)
{
    int out[10], count[10] = {0};
    for (int i = 0; i < n; i++) {
        count[(a[i] / exp) % 10]++;
    }
    for (int d = 1; d < 10; d++) {
        count[d] += count[d - 1];
    }
    for (int i = n - 1; i >= 0; i--) {
        out[--count[(a[i] / exp) % 10]] = a[i];
    }
    for (int i = 0; i < n; i++) {
        a[i] = out[i];
    }
}

int main(void)
{
    int a[] = {170, 45, 75, 90, 802, 24, 2, 66};
    int n = 8, max = 802;
    for (int exp = 1; max / exp > 0; exp *= 10) {
        count_by_digit(a, n, exp);
    }
    printf("Radix sorted:");
    for (int i = 0; i < n; i++) {
        printf(" %d", a[i]);
    }
    printf("\n");
    return 0;
}
''')
add(512, r'''
#include <stdio.h>

int main(void)
{
    int a[] = {23, 12, 1, 8, 34, 54, 2, 3};
    int n = 8;
    for (int gap = n / 2; gap > 0; gap /= 2) {
        for (int i = gap; i < n; i++) {
            int temp = a[i];
            int j = i;
            while (j >= gap && a[j - gap] > temp) {
                a[j] = a[j - gap];
                j -= gap;
            }
            a[j] = temp;
        }
    }
    printf("Shell sorted:");
    for (int i = 0; i < n; i++) {
        printf(" %d", a[i]);
    }
    printf("\n");
    return 0;
}
''')
add(513, r'''
#include <stdio.h>

int main(void)
{
    int a[] = {5, 1, 4, 2, 8, 0, 3};
    int start = 0, end = 6, swapped = 1;
    while (swapped) {
        swapped = 0;
        for (int i = start; i < end; i++) {      /* forward pass */
            if (a[i] > a[i + 1]) {
                int t = a[i]; a[i] = a[i + 1]; a[i + 1] = t;
                swapped = 1;
            }
        }
        end--;
        for (int i = end - 1; i >= start; i--) { /* backward pass */
            if (a[i] > a[i + 1]) {
                int t = a[i]; a[i] = a[i + 1]; a[i + 1] = t;
                swapped = 1;
            }
        }
        start++;
    }
    printf("Cocktail sorted:");
    for (int i = 0; i < 7; i++) {
        printf(" %d", a[i]);
    }
    printf("\n");
    return 0;
}
''')
add(514, r'''
#include <stdio.h>

int main(void)
{
    int a[] = {8, 4, 1, 56, 3, -44, 23, -6, 28, 0};
    int n = 10, gap = n, sorted = 0;
    while (!sorted) {
        gap = gap * 10 / 13;       /* shrink factor about 1.3 */
        if (gap <= 1) {
            gap = 1;
            sorted = 1;
        }
        for (int i = 0; i + gap < n; i++) {
            if (a[i] > a[i + gap]) {
                int t = a[i]; a[i] = a[i + gap]; a[i + gap] = t;
                sorted = 0;
            }
        }
    }
    printf("Comb sorted:");
    for (int i = 0; i < n; i++) {
        printf(" %d", a[i]);
    }
    printf("\n");
    return 0;
}
''')
add(515, r'''
#include <stdio.h>
#include <string.h>

int main(void)
{
    char names[5][20] = {"mango", "apple", "cherry", "banana", "grape"};
    for (int i = 0; i < 4; i++) {
        for (int j = 0; j < 4 - i; j++) {
            if (strcmp(names[j], names[j + 1]) > 0) {
                char t[20];
                strcpy(t, names[j]);
                strcpy(names[j], names[j + 1]);
                strcpy(names[j + 1], t);
            }
        }
    }
    printf("Alphabetical order:\n");
    for (int i = 0; i < 5; i++) {
        printf("%s\n", names[i]);
    }
    return 0;
}
''')
add(516, r'''
#include <stdio.h>

struct Student {
    char name[20];
    int marks;
};

int main(void)
{
    struct Student s[4] = {{"Asha", 78}, {"Ben", 92}, {"Chitra", 65}, {"Dev", 85}};
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3 - i; j++) {
            if (s[j].marks < s[j + 1].marks) {   /* highest marks first */
                struct Student t = s[j];
                s[j] = s[j + 1];
                s[j + 1] = t;
            }
        }
    }
    printf("Rank  Name    Marks\n");
    for (int i = 0; i < 4; i++) {
        printf("%-5d %-7s %d\n", i + 1, s[i].name, s[i].marks);
    }
    return 0;
}
''')
add(517, r'''
#include <stdio.h>

struct Student {
    int id;
    char name[20];
};

int main(void)
{
    struct Student s[4] = {{104, "Divya"}, {101, "Arun"}, {103, "Chen"}, {102, "Bela"}};
    for (int i = 1; i < 4; i++) {
        struct Student key = s[i];
        int j = i - 1;
        while (j >= 0 && s[j].id > key.id) {
            s[j + 1] = s[j];
            j--;
        }
        s[j + 1] = key;
    }
    printf("ID    Name\n");
    for (int i = 0; i < 4; i++) {
        printf("%-5d %s\n", s[i].id, s[i].name);
    }
    return 0;
}
''')
add(518, r'''
#include <stdio.h>

int main(void)
{
    int a[] = {4, 6, 2, 4, 2, 4, 9, 6};
    int n = 8;
    int val[8], freq[8], m = 0;
    for (int i = 0; i < n; i++) {
        int k = 0;
        while (k < m && val[k] != a[i]) {
            k++;
        }
        if (k == m) {
            val[m] = a[i];
            freq[m] = 0;
            m++;
        }
        freq[k]++;
    }
    for (int i = 0; i < m - 1; i++) {          /* higher frequency first */
        for (int j = 0; j < m - 1 - i; j++) {
            if (freq[j] < freq[j + 1] || (freq[j] == freq[j + 1] && val[j] > val[j + 1])) {
                int t = freq[j]; freq[j] = freq[j + 1]; freq[j + 1] = t;
                t = val[j]; val[j] = val[j + 1]; val[j + 1] = t;
            }
        }
    }
    printf("Sorted by frequency:");
    for (int i = 0; i < m; i++) {
        for (int c = 0; c < freq[i]; c++) {
            printf(" %d", val[i]);
        }
    }
    printf("\n");
    return 0;
}
''')
add(519, r'''
#include <stdio.h>

int main(void)
{
    int a[] = {7, 2, 9, 4, 6, 1, 8, 3};
    int n = 8, out[8], k = 0;
    for (int i = 0; i < n; i++) {      /* evens first, original order kept */
        if (a[i] % 2 == 0) {
            out[k++] = a[i];
        }
    }
    for (int i = 0; i < n; i++) {
        if (a[i] % 2 != 0) {
            out[k++] = a[i];
        }
    }
    printf("Evens then odds:");
    for (int i = 0; i < n; i++) {
        printf(" %d", out[i]);
    }
    printf("\n");
    return 0;
}
''')
add(520, r'''
#include <stdio.h>

struct Item {
    int key;
    char tag;
};

int main(void)
{
    /* insertion sort is stable: equal keys keep their input order (tags show it) */
    struct Item a[6] = {{3, 'a'}, {1, 'b'}, {3, 'c'}, {2, 'd'}, {1, 'e'}, {3, 'f'}};
    for (int i = 1; i < 6; i++) {
        struct Item cur = a[i];
        int j = i - 1;
        while (j >= 0 && a[j].key > cur.key) {
            a[j + 1] = a[j];
            j--;
        }
        a[j + 1] = cur;
    }
    for (int i = 0; i < 6; i++) {
        printf("%d%c ", a[i].key, a[i].tag);
    }
    printf("\n");
    return 0;
}
''')
