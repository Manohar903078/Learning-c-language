#!/usr/bin/env python3
"""Check a batch of programs.
usage: python3 tools/progcheck.py tools/progs/p101_200.py 101 200 [--show]
Compiles each program with gcc -std=gnu99 -Wall -Wextra, runs it with its stdin in an empty temp dir,
and reports missing ids, warnings, errors, crashes, timeouts, empty output. --show prints the outputs."""
import sys, os, subprocess, tempfile, importlib.util, json
path, lo, hi = sys.argv[1], int(sys.argv[2]), int(sys.argv[3]); show = "--show" in sys.argv
spec = importlib.util.spec_from_file_location("batch", path); m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
P = m.P
root = os.path.dirname(os.path.abspath(__file__))
q = {x["id"]: x["q"] for x in json.load(open(os.path.join(root, "..", "data", "practice_q.json")))["items"]}
problems = []
missing = [i for i in range(lo, hi + 1) if i not in P]; extra = [i for i in P if i < lo or i > hi]
if missing: problems.append(f"MISSING ids: {missing}")
if extra: problems.append(f"OUT-OF-RANGE ids: {extra}")
seen = {}
for i in sorted(P):
    if i < lo or i > hi: continue
    stdin, code = P[i]
    if code in seen: problems.append(f"{i}: identical code to {seen[code]}")
    seen[code] = i
    with tempfile.TemporaryDirectory() as d:
        src, exe = os.path.join(d, "a.c"), os.path.join(d, "a.out")
        open(src, "w").write(code + "\n")
        c = subprocess.run(["gcc", "-std=gnu99", "-Wall", "-Wextra", "-o", exe, src, "-lm"], capture_output=True, text=True)
        if c.returncode != 0: problems.append(f"{i}: COMPILE ERROR {c.stderr[:300]}"); continue
        if c.stderr.strip(): problems.append(f"{i}: WARNING {c.stderr[:300]}")
        try:
            r = subprocess.run([exe], input=stdin, capture_output=True, text=True, timeout=5, cwd=d)
        except subprocess.TimeoutExpired:
            problems.append(f"{i}: TIMEOUT (waits for more input or loops forever)"); continue
        if r.returncode != 0: problems.append(f"{i}: exit code {r.returncode} {r.stderr[:100]}")
        if not r.stdout.strip(): problems.append(f"{i}: EMPTY OUTPUT")
        if show: print(f"--- {i}: {q[i][:110]}\n[stdin: {stdin!r}]\n{r.stdout[:400]}")
print(f"checked {len([i for i in P if lo <= i <= hi])} programs, {len(problems)} problem(s)")
for p in problems: print(" ", p)
