# programs 801-900
P = {}
def add(i, code, stdin=""): P[i] = (stdin, code.strip("\n"))

add(801, r'''
#include <stdio.h>

int main(void)
{
    int value = 42;
    int *p = &value;
    printf("Value of value : %d\n", value);
    printf("Value via *p   : %d\n", *p);
    printf("p holds the address of value: %s\n", (p == &value) ? "yes" : "no");
    return 0;
}
''')
add(802, r'''
#include <stdio.h>

int main(void)
{
    int score = 70;
    int *ptr = NULL;            /* start with a safe, known value */
    printf("ptr is NULL before init: %s\n", ptr == NULL ? "yes" : "no");
    ptr = &score;               /* initialization */
    printf("*ptr = %d\n", *ptr);
    *ptr = 95;                  /* write through the pointer */
    printf("After *ptr = 95, score = %d\n", score);
    return 0;
}
''')
add(803, r'''
#include <stdio.h>

void swap(int *a, int *b)
{
    int temp = *a;
    *a = *b;
    *b = temp;
}

int main(void)
{
    int x = 15, y = 40;
    printf("Before: x = %d, y = %d\n", x, y);
    swap(&x, &y);
    printf("After : x = %d, y = %d\n", x, y);
    return 0;
}
''')
add(804, r'''
#include <stdio.h>

int *larger(int *a, int *b)
{
    return (*a >= *b) ? a : b;
}

int main(void)
{
    int m = 37, n = 52;
    int *big = larger(&m, &n);
    printf("m = %d, n = %d\n", m, n);
    printf("Larger value = %d\n", *big);
    printf("It is n: %s\n", big == &n ? "yes" : "no");
    return 0;
}
''')
add(805, r'''
#include <stdio.h>

int main(void)
{
    int a[6] = {4, 8, 15, 16, 23, 42};
    int *p = a;
    int *end = a + 6;
    int i = 0;
    while (p < end) {
        printf("a[%d] = %d\n", i, *p);
        p++;
        i++;
    }
    return 0;
}
''')
add(806, r'''
#include <stdio.h>

int main(void)
{
    int data[5] = {12, 7, 30, 5, 21};
    int *p;
    int sum = 0;
    for (p = data; p < data + 5; p++) {
        sum += *p;
    }
    printf("Sum of array = %d\n", sum);
    return 0;
}
''')
add(807, r'''
#include <stdio.h>

int main(void)
{
    const char *src = "Pointers are fun";
    char dest[40];
    const char *s = src;
    char *d = dest;
    while (*s != '\0') {
        *d++ = *s++;
    }
    *d = '\0';
    printf("Source : %s\n", src);
    printf("Copy   : %s\n", dest);
    return 0;
}
''')
add(808, r'''
#include <stdio.h>

int main(void)
{
    char text[] = "Hello World";
    char *left = text;
    char *right = text;
    while (*right != '\0') {
        right++;
    }
    right--;                        /* last real character */
    while (left < right) {
        char t = *left;
        *left = *right;
        *right = t;
        left++;
        right--;
    }
    printf("Reversed: %s\n", text);
    return 0;
}
''')
add(809, r'''
#include <stdio.h>

int main(void)
{
    const char *a = "apple";
    const char *b = "apricot";
    const char *p = a, *q = b;
    while (*p != '\0' && *p == *q) {
        p++;
        q++;
    }
    printf("\"%s\" vs \"%s\"\n", a, b);
    if (*p == *q) {
        printf("The strings are equal\n");
    } else {
        printf("They differ at position %d ('%c' vs '%c')\n", (int)(p - a), *p, *q);
        printf("%s comes first\n", (*p < *q) ? a : b);
    }
    return 0;
}
''')
add(810, r'''
#include <stdio.h>

int main(void)
{
    char line[80];
    char *p;
    int count = 0;
    printf("Enter a word: ");
    scanf("%79s", line);
    for (p = line; *p != '\0'; p++) {
        count++;
    }
    printf("\"%s\" has %d characters\n", line, count);
    return 0;
}
''', "programming")
add(811, r'''
#include <stdio.h>

void addBonus(int *marks, int bonus)
{
    *marks += bonus;
}

int main(void)
{
    int marks = 72;
    printf("Marks before: %d\n", marks);
    addBonus(&marks, 8);
    printf("Marks after : %d\n", marks);
    return 0;
}
''')
add(812, r'''
#include <stdio.h>

int main(void)
{
    int num = 100;
    int *p = &num;
    int **pp = &p;
    printf("num   = %d\n", num);
    printf("*p    = %d\n", *p);
    printf("**pp  = %d\n", **pp);
    **pp = 250;
    printf("After **pp = 250, num = %d\n", num);
    return 0;
}
''')
add(813, r'''
#include <stdio.h>

int main(void)
{
    const char *days[] = {"Monday", "Tuesday", "Wednesday", "Thursday", "Friday"};
    int i;
    for (i = 0; i < 5; i++) {
        printf("days[%d] = %s (first letter %c)\n", i, days[i], days[i][0]);
    }
    return 0;
}
''')
add(814, r'''
#include <stdio.h>

int main(void)
{
    int arr[4] = {10, 20, 30, 40};
    int (*pa)[4] = &arr;        /* pointer to an array of 4 ints */
    int i;
    printf("sizeof(*pa) = %zu bytes\n", sizeof(*pa));
    for (i = 0; i < 4; i++) {
        printf("(*pa)[%d] = %d\n", i, (*pa)[i]);
    }
    return 0;
}
''')
add(815, r'''
#include <stdio.h>

int add(int a, int b) { return a + b; }
int sub(int a, int b) { return a - b; }
int mul(int a, int b) { return a * b; }

int main(void)
{
    int (*op)(int, int);
    op = add;
    printf("12 + 5 = %d\n", op(12, 5));
    op = sub;
    printf("12 - 5 = %d\n", op(12, 5));
    op = mul;
    printf("12 * 5 = %d\n", op(12, 5));
    return 0;
}
''')
add(816, r'''
#include <stdio.h>

void sayHello(void) { printf("Hello from option 1\n"); }
void showDate(void) { printf("Option 2: pretend the date is shown here\n"); }
void sayBye(void)   { printf("Option 3: Goodbye\n"); }

int main(void)
{
    void (*menu[3])(void) = {sayHello, showDate, sayBye};
    int choice;
    printf("Menu: 1) Hello  2) Date  3) Bye  (0 to quit)\n");
    do {
        printf("Choice: ");
        if (scanf("%d", &choice) != 1) {
            break;
        }
        if (choice >= 1 && choice <= 3) {
            menu[choice - 1]();
        } else if (choice != 0) {
            printf("Invalid choice\n");
        }
    } while (choice != 0);
    return 0;
}
''', "2\n1\n7\n3\n0\n")
add(817, r'''
#include <stdio.h>

int *counter(void)
{
    static int count = 0;       /* lives for the whole program */
    count++;
    return &count;
}

int main(void)
{
    int i;
    for (i = 0; i < 3; i++) {
        int *p = counter();
        printf("Call %d: counter = %d\n", i + 1, *p);
    }
    return 0;
}
''')
add(818, r'''
#include <stdio.h>

void show(const int *p)
{
    if (p == NULL) {
        printf("Pointer is NULL, nothing to print\n");
    } else {
        printf("Value = %d\n", *p);
    }
}

int main(void)
{
    int x = 9;
    show(&x);
    show(NULL);
    return 0;
}
''')
add(819, r'''
#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int *p = malloc(sizeof *p);
    if (p == NULL) {
        printf("Error: out of memory\n");
        return 1;
    }
    *p = 77;
    printf("Stored value: %d\n", *p);
    free(p);
    p = NULL;
    printf("Memory freed\n");
    return 0;
}
''')
add(820, r'''
#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int n = 5, i, sum = 0;
    int *a = malloc(n * sizeof *a);
    if (a == NULL) {
        printf("Error: out of memory\n");
        return 1;
    }
    for (i = 0; i < n; i++) {
        a[i] = (i + 1) * 3;
        sum += a[i];
    }
    printf("Array values:");
    for (i = 0; i < n; i++) {
        printf(" %d", a[i]);
    }
    printf("\nSum = %d\n", sum);
    free(a);
    return 0;
}
''')
add(821, r'''
#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int i;
    int *a = malloc(3 * sizeof *a);
    int *bigger;
    if (a == NULL) {
        return 1;
    }
    for (i = 0; i < 3; i++) {
        a[i] = i + 1;
    }
    bigger = realloc(a, 6 * sizeof *a);
    if (bigger == NULL) {
        free(a);
        return 1;
    }
    a = bigger;
    for (i = 3; i < 6; i++) {
        a[i] = (i + 1) * 10;
    }
    printf("Resized array:");
    for (i = 0; i < 6; i++) {
        printf(" %d", a[i]);
    }
    printf("\n");
    free(a);
    return 0;
}
''')
add(822, r'''
#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int i;
    int *a = calloc(6, sizeof *a);
    if (a == NULL) {
        printf("Error: out of memory\n");
        return 1;
    }
    printf("calloc gives zeros:");
    for (i = 0; i < 6; i++) {
        printf(" %d", a[i]);
    }
    printf("\n");
    free(a);
    return 0;
}
''')
