# programs 301-400
P = {}
def add(i, code, stdin=""): P[i] = (stdin, code.strip("\n"))

add(301, r'''
#include <stdio.h>

int main(void)
{
    int n, i, prime = 1;
    printf("Enter a number: ");
    scanf("%d", &n);
    if (n < 2) {
        prime = 0;
    }
    for (i = 2; i * i <= n; i++) {
        if (n % i == 0) {
            prime = 0;
            break;
        }
    }
    printf("%d is %s\n", n, prime ? "a prime number" : "not a prime number");
    return 0;
}
''', "97")
add(302, r'''
#include <stdio.h>

int main(void)
{
    int lo, hi, n, i, prime, count = 0;
    printf("Enter lower and upper limits: ");
    scanf("%d %d", &lo, &hi);
    printf("Primes between %d and %d:\n", lo, hi);
    for (n = lo; n <= hi; n++) {
        prime = (n >= 2);
        for (i = 2; i * i <= n; i++) {
            if (n % i == 0) {
                prime = 0;
                break;
            }
        }
        if (prime) {
            printf("%d ", n);
            count++;
        }
    }
    printf("\nTotal: %d\n", count);
    return 0;
}
''', "10 60")
add(303, r'''
#include <stdio.h>

int main(void)
{
    int n, i, sum = 0;
    printf("Enter a number: ");
    scanf("%d", &n);
    for (i = 1; i <= n / 2; i++) {
        if (n % i == 0) {
            sum += i;
        }
    }
    if (n > 1 && sum == n) {
        printf("%d is a perfect number (sum of proper divisors = %d)\n", n, sum);
    } else {
        printf("%d is not a perfect number (sum of proper divisors = %d)\n", n, sum);
    }
    return 0;
}
''', "28")
add(304, r'''
#include <stdio.h>

int main(void)
{
    int lo, hi, n, i, sum;
    printf("Enter range (low high): ");
    scanf("%d %d", &lo, &hi);
    printf("Perfect numbers from %d to %d:\n", lo, hi);
    for (n = (lo < 2 ? 2 : lo); n <= hi; n++) {
        sum = 0;
        for (i = 1; i <= n / 2; i++) {
            if (n % i == 0) {
                sum += i;
            }
        }
        if (sum == n) {
            printf("%d\n", n);
        }
    }
    return 0;
}
''', "1 1000")
add(305, r'''
#include <stdio.h>

int main(void)
{
    int n, temp, digits = 0, i;
    long long sum = 0, power;
    printf("Enter a number: ");
    scanf("%d", &n);
    for (temp = n; temp > 0; temp /= 10) {
        digits++;
    }
    for (temp = n; temp > 0; temp /= 10) {
        power = 1;
        for (i = 0; i < digits; i++) {
            power *= temp % 10;
        }
        sum += power;
    }
    printf("Sum of digits raised to power %d = %lld\n", digits, sum);
    printf("%d is %san Armstrong number\n", n, sum == n ? "" : "not ");
    return 0;
}
''', "9474")
add(306, r'''
#include <stdio.h>

static long long power(int base, int exp)
{
    long long r = 1;
    while (exp-- > 0) {
        r *= base;
    }
    return r;
}

int main(void)
{
    int lo, hi, n, temp, digits;
    long long sum;
    printf("Enter range (low high): ");
    scanf("%d %d", &lo, &hi);
    printf("Armstrong numbers in [%d, %d]:\n", lo, hi);
    for (n = lo; n <= hi; n++) {
        digits = 0;
        for (temp = n; temp > 0; temp /= 10) {
            digits++;
        }
        sum = 0;
        for (temp = n; temp > 0; temp /= 10) {
            sum += power(temp % 10, digits);
        }
        if (n > 0 && sum == n) {
            printf("%d ", n);
        }
    }
    printf("\n");
    return 0;
}
''', "1 1000")
add(307, r'''
#include <stdio.h>

int main(void)
{
    int n, temp, rev = 0;
    printf("Enter a number: ");
    scanf("%d", &n);
    for (temp = n; temp > 0; temp /= 10) {
        rev = rev * 10 + temp % 10;
    }
    printf("Reverse of %d is %d\n", n, rev);
    printf("%d is %s\n", n, rev == n ? "a palindrome" : "not a palindrome");
    return 0;
}
''', "12321")
add(308, r'''
#include <stdio.h>

int is_palindrome(int n)
{
    int rev = 0, temp = n;
    while (temp > 0) {
        rev = rev * 10 + temp % 10;
        temp /= 10;
    }
    return rev == n;
}

int main(void)
{
    int lo, hi, n, count = 0;
    printf("Enter range (low high): ");
    scanf("%d %d", &lo, &hi);
    for (n = lo; n <= hi; n++) {
        if (is_palindrome(n)) {
            printf("%d ", n);
            count++;
        }
    }
    printf("\nFound %d palindromes\n", count);
    return 0;
}
''', "100 200")
add(309, r'''
#include <stdio.h>

int main(void)
{
    int n, temp, d, i, f, sum = 0;
    printf("Enter a number: ");
    scanf("%d", &n);
    for (temp = n; temp > 0; temp /= 10) {
        d = temp % 10;
        f = 1;
        for (i = 2; i <= d; i++) {
            f *= i;
        }
        printf("%d! = %d\n", d, f);
        sum += f;
    }
    printf("Sum of factorials = %d\n", sum);
    printf("%d is %sa strong number\n", n, sum == n ? "" : "not ");
    return 0;
}
''', "145")
add(310, r'''
#include <stdio.h>

int main(void)
{
    int fact[10] = {1, 1, 2, 6, 24, 120, 720, 5040, 40320, 362880};
    int lo, hi, n, temp, sum;
    printf("Enter range (low high): ");
    scanf("%d %d", &lo, &hi);
    printf("Strong numbers in range:\n");
    for (n = lo; n <= hi; n++) {
        sum = 0;
        for (temp = n; temp > 0; temp /= 10) {
            sum += fact[temp % 10];
        }
        if (n > 0 && sum == n) {
            printf("%d\n", n);
        }
    }
    return 0;
}
''', "1 100000")
add(311, r'''
#include <stdio.h>

int main(void)
{
    int n, temp, sum = 0;
    printf("Enter a number: ");
    scanf("%d", &n);
    for (temp = n; temp > 0; temp /= 10) {
        sum += temp % 10;
    }
    printf("Digit sum = %d\n", sum);
    if (sum > 0 && n % sum == 0) {
        printf("%d is a Harshad number (%d / %d = %d)\n", n, n, sum, n / sum);
    } else {
        printf("%d is not a Harshad number\n", n);
    }
    return 0;
}
''', "156")
add(312, r'''
#include <stdio.h>

int main(void)
{
    long long n, sq, mod = 1, temp;
    printf("Enter a number: ");
    scanf("%lld", &n);
    for (temp = n; temp > 0; temp /= 10) {
        mod *= 10;
    }
    sq = n * n;
    printf("Square = %lld, last digits = %lld\n", sq, sq % mod);
    printf("%lld is %san automorphic number\n", n, sq % mod == n ? "" : "not ");
    return 0;
}
''', "376")
add(313, r'''
#include <stdio.h>

int main(void)
{
    long long n, sq, sum = 0;
    printf("Enter a number: ");
    scanf("%lld", &n);
    sq = n * n;
    while (sq > 0) {
        sum += sq % 10;
        sq /= 10;
    }
    printf("Sum of digits of square of %lld = %lld\n", n, sum);
    printf("%lld is %sa neon number\n", n, sum == n ? "" : "not ");
    return 0;
}
''', "9")
add(314, r'''
#include <stdio.h>

int main(void)
{
    int n, temp, sum = 0, product = 1;
    printf("Enter a number: ");
    scanf("%d", &n);
    for (temp = n; temp > 0; temp /= 10) {
        sum += temp % 10;
        product *= temp % 10;
    }
    printf("Sum = %d, Product = %d\n", sum, product);
    printf("%d is %sa spy number\n", n, sum == product ? "" : "not ");
    return 0;
}
''', "1124")
add(315, r'''
#include <stdio.h>

int main(void)
{
    char s[20];
    int i, has_zero = 0;
    printf("Enter a number: ");
    scanf("%19s", s);
    /* A duck number has a zero digit but does not start with zero */
    for (i = 1; s[i] != '\0'; i++) {
        if (s[i] == '0') {
            has_zero = 1;
        }
    }
    if (has_zero && s[0] != '0') {
        printf("%s is a duck number\n", s);
    } else {
        printf("%s is not a duck number\n", s);
    }
    return 0;
}
''', "30405")
add(316, r'''
#include <stdio.h>

int main(void)
{
    int n, root = 1;
    printf("Enter a number: ");
    scanf("%d", &n);
    /* n is sunny if n+1 is a perfect square */
    while (root * root < n + 1) {
        root++;
    }
    if (root * root == n + 1) {
        printf("%d + 1 = %d = %d^2, so %d is a sunny number\n", n, n + 1, root, n);
    } else {
        printf("%d is not a sunny number\n", n);
    }
    return 0;
}
''', "35")
add(317, r'''
#include <stdio.h>

int main(void)
{
    int n, k = 0, sum = 0;
    printf("Enter a number: ");
    scanf("%d", &n);
    while (sum < n) {
        k++;
        sum += k;
    }
    if (sum == n && n > 0) {
        printf("%d is triangular: it is the sum of 1..%d\n", n, k);
    } else {
        printf("%d is not a triangular number\n", n);
    }
    return 0;
}
''', "55")
add(318, r'''
#include <stdio.h>

int main(void)
{
    long long n, i = 0;
    printf("Enter a number: ");
    scanf("%lld", &n);
    while (i * i < n) {
        i++;
    }
    if (n >= 0 && i * i == n) {
        printf("%lld is a perfect square (%lld x %lld)\n", n, i, i);
    } else {
        printf("%lld is not a perfect square\n", n);
    }
    return 0;
}
''', "144")
add(319, r'''
#include <stdio.h>

int main(void)
{
    long long n;
    printf("Enter a number: ");
    scanf("%lld", &n);
    /* a power of 2 has exactly one set bit */
    if (n > 0 && (n & (n - 1)) == 0) {
        printf("%lld is a power of 2\n", n);
    } else {
        printf("%lld is not a power of 2\n", n);
    }
    return 0;
}
''', "1024")
add(320, r'''
#include <stdio.h>

int main(void)
{
    int n, i;
    printf("Enter a positive number: ");
    scanf("%d", &n);
    printf("Factors of %d: ", n);
    for (i = 1; i <= n; i++) {
        if (n % i == 0) {
            printf("%d ", i);
        }
    }
    printf("\n");
    return 0;
}
''', "36")
add(321, r'''
#include <stdio.h>

int main(void)
{
    int n, i, count = 0;
    printf("Enter a positive number: ");
    scanf("%d", &n);
    for (i = 1; i * i <= n; i++) {
        if (n % i == 0) {
            count += (i * i == n) ? 1 : 2;
        }
    }
    printf("%d has %d factors\n", n, count);
    return 0;
}
''', "360")
add(322, r'''
#include <stdio.h>

int main(void)
{
    int n, i, sum = 0;
    printf("Enter a number: ");
    scanf("%d", &n);
    for (i = 1; i < n; i++) {
        if (n % i == 0) {
            sum += i;
        }
    }
    printf("Sum of proper divisors of %d = %d\n", n, sum);
    return 0;
}
''', "220")
add(323, r'''
#include <stdio.h>

int main(void)
{
    int a, b, i, gcd = 1;
    printf("Enter two integers: ");
    scanf("%d %d", &a, &b);
    if (a < 0) { a = -a; }
    if (b < 0) { b = -b; }
    /* try every candidate up to the smaller number */
    for (i = 1; i <= a && i <= b; i++) {
        if (a % i == 0 && b % i == 0) {
            gcd = i;
        }
    }
    printf("GCD(%d, %d) = %d\n", a, b, gcd);
    return 0;
}
''', "48 180")
add(324, r'''
#include <stdio.h>

int main(void)
{
    int a, b, big, lcm;
    printf("Enter two positive integers: ");
    scanf("%d %d", &a, &b);
    big = a > b ? a : b;
    lcm = big;
    while (lcm % a != 0 || lcm % b != 0) {
        lcm += big;
    }
    printf("LCM(%d, %d) = %d\n", a, b, lcm);
    return 0;
}
''', "12 18")
add(325, r'''
#include <stdio.h>

int main(void)
{
    int a, b, r;
    printf("Enter two integers: ");
    scanf("%d %d", &a, &b);
    printf("Euclid steps:\n");
    while (b != 0) {
        r = a % b;
        printf("%d = %d x %d + %d\n", a, b, a / b, r);
        a = b;
        b = r;
    }
    printf("GCD = %d\n", a);
    return 0;
}
''', "1071 462")
add(326, r'''
#include <stdio.h>

int main(void)
{
    int n, p, first = 1;
    printf("Enter an integer (>= 2): ");
    scanf("%d", &n);
    printf("%d = ", n);
    for (p = 2; p * p <= n; p++) {
        while (n % p == 0) {
            printf(first ? "%d" : " x %d", p);
            first = 0;
            n /= p;
        }
    }
    if (n > 1) {
        printf(first ? "%d" : " x %d", n);
    }
    printf("\n");
    return 0;
}
''', "360")
add(327, r'''
#include <stdio.h>

static int is_prime(int n)
{
    int i;
    if (n < 2) {
        return 0;
    }
    for (i = 2; i * i <= n; i++) {
        if (n % i == 0) {
            return 0;
        }
    }
    return 1;
}

int main(void)
{
    int lo, hi, n;
    printf("Enter range (low high): ");
    scanf("%d %d", &lo, &hi);
    printf("Twin primes:\n");
    for (n = lo; n + 2 <= hi; n++) {
        if (is_prime(n) && is_prime(n + 2)) {
            printf("(%d, %d)\n", n, n + 2);
        }
    }
    return 0;
}
''', "1 100")
add(328, r'''
#include <stdio.h>

static int divisor_sum(int n)
{
    int i, s = 0;
    for (i = 1; i < n; i++) {
        if (n % i == 0) {
            s += i;
        }
    }
    return s;
}

int main(void)
{
    int a, b, sa, sb;
    printf("Enter two numbers: ");
    scanf("%d %d", &a, &b);
    sa = divisor_sum(a);
    sb = divisor_sum(b);
    printf("Sum of proper divisors of %d = %d\n", a, sa);
    printf("Sum of proper divisors of %d = %d\n", b, sb);
    if (sa == b && sb == a && a != b) {
        printf("%d and %d are amicable numbers\n", a, b);
    } else {
        printf("%d and %d are not amicable numbers\n", a, b);
    }
    return 0;
}
''', "1184 1210")
add(329, r'''
#include <stdio.h>

int main(void)
{
    long long n, a = 0, b = 1, t;
    printf("Enter a number: ");
    scanf("%lld", &n);
    while (a < n) {
        t = a + b;
        a = b;
        b = t;
    }
    if (a == n && n >= 0) {
        printf("%lld is a Fibonacci number\n", n);
    } else {
        printf("%lld is not a Fibonacci number\n", n);
    }
    return 0;
}
''', "144")
add(330, r'''
#include <stdio.h>

int main(void)
{
    int limit, a = 0, b = 1, next;
    printf("Enter the limit: ");
    scanf("%d", &limit);
    printf("Fibonacci numbers up to %d:\n", limit);
    while (a <= limit) {
        printf("%d ", a);
        next = a + b;
        a = b;
        b = next;
    }
    printf("\n");
    return 0;
}
''', "500")
add(331, r'''
#include <stdio.h>

int main(void)
{
    int n, i;
    long long a = 0, b = 1, t;
    printf("Enter n (0 to 90): ");
    scanf("%d", &n);
    for (i = 0; i < n; i++) {
        t = a + b;
        a = b;
        b = t;
    }
    printf("Fibonacci(%d) = %lld\n", n, a);
    return 0;
}
''', "50")
add(332, r'''
#include <stdio.h>

int main(void)
{
    int n, temp, d, i, f, sum = 0;
    printf("Enter a number: ");
    scanf("%d", &n);
    for (temp = n; temp > 0; temp /= 10) {
        d = temp % 10;
        f = 1;
        for (i = 2; i <= d; i++) {
            f *= i;
        }
        sum += f;
    }
    printf("Sum of digit factorials = %d\n", sum);
    printf("%d is %sa Krishnamurthy number\n", n, sum == n ? "" : "not ");
    return 0;
}
''', "40585")
add(333, r'''
#include <stdio.h>

int main(void)
{
    int n, temp, digits = 0, pos, i;
    long long sum = 0, p;
    printf("Enter a number: ");
    scanf("%d", &n);
    for (temp = n; temp > 0; temp /= 10) {
        digits++;
    }
    pos = digits;
    for (temp = n; temp > 0; temp /= 10) {
        p = 1;
        for (i = 0; i < pos; i++) {
            p *= temp % 10;
        }
        sum += p;
        pos--;
    }
    printf("Sum of digits powered by position = %lld\n", sum);
    printf("%d is %sa Disarium number\n", n, sum == n ? "" : "not ");
    return 0;
}
''', "175")
add(334, r'''
#include <stdio.h>

int main(void)
{
    long long n, sq, div = 1, temp, left, right;
    printf("Enter a number: ");
    scanf("%lld", &n);
    for (temp = n; temp > 0; temp /= 10) {
        div *= 10;
    }
    sq = n * n;
    left = sq / div;
    right = sq % div;
    printf("%lld^2 = %lld, split into %lld + %lld\n", n, sq, left, right);
    if (n > 0 && left + right == n) {
        printf("%lld is a Kaprekar number\n", n);
    } else {
        printf("%lld is not a Kaprekar number\n", n);
    }
    return 0;
}
''', "297")
add(335, r'''
#include <stdio.h>

static int square_digit_sum(int n)
{
    int s = 0;
    while (n > 0) {
        s += (n % 10) * (n % 10);
        n /= 10;
    }
    return s;
}

int main(void)
{
    int n, x, steps = 0;
    printf("Enter a number: ");
    scanf("%d", &n);
    x = n;
    /* every unhappy number eventually reaches 4 */
    while (x != 1 && x != 4) {
        x = square_digit_sum(x);
        printf("-> %d\n", x);
        steps++;
    }
    printf("%d is %s (after %d steps)\n", n, x == 1 ? "a happy number" : "not a happy number", steps);
    return 0;
}
''', "19")
add(336, r'''
#include <stdio.h>

int main(void)
{
    int n, temp;
    printf("Enter a number: ");
    scanf("%d", &n);
    temp = n;
    /* reduce to a single digit by repeated digit sums */
    while (temp > 9) {
        int sum = 0;
        while (temp > 0) {
            sum += temp % 10;
            temp /= 10;
        }
        temp = sum;
    }
    /* magic number: the final single digit is 1 */
    printf("%d is %sa magic number\n", n, temp == 1 ? "" : "not ");
    return 0;
}
''', "1729")
add(337, r'''
#include <stdio.h>

int main(void)
{
    int n;
    printf("Enter a number: ");
    scanf("%d", &n);
    if (n % 7 == 0 && n % 10 == 7) {
        printf("%d is a buzz number (divisible by 7 and ends with 7)\n", n);
    } else if (n % 7 == 0) {
        printf("%d is a buzz number (divisible by 7)\n", n);
    } else if (n % 10 == 7) {
        printf("%d is a buzz number (ends with 7)\n", n);
    } else {
        printf("%d is not a buzz number\n", n);
    }
    return 0;
}
''', "147")
add(338, r'''
#include <stdio.h>

int main(void)
{
    /* cyclic number: n*1 .. n*(digits) are rotations of n; test 142857 */
    int n, k, multiple, digits = 0, temp, i, cyclic = 1;
    int seen[10] = {0};
    printf("Enter a number: ");
    scanf("%d", &n);
    for (temp = n; temp > 0; temp /= 10) {
        digits++;
    }
    for (k = 1; k <= digits; k++) {
        int d[10] = {0};
        multiple = n * k;
        for (temp = multiple; temp > 0; temp /= 10) {
            d[temp % 10]++;
        }
        for (temp = n, i = 0; temp > 0; temp /= 10) {
            seen[temp % 10]++;
        }
        for (i = 0; i < 10; i++) {
            if (d[i] != seen[i] / k) {
                cyclic = 0;
            }
        }
        for (i = 0; i < 10; i++) {
            seen[i] = 0;
        }
        printf("%d x %d = %d\n", n, k, multiple);
    }
    printf("%d is %sa cyclic number\n", n, cyclic ? "" : "not ");
    return 0;
}
''', "142857")
add(339, r'''
#include <stdio.h>

int main(void)
{
    long long n, sum;
    printf("Enter an integer: ");
    scanf("%lld", &n);
    if (n < 0) {
        n = -n;
    }
    while (n > 9) {
        sum = 0;
        while (n > 0) {
            sum += n % 10;
            n /= 10;
        }
        printf("Digit sum = %lld\n", sum);
        n = sum;
    }
    printf("Digital root = %lld\n", n);
    return 0;
}
''', "987654321")
add(340, r'''
#include <stdio.h>

int main(void)
{
    int n, i, j, prime;
    long long sum = 0;
    printf("Enter N: ");
    scanf("%d", &n);
    for (i = 2; i <= n; i++) {
        prime = 1;
        for (j = 2; j * j <= i; j++) {
            if (i % j == 0) {
                prime = 0;
                break;
            }
        }
        if (prime) {
            sum += i;
        }
    }
    printf("Sum of primes up to %d = %lld\n", n, sum);
    return 0;
}
''', "100")
add(341, r'''
#include <stdio.h>

int main(void)
{
    long long n, product = 1;
    printf("Enter an integer: ");
    scanf("%lld", &n);
    if (n < 0) {
        n = -n;
    }
    do {
        product *= n % 10;
        n /= 10;
    } while (n > 0);
    printf("Product of digits = %lld\n", product);
    return 0;
}
''', "2357")
add(342, r'''
#include <stdio.h>

int main(void)
{
    long long n, k = 0;
    printf("Enter a number: ");
    scanf("%lld", &n);
    while (k * (k + 1) < n) {
        k++;
    }
    if (n >= 0 && k * (k + 1) == n) {
        printf("%lld = %lld x %lld, so it is a pronic number\n", n, k, k + 1);
    } else {
        printf("%lld is not a pronic number\n", n);
    }
    return 0;
}
''', "156")
add(343, r'''
#include <stdio.h>

int main(void)
{
    long long n, f = 1, i = 1;
    printf("Enter a number: ");
    scanf("%lld", &n);
    while (f < n) {
        i++;
        f *= i;
    }
    if (f == n) {
        printf("%lld is a factorial number (%lld! = %lld)\n", n, i, n);
    } else {
        printf("%lld is not a factorial number\n", n);
    }
    return 0;
}
''', "720")
add(344, r'''
#include <stdio.h>

int main(void)
{
    int n, base, digits[40], count = 0, i, pal = 1;
    printf("Enter number and base (2-16): ");
    scanf("%d %d", &n, &base);
    if (base < 2 || base > 16 || n < 0) {
        printf("Error: invalid input\n");
        return 0;
    }
    do {
        digits[count++] = n % base;
        n /= base;
    } while (n > 0);
    printf("Digits in base %d (least significant first): ", base);
    for (i = 0; i < count; i++) {
        printf("%d ", digits[i]);
        if (digits[i] != digits[count - 1 - i]) {
            pal = 0;
        }
    }
    printf("\n%s\n", pal ? "Palindrome in this base" : "Not a palindrome in this base");
    return 0;
}
''', "585 2")
add(345, r'''
#include <stdio.h>

int main(void)
{
    int lo, hi, n, i, sum;
    printf("Enter range (low high): ");
    scanf("%d %d", &lo, &hi);
    printf("Abundant numbers:\n");
    for (n = lo < 1 ? 1 : lo; n <= hi; n++) {
        sum = 0;
        for (i = 1; i <= n / 2; i++) {
            if (n % i == 0) {
                sum += i;
            }
        }
        if (sum > n) {
            printf("%d (divisor sum %d)\n", n, sum);
        }
    }
    return 0;
}
''', "1 50")
