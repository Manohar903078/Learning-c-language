# programs 1-50  : id -> (stdin, code)
P = {}
def add(i, code, stdin=""): P[i] = (stdin, code.strip("\n"))

add(1, r'''
#include <stdio.h>

int main(void)
{
    printf("Hello, World!\n");
    return 0;
}
''')
add(2, r'''
#include <stdio.h>

int main(void)
{
    printf("Name    : Ravi Kumar\n");
    printf("College : LearnC Institute of Technology\n");
    printf("Branch  : Computer Science\n");
    printf("Year    : 2nd Year\n");
    return 0;
}
''')
add(3, r'''
#include <stdio.h>

int main(void)
{
    printf("===== STUDENT BIO =====\n");
    printf("Name   : Sita Devi\n");
    printf("Age    : 19\n");
    printf("Course : B.Tech (CSE)\n");
    printf("Hobby  : Coding and music\n");
    return 0;
}
''')
add(4, r'''
#include <stdio.h>

int main(void)
{
    printf("**********\n");
    printf("*        *\n");
    printf("*        *\n");
    printf("*        *\n");
    printf("**********\n");
    return 0;
}
''')
add(5, r'''
#include <stdio.h>

int main(void)
{
    int a = 25, b = 17;
    printf("%d + %d = %d\n", a, b, a + b);
    return 0;
}
''')
add(6, r'''
#include <stdio.h>

int main(void)
{
    int a = 50, b = 18;
    printf("%d - %d = %d\n", a, b, a - b);
    return 0;
}
''')
add(7, r'''
#include <stdio.h>

int main(void)
{
    int a = 12, b = 7;
    printf("%d x %d = %d\n", a, b, a * b);
    return 0;
}
''')
add(8, r'''
#include <stdio.h>

int main(void)
{
    int a = 47, b = 5;
    printf("Quotient  = %d\n", a / b);
    printf("Remainder = %d\n", a % b);
    return 0;
}
''')
add(9, r'''
#include <stdio.h>

int main(void)
{
    char ch = 'A';
    printf("ASCII value of '%c' is %d\n", ch, ch);
    return 0;
}
''')
add(10, r'''
#include <stdio.h>

int main(void)
{
    int code = 97;
    printf("ASCII %d represents the character '%c'\n", code, code);
    return 0;
}
''')
add(11, r'''
#include <stdio.h>

int main(void)
{
    int    age   = 20;
    float  price = 99.5f;
    double pi    = 3.141592653589;
    char   grade = 'A';

    printf("int    : %d\n", age);
    printf("float  : %f\n", price);
    printf("double : %lf\n", pi);
    printf("char   : %c\n", grade);
    return 0;
}
''')
add(12, r'''
#include <stdio.h>

int main(void)
{
    printf("Line one\nLine two\n");
    printf("Name\tMarks\n");
    printf("Ravi\t90\n");
    printf("Path: C:\\Users\\Student\n");
    return 0;
}
''')
add(13, r'''
#include <stdio.h>

int main(void)
{
    printf("%-10s %-10s %s\n", "Item", "Quantity", "Price");
    printf("%-10s %-10d %.2f\n", "Pen", 10, 5.50);
    printf("%-10s %-10d %.2f\n", "Notebook", 4, 40.00);
    printf("%-10s %-10d %.2f\n", "Eraser", 2, 3.25);
    return 0;
}
''')
add(14, r'''
#include <stdio.h>

int main(void)
{
    int    i = 42;
    float  f = 3.14159f;
    double d = 2.718281828;
    char   c = 'Z';

    printf("%%d  -> %d\n", i);
    printf("%%f  -> %f\n", f);
    printf("%%lf -> %lf\n", d);
    printf("%%c  -> %c\n", c);
    return 0;
}
''')
add(15, r'''
#include <stdio.h>   /* needed for printf */

int main(void)       /* program starts here */
{
    int a = 6;       /* first number  */
    int b = 4;       /* second number */
    int sum;         /* to store result */

    sum = a + b;                       /* add the numbers */
    printf("Sum = %d\n", sum);         /* show the result */
    return 0;                          /* end of program  */
}
''')
add(16, r'''
#include <stdio.h>

int main(void)
{
    printf("+------------------+\n");
    printf("|                  |\n");
    printf("|   LEARN C FAST   |\n");
    printf("|                  |\n");
    printf("+------------------+\n");
    return 0;
}
''')
add(17, r'''
#include <stdio.h>

int main(void)
{
    printf("He said, \"C is the mother of many languages.\"\n");
    return 0;
}
''')
add(18, r'''
#include <stdio.h>

int main(void)
{
    float x = 7.56789f;
    printf("Value with 2 decimals = %.2f\n", x);
    return 0;
}
''')
add(19, r'''
#include <stdio.h>

int main(void)
{
    int total = 135;
    printf("%d minutes = %d hour(s) and %d minute(s)\n", total, total / 60, total % 60);
    return 0;
}
''')
add(20, r'''
#include <stdio.h>

int main(void)
{
    printf("Size of char   = %zu byte(s)\n", sizeof(char));
    printf("Size of int    = %zu byte(s)\n", sizeof(int));
    printf("Size of float  = %zu byte(s)\n", sizeof(float));
    printf("Size of double = %zu byte(s)\n", sizeof(double));
    return 0;
}
''')
add(21, r'''
#include <stdio.h>

int main(void)
{
    int choice;
    printf("1. Greeting\n2. Joke\n3. Quote\nEnter choice: ");
    scanf("%d", &choice);

    if (choice == 1)      printf("Hello! Welcome to C.\n");
    else if (choice == 2) printf("Why do programmers prefer dark mode? Light attracts bugs!\n");
    else if (choice == 3) printf("Practice makes a programmer perfect.\n");
    else                  printf("Invalid choice.\n");
    return 0;
}
''', "2")
add(22, r'''
#include <stdio.h>

int main(void)
{
    printf("Program finished successfully.\n");
    return 0;   /* 0 tells the operating system: no error */
}
''')
add(23, r'''
#include <stdio.h>

int main(void)
{
    printf("========== INVOICE ==========\n");
    printf("%-12s %3s %8s %9s\n", "Item", "Qty", "Rate", "Amount");
    printf("%-12s %3d %8.2f %9.2f\n", "Notebook", 5, 40.00, 5 * 40.00);
    printf("%-12s %3d %8.2f %9.2f\n", "Pen", 10, 12.50, 10 * 12.50);
    printf("-----------------------------\n");
    printf("%-12s %22.2f\n", "TOTAL", 5 * 40.00 + 10 * 12.50);
    return 0;
}
''')
add(24, r'''
#include <stdio.h>

int main(void)
{
    printf("   /\\\n");
    printf("  /  \\\n");
    printf(" /____\\\n");
    printf(" |    |\n");
    printf(" |____|\n");
    return 0;
}
''')
add(25, r'''
#include <stdio.h>

int main(void)
{
    puts("C is powerful.");
    puts("C is fast.");
    puts("C is the base of many languages.");
    return 0;
}
''')
add(26, r'''
#include <stdio.h>

int main(void)
{
    char word[50];
    printf("Enter a word: ");
    scanf("%49s", word);
    printf("Hello, %s!\n", word);
    return 0;
}
''', "World")
add(27, r'''
#include <stdio.h>

void showDetails(void)          /* user-defined function */
{
    printf("Name    : Ravi Kumar\n");
    printf("College : LearnC Institute of Technology\n");
    printf("Branch  : Computer Science\n");
    printf("Year    : 2nd Year\n");
}

int main(void)
{
    showDetails();
    return 0;
}
''')
add(28, r'''
#include <stdio.h>

int main(void)
{
    char name[40];
    int age;

    printf("Enter name and age: ");
    if (scanf("%39s %d", name, &age) != 2) {
        printf("Error: please enter a name followed by a number.\n");
        return 1;
    }
    if (age < 1 || age > 100) {
        printf("Error: age must be between 1 and 100.\n");
        return 1;
    }
    printf("--- Student Bio ---\n");
    printf("Name : %s\n", name);
    printf("Age  : %d\n", age);
    return 0;
}
''', "Sita 19")
add(29, r'''
#include <stdio.h>

void rectangle(int rows, int cols)
{
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++)
            printf("*");
        printf("\n");
    }
}

int main(void)
{
    printf("Test 1 (2 x 5)\n"); rectangle(2, 5);
    printf("Test 2 (3 x 3)\n"); rectangle(3, 3);
    printf("Test 3 (1 x 8)\n"); rectangle(1, 8);
    return 0;
}
''')
add(30, r'''
#include <stdio.h>

int main(void)
{
    int a = 120;      /* first fixed number  */
    int b = 80;       /* second fixed number */
    int sum = a + b;  /* addition operator + */

    printf("Sum of %d and %d is %d\n", a, b, sum);
    return 0;
}
''')
add(31, r'''
#include <stdio.h>
#include <limits.h>

int main(void)
{
    long long a = INT_MIN, b = 1;           /* boundary case: smallest int */
    long long diff = a - b;                 /* long long avoids overflow   */

    printf("%lld - %lld = %lld\n", a, b, diff);
    if (diff < INT_MIN)
        printf("Note: result does not fit in a normal int.\n");
    return 0;
}
''')
add(32, r'''
#include <stdio.h>

int main(void)
{
    int choice, a = 9, b = 8;
    do {
        printf("\n1. Multiply %d x %d\n2. Exit\nChoice: ", a, b);
        scanf("%d", &choice);
        if (choice == 1)
            printf("Product = %d\n", a * b);
        else if (choice != 2)
            printf("Invalid choice\n");
    } while (choice != 2);
    return 0;
}
''', "1\n2")
add(33, r'''
#include <stdio.h>

int main(void)
{
    int a = 47, b = 5;
    int q = a / b;
    int r = a % b;

    printf("Step 1: %d / %d = %d (quotient)\n", a, b, q);
    printf("Step 2: %d %% %d = %d (remainder)\n", a, b, r);
    printf("Check : %d x %d + %d = %d\n", b, q, r, b * q + r);
    return 0;
}
''')
add(34, r'''
#include <stdio.h>

int main(void)
{
    char text[] = "HELLO";
    for (int i = 0; text[i] != '\0'; i++)
        printf("'%c' -> %d\n", text[i], text[i]);
    return 0;
}
''')
add(35, r'''
#include <stdio.h>

int main(void)
{
    int codes[] = {72, 101, 108, 108, 111};
    int *p = codes;

    for (int i = 0; i < 5; i++)
        printf("%d -> %c\n", *(p + i), *(p + i));
    return 0;
}
''')
add(36, r'''
#include <stdio.h>

int main(void)
{
    int    ages[3]   = {18, 19, 20};
    float  fees[3]   = {1200.5f, 1500.75f, 1800.0f};
    double pi[2]     = {3.14159, 2.71828};
    char   grades[3] = {'A', 'B', 'C'};

    for (int i = 0; i < 3; i++)
        printf("age=%d fee=%.2f grade=%c\n", ages[i], fees[i], grades[i]);
    printf("pi=%lf e=%lf\n", pi[0], pi[1]);
    return 0;
}
''')
add(37, r'''
#include <stdio.h>

struct Escape {
    const char *name;
    const char *meaning;
};

int main(void)
{
    struct Escape list[] = { {"\\n", "new line"}, {"\\t", "tab"}, {"\\\\", "backslash"} };

    printf("Line1\nLine2\n");
    printf("A\tB\tC\n");
    printf("Backslash: \\\n");
    for (int i = 0; i < 3; i++)
        printf("%s = %s\n", list[i].name, list[i].meaning);
    return 0;
}
''')
add(38, r'''
#include <stdio.h>

int main(void)
{
    const char *item[] = {"Pen", "Book", "Bag", "Ruler"};
    int   qty[]   = {10, 5, 1, 4};
    float price[] = {5.5f, 60.0f, 450.0f, 12.25f};

    printf("%-8s %-5s %8s\n", "Item", "Qty", "Price");
    for (int i = 0; i < 4; i++)
        printf("%-8s %-5d %8.2f\n", item[i], qty[i], price[i]);
    return 0;
}
''')
add(39, r'''
#include <stdio.h>

int main(void)
{
    int i = 100; float f = 12.5f; double d = 9.87654321; char c = 'K';

    printf("+----------+--------------+\n");
    printf("| Specifier| Output       |\n");
    printf("+----------+--------------+\n");
    printf("| %%d       | %-12d |\n", i);
    printf("| %%f       | %-12f |\n", f);
    printf("| %%lf      | %-12lf |\n", d);
    printf("| %%c       | %-12c |\n", c);
    printf("+----------+--------------+\n");
    return 0;
}
''')
add(40, r'''
#include <stdio.h>

int main(void)
{
    int n;                                  /* number to read */
    printf("Enter an integer: ");
    if (scanf("%d", &n) == 1)               /* scanf returns count read */
        printf("You entered %d\n", n);
    else
        printf("Invalid input!\n");         /* validation message */
    return 0;
}
''', "42")
add(41, r'''
#include <stdio.h>

void line(void)  { printf("+-----------+\n"); }
void empty(void) { printf("|           |\n"); }
void title(void) { printf("| Learn  C  |\n"); }

int main(void)
{
    line(); empty(); title(); empty(); line();
    return 0;
}
''')
add(42, r'''
#include <stdio.h>

int main(void)
{
    /* Time cost : O(1) - one printf call.
       Space cost: O(1) - no extra variables.   */
    printf("The teacher said, \"Practice daily!\"\n");
    return 0;
}
''')
add(43, r'''
#include <stdio.h>

int main(void)
{
    float tests[] = {3.14159f, 0.0f, 0.005f, 99999.999f};   /* normal, zero, tiny, big */
    for (int i = 0; i < 4; i++)
        printf("%f -> %.2f\n", tests[i], tests[i]);
    return 0;
}
''')
add(44, r'''
#include <stdio.h>

void convert(int minutes, int *h, int *m)     /* no global variables used */
{
    *h = minutes / 60;
    *m = minutes % 60;
}

int main(void)
{
    int h, m;
    convert(135, &h, &m);
    printf("135 minutes = %d h %d min\n", h, m);
    return 0;
}
''')
add(45, r'''
#include <stdio.h>

int main(void)
{
    size_t s_int = sizeof(int), s_char = sizeof(char);
    size_t s_float = sizeof(float), s_double = sizeof(double);

    if (s_int == 0 || s_char == 0 || s_float == 0 || s_double == 0) {
        printf("Error: could not determine a size\n");
        return 1;
    }
    printf("char=%zu int=%zu float=%zu double=%zu\n", s_char, s_int, s_float, s_double);
    return 0;
}
''')
add(46, r'''
#include <stdio.h>

int main(void)
{
    int a = 15, b = 6;
    /* Time: O(1) - a single multiplication.
       Space: O(1) - three integers only.   */
    printf("%d x %d = %d\n", a, b, a * b);
    return 0;
}
''')
add(47, r'''
#include <stdio.h>

int main(void)
{
    char ch;
    printf("Enter a character: ");
    scanf(" %c", &ch);
    printf("ASCII value of '%c' = %d\n", ch, ch);
    return 0;
}
''', "G")
add(48, r'''
#include <stdio.h>

int main(void)
{
    int    count = 10;        /* whole number           */
    float  rate  = 2.5f;      /* decimal, 6 digits      */
    double big   = 123456.789012; /* decimal, more digits */
    char   ch    = 'x';       /* single character       */

    printf("%d %.1f %.3lf %c\n", count, rate, big, ch);
    return 0;
}
''')
add(49, r'''
#include <stdio.h>

int main(void)
{
    char *item[] = {"Apple", "Banana", "Mango"};
    int qty[] = {6, 12, 3};
    float price[] = {20.0f, 5.5f, 35.0f};

    printf("%-8s%5s%9s\n", "Item", "Qty", "Price");
    for (int i = 0; i < 3; i++)
        printf("%-8s%5d%9.2f\n", item[i], qty[i], price[i]);
    return 0;
}
''')
add(50, r'''
#include <stdio.h>

int main(void)
{
    int values[] = {4, 8, 15, 16, 23, 42};   /* list of numbers   */
    int n = 6, sum = 0;                      /* count and total   */

    for (int i = 0; i < n; i++) {            /* visit each value  */
        sum += values[i];                    /* add it to total   */
    }
    printf("Sum = %d\n", sum);               /* print the total   */
    return 0;
}
''')
