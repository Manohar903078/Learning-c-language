import re, json, sys
SP = "/tmp/claude-0/-home-claude/ee77387a-eaf2-5d55-9ff3-14931cba7379/scratchpad/ex/"
OUT = "/home/claude/app/data/"

def clean_lines(path, footer):
    out = []
    for ln in open(path, encoding="utf-8").read().split("\n"):
        ln = ln.rstrip()
        if not ln.strip(): continue
        ln = re.sub(footer + r".*?Page \d+", "", ln).strip()
        if not ln or re.match(footer, ln): continue
        out.append(ln)
    return out

def fix(t):
    t = t.replace("■", "\\0")
    return re.sub(r"\s+", " ", t).strip()

# ---------- practice ----------
lines = clean_lines(SP + "practice.txt", r"C Programming Practice Question Bank")
topics, cur, items = [], None, []
LV = re.compile(r"^(BASIC|INTERMEDIATE|ADVANCED) • Questions (\d+)[–-](\d+)")
for idx, ln in enumerate(lines):
    nxt = lines[idx+1] if idx+1 < len(lines) else ""
    m = re.match(r"^(\d{2})\. (.+)$", ln)
    if m and LV.match(nxt):
        cur = {"no": int(m.group(1)), "title": m.group(2).strip(), "level": None, "range": None}
        topics.append(cur); continue
    m = LV.match(ln)
    if m and cur is not None:
        cur["level"] = m.group(1).title(); cur["range"] = [int(m.group(2)), int(m.group(3))]; continue
    m = re.match(r"^(\d{1,4})\. (.+)$", ln)
    if m and cur is not None and cur["range"]:
        items.append({"id": int(m.group(1)), "topic": cur["no"], "q": m.group(2)}); continue
    if items and cur is not None:
        items[-1]["q"] += " " + ln.strip()
for it in items: it["q"] = fix(it["q"])
print("practice topics", len(topics), "items", len(items))
ids = [x["id"] for x in items]
assert ids == list(range(1, 2001)), (ids[:5], len(ids), [a for a,b in zip(ids, range(1,2001)) if a!=b][:5])
json.dump({"topics": topics, "items": items}, open(OUT + "practice_q.json", "w"), ensure_ascii=False)

# ---------- interview ----------
lines = clean_lines(SP + "interview.txt", r"C Programming Interview Question Bank")
secs, items, expected = [], [], 1
started = False
for ln in lines:
    if not started:
        if re.match(r"^1\. C Fundamentals", ln.strip()): started = True
        else: continue
    s = ln.strip()
    m = re.match(r"^(\d{1,4})\. (.+)$", s)
    if m:
        n, t = int(m.group(1)), m.group(2)
        is_header = (not t.rstrip().endswith(("?", "."))) and (n <= 25 and (len(secs)+1 == n))
        if is_header:
            secs.append({"no": n, "title": t.strip()}); continue
        if n == expected:
            items.append({"id": n, "sec": len(secs), "q": t}); expected += 1; continue
    if items: items[-1]["q"] += " " + s
for it in items: it["q"] = fix(it["q"])
print("interview sections", len(secs), "items", len(items))
assert len(items) == 2000, len(items)
json.dump({"sections": secs, "items": items}, open(OUT + "interview_q.json", "w"), ensure_ascii=False)
print([ (s["no"], s["title"]) for s in secs][:30])
