# programs 101-200
P = {}
def add(i, code, stdin=""): P[i] = (stdin, code.strip("\n"))

add(101, r'''
#include <stdio.h>

int main(void)
{
    int a = 17, b = 5;
    printf("a = %d, b = %d\n", a, b);
    printf("a + b = %d\n", a + b);
    printf("a - b = %d\n", a - b);
    printf("a * b = %d\n", a * b);
    printf("a / b = %d (integer division)\n", a / b);
    printf("a %% b = %d (remainder)\n", a % b);
    return 0;
}
''')
add(102, r'''
#include <stdio.h>

int main(void)
{
    int x = 5, y;
    y = ++x;   /* x becomes 6 first, then y gets 6 */
    printf("Pre-increment : x = %d, y = %d\n", x, y);
    x = 5;
    y = x++;   /* y gets 5 first, then x becomes 6 */
    printf("Post-increment: x = %d, y = %d\n", x, y);
    return 0;
}
''')
add(103, r'''
#include <stdio.h>

int main(void)
{
    int n = 10, r;
    r = --n;
    printf("Pre-decrement : n = %d, r = %d\n", n, r);
    n = 10;
    r = n--;
    printf("Post-decrement: n = %d, r = %d\n", n, r);
    return 0;
}
''')
add(104, r'''
#include <stdio.h>

int main(void)
{
    int a = 4, b = 6, c = 2;
    int r1 = a + b * c;        /* * before + */
    int r2 = (a + b) * c;      /* brackets first */
    int r3 = a + b / c - 1;    /* / before + and - */
    int r4 = a * b % 5 + c;    /* * and % same level, left to right */
    printf("a + b * c       = %d\n", r1);
    printf("(a + b) * c     = %d\n", r2);
    printf("a + b / c - 1   = %d\n", r3);
    printf("a * b %% 5 + c   = %d\n", r4);
    return 0;
}
''')
add(105, r'''
#include <stdio.h>

int main(void)
{
    int a = 12, b = 20;
    printf("a = %d, b = %d\n", a, b);
    printf("a == b : %d\n", a == b);
    printf("a != b : %d\n", a != b);
    printf("a <  b : %d\n", a < b);
    printf("a >  b : %d\n", a > b);
    printf("a <= b : %d\n", a <= b);
    printf("a >= b : %d\n", a >= b);
    return 0;
}
''')
add(106, r'''
#include <stdio.h>

int main(void)
{
    int age = 25, hasId = 1;
    printf("age = %d, hasId = %d\n", age, hasId);
    printf("(age >= 18) && hasId : %d\n", (age >= 18) && hasId);
    printf("(age < 18) || hasId  : %d\n", (age < 18) || hasId);
    printf("!hasId               : %d\n", !hasId);
    printf("!(age > 30)          : %d\n", !(age > 30));
    return 0;
}
''')
add(107, r'''
#include <stdio.h>

int main(void)
{
    int x = 20;
    printf("Start : x = %d\n", x);
    x += 5;  printf("x += 5  -> %d\n", x);
    x -= 3;  printf("x -= 3  -> %d\n", x);
    x *= 2;  printf("x *= 2  -> %d\n", x);
    x /= 4;  printf("x /= 4  -> %d\n", x);
    x %= 5;  printf("x %%= 5  -> %d\n", x);
    return 0;
}
''')
add(108, r'''
#include <stdio.h>

int main(void)
{
    int a = 42, b = 58;
    int larger = (a > b) ? a : b;
    printf("a = %d, b = %d\n", a, b);
    printf("Larger number = %d\n", larger);
    return 0;
}
''')
add(109, r'''
#include <stdio.h>

int main(void)
{
    int a = 33, b = 12, c = 27;
    /* smaller of a and b, then compare with c */
    int small = (a < b) ? a : b;
    small = (small < c) ? small : c;
    printf("Numbers: %d %d %d\n", a, b, c);
    printf("Smallest = %d\n", small);
    return 0;
}
''')
add(110, r'''
#include <stdio.h>

int main(void)
{
    int n;
    printf("Enter an integer: ");
    scanf("%d", &n);
    if (n % 2 == 0) {
        printf("%d is even.\n", n);
    } else {
        printf("%d is not even.\n", n);
    }
    return 0;
}
''', "48")
add(111, r'''
#include <stdio.h>

int main(void)
{
    char ch;
    printf("Enter a character: ");
    scanf(" %c", &ch);
    if ((ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z')) {
        printf("'%c' is an alphabet.\n", ch);
    } else {
        printf("'%c' is not an alphabet.\n", ch);
    }
    return 0;
}
''', "k")
add(112, r'''
#include <stdio.h>

int main(void)
{
    int a = 12, b = 10;   /* 1100 and 1010 in binary */
    printf("a = %d, b = %d\n", a, b);
    printf("a & b = %d\n", a & b);
    printf("a | b = %d\n", a | b);
    printf("a ^ b = %d\n", a ^ b);
    return 0;
}
''')
add(113, r'''
#include <stdio.h>

int main(void)
{
    int n = 6;
    printf("n = %d\n", n);
    printf("n << 1 = %d (multiply by 2)\n", n << 1);
    printf("n << 3 = %d (multiply by 8)\n", n << 3);
    printf("n >> 1 = %d (divide by 2)\n", n >> 1);
    printf("n >> 2 = %d (divide by 4)\n", n >> 2);
    return 0;
}
''')
add(114, r'''
#include <stdio.h>

int main(void)
{
    unsigned int num, pos;
    printf("Enter a number and a bit position (0-31): ");
    scanf("%u %u", &num, &pos);
    if (pos > 31) {
        printf("Position must be 0 to 31.\n");
        return 0;
    }
    printf("Before: %u\n", num);
    num = num | (1u << pos);    /* OR with a 1 at the position sets it */
    printf("After setting bit %u: %u\n", pos, num);
    return 0;
}
''', "10 2")
add(115, r'''
#include <stdio.h>

int main(void)
{
    unsigned int num, pos;
    printf("Enter a number and a bit position (0-31): ");
    scanf("%u %u", &num, &pos);
    if (pos > 31) {
        printf("Position must be 0 to 31.\n");
        return 0;
    }
    printf("Before: %u\n", num);
    num = num & ~(1u << pos);   /* AND with a 0 at the position clears it */
    printf("After clearing bit %u: %u\n", pos, num);
    return 0;
}
''', "15 1")
add(116, r'''
#include <stdio.h>

int main(void)
{
    unsigned int num, pos;
    printf("Enter a number and a bit position (0-31): ");
    scanf("%u %u", &num, &pos);
    if (pos > 31) {
        printf("Position must be 0 to 31.\n");
        return 0;
    }
    printf("Before: %u\n", num);
    num = num ^ (1u << pos);    /* XOR flips the bit */
    printf("After toggling bit %u: %u\n", pos, num);
    num = num ^ (1u << pos);
    printf("Toggled again: %u\n", num);
    return 0;
}
''', "37 3")
add(117, r'''
#include <stdio.h>

int main(void)
{
    int n;
    printf("Enter an integer: ");
    scanf("%d", &n);
    if ((n & 1) == 0) {     /* last bit 0 means even */
        printf("%d is even.\n", n);
    } else {
        printf("%d is odd.\n", n);
    }
    return 0;
}
''', "-27")
add(118, r'''
#include <stdio.h>

int main(void)
{
    int a = 7, b = 3;
    double c = 2.5;
    int t1 = a / b;
    double t2 = (double)a / b;
    double t3 = t2 * c;
    double result = t1 + t3 - a % b;
    printf("a = %d, b = %d, c = %.1f\n", a, b, c);
    printf("a / b            = %d\n", t1);
    printf("(double)a / b    = %.3f\n", t2);
    printf("t2 * c           = %.3f\n", t3);
    printf("a %% b            = %d\n", a % b);
    printf("t1 + t3 - a %% b  = %.3f\n", result);
    return 0;
}
''')
add(119, r'''
#include <stdio.h>

int main(void)
{
    int a, b;
    printf("Enter dividend and divisor (positive): ");
    scanf("%d %d", &a, &b);
    if (a <= 0 || b <= 0) {
        printf("Both numbers must be positive.\n");
        return 0;
    }
    /* a - (a / b) * b equals a % b */
    int rem = a - (a / b) * b;
    printf("Remainder of %d / %d = %d\n", a, b, rem);
    return 0;
}
''', "47 6")
add(120, r'''
#include <stdio.h>

int main(void)
{
    int a, b, c;
    /* comma operator: evaluates left to right, value is the last one */
    a = (b = 1, c = 2, b + c);
    printf("a = (b=1, c=2, b+c) -> a = %d\n", a);
    b = (a++, a * 10);
    printf("b = (a++, a*10) -> a = %d, b = %d\n", a, b);
    for (a = 0, c = 10; a < c; a += 3, c -= 3) {
        printf("loop: a = %d, c = %d\n", a, c);
    }
    return 0;
}
''')
add(121, r'''
#include <stdio.h>

int main(void)
{
    int n;
    printf("Enter a number: ");
    scanf("%d", &n);
    printf("%d is %s.\n", n, (n == 0) ? "zero" : "not zero");
    return 0;
}
''', "0")
add(122, r'''
#include <stdio.h>

int main(void)
{
    int a[4] = {17, -17, 17, -17};
    int b[4] = {5, 5, -5, -5};
    int i;
    /* C99: integer division truncates toward zero */
    for (i = 0; i < 4; i++) {
        printf("%4d / %2d = %3d, %4d %% %2d = %2d\n",
               a[i], b[i], a[i] / b[i], a[i], b[i], a[i] % b[i]);
    }
    return 0;
}
''')
add(123, r'''
#include <stdio.h>

int main(void)
{
    int p, q;
    printf("p q | p&&q p||q !p\n");
    for (p = 0; p <= 1; p++) {
        for (q = 0; q <= 1; q++) {
            printf("%d %d |  %d    %d   %d\n", p, q, p && q, p || q, !p);
        }
    }
    return 0;
}
''')
add(124, r'''
#include <stdio.h>

#define READ  1
#define WRITE 2
#define EXEC  4

int main(void)
{
    int perm = READ | WRITE;     /* combine two flags */
    printf("READ|WRITE = %d\n", perm);
    perm = perm | EXEC;
    printf("Add EXEC   = %d\n", perm);
    printf("Has WRITE? %s\n", (perm & WRITE) ? "yes" : "no");
    return 0;
}
''')
add(125, r'''
#include <stdio.h>

int main(void)
{
    int n;
    int mask = 1 << 3;    /* fourth bit (bit index 3) = 8 */
    printf("Enter a number: ");
    scanf("%d", &n);
    if (n & mask) {
        printf("%d has the fourth bit set.\n", n);
    } else {
        printf("%d does not have the fourth bit set.\n", n);
    }
    return 0;
}
''', "26")
add(126, r'''
#include <stdio.h>

int main(void)
{
    int a, b;
    printf("Enter first integer: ");
    scanf("%d", &a);
    printf("Enter second integer: ");
    scanf("%d", &b);
    printf("%d + %d = %d\n", a, b, a + b);
    printf("%d - %d = %d\n", a, b, a - b);
    printf("%d * %d = %d\n", a, b, a * b);
    if (b != 0) {
        printf("%d / %d = %d\n", a, b, a / b);
        printf("%d %% %d = %d\n", a, b, a % b);
    } else {
        printf("Division and modulus skipped: second number is zero.\n");
    }
    return 0;
}
''', "84\n13\n")
add(127, r'''
#include <stdio.h>

/* Shows both forms of increment on a copy of the value */
void demoIncrement(int start)
{
    int x = start;
    int pre = ++x;
    printf("start=%d -> pre-increment gives %d, x is now %d\n", start, pre, x);
    x = start;
    int post = x++;
    printf("start=%d -> post-increment gives %d, x is now %d\n", start, post, x);
}

int main(void)
{
    demoIncrement(7);
    demoIncrement(-1);
    return 0;
}
''')
add(128, r'''
#include <stdio.h>

int main(void)
{
    int n, pre, post, copy;
    printf("Enter an integer between -1000 and 1000: ");
    if (scanf("%d", &n) != 1) {
        printf("Error: that is not an integer.\n");
        return 0;
    }
    if (n < -1000 || n > 1000) {
        printf("Error: %d is outside the allowed range.\n", n);
        return 0;
    }
    copy = n;
    pre = --copy;
    printf("Pre-decrement : result = %d, variable = %d\n", pre, copy);
    copy = n;
    post = copy--;
    printf("Post-decrement: result = %d, variable = %d\n", post, copy);
    return 0;
}
''', "250\n")
add(129, r'''
#include <stdio.h>

int main(void)
{
    int i, a, b, c, d;
    for (i = 1; i <= 3; i++) {
        printf("Test %d - enter a b c d: ", i);
        scanf("%d %d %d %d", &a, &b, &c, &d);
        /* * and / first, then + and - from left to right */
        printf("a + b * c - d = %d\n", a + b * c - d);
        printf("(a + b) * (c - d) = %d\n", (a + b) * (c - d));
    }
    return 0;
}
''', "2 3 4 5\n10 0 7 1\n-3 8 2 9\n")
add(130, r'''
#include <stdio.h>

int main(void)
{
    int a, b;
    printf("Enter two integers: ");
    scanf("%d %d", &a, &b);

    /* Each relational operator yields 1 (true) or 0 (false) */
    printf("%d == %d is %d\n", a, b, a == b);
    printf("%d != %d is %d\n", a, b, a != b);
    printf("%d > %d is %d\n", a, b, a > b);
    printf("%d < %d is %d\n", a, b, a < b);

    /* Use the results to describe the relation in words */
    if (a > b) {
        printf("%d is greater than %d\n", a, b);
    } else if (a < b) {
        printf("%d is less than %d\n", a, b);
    } else {
        printf("Both numbers are equal\n");
    }
    return 0;
}
''', "15 -4\n")
add(131, r'''
#include <stdio.h>
#include <limits.h>

int main(void)
{
    int values[5] = {INT_MIN, -1, 0, 1, INT_MAX};
    int i;
    printf("%12s | truth | !v | v&&1 | v||0\n", "value");
    for (i = 0; i < 5; i++) {
        int v = values[i];
        /* any non-zero value counts as true, including negatives */
        printf("%12d |   %d   |  %d |   %d   |  %d\n",
               v, v != 0, !v, v && 1, v || 0);
    }
    return 0;
}
''')
add(132, r'''
#include <stdio.h>

int main(void)
{
    int x = 100, choice, amount;
    do {
        printf("\nx = %d\n", x);
        printf("1.+=  2.-=  3.*=  4./=  5.%%=  0.Exit\nChoice: ");
        if (scanf("%d", &choice) != 1) {
            break;
        }
        if (choice >= 1 && choice <= 5) {
            printf("Amount: ");
            scanf("%d", &amount);
            if (choice == 1) {
                x += amount;
            } else if (choice == 2) {
                x -= amount;
            } else if (choice == 3) {
                x *= amount;
            } else if (amount == 0) {
                printf("Amount cannot be zero here.\n");
            } else if (choice == 4) {
                x /= amount;
            } else {
                x %= amount;
            }
        } else if (choice != 0) {
            printf("Invalid choice.\n");
        }
    } while (choice != 0);
    printf("Final x = %d\n", x);
    return 0;
}
''', "1\n50\n3\n2\n4\n7\n5\n0\n9\n0\n")
add(133, r'''
#include <stdio.h>

int main(void)
{
    int a, b, larger;
    printf("Enter two numbers: ");
    scanf("%d %d", &a, &b);
    printf("Step 1: test (a > b) -> (%d > %d) = %d\n", a, b, a > b);
    larger = (a > b) ? a : b;
    printf("Step 2: condition is %s, so pick %s\n",
           (a > b) ? "true" : "false", (a > b) ? "a" : "b");
    printf("Larger number = %d\n", larger);
    return 0;
}
''', "-8 -3\n")
add(134, r'''
#include <stdio.h>

int main(void)
{
    int nums[3], i, smallest;
    for (i = 0; i < 3; i++) {
        printf("Enter number %d: ", i + 1);
        scanf("%d", &nums[i]);
    }
    smallest = nums[0];
    for (i = 1; i < 3; i++) {
        smallest = (nums[i] < smallest) ? nums[i] : smallest;
    }
    printf("Smallest of the three = %d\n", smallest);
    return 0;
}
''', "44\n19\n63\n")
add(135, r'''
#include <stdio.h>

/* Receives the address of the number and reads it through the pointer */
int isEven(const int *p)
{
    return (*p % 2 == 0);
}

int main(void)
{
    int n;
    int *ptr = &n;
    printf("Enter an integer: ");
    scanf("%d", ptr);
    if (isEven(ptr)) {
        printf("%d is even.\n", *ptr);
    } else {
        printf("%d is odd.\n", *ptr);
    }
    return 0;
}
''', "91\n")
add(136, r'''
#include <stdio.h>

int main(void)
{
    char text[21];
    int i;
    printf("Enter up to 20 characters (no spaces): ");
    scanf("%20s", text);
    for (i = 0; text[i] != '\0'; i++) {
        char ch = text[i];
        if ((ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z')) {
            printf("'%c' -> alphabet\n", ch);
        } else {
            printf("'%c' -> not an alphabet\n", ch);
        }
    }
    return 0;
}
''', "C9_x#\n")
add(137, r'''
#include <stdio.h>

struct Pair {
    unsigned int first;
    unsigned int second;
};

int main(void)
{
    struct Pair p;
    printf("Enter two non-negative integers: ");
    scanf("%u %u", &p.first, &p.second);
    printf("%u & %u = %u\n", p.first, p.second, p.first & p.second);
    printf("%u | %u = %u\n", p.first, p.second, p.first | p.second);
    printf("%u ^ %u = %u\n", p.first, p.second, p.first ^ p.second);
    return 0;
}
''', "45 27\n")
add(138, r'''
#include <stdio.h>

int main(void)
{
    int n, i;
    int values[10];
    printf("How many values (1-10)? ");
    scanf("%d", &n);
    if (n < 1 || n > 10) {
        printf("Count must be between 1 and 10.\n");
        return 0;
    }
    printf("Enter %d positive integers: ", n);
    for (i = 0; i < n; i++) {
        scanf("%d", &values[i]);
    }
    printf("%6s %8s %8s\n", "value", "<< 2", ">> 1");
    for (i = 0; i < n; i++) {
        printf("%6d %8d %8d\n", values[i], values[i] << 2, values[i] >> 1);
    }
    return 0;
}
''', "5\n1 8 13 100 255\n")
add(139, r'''
#include <stdio.h>

int main(void)
{
    unsigned int num = 20, pos = 0;
    unsigned int result;
    printf("Enter number and bit position (0-7): ");
    scanf("%u %u", &num, &pos);
    if (pos > 7) {
        printf("Position out of range.\n");
        return 0;
    }
    result = num | (1u << pos);
    printf("+------------------+-------+\n");
    printf("| %-16s | %5u |\n", "Original number", num);
    printf("| %-16s | %5u |\n", "Bit position", pos);
    printf("| %-16s | %5u |\n", "After setting", result);
    printf("+------------------+-------+\n");
    return 0;
}
''', "20 3\n")
add(140, r'''
#include <stdio.h>

int main(void)
{
    int num, pos;
    printf("Enter a non-negative number and a bit position (0-30): ");
    if (scanf("%d %d", &num, &pos) != 2) {
        printf("Error: please enter two integers.\n");
        return 0;
    }
    if (num < 0) {
        printf("Error: number must not be negative.\n");
        return 0;
    }
    if (pos < 0 || pos > 30) {
        printf("Error: bit position must be 0 to 30.\n");
        return 0;
    }
    printf("%d with bit %d cleared = %d\n", num, pos, num & ~(1 << pos));
    return 0;
}
''', "255 4\n")
add(141, r'''
#include <stdio.h>

unsigned int toggleBit(unsigned int n, int pos)
{
    return n ^ (1u << pos);
}

int isValidPos(int pos)
{
    return pos >= 0 && pos < 32;
}

void showBits(unsigned int n)
{
    int i;
    for (i = 7; i >= 0; i--) {
        printf("%u", (n >> i) & 1u);
    }
}

int main(void)
{
    unsigned int n;
    int pos;
    printf("Enter a number (0-255) and bit position: ");
    scanf("%u %d", &n, &pos);
    if (!isValidPos(pos) || n > 255) {
        printf("Invalid input.\n");
        return 0;
    }
    printf("Before: ");
    showBits(n);
    printf(" (%u)\n", n);
    n = toggleBit(n, pos);
    printf("After : ");
    showBits(n);
    printf(" (%u)\n", n);
    return 0;
}
''', "90 5\n")
add(142, r'''
#include <stdio.h>

/* Time: O(1) - one AND operation per number. Space: O(1) - no extra memory. */
int main(void)
{
    int n, i;
    int nums[4];
    printf("Enter 4 integers: ");
    for (i = 0; i < 4; i++) {
        scanf("%d", &nums[i]);
    }
    /* The whole loop is O(k) for k numbers; each check is a single bit test */
    for (i = 0; i < 4; i++) {
        n = nums[i];
        printf("%d is %s\n", n, (n & 1) ? "odd" : "even");
    }
    return 0;
}
''', "10 7 -4 0\n")
add(143, r'''
#include <stdio.h>
#include <limits.h>

/* expression: (a + b) * 2 - a / 3, calculated in long long to avoid overflow */
void evaluate(const char *label, int a, int b)
{
    long long sum = (long long)a + b;
    long long doubled = sum * 2;
    long long third = a / 3;
    printf("%s: a=%d b=%d\n", label, a, b);
    printf("  a + b = %lld\n  (a + b) * 2 = %lld\n  a / 3 = %lld\n", sum, doubled, third);
    printf("  result = %lld\n", doubled - third);
}

int main(void)
{
    evaluate("Normal ", 30, 12);
    evaluate("Minimum", INT_MIN, INT_MIN);
    evaluate("Maximum", INT_MAX, INT_MAX);
    return 0;
}
''')
add(144, r'''
#include <stdio.h>

int remainderOf(int a, int b)
{
    int quotient = a / b;
    return a - quotient * b;
}

int main(void)
{
    int a, b;
    printf("Enter positive dividend and divisor: ");
    if (scanf("%d %d", &a, &b) != 2 || a <= 0 || b <= 0) {
        printf("Please enter two positive integers.\n");
        return 0;
    }
    printf("%d - (%d / %d) * %d = %d\n", a, a, b, b, remainderOf(a, b));
    return 0;
}
''', "1000 33\n")
add(145, r'''
#include <stdio.h>

int main(void)
{
    int a, b, total, i;
    printf("Enter a start value and a limit: ");
    if (scanf("%d %d", &a, &b) != 2) {
        printf("Error: two integers are required.\n");
        return 1;
    }
    /* comma operator in for: two variables updated together */
    for (i = a, total = 0; i <= b; i++, total += i) {
        printf("i=%d total=%d\n", i, total);
    }
    total = (a = 5, b = 6, a * b);
    printf("Value of (a=5, b=6, a*b) = %d\n", total);
    return 0;
}
''', "1 4\n")
add(146, r'''
#include <stdio.h>

/* Each compound assignment is a single operation: Time O(1), Space O(1). */
int main(void)
{
    int n = 9;
    n += 6;
    printf("n += 6  -> %d\n", n);
    n <<= 2;
    printf("n <<= 2 -> %d\n", n);
    n &= 0x3C;
    printf("n &= 0x3C -> %d\n", n);
    n |= 3;
    printf("n |= 3  -> %d\n", n);
    n ^= 5;
    printf("n ^= 5  -> %d\n", n);
    n >>= 1;
    printf("n >>= 1 -> %d\n", n);
    return 0;
}
''')
add(147, r'''
#include <stdio.h>

int main(void)
{
    int a, b, c, smallest;
    printf("Enter three integers: ");
    scanf("%d %d %d", &a, &b, &c);
    smallest = (a < b) ? ((a < c) ? a : c) : ((b < c) ? b : c);
    printf("The smallest of %d, %d and %d is %d\n", a, b, c, smallest);
    return 0;
}
''', "72 -15 40\n")
add(148, r'''
#include <stdio.h>

int main(void)
{
    char ch;
    printf("Enter a character: ");
    scanf(" %c", &ch);

    /* Letters occupy two continuous ranges in ASCII: 'A'-'Z' and 'a'-'z' */
    if (ch >= 'A' && ch <= 'Z') {
        printf("'%c' is an uppercase alphabet.\n", ch);
    } else if (ch >= 'a' && ch <= 'z') {
        printf("'%c' is a lowercase alphabet.\n", ch);
    } else {
        /* anything else is a digit, symbol, etc. */
        printf("'%c' is not an alphabet.\n", ch);
    }
    return 0;
}
''', "M\n")
add(149, r'''
#include <stdio.h>

int main(void)
{
    int n = 3, i;
    printf("Left shifts of %d:\n", n);
    for (i = 0; i <= 4; i++) {
        printf("  %d << %d = %d\n", n, i, n << i);
    }
    n = 200;
    printf("Right shifts of %d:\n", n);
    for (i = 0; i <= 4; i++) {
        printf("  %d >> %d = %d\n", n, i, n >> i);
    }
    return 0;
}
''')
add(150, r'''
#include <stdio.h>

int main(void)
{
    int count, i;
    unsigned int num[8], pos[8];
    printf("How many records (1-8)? ");
    scanf("%d", &count);
    if (count < 1 || count > 8) {
        printf("Invalid count.\n");
        return 0;
    }
    for (i = 0; i < count; i++) {
        printf("Record %d - number and bit position: ", i + 1);
        scanf("%u %u", &num[i], &pos[i]);
    }
    for (i = 0; i < count; i++) {
        if (pos[i] > 31) {
            printf("Record %d: bad position %u\n", i + 1, pos[i]);
        } else {
            printf("Record %d: %u -> %u\n", i + 1, num[i], num[i] & ~(1u << pos[i]));
        }
    }
    return 0;
}
''', "4\n255 0\n64 6\n9 1\n7 40\n")
