import glob, importlib.util, os, sys
H=os.path.dirname(os.path.abspath(__file__))
def load(p):
    s=importlib.util.spec_from_file_location("m",p); m=importlib.util.module_from_spec(s); s.loader.exec_module(m); return m.P
files=sorted(glob.glob(H+"/progs/q*.py"))+sorted(glob.glob(H+"/progs/p*.py"))+sorted(glob.glob(H+"/prog_[c-j].py"))
P={}
for f in files:
    for k,v in load(f).items():
        if 101<=k<=1000 and k not in P: P[k]=v
