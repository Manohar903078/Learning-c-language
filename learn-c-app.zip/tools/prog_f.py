# programs 401-500
P = {}
def add(i, code, stdin=""): P[i] = (stdin, code.strip("\n"))

add(401, r'''
#include <stdio.h>

int main(void)
{
    int size = 5;
    for (int r = 0; r < size; r++) {
        for (int c = 0; c < size; c++) {
            printf("* ");
        }
        printf("\n");
    }
    return 0;
}
''')
add(402, r'''
#include <stdio.h>

int main(void)
{
    int size = 6;
    for (int r = 0; r < size; r++) {
        for (int c = 0; c < size; c++) {
            if (r == 0 || r == size - 1 || c == 0 || c == size - 1) {
                printf("* ");
            } else {
                printf("  ");
            }
        }
        printf("\n");
    }
    return 0;
}
''')
add(403, r'''
#include <stdio.h>

int main(void)
{
    int rows = 5;
    for (int i = 1; i <= rows; i++) {
        for (int j = 1; j <= i; j++) {
            printf("* ");
        }
        printf("\n");
    }
    return 0;
}
''')
add(404, r'''
#include <stdio.h>

int main(void)
{
    int rows = 6;
    for (int i = rows; i >= 1; i--) {
        for (int j = 1; j <= i; j++) {
            printf("* ");
        }
        printf("\n");
    }
    return 0;
}
''')
add(405, r'''
#include <stdio.h>

int main(void)
{
    int rows = 5;
    for (int i = 1; i <= rows; i++) {
        for (int j = 1; j <= i; j++) {
            printf("%d ", j);
        }
        printf("\n");
    }
    return 0;
}
''')
add(406, r'''
#include <stdio.h>

int main(void)
{
    int rows = 5;
    for (int i = rows; i >= 1; i--) {
        for (int j = 1; j <= i; j++) {
            printf("%d ", j);
        }
        printf("\n");
    }
    return 0;
}
''')
add(407, r'''
#include <stdio.h>

int main(void)
{
    int rows = 5;
    for (int i = 1; i <= rows; i++) {
        for (int s = 0; s < rows - i; s++) {
            printf(" ");
        }
        for (int j = 0; j < 2 * i - 1; j++) {
            printf("*");
        }
        printf("\n");
    }
    return 0;
}
''')
add(408, r'''
#include <stdio.h>

int main(void)
{
    int rows = 5;
    for (int i = rows; i >= 1; i--) {
        for (int s = 0; s < rows - i; s++) {
            printf(" ");
        }
        for (int j = 0; j < 2 * i - 1; j++) {
            printf("*");
        }
        printf("\n");
    }
    return 0;
}
''')
add(409, r'''
#include <stdio.h>

int main(void)
{
    int n = 4;
    for (int i = 1; i <= n; i++) {
        printf("%*s", n - i, "");
        for (int j = 0; j < 2 * i - 1; j++) {
            printf("*");
        }
        printf("\n");
    }
    for (int i = n - 1; i >= 1; i--) {
        printf("%*s", n - i, "");
        for (int j = 0; j < 2 * i - 1; j++) {
            printf("*");
        }
        printf("\n");
    }
    return 0;
}
''')
add(410, r'''
#include <stdio.h>

int main(void)
{
    int n = 5;
    int width = 2 * n - 1;
    for (int r = 0; r < width; r++) {
        int k = (r < n) ? r : width - 1 - r;   /* distance from the middle row's top */
        int left = n - 1 - k;
        int right = n - 1 + k;
        for (int c = 0; c < width; c++) {
            if (c == left || c == right) {
                printf("*");
            } else if (c < right) {
                printf(" ");
            }
        }
        printf("\n");
    }
    return 0;
}
''')
add(411, r'''
#include <stdio.h>

int main(void)
{
    int n = 5;
    for (int i = 1; i <= n; i++) {
        for (int j = 0; j < i; j++) {
            printf("*");
        }
        printf("\n");
    }
    for (int i = n - 1; i >= 1; i--) {
        for (int j = 0; j < i; j++) {
            printf("*");
        }
        printf("\n");
    }
    return 0;
}
''')
add(412, r'''
#include <stdio.h>

int main(void)
{
    int n = 4;
    for (int i = 1; i <= n; i++) {
        printf("%.*s", i, "****");
        printf("%*s", 2 * (n - i), "");
        printf("%.*s", i, "****");
        printf("\n");
    }
    for (int i = n; i >= 1; i--) {
        printf("%.*s", i, "****");
        printf("%*s", 2 * (n - i), "");
        printf("%.*s", i, "****");
        printf("\n");
    }
    return 0;
}
''')
add(413, r'''
#include <stdio.h>

int main(void)
{
    int rows = 6;
    for (int i = 1; i <= rows; i++) {
        for (int j = 1; j <= i; j++) {
            if (j == 1 || j == i || i == rows) {
                printf("* ");
            } else {
                printf("  ");
            }
        }
        printf("\n");
    }
    return 0;
}
''')
add(414, r'''
#include <stdio.h>

int main(void)
{
    int rows = 5, width = 6;
    for (int i = 0; i < rows; i++) {
        printf("%*s", rows - 1 - i, "");
        for (int j = 0; j < width; j++) {
            printf("*");
        }
        printf("\n");
    }
    return 0;
}
''')
add(415, r'''
#include <stdio.h>

int main(void)
{
    int rows = 4, width = 7;
    for (int i = 0; i < rows; i++) {
        printf("%*s", i * 2, "");   /* shift each row right to slant it */
        for (int j = 0; j < width; j++) {
            printf("*");
        }
        printf("\n");
    }
    return 0;
}
''')
add(416, r'''
#include <stdio.h>

int main(void)
{
    int rows = 6;
    for (int i = 1; i <= rows; i++) {
        for (int s = 0; s < rows - i; s++) {
            printf("  ");
        }
        for (int j = 0; j < i; j++) {
            printf("* ");
        }
        printf("\n");
    }
    return 0;
}
''')
add(417, r'''
#include <stdio.h>

int main(void)
{
    int rows = 6, number = 1;
    for (int i = 1; i <= rows; i++) {
        for (int j = 1; j <= i; j++) {
            printf("%3d", number);
            number++;
        }
        printf("\n");
    }
    return 0;
}
''')
add(418, r'''
#include <stdio.h>

int main(void)
{
    int rows = 7;
    for (int i = 0; i < rows; i++) {
        int value = 1;
        printf("%*s", (rows - 1 - i) * 2, "");
        for (int j = 0; j <= i; j++) {
            printf("%4d", value);
            value = value * (i - j) / (j + 1);   /* next C(i, j+1) */
        }
        printf("\n");
    }
    return 0;
}
''')
add(419, r'''
#include <stdio.h>

int main(void)
{
    int rows = 5;
    for (int i = 1; i <= rows; i++) {
        printf("%*s", rows - i, "");
        for (int j = 1; j <= i; j++) {
            printf("%d", i);
            if (j < i) {
                printf(" ");
            }
        }
        printf("\n");
    }
    return 0;
}
''')
add(420, r'''
#include <stdio.h>

int main(void)
{
    int rows = 5;
    for (int i = 1; i <= rows; i++) {
        printf("%*s", rows - i, "");
        for (int j = 1; j <= i; j++) {
            printf("%d", j);
        }
        for (int j = i - 1; j >= 1; j--) {
            printf("%d", j);
        }
        printf("\n");
    }
    return 0;
}
''')
add(421, r'''
#include <stdio.h>

int main(void)
{
    int rows = 5;
    for (int i = 1; i <= rows; i++) {
        for (int j = 1; j <= i; j++) {
            printf("%d ", i);
        }
        printf("\n");
    }
    return 0;
}
''')
add(422, r'''
#include <stdio.h>

int main(void)
{
    int rows = 6;
    for (int i = 1; i <= rows; i++) {
        for (int j = 1; j <= i; j++) {
            printf("%d ", (i + j) % 2);
        }
        printf("\n");
    }
    return 0;
}
''')
add(423, r'''
#include <stdio.h>

int main(void)
{
    int rows = 5;
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j <= i; j++) {
            printf("%c ", 'A' + j);
        }
        printf("\n");
    }
    return 0;
}
''')
add(424, r'''
#include <stdio.h>

int main(void)
{
    int rows = 5;
    for (int i = rows; i >= 1; i--) {
        for (int j = 0; j < i; j++) {
            printf("%c ", 'A' + j);
        }
        printf("\n");
    }
    return 0;
}
''')
add(425, r'''
#include <stdio.h>

int main(void)
{
    int rows = 5;
    char letter = 'A';
    for (int i = 1; i <= rows; i++) {
        for (int j = 1; j <= i; j++) {
            printf("%c ", letter);
            letter = (letter == 'Z') ? 'A' : letter + 1;   /* wrap after Z */
        }
        printf("\n");
    }
    return 0;
}
''')
add(426, r'''
#include <stdio.h>

int main(void)
{
    int rows = 6;
    for (int i = 1; i <= rows; i++) {
        printf("%*s", rows - i, "");
        for (int j = 1; j <= 2 * i - 1; j++) {
            if (j == 1 || j == 2 * i - 1 || i == rows) {
                printf("*");
            } else {
                printf(" ");
            }
        }
        printf("\n");
    }
    return 0;
}
''')
add(427, r'''
#include <stdio.h>

int main(void)
{
    int rows = 5, cols = 9;
    for (int r = 0; r < rows; r++) {
        for (int c = 0; c < cols; c++) {
            if (r == 0 || r == rows - 1 || c == 0 || c == cols - 1) {
                printf("*");
            } else {
                printf(" ");
            }
        }
        printf("\n");
    }
    return 0;
}
''')
add(428, r'''
#include <stdio.h>

int main(void)
{
    int size = 8;
    for (int r = 0; r < size; r++) {
        for (int c = 0; c < size; c++) {
            printf("%c ", ((r + c) % 2 == 0) ? '#' : '.');
        }
        printf("\n");
    }
    return 0;
}
''')
add(429, r'''
#include <stdio.h>

int main(void)
{
    int size = 7;
    for (int r = 0; r < size; r++) {
        for (int c = 0; c < size; c++) {
            if (r == c || r + c == size - 1) {
                printf("*");
            } else {
                printf(" ");
            }
        }
        printf("\n");
    }
    return 0;
}
''')
add(430, r'''
#include <stdio.h>

int main(void)
{
    int size = 7, mid = size / 2;
    for (int r = 0; r < size; r++) {
        for (int c = 0; c < size; c++) {
            if (r == mid || c == mid) {
                printf("*");
            } else {
                printf(" ");
            }
        }
        printf("\n");
    }
    return 0;
}
''')
add(431, r'''
#include <stdio.h>

int main(void)
{
    int n = 5;
    for (int i = n; i >= 1; i--) {          /* top half: inverted pyramid */
        printf("%*s", n - i, "");
        for (int j = 0; j < 2 * i - 1; j++) {
            printf("*");
        }
        printf("\n");
    }
    for (int i = 2; i <= n; i++) {          /* bottom half: upright pyramid */
        printf("%*s", n - i, "");
        for (int j = 0; j < 2 * i - 1; j++) {
            printf("*");
        }
        printf("\n");
    }
    return 0;
}
''')
add(432, r'''
#include <stdio.h>

int main(void)
{
    int n = 4, size = 2 * n - 1;
    for (int r = 0; r < size; r++) {
        for (int c = 0; c < size; c++) {
            int top = r, left = c, bottom = size - 1 - r, right = size - 1 - c;
            int layer = top;
            if (left < layer) { layer = left; }
            if (bottom < layer) { layer = bottom; }
            if (right < layer) { layer = right; }
            printf("%d ", n - layer);
        }
        printf("\n");
    }
    return 0;
}
''')
add(433, r'''
#include <stdio.h>

int main(void)
{
    int n = 6;
    printf("Multiplication grid 1 to %d\n", n);
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= n; j++) {
            printf("%4d", i * j);
        }
        printf("\n");
    }
    return 0;
}
''')
add(434, r'''
#include <stdio.h>

int main(void)
{
    int steps = 6;
    for (int i = 1; i <= steps; i++) {
        printf("%*s", steps - i, "");
        for (int j = 0; j < i; j++) {
            printf("#");
        }
        printf("\n");
    }
    return 0;
}
''')
add(435, r'''
#include <stdio.h>

int main(void)
{
    int rows = 6;
    for (int i = 1; i <= rows; i++) {
        for (int j = 1; j <= i; j++) {
            printf("%d ", i);
        }
        printf("\n");
    }
    return 0;
}
''')
add(436, r'''
#include <stdio.h>

int main(void)
{
    int rows = 5, cols = 8;
    for (int r = 0; r < rows; r++) {
        for (int c = 0; c < cols; c++) {
            printf("%d ", (r + c + 1) % 2);   /* starts each row with 1 or 0 alternately */
        }
        printf("\n");
    }
    return 0;
}
''')
add(437, r'''
#include <stdio.h>

int main(void)
{
    int rows = 7;
    for (int i = 1; i <= rows; i++) {
        for (int j = 1; j <= i; j++) {
            if (j == 1 || j == i || i == rows) {
                printf("*");
            } else {
                printf(" ");
            }
        }
        printf("\n");
    }
    return 0;
}
''')
add(438, r'''
#include <stdio.h>

int main(void)
{
    int rows = 5;
    for (int i = 1; i <= rows; i++) {
        printf("%*s", (rows - i) * 2, "");
        for (int j = 1; j <= i; j++) {
            printf("%d ", j);
        }
        for (int j = i - 1; j >= 1; j--) {
            printf("%d ", j);
        }
        printf("\n");
    }
    return 0;
}
''')
add(439, r'''
#include <stdio.h>

int main(void)
{
    int rows = 6;
    for (int i = 1; i <= rows; i++) {
        for (int j = 1; j <= i; j++) {
            /* 1 when row and column have the same parity, else 0 */
            printf("%d ", (i % 2 == j % 2) ? 1 : 0);
        }
        printf("\n");
    }
    return 0;
}
''')
add(440, r'''
#include <stdio.h>

int main(void)
{
    int n = 5;
    for (int i = 1; i <= 2 * n - 1; i++) {
        int k = (i <= n) ? i : 2 * n - i;
        printf("%*s", (n - k) * 2, "");
        for (int j = 1; j <= k; j++) {
            printf("%d ", j);
        }
        for (int j = k - 1; j >= 1; j--) {
            printf("%d ", j);
        }
        printf("\n");
    }
    return 0;
}
''')
add(441, r'''
#include <stdio.h>

int main(void)
{
    int rows = 5, cols = 9;
    for (int r = 0; r < rows; r++) {
        for (int c = 0; c < cols; c++) {
            printf("%c ", ((r + c) % 2 == 0) ? '*' : '+');
        }
        printf("\n");
    }
    return 0;
}
''')
add(442, r'''
#include <stdio.h>

int main(void)
{
    int size;
    printf("Enter the side length of the square: ");
    scanf("%d", &size);
    for (int r = 0; r < size; r++) {
        for (int c = 0; c < size; c++) {
            printf("* ");
        }
        printf("\n");
    }
    return 0;
}
''', "6")
add(443, r'''
#include <stdio.h>

/* Prints a hollow square of the given size. */
void print_hollow_square(int size)
{
    for (int r = 0; r < size; r++) {
        for (int c = 0; c < size; c++) {
            if (r == 0 || r == size - 1 || c == 0 || c == size - 1) {
                printf("* ");
            } else {
                printf("  ");
            }
        }
        printf("\n");
    }
}

int main(void)
{
    printf("Hollow square of size 7:\n");
    print_hollow_square(7);
    return 0;
}
''')
add(444, r'''
#include <stdio.h>

int main(void)
{
    int rows;
    printf("Enter the number of rows (1-20): ");
    if (scanf("%d", &rows) != 1) {
        printf("Error: input is not a number.\n");
        return 0;
    }
    if (rows < 1 || rows > 20) {
        printf("Error: rows must be between 1 and 20.\n");
        return 0;
    }
    for (int i = 1; i <= rows; i++) {
        for (int j = 1; j <= i; j++) {
            printf("* ");
        }
        printf("\n");
    }
    return 0;
}
''', "5")
add(445, r'''
#include <stdio.h>

int main(void)
{
    int tests[3] = {3, 5, 1};
    for (int t = 0; t < 3; t++) {
        printf("Test %d: rows = %d\n", t + 1, tests[t]);
        for (int i = tests[t]; i >= 1; i--) {
            for (int j = 1; j <= i; j++) {
                printf("* ");
            }
            printf("\n");
        }
    }
    return 0;
}
''')
add(446, r'''
#include <stdio.h>

int main(void)
{
    int rows = 6;
    /* Row i prints the numbers 1..i, so each row is one number longer. */
    for (int i = 1; i <= rows; i++) {
        /* inner loop counts from 1 up to the current row number */
        for (int j = 1; j <= i; j++) {
            printf("%d ", j);
        }
        printf("\n");
    }
    return 0;
}
''')
add(447, r'''
#include <stdio.h>

static void inverted_triangle(int rows)
{
    if (rows <= 0) {
        printf("(rows = %d: nothing to print)\n", rows);
        return;
    }
    for (int i = rows; i >= 1; i--) {
        for (int j = 1; j <= i; j++) {
            printf("%d ", j);
        }
        printf("\n");
    }
}

int main(void)
{
    int cases[4] = {-2, 0, 1, 4};   /* negative, zero, minimum, normal */
    for (int k = 0; k < 4; k++) {
        printf("Case rows=%d\n", cases[k]);
        inverted_triangle(cases[k]);
    }
    return 0;
}
''')
add(448, r'''
#include <stdio.h>

int main(void)
{
    int choice, rows;
    do {
        printf("\n1. Print pyramid\n2. Exit\nEnter choice: ");
        if (scanf("%d", &choice) != 1) {
            printf("Error: invalid choice.\n");
            break;
        }
        if (choice == 1) {
            printf("Enter rows: ");
            if (scanf("%d", &rows) != 1 || rows < 1) {
                printf("Error: invalid rows.\n");
                break;
            }
            for (int i = 1; i <= rows; i++) {
                printf("%*s", rows - i, "");
                for (int j = 0; j < 2 * i - 1; j++) {
                    printf("*");
                }
                printf("\n");
            }
        } else if (choice != 2) {
            printf("Unknown choice, try again.\n");
        }
    } while (choice != 2);
    printf("Goodbye!\n");
    return 0;
}
''', "1\n4\n7\n1\n2\n2\n")
add(449, r'''
#include <stdio.h>

int main(void)
{
    int rows = 4;
    for (int i = rows; i >= 1; i--) {
        int spaces = rows - i;
        int stars = 2 * i - 1;
        printf("Row %d: spaces=%d stars=%d -> ", rows - i + 1, spaces, stars);
        printf("%*s", spaces, "");
        for (int j = 0; j < stars; j++) {
            printf("*");
        }
        printf("\n");
    }
    return 0;
}
''')
add(450, r'''
#include <stdio.h>

int main(void)
{
    int n = 5;
    /* one loop over all 2n-1 rows instead of writing each row by hand */
    for (int row = 1; row <= 2 * n - 1; row++) {
        int stars_half = (row <= n) ? row : 2 * n - row;
        printf("%*s", n - stars_half, "");
        for (int j = 0; j < 2 * stars_half - 1; j++) {
            printf("*");
        }
        printf("\n");
    }
    return 0;
}
''')
